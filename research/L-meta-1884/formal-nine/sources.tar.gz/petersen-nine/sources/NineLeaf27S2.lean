import NinePin27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5767 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6748]
theorem b4_5767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5767 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5772 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6748]
theorem b4_5772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5772 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5775 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6172,w6300,w6588]
theorem b4_5775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5775 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_5775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6172,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6172 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5779 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6748]
theorem b4_5779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5779 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_5779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5780 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6182,w6300,w6588]
theorem b4_5780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5780 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_5780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6182,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6182 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5784 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_5784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5784 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_5784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6237,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6237 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5788 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6748]
theorem b4_5788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5788 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6436,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5790 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6459,w6588]
theorem b4_5790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5790 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_5790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6459,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6459 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5794 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6748]
theorem b4_5794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5794 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_5794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5795 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6466,w6588]
theorem b4_5795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5795 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_5795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6466,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6466 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5799 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_5799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5799 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_5799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6499,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6499 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5803 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6515,w6588]
theorem b4_5803 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5803 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_5803 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6515,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6515 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5807 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6748]
theorem b4_5807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5807 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_5807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5808 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6524,w6588]
theorem b4_5808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5808 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_5808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6524,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6524 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5812 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_5812 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5812 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true))] s4_5812 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6553,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6553 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5829 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6807]
theorem b4_5829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5829 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s4_5829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6807] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6807 rfl))))))))))) (by decide +kernel)
def s4_5830 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6813]
theorem b4_5830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5830 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s4_5830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6813] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6813 rfl))))))))))) (by decide +kernel)
def s4_5831 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6821]
theorem b4_5831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5831 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(0,true))] s4_5831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6821] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6821 rfl))))))))))) (by decide +kernel)
def s4_5832 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6852]
theorem b4_5832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5832 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_5832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6852] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6852 rfl))))))))))) (by decide +kernel)
def s4_5833 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6857]
theorem b4_5833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5833 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(1,true))] s4_5833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6857] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6857 rfl))))))))))) (by decide +kernel)
def s4_5834 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6859]
theorem b4_5834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5834 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_5834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6859] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6859 rfl))))))))))) (by decide +kernel)
def s4_5835 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6890]
theorem b4_5835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5835 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_5835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6890] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6890 rfl))))))))))) (by decide +kernel)
def s4_5836 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6895]
theorem b4_5836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5836 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_5836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6895] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6895 rfl))))))))))) (by decide +kernel)
def s4_5837 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6897]
theorem b4_5837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5837 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_5837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748,v27_6897] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 (PetersenWireProjection.cons pc27_6897 rfl))))))))))) (by decide +kernel)
def s4_5854 : List (BitVec 512) := [w1119,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6748]
theorem b4_5854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5854 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5855 : List (BitVec 512) := [w1119,w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_5855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5855 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true))] s4_5855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_6101,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5881 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5618,w5956,w6101,w6300,w6588]
theorem b4_5881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5881 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5618,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5618 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5885 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_5885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5885 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5769,v27_5956,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5769 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s4_5886 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6748]
theorem b4_5886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5886 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5769,v27_5956,v27_6300,v27_6720,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5769 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5887 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6101,w6300,w6588]
theorem b4_5887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5887 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5898 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6096,w6101,w6300,w6588]
theorem b4_5898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5898 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6096,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6096 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5910 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6321,w6588]
theorem b4_5910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5910 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6321,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6321 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5913 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6436,w6588]
theorem b4_5913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5913 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5931 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6690,w6748]
theorem b4_5931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5931 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5932 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b4_5932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5932 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl)))))))))) (by decide +kernel)
def s4_5933 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720,w6748]
theorem b4_5933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5933 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6720,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5934 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6748]
theorem b4_5934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5934 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s4_5939 : List (BitVec 512) := [w1119,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6748]
theorem b4_5939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5939 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6389,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5940 : List (BitVec 512) := [w1119,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_5940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5940 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s4_5940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6389,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5945 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_5945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5945 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5698,v27_5956,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5698 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s4_5946 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6748]
theorem b4_5946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5946 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5698,v27_5956,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5698 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5947 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b4_5947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5947 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5949 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b4_5949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5949 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6061,v27_6300,v27_6690] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 rfl)))))))))) (by decide +kernel)
def s4_5950 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6748]
theorem b4_5950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5950 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6061,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6061 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_5951 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6389,w6588]
theorem b4_5951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5951 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_5952 : List (BitVec 512) := [w1119,w3766,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b4_5952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5952 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_5952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_8220 : List (BitVec 512) := [w1328,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8220 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(1,true))] s4_8220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1328,v27_1599,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1328 (PetersenWireProjection.cons pc27_1599 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_8223 : List (BitVec 512) := [w1328,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8223 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(1,true))] s4_8223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1328,v27_1832,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1328 (PetersenWireProjection.cons pc27_1832 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_8328 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b4_8328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8328 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,false),(1,true))] s4_8328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1328,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1328 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_12318 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4892,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12318 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s4_12318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_2468,v27_3766,v27_4344,v27_4716,v27_4892,v27_4926,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4892 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_12324 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4917,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12324 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s4_12324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_2468,v27_3766,v27_4344,v27_4716,v27_4917,v27_4926,v27_5135,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_2468 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_15040 : List (BitVec 512) := [w3766,w4136,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_15040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15040 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_15040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4136,v27_4344,v27_4716,v27_5135,v27_5393,v27_5769,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4136 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5769 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_15830 : List (BitVec 512) := [w3766,w4344,w4345,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15830 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_15830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4345,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4345 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_15831 : List (BitVec 512) := [w3766,w4344,w4345,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_15831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15831 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_15831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4345,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6895] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4345 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6895 rfl))))))))))) (by decide +kernel)
def s4_16226 : List (BitVec 512) := [w3766,w4344,w4437,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_16226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16226 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_16226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4437,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6225,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4437 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6225 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16227 : List (BitVec 512) := [w3766,w4344,w4437,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16227 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4437,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4437 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_16956 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16956 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16957 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_16957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16957 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s4_16957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5135,v27_5393,v27_5585,v27_5956,v27_6237,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6237 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16958 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_16958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16958 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16960 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_16960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16960 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6748] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s4_16962 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16962 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(1,true))] s4_16962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_16966 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_16966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16966 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4916,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4916 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_16968 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_16968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16968 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(1,true))] s4_16968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4916,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4916 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_16970 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_16970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16970 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_16970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4917,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
end NineCert
