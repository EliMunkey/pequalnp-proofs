import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12100 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12100 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12101 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12101 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12102 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12102 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12103 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12103 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12104 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12104 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12105 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12105 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12106 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12106 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12107 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12107 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12108 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12108 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12109 : List (BitVec 512) := [w2468,w3766,w3929,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12109 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_3929,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12237 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4602,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12237 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12238 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4634,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12238 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4634,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4634 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12240 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w4814,w5135,w5585,w5956,w6300,w6588]
theorem b4_12240 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12240 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12240 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12243 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5203,w5585,w5956,w6300,w6588]
theorem b4_12243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12243 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12250 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5675,w5956,w6300,w6588]
theorem b4_12250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12250 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12257 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6048,w6300,w6588]
theorem b4_12257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12257 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12264 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6377,w6588]
theorem b4_12264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12264 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12270 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12270 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12275 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588,w6667]
theorem b4_12275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12275 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_12288 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12288 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12288 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12288 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12289 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12289 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12289 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12289 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12290 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12290 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12290 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12290 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12291 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12291 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12291 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12291 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12292 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12292 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12292 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12292 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12293 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12293 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12293 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12293 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12294 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12294 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12294 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(9,true))] s4_12294 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_12295 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12295 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12296 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12296 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_12297 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12297 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12297 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12297 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_12298 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12298 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12299 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12299 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12300 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12300 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12301 : List (BitVec 512) := [w2468,w3766,w4344,w4602,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12301 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12302 : List (BitVec 512) := [w2468,w3766,w4344,w4634,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12302 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4634,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4634 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12303 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12303 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12304 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12304 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12305 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12305 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12305 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12305 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12306 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12306 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12307 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12307 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12308 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12308 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12309 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12309 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(9,true))] s4_12309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_12310 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12310 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12310 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12310 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12311 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12311 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_12312 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12312 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_12313 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12313 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12314 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12314 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12315 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12315 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12316 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4814,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12316 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12317 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4864,w5135,w5585,w5956,w6300,w6588]
theorem b4_12317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12317 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4864,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4864 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12328 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w4966,w5135,w5585,w5956,w6300,w6588]
theorem b4_12328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12328 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12329 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5203,w5585,w5956,w6300,w6588]
theorem b4_12329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12329 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12338 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6048,w6300,w6588]
theorem b4_12338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12338 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12345 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12345 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12346 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6538,w6588]
theorem b4_12346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12346 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12355 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4966,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12355 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12356 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4966,w5135,w5585,w5956,w6300,w6588]
theorem b4_12356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12357 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5203,w5585,w5698,w5956,w6300,w6588]
theorem b4_12357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12357 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12358 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5203,w5585,w5769,w5956,w6300,w6588]
theorem b4_12358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12358 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12359 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6300,w6543,w6588]
theorem b4_12359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12359 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12360 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5203,w5585,w5956,w6389,w6522,w6588]
theorem b4_12360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12398 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5730,w5956,w6300,w6588]
theorem b4_12398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12398 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5730,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12405 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6048,w6300,w6588]
theorem b4_12405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12405 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12412 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b4_12412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12412 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12413 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6538,w6588]
theorem b4_12413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12413 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
