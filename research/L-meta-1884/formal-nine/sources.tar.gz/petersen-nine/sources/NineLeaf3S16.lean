import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4292 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b3_4292 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4292 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s3_4292 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4293 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b3_4293 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4293 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(8,true),(7,true))] s3_4293 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4294 : List (BitVec 512) := [w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6890]
theorem b3_4294 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4294 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4294 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s3_4295 : List (BitVec 512) := [w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b3_4295 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4295 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4295 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl)))))))))) (by decide +kernel)
def s3_4296 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_4296 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4296 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_4296 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4297 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6895]
theorem b3_4297 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4297 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s3_4297 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_4298 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4298 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4298 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4298 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4299 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_4299 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4299 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_4299 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s3_4300 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720,w6895]
theorem b3_4300 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4300 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false))] s3_4300 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_4301 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4301 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4301 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4302 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6895]
theorem b3_4302 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4302 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s3_4302 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_4303 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b3_4303 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4303 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s3_4303 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s3_4304 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4304 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4304 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_4304 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4305 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6904]
theorem b3_4305 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4305 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_4305 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_4306 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4306 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4306 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4306 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4307 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4307 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4307 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4307 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4308 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6904]
theorem b3_4308 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4308 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s3_4308 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_4309 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b3_4309 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_4309 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
def s3_4310 : List (BitVec 512) := [w3766,w4344,w4376,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4310 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4310 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true))] s3_4310 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4376,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4376 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4311 : List (BitVec 512) := [w3766,w4344,w4382,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4311 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false))] s3_4311 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4382,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4382 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4314 : List (BitVec 512) := [w3766,w4344,w4394,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4314 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4314 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(7,true))] s3_4314 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4394,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4394 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4319 : List (BitVec 512) := [w3766,w4344,w4405,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_4319 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_4319 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4320 : List (BitVec 512) := [w3766,w4344,w4405,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4320 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4320 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_4320 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4324 : List (BitVec 512) := [w3766,w4344,w4464,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4324 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(5,true))] s3_4324 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4464,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4464 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4325 : List (BitVec 512) := [w3766,w4344,w4471,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4325 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4325 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,false))] s3_4325 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4471,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4471 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4328 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_4328 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4328 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false))] s3_4328 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4329 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4329 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4329 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false))] s3_4329 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4332 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4332 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true))] s3_4332 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4333 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_4333 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4333 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true))] s3_4333 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_4338 : List (BitVec 512) := [w3766,w4344,w4528,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4338 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true))] s3_4338 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4528,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4528 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4341 : List (BitVec 512) := [w3766,w4344,w4547,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_4341 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4341 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false))] s3_4341 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4547,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4547 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4342 : List (BitVec 512) := [w3766,w4344,w4547,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4342 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4342 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false))] s3_4342 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4547,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4547 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4612 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_4612 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4612 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4612 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4613 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_4613 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4613 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4613 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4614 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6136,w6300,w6588]
theorem b3_4614 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4614 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4614 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4615 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6179,w6300,w6588]
theorem b3_4615 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4615 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_4615 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4616 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_4616 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4616 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s3_4616 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4617 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_4617 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4617 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_4617 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4618 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6436,w6588]
theorem b3_4618 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4618 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_4618 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4619 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6464,w6588]
theorem b3_4619 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4619 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_4619 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4620 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b3_4620 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4620 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s3_4620 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4621 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_4621 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4621 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4621 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4622 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_4622 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4622 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_4622 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_4623 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6748]
theorem b3_4623 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4623 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_4623 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))))) (by decide +kernel)
def s3_4624 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6785]
theorem b3_4624 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4624 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_4624 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_4625 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6807]
theorem b3_4625 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4625 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s3_4625 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl)))))))))))) (by decide +kernel)
def s3_4626 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6832]
theorem b3_4626 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4626 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_4626 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_4627 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_4627 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4627 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4627 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4628 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_4628 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4628 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4628 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5769,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4629 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_4629 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4629 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4629 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4633 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_4633 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4633 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4633 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4638 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_4638 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4638 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_4638 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_4647 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6061,w6300,w6588]
theorem b3_4647 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4647 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4647 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4652 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b3_4652 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4652 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4652 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4667 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b3_4667 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4667 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4667 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4668 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6588]
theorem b3_4668 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4668 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_4668 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4669 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6061,w6300,w6436,w6588]
theorem b3_4669 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4669 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_4669 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4670 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b3_4670 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4670 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_4670 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4671 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6873]
theorem b3_4671 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4671 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4671 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4672 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_4672 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4672 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4672 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4675 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b3_4675 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4675 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_4675 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4701 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b3_4701 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4701 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_4701 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4711 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_4711 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4711 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_4711 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4719 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b3_4719 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4719 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_4719 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
