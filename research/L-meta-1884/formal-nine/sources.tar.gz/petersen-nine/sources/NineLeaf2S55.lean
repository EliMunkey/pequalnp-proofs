import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4726 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4726 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4726 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_4726 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4729 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5802,w5956,w6300,w6588]
theorem b5_4729 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4729 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s5_4729 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5802,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5802 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4735 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6231,w6300,w6588]
theorem b5_4735 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4735 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,false))] s5_4735 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6231,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6231 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4739 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6495,w6588]
theorem b5_4739 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4739 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(4,true),(0,false))] s5_4739 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6495,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6495 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4751 : List (BitVec 512) := [w2498,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4751 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4751 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(2,false),(0,false))] s5_4751 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2498,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2498 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4754 : List (BitVec 512) := [w2518,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4754 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4754 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_4754 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2518,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2518 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4755 : List (BitVec 512) := [w2523,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4755 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4755 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(0,false),(9,true)),(false,(2,false),(0,false))] s5_4755 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2523,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2523 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5244 : List (BitVec 512) := [w3766,w4072,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_5244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5244 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(3,true))] s5_5244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4072,v2_4344,v2_4716,v2_5135,v2_5471,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4072 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5471 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5521 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5884,w6179,w6300,w6832]
theorem b5_5521 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5521 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true)),(false,(1,true),(4,true))] s5_5521 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4403,v2_4716,v2_5135,v2_5393,v2_5884,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4403 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_5666 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6117,w6300,w6588]
theorem b5_5666 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5666 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(7,true)),(false,(1,false),(3,true))] s5_5666 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6117,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6117 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5667 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6188,w6300,w6588]
theorem b5_5667 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5667 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(3,true))] s5_5667 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6188,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6188 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5779 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w6179,w6522,w6785,w6873]
theorem b5_5779 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5779 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_5779 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_6179,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_5780 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5485,w5585,w6179,w6300,w6832]
theorem b5_5780 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5780 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true)),(false,(1,true),(4,true))] s5_5780 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5485,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5485 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_5781 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5496,w5585,w6179,w6522,w6588]
theorem b5_5781 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5781 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(4,true))] s5_5781 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5496,v2_5585,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5496 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5782 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5522,w5585,w5956,w6300,w6588]
theorem b5_5782 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5782 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false))] s5_5782 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5522,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5522 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5783 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5523,w5585,w5956,w6300,w6588]
theorem b5_5783 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5783 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_5783 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5523,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5523 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5784 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5524,w5585,w5956,w6300,w6588]
theorem b5_5784 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5784 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_5784 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5524,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5524 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5785 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5525,w5585,w5956,w6300,w6588]
theorem b5_5785 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5785 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false))] s5_5785 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5525,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5525 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5786 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5526,w5585,w5956,w6300,w6588]
theorem b5_5786 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5786 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_5786 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5526,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5526 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5787 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5527,w5585,w5956,w6300,w6588]
theorem b5_5787 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5787 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_5787 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5527,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5527 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5806 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5750,w6158,w6522,w6588]
theorem b5_5806 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5806 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true)),(false,(6,true),(5,true))] s5_5806 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5750,v2_6158,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5750 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5877 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5891,w5956,w6522,w6588]
theorem b5_5877 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true)),(false,(6,true),(5,true))] s5_5877 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5891,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5891 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5878 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5895,w5956,w6300,w6588]
theorem b5_5878 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5878 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_5878 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5895,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5895 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5879 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5896,w5956,w6300,w6588]
theorem b5_5879 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5879 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_5879 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5896,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5896 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5880 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5897,w5956,w6300,w6588]
theorem b5_5880 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5880 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_5880 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5897,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5897 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5881 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5898,w5956,w6300,w6588]
theorem b5_5881 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5881 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_5881 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5898,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5898 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5882 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5899,w5956,w6300,w6588]
theorem b5_5882 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5882 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_5882 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5899,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5899 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5883 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5900,w5956,w6300,w6588]
theorem b5_5883 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5883 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_5883 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5900,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5900 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5884 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5901,w5956,w6300,w6588]
theorem b5_5884 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5884 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_5884 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5901,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5901 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5885 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5902,w5956,w6300,w6588]
theorem b5_5885 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5885 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s5_5885 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5902,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5902 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_5921 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6591,w6767]
theorem b5_5921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5921 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(10,true))] s5_5921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6591,v2_6767] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6591 (PetersenWireProjection.cons pc2_6767 rfl)))))))))) (by decide +kernel)
def s5_6028 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6767,w6873]
theorem b5_6028 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6028 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6028 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6321,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6321 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6031 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6330,w6767,w6873]
theorem b5_6031 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6031 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6031 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6330,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6330 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6034 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6331,w6767,w6873]
theorem b5_6034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6034 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6331,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6331 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6037 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6333,w6767,w6873]
theorem b5_6037 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6037 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6037 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6333,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6333 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6041 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6334,w6767,w6873]
theorem b5_6041 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6041 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6041 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6334,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6334 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6044 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6336,w6767,w6873]
theorem b5_6044 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6044 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6044 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6336,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6336 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6047 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6365,w6767,w6873]
theorem b5_6047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6047 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(9,true),(5,true)),(false,(1,true),(6,true))] s5_6047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6365,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6365 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6050 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6372,w6767,w6873]
theorem b5_6050 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6050 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(5,true),(9,true)),(false,(1,true),(6,true))] s5_6050 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6372,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6372 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6063 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6829,w6873]
theorem b5_6063 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6063 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(1,false),(8,true)),(false,(6,true),(10,true))] s5_6063 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6829,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6829 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6072 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5981,w6300,w6767,w6832]
theorem b5_6072 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6072 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_6072 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5981,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5981 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6074 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5992,w6300,w6767,w6832]
theorem b5_6074 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6074 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_6074 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5992,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5992 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6076 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6300,w6767,w6832]
theorem b5_6076 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6076 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_6076 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5993,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5993 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6078 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6451,w6522,w6588]
theorem b5_6078 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6078 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(5,true))] s5_6078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5993,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5993 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6082 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5995,w6300,w6767,w6832]
theorem b5_6082 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6082 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(2,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_6082 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5995,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5995 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6084 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5996,w6300,w6767,w6832]
theorem b5_6084 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6084 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_6084 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5996,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5996 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6086 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5998,w6300,w6767,w6832]
theorem b5_6086 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6086 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_6086 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5998,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5998 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_6088 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6002,w6451,w6522,w6588]
theorem b5_6088 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6088 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_6088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6002,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6002 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6091 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6003,w6451,w6522,w6588]
theorem b5_6091 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6091 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_6091 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6003,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6003 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6094 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6004,w6451,w6522,w6588]
theorem b5_6094 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6094 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_6094 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6004,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6004 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6096 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6006,w6451,w6522,w6588]
theorem b5_6096 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6096 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_6096 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6006,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6006 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6110 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6902]
theorem b5_6110 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6110 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,false),(9,true)),(false,(6,true),(5,true))] s5_6110 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588,v2_6902] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6902 rfl)))))))))) (by decide +kernel)
def s5_6115 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6827,w6873]
theorem b5_6115 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6115 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(4,true),(5,true)),(false,(10,true),(6,true))] s5_6115 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6827,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6827 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6117 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6522,w6720,w6890]
theorem b5_6117 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6117 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(5,true),(4,true)),(false,(10,true),(1,false))] s5_6117 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6720,v2_6890] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_6118 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6522,w6813,w6873]
theorem b5_6118 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6118 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(1,false),(8,true)),(false,(6,true),(10,true))] s5_6118 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6119 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6163,w6522,w6588,w6890]
theorem b5_6119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6119 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,false),(9,true)),(false,(6,true),(5,true))] s5_6119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6163,v2_6522,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6163 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_6120 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6163,w6522,w6785,w6873]
theorem b5_6120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6120 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(4,true),(5,true)),(false,(10,true),(6,true))] s5_6120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6163,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6163 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6129 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6782,w6873]
theorem b5_6129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6129 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(4,true),(5,true)),(false,(6,true),(10,true))] s5_6129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6522,v2_6782,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6133 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6522,w6767,w6873]
theorem b5_6133 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6133 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_6133 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6225,v2_6522,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6135 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6246,w6522,w6720,w6873]
theorem b5_6135 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6135 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(4,true),(5,true)),(false,(6,true),(10,true))] s5_6135 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6246,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6136 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6767,w6908]
theorem b5_6136 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6136 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(1,false),(5,true)),(false,(8,true),(5,true))] s5_6136 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6300,v2_6767,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6908 rfl)))))))))) (by decide +kernel)
def s5_6138 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6522,w6767,w6873]
theorem b5_6138 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6138 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true)),(false,(5,true),(8,true))] s5_6138 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6522,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6147 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6829,w6873]
theorem b5_6147 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6147 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true)),(false,(8,true),(6,true))] s5_6147 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6464,v2_6829,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6829 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6151 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5894,w5956,w6464,w6813,w6873]
theorem b5_6151 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6151 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true)),(false,(8,true),(6,true))] s5_6151 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5894,v2_5956,v2_6464,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
end NineCert
