import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11848 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6604]
theorem b4_11848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11848 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_11848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6604] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6604 rfl))))))))))) (by decide +kernel)
def s4_11849 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6631]
theorem b4_11849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11849 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_11849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6631] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6631 rfl))))))))))) (by decide +kernel)
def s4_11850 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6654]
theorem b4_11850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11850 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,true),(2,true)),(false,(0,true),(9,true))] s4_11850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6654] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6654 rfl))))))))))) (by decide +kernel)
def s4_11851 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_11851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11851 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(1,false),(3,true))] s4_11851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6807] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6807 rfl))))))))))) (by decide +kernel)
def s4_11852 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_11852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11852 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(0,false),(3,true))] s4_11852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6859] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6859 rfl))))))))))) (by decide +kernel)
def s4_11853 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_11853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11853 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(1,false),(0,false))] s4_11853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6869] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6869 rfl))))))))))) (by decide +kernel)
def s4_11854 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_11854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11854 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,false),(9,true))] s4_11854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_11855 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_11855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11855 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(9,true))] s4_11855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6904] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6904 rfl))))))))))) (by decide +kernel)
def s4_11856 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_11856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11856 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(0,false),(9,true))] s4_11856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6912] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6912 rfl))))))))))) (by decide +kernel)
def s4_11857 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_11857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11857 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(9,true),(3,true))] s4_11857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6857] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11858 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_11858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11858 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(9,true),(5,true))] s4_11858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11859 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_11859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11859 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(5,true),(3,true))] s4_11859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11860 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_11860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11860 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(5,true),(9,true))] s4_11860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11861 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6300,w6549,w6588]
theorem b4_11861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11861 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(4,true),(3,true))] s4_11861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11862 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_11862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11862 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(1,false))] s4_11862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11863 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_11863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11863 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_11863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11864 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_11864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11864 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_11864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11865 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6136,w6300,w6522,w6588]
theorem b4_11865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11865 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(2,true)),(false,(5,true),(4,true))] s4_11865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6136,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11866 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_11866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11866 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(4,true))] s4_11866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6225,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11867 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6543,w6588]
theorem b4_11867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11867 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(4,true),(8,true))] s4_11867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11868 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6567,w6588]
theorem b4_11868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11868 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true))] s4_11868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11869 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588,w6690]
theorem b4_11869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11869 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(4,true),(8,true))] s4_11869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11870 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588,w6785]
theorem b4_11870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11870 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(4,true),(5,true))] s4_11870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11871 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588,w6857]
theorem b4_11871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11871 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(4,true),(5,true))] s4_11871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11872 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588,w6908]
theorem b4_11872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11872 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(4,true),(8,true))] s4_11872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_11873 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6389,w6522,w6588]
theorem b4_11873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_11873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11874 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_11874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_11874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s4_11875 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_11875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11875 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(7,true),(0,false))] s4_11875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11876 : List (BitVec 512) := [w2410,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_11876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11876 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(8,true),(3,true))] s4_11876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11877 : List (BitVec 512) := [w2410,w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_11877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true))] s4_11877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11878 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6748]
theorem b4_11878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11878 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(3,true)),(false,(8,true),(1,false))] s4_11878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11879 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6690,w6720]
theorem b4_11879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11879 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s4_11879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11880 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720,w6873]
theorem b4_11880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11880 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(3,true)),(false,(8,true),(9,true))] s4_11880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11881 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_11881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11881 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(9,true),(8,true))] s4_11881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11882 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6549,w6588,w6720]
theorem b4_11882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11882 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(8,true),(9,true))] s4_11882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11883 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_11883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11883 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true))] s4_11883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11884 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6720]
theorem b4_11884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11884 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true))] s4_11884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11885 : List (BitVec 512) := [w2410,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_11885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11885 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(3,true)),(false,(3,true),(5,true))] s4_11885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11886 : List (BitVec 512) := [w2410,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6690]
theorem b4_11886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11886 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(3,true),(9,true))] s4_11886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11887 : List (BitVec 512) := [w2410,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6690]
theorem b4_11887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11887 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(3,true)),(false,(3,true),(4,true))] s4_11887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11888 : List (BitVec 512) := [w2410,w3766,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b4_11888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11888 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(8,true),(3,true))] s4_11888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11889 : List (BitVec 512) := [w2410,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11889 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_11889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3901,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11890 : List (BitVec 512) := [w2410,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11890 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_11890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3901,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11891 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11891 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(4,true))] s4_11891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11892 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11892 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(8,true))] s4_11892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11893 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_11893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11893 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(3,true))] s4_11893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11894 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11894 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(7,true),(0,false))] s4_11894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11895 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_11895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11895 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(1,false),(5,true))] s4_11895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11896 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_11896 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11896 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(0,false),(3,true))] s4_11896 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11897 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_11897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11897 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(8,true))] s4_11897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11898 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_11898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11898 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(1,false),(3,true))] s4_11898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11899 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11899 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_11899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11900 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_11900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11900 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(1,false),(4,true))] s4_11900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11901 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_11901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11901 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(0,false),(3,true))] s4_11901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11902 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_11902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11902 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(1,false),(8,true))] s4_11902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_11903 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_11903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11903 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(1,false),(3,true))] s4_11903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11904 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_11904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11904 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true))] s4_11904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6859] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6859 rfl))))))))))) (by decide +kernel)
def s4_11905 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_11905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11905 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(8,true))] s4_11905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11906 : List (BitVec 512) := [w2426,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_11906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11906 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(2,true)),(false,(5,true),(4,true))] s4_11906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11907 : List (BitVec 512) := [w2426,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6720]
theorem b4_11907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11907 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(2,true)),(false,(9,true),(8,true))] s4_11907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11908 : List (BitVec 512) := [w2426,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11908 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(3,true),(5,true))] s4_11908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11909 : List (BitVec 512) := [w2426,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6690]
theorem b4_11909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11909 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(9,true))] s4_11909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11910 : List (BitVec 512) := [w2431,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11910 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(1,false))] s4_11910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11911 : List (BitVec 512) := [w2431,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11911 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(1,false))] s4_11911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
