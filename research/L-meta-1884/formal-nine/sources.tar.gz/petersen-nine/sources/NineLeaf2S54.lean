import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3822 : List (BitVec 512) := [w2436,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3822 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3822 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(1,false),(9,true))] s5_3822 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3823 : List (BitVec 512) := [w2436,w3296,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3823 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3823 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false)),(false,(3,true),(0,true))] s5_3823 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3296,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3296 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3824 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3824 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3824 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_3824 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3825 : List (BitVec 512) := [w2444,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3825 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3825 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_3825 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2444,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2444 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3827 : List (BitVec 512) := [w2457,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3827 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3827 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(4,true),(0,false))] s5_3827 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3828 : List (BitVec 512) := [w2457,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3828 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3828 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(6,true),(2,false))] s5_3828 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3829 : List (BitVec 512) := [w2457,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3829 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3829 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(2,false))] s5_3829 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3830 : List (BitVec 512) := [w2457,w2698,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3830 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3830 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_3830 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_2698,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_2698 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3831 : List (BitVec 512) := [w2458,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3831 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3831 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(8,true)),(false,(0,false),(2,false))] s5_3831 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3832 : List (BitVec 512) := [w2458,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3832 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3832 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(6,true),(1,false))] s5_3832 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3833 : List (BitVec 512) := [w2458,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3833 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3833 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true)),(false,(9,true),(1,false))] s5_3833 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3303,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3834 : List (BitVec 512) := [w2458,w3306,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3834 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3834 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false)),(false,(3,true),(0,true))] s5_3834 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3306,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3306 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3835 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3835 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3835 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_3835 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3895 : List (BitVec 512) := [w2468,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3895 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3895 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_3895 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3903 : List (BitVec 512) := [w2468,w2701,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3903 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3903 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_3903 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_2701,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_2701 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4095 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4885,w5135,w5585,w5956,w6300,w6588]
theorem b5_4095 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4095 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_4095 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_4885,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4885 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4101 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4961,w5135,w5585,w5956,w6300,w6588]
theorem b5_4101 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4101 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_4101 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_4961,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4961 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4105 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5256,w5585,w5956,w6300,w6588]
theorem b5_4105 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4105 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_4105 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5256,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5256 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4107 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5264,w5585,w5956,w6300,w6588]
theorem b5_4107 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4107 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true))] s5_4107 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5264,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5264 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4108 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5265,w5585,w5956,w6300,w6588]
theorem b5_4108 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4108 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true))] s5_4108 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5265,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5265 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4111 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6588,w6890]
theorem b5_4111 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4111 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(0,false),(5,true))] s5_4111 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_4112 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6720,w6873]
theorem b5_4112 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4112 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(9,true),(5,true))] s5_4112 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_4113 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6785,w6873]
theorem b5_4113 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4113 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(6,true)),(false,(9,true),(5,true))] s5_4113 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_4114 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w6101,w6389,w6588]
theorem b5_4114 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4114 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true)),(false,(8,true),(4,true))] s5_4114 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_6101,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4115 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w6101,w6588,w6873]
theorem b5_4115 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4115 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(3,true)),(false,(9,true),(5,true))] s5_4115 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_6101,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_4118 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_4118 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4118 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_4118 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_4132 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5722,w5956,w6300,w6588]
theorem b5_4132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4132 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s5_4132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5722,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5722 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4137 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5799,w5956,w6300,w6588]
theorem b5_4137 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4137 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true))] s5_4137 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5799,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5799 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4138 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5800,w5956,w6300,w6588]
theorem b5_4138 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4138 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true))] s5_4138 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5800,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5800 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4179 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6145,w6300,w6588]
theorem b5_4179 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4179 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(8,true))] s5_4179 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6145,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6145 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4183 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6205,w6300,w6588]
theorem b5_4183 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4183 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(7,true))] s5_4183 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6205,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6205 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4184 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6231,w6300,w6588]
theorem b5_4184 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4184 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s5_4184 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6231,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6231 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4186 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6495,w6588]
theorem b5_4186 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4186 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s5_4186 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6495,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6495 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4257 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_4257 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4257 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_4257 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_4265 : List (BitVec 512) := [w2469,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4265 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s5_4265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2469,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2469 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4268 : List (BitVec 512) := [w2470,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4268 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4268 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s5_4268 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2470,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2470 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4271 : List (BitVec 512) := [w2471,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4271 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4271 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s5_4271 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2471,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2471 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4274 : List (BitVec 512) := [w2488,w2489,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4274 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4274 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s5_4274 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2489,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2489 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4275 : List (BitVec 512) := [w2488,w2490,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4275 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4275 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s5_4275 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2490,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2490 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4276 : List (BitVec 512) := [w2488,w2545,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4276 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4276 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(3,true),(0,false))] s5_4276 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2545,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2545 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4277 : List (BitVec 512) := [w2488,w2546,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4277 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4277 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s5_4277 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2546,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2546 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4279 : List (BitVec 512) := [w2488,w2893,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4279 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4279 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s5_4279 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2893,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2893 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4280 : List (BitVec 512) := [w2488,w2894,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4280 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4280 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s5_4280 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_2894,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_2894 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4288 : List (BitVec 512) := [w2488,w3312,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4288 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(7,true)),(false,(3,true),(0,true))] s5_4288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3312,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3312 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4408 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5289,w5585,w6101,w6300,w6588]
theorem b5_4408 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4408 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s5_4408 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5585,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4413 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5313,w5585,w6101,w6300,w6588]
theorem b5_4413 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4413 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s5_4413 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4563 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6080,w6101,w6300,w6588]
theorem b5_4563 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4563 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s5_4563 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6080,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4576 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_4576 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4576 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(1,false)),(false,(1,true),(7,true))] s5_4576 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4638 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w4887,w5135,w5585,w5956,w6300,w6588]
theorem b5_4638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_4638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_4887,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4887 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4641 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w4964,w5135,w5585,w5956,w6300,w6588]
theorem b5_4641 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4641 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_4641 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_4964,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4964 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4643 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5292,w5585,w5956,w6300,w6588]
theorem b5_4643 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4643 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_4643 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5292,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5292 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4644 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5317,w5585,w5956,w6300,w6588]
theorem b5_4644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4644 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false))] s5_4644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5317,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5317 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4645 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4645 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_4645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4652 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6145,w6300,w6588]
theorem b5_4652 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4652 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_4652 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6145,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6145 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4685 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5258,w5585,w5956,w6300,w6588]
theorem b5_4685 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4685 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(5,true))] s5_4685 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5258,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5258 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4686 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5295,w5585,w5956,w6300,w6588]
theorem b5_4686 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4686 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s5_4686 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5295,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5295 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4687 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5321,w5585,w5956,w6300,w6588]
theorem b5_4687 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4687 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(6,true)),(false,(1,false),(0,false))] s5_4687 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5321,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5321 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4688 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4688 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_4688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4690 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5725,w5956,w6300,w6588]
theorem b5_4690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4690 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(5,true))] s5_4690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5725,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5725 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4697 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6205,w6300,w6588]
theorem b5_4697 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4697 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s5_4697 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6205,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6205 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4722 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5268,w5585,w5956,w6300,w6588]
theorem b5_4722 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4722 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s5_4722 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5268,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5268 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4723 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5297,w5585,w5956,w6300,w6588]
theorem b5_4723 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4723 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,false))] s5_4723 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5297,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5297 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4724 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5309,w5585,w5956,w6300,w6588]
theorem b5_4724 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4724 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(4,true),(0,false))] s5_4724 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5309,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5309 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_4725 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5322,w5585,w5956,w6300,w6588]
theorem b5_4725 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4725 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s5_4725 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5322,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5322 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
