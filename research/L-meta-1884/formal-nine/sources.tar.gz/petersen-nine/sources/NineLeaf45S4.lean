import NinePin45
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_914 : List (BitVec 512) := [w628,w2681,w3766,w4344,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_914 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s5_914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2681,v45_3766,v45_4344,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2681 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_915 : List (BitVec 512) := [w628,w2702,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_915 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_915 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true)),(false,(5,true),(0,true))] s5_915 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2702,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2702 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_917 : List (BitVec 512) := [w628,w3258,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_917 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3258,v45_4344,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_921 : List (BitVec 512) := [w628,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_921 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_922 : List (BitVec 512) := [w628,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_922 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_922 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_922 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))) (by decide +kernel)
def s5_923 : List (BitVec 512) := [w628,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_923 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_923 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s5_923 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6720 rfl)))))))))) (by decide +kernel)
def s5_1623 : List (BitVec 512) := [w1061,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1623 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1623 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_1623 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1061,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1061 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2318 : List (BitVec 512) := [w1290,w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_2318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2318 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2319 : List (BitVec 512) := [w1290,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2319 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_2319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2320 : List (BitVec 512) := [w1290,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_2320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2320 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2321 : List (BitVec 512) := [w1291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2321 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2321 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2321 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1291,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1291 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2325 : List (BitVec 512) := [w1292,w1875,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2325 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2325 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(1,true))] s5_2325 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1875,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1875 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2326 : List (BitVec 512) := [w1292,w1883,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_2326 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2326 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(1,true))] s5_2326 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1883,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1883 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2327 : List (BitVec 512) := [w1292,w1895,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_2327 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2327 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(1,true))] s5_2327 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1895,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1895 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2329 : List (BitVec 512) := [w1292,w1912,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6807]
theorem b5_2329 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2329 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(1,true))] s5_2329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1912,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1912 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2330 : List (BitVec 512) := [w1292,w2140,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2330 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2330 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2140,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2140 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2332 : List (BitVec 512) := [w1292,w2164,w3258,w4344,w4716,w5135,w5393,w5956,w6300,w6807]
theorem b5_2332 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2332 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2332 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2333 : List (BitVec 512) := [w1292,w2164,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2333 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2333 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2333 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3258,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2335 : List (BitVec 512) := [w1292,w2164,w3321,w4344,w4716,w5135,w5393,w5956,w6300,w6807]
theorem b5_2335 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2335 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2335 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2336 : List (BitVec 512) := [w1292,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6389]
theorem b5_2336 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2336 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2336 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6389] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 rfl)))))))))) (by decide +kernel)
def s5_2337 : List (BitVec 512) := [w1292,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6890]
theorem b5_2337 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2337 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s5_2337 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6890] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6890 rfl)))))))))) (by decide +kernel)
def s5_2339 : List (BitVec 512) := [w1292,w2166,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6807]
theorem b5_2339 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2339 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s5_2339 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2166,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2166 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2340 : List (BitVec 512) := [w1292,w2166,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2340 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2340 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s5_2340 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2166,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2166 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2343 : List (BitVec 512) := [w1292,w2172,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6807]
theorem b5_2343 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2343 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s5_2343 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2172,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2172 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2344 : List (BitVec 512) := [w1292,w2172,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2344 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2344 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s5_2344 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2172,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2172 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2348 : List (BitVec 512) := [w1292,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2348 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2348 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_2348 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2468,v45_3258,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2352 : List (BitVec 512) := [w1292,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6807]
theorem b5_2352 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2352 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_2352 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2355 : List (BitVec 512) := [w1292,w2468,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6690]
theorem b5_2355 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2355 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_2355 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2468,v45_3766,v45_4716,v45_5135,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2358 : List (BitVec 512) := [w1292,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2358 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2358 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s5_2358 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2496,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2496 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2363 : List (BitVec 512) := [w1292,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6807]
theorem b5_2363 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2363 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true)),(false,(5,true),(0,true))] s5_2363 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2683,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2683 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2364 : List (BitVec 512) := [w1292,w2683,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2364 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2364 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true)),(false,(5,true),(0,true))] s5_2364 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2683,v45_3766,v45_4716,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2683 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2366 : List (BitVec 512) := [w1292,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6807]
theorem b5_2366 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2366 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s5_2366 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2686,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2686 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2368 : List (BitVec 512) := [w1292,w2687,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6807]
theorem b5_2368 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2368 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s5_2368 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2687,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2687 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2371 : List (BitVec 512) := [w1292,w2837,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2371 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2371 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(0,true))] s5_2371 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2837,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2837 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2373 : List (BitVec 512) := [w1292,w3177,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_2373 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2373 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s5_2373 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3177,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3177 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2376 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b5_2376 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2376 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2376 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2377 : List (BitVec 512) := [w1292,w3258,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_2377 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2377 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s5_2377 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2379 : List (BitVec 512) := [w1292,w3258,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_2379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2379 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2380 : List (BitVec 512) := [w1292,w3258,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_2380 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2380 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2380 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3258,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2383 : List (BitVec 512) := [w1292,w3321,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b5_2383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2383 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_2383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3321,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3321 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2396 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6807]
theorem b5_2396 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2396 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s5_2396 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6522,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2403 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6807]
theorem b5_2403 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2403 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(3,true)),(false,(0,true),(3,true))] s5_2403 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5470,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5470 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_2405 : List (BitVec 512) := [w1292,w3766,w4716,w4793,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2405 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2405 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s5_2405 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_4793,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_4793 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2407 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6690]
theorem b5_2407 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2407 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(0,true))] s5_2407 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6225,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6225 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2408 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6690]
theorem b5_2408 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2408 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s5_2408 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6522,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2409 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_2409 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2409 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s5_2409 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6389,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2410 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5470,w5585,w5698,w5956,w6300,w6690]
theorem b5_2410 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2410 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(3,true)),(false,(0,true),(3,true))] s5_2410 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5470,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5470 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2411 : List (BitVec 512) := [w1292,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6690]
theorem b5_2411 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2411 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s5_2411 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6422,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2412 : List (BitVec 512) := [w1292,w3766,w5135,w5393,w5698,w5769,w5956,w6389,w6422,w6588]
theorem b5_2412 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2412 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(0,true))] s5_2412 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6389,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_2612 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6663]
theorem b5_2612 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2612 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(5,true))] s5_2612 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1328,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6663] (PetersenWireProjection.cons pc45_1328 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6663 rfl)))))))))) (by decide +kernel)
def s5_2617 : List (BitVec 512) := [w1328,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2617 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2617 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(5,true))] s5_2617 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1328,v45_3258,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1328 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_2883 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6663]
theorem b5_2883 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2883 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s5_2883 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1384,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6663] (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6663 rfl)))))))))) (by decide +kernel)
def s5_2889 : List (BitVec 512) := [w1384,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2889 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2889 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s5_2889 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1384,v45_3258,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_3256 : List (BitVec 512) := [w1415,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6663]
theorem b5_3256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3256 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(5,true))] s5_3256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1415,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6663] (PetersenWireProjection.cons pc45_1415 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6663 rfl)))))))))) (by decide +kernel)
def s5_3261 : List (BitVec 512) := [w1415,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_3261 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3261 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(5,true))] s5_3261 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1415,v45_3258,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1415 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_3341 : List (BitVec 512) := [w1711,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_3341 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3341 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_3341 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1711,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1711 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_4129 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5690,w5956,w6300,w6588]
theorem b5_4129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4129 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_4129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5690,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5690 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_4130 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5694,w5956,w6300,w6588]
theorem b5_4130 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4130 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_4130 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5694,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5694 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_5762 : List (BitVec 512) := [w3766,w4344,w4716,w4998,w5393,w5585,w5726,w5956,w6300,w6588]
theorem b5_5762 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5762 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true)),(false,(5,true),(0,true))] s5_5762 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_4998,v45_5393,v45_5585,v45_5726,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_4998 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5726 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_5789 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5697,w5956,w6300,w6588]
theorem b5_5789 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5789 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_5789 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5697,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5697 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s6_7 : List (BitVec 512) := [w357,w3258,w4716,w5135,w5393,w5698,w6179,w6300,w6690]
theorem b6_7 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_7 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s6_7 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3258,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))) (by decide +kernel)
def s6_12 : List (BitVec 512) := [w628,w2681,w3766,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b6_12 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_12 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s6_12 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2681,v45_3766,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2681 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))) (by decide +kernel)
def s6_13 : List (BitVec 512) := [w628,w3258,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b6_13 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_13 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s6_13 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3258,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))) (by decide +kernel)
end NineCert
