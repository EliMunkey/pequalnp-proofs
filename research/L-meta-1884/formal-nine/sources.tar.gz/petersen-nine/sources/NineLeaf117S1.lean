import NinePin117
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2294 : List (BitVec 512) := [w1270,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2294 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2294 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1270,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1270 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2305 : List (BitVec 512) := [w1279,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2305 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1279,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1279 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_2309 : List (BitVec 512) := [w1280,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2309 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1280,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1280 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2415 : List (BitVec 512) := [w1295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2415 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2415 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2415 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1295,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1295 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2418 : List (BitVec 512) := [w1298,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2418 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2418 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2418 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1298,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1298 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2423 : List (BitVec 512) := [w1303,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2423 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2423 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2423 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1303,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1303 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2570 : List (BitVec 512) := [w1315,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2570 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2570 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1315,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1315 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2573 : List (BitVec 512) := [w1318,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2573 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1318,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1318 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2577 : List (BitVec 512) := [w1322,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2577 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2577 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2577 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1322,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1322 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2641 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618]
theorem b5_2641 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2641 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2641 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1328,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6618] (PetersenWireProjection.cons pc117_1328 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6618 rfl)))))))))) (by decide +kernel)
def s5_2718 : List (BitVec 512) := [w1356,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2718 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2718 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2718 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1356,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1356 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2721 : List (BitVec 512) := [w1359,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2721 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2721 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2721 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1359,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1359 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2725 : List (BitVec 512) := [w1363,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2725 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2725 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2725 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1363,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1363 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2795 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6869]
theorem b5_2795 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2795 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2795 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1374,v117_2681,v117_3766,v117_4344,v117_4716,v117_5393,v117_5585,v117_5956,v117_6300,v117_6869] (PetersenWireProjection.cons pc117_1374 (PetersenWireProjection.cons pc117_2681 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6869 rfl)))))))))) (by decide +kernel)
def s5_2796 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4748,w5393,w5585,w5956,w6300,w6720]
theorem b5_2796 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2796 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2796 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1374,v117_2681,v117_3766,v117_4344,v117_4748,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1374 (PetersenWireProjection.cons pc117_2681 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4748 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_2855 : List (BitVec 512) := [w1377,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2855 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2855 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2855 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1377,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1377 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2859 : List (BitVec 512) := [w1380,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2859 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2859 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2859 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1380,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1380 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_2875 : List (BitVec 512) := [w1384,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b5_2875 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2875 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2875 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1384,v117_2681,v117_3766,v117_4344,v117_4716,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1384 (PetersenWireProjection.cons pc117_2681 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_2957 : List (BitVec 512) := [w1384,w3766,w4344,w4749,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2957 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2957 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2957 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1384,v117_3766,v117_4344,v117_4749,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1384 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4749 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_2985 : List (BitVec 512) := [w1387,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2985 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2985 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_2985 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1387,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1387 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_3026 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6604]
theorem b5_3026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3026 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_3026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1388,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6604] (PetersenWireProjection.cons pc117_1388 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6604 rfl)))))))))) (by decide +kernel)
def s5_3221 : List (BitVec 512) := [w1406,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3221 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3221 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_3221 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1406,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1406 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_3224 : List (BitVec 512) := [w1409,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3224 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_3224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1409,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1409 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_3325 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3325 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3325 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_3325 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1423,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6720] (PetersenWireProjection.cons pc117_1423 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6720 rfl)))))))))) (by decide +kernel)
def s5_3329 : List (BitVec 512) := [w1425,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3329 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3329 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_3329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_1425,v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6588] (PetersenWireProjection.cons pc117_1425 (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6588 rfl)))))))))) (by decide +kernel)
def s5_5984 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6686,w6873]
theorem b5_5984 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5984 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_5984 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6686,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6686 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6026 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6856]
theorem b5_6026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6026 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6300,v117_6785,v117_6856] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6856 rfl)))))))))) (by decide +kernel)
def s5_6029 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6785,w6873]
theorem b5_6029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6029 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6321,v117_6785,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6321 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6030 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6330,w6720,w6873]
theorem b5_6030 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6030 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6030 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6330,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6330 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6036 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6333,w6720,w6873]
theorem b5_6036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6036 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6333,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6333 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6038 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6333,w6785,w6873]
theorem b5_6038 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6038 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6038 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6333,v117_6785,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6333 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6042 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6334,w6785,w6873]
theorem b5_6042 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6042 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6042 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6334,v117_6785,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6334 (PetersenWireProjection.cons pc117_6785 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6043 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6336,w6720,w6873]
theorem b5_6043 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6043 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5956,v117_6336,v117_6720,v117_6873] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5956 (PetersenWireProjection.cons pc117_6336 (PetersenWireProjection.cons pc117_6720 (PetersenWireProjection.cons pc117_6873 rfl)))))))))) (by decide +kernel)
def s5_6075 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6300,w6690,w6832]
theorem b5_6075 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6075 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6075 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5993,v117_6300,v117_6690,v117_6832] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5993 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 rfl)))))))))) (by decide +kernel)
def s5_6083 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5996,w6300,w6690,w6832]
theorem b5_6083 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6083 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6083 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5996,v117_6300,v117_6690,v117_6832] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5996 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 rfl)))))))))) (by decide +kernel)
def s5_6085 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5998,w6300,w6690,w6832]
theorem b5_6085 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6085 := by
  intro m le c
  apply rejects_sound r117 i8 7 tgt (small117 adj) hot117 [] s5_6085 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v117_3766,v117_4344,v117_4716,v117_5135,v117_5393,v117_5585,v117_5998,v117_6300,v117_6690,v117_6832] (PetersenWireProjection.cons pc117_3766 (PetersenWireProjection.cons pc117_4344 (PetersenWireProjection.cons pc117_4716 (PetersenWireProjection.cons pc117_5135 (PetersenWireProjection.cons pc117_5393 (PetersenWireProjection.cons pc117_5585 (PetersenWireProjection.cons pc117_5998 (PetersenWireProjection.cons pc117_6300 (PetersenWireProjection.cons pc117_6690 (PetersenWireProjection.cons pc117_6832 rfl)))))))))) (by decide +kernel)
end NineCert
