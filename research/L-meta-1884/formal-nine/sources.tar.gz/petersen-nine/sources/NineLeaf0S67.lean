import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13442 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_13442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13442 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true))] s4_13442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5760,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5760 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13443 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_13443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13443 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(1,true),(0,true))] s4_13443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5767,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5767 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13444 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b4_13444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13444 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5981,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5981 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13445 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_13445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13445 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_13445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5992,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5992 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13446 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_13446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13446 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_13446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5993,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5993 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13447 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_13447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13447 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5995,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5995 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13448 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5996,w6300,w6588]
theorem b4_13448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13448 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5996,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5996 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13449 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5998,w6300,w6588]
theorem b4_13449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13449 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5998,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5998 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13450 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6002,w6300,w6588]
theorem b4_13450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13450 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6002,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6002 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13451 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6003,w6300,w6588]
theorem b4_13451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13451 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_13451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6003,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6003 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13452 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_13452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13452 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6004,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6004 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13453 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6300,w6588]
theorem b4_13453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13453 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6006,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6006 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13454 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6007,w6300,w6588]
theorem b4_13454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13454 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_13454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6007,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6007 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13455 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6009,w6300,w6588]
theorem b4_13455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13455 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6009,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6009 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13456 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_13456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13456 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6014,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6014 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13457 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_13457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13457 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6017,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6017 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13458 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_13458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13458 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6019,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6019 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13459 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_13459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13459 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6023,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6023 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13460 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_13460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13460 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6024,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6024 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13461 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_13461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13461 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6026,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6026 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13462 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6032,w6300,w6588]
theorem b4_13462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13462 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_13462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6032,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6032 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13463 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6033,w6300,w6588]
theorem b4_13463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13463 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_13463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6033,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6033 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13464 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6034,w6300,w6588]
theorem b4_13464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13464 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_13464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6034,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6034 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13465 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6035,w6300,w6588]
theorem b4_13465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13465 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_13465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6035,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6035 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13466 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6036,w6300,w6588]
theorem b4_13466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13466 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_13466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6036,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6036 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13467 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6037,w6300,w6588]
theorem b4_13467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13467 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_13467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6037,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6037 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13468 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6038,w6300,w6588]
theorem b4_13468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13468 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(7,true))] s4_13468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6038,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6038 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13469 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6039,w6300,w6588]
theorem b4_13469 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13469 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_13469 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6039,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6039 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13470 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6040,w6300,w6588]
theorem b4_13470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13470 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_13470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6040,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6040 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13471 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6041,w6300,w6588]
theorem b4_13471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13471 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(0,true)),(false,(0,true),(7,true))] s4_13471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6041,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6041 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13472 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6042,w6300,w6588]
theorem b4_13472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13472 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_13472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6042,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6042 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13473 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_13473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13473 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_13473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6044,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6044 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13474 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_13474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13474 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(1,true)),(false,(1,true),(0,true))] s4_13474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6087,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6087 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13475 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6097,w6300,w6588]
theorem b4_13475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13475 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(6,true)),(false,(1,true),(0,true))] s4_13475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6097,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6097 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13476 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_13476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13476 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true)),(false,(1,true),(0,true))] s4_13476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6099,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6099 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13477 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_13477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13477 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s4_13477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6166,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6166 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13478 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_13478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13478 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true))] s4_13478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6173,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6173 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13479 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6588]
theorem b4_13479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13479 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,true))] s4_13479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6177,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6177 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13480 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_13480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13480 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true)),(false,(1,false),(0,false))] s4_13480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13481 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6321,w6588]
theorem b4_13481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_13481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6321,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6321 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13482 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6330,w6588]
theorem b4_13482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13482 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_13482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6330,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6330 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13483 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b4_13483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13483 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_13483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6331,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6331 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13484 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6333,w6588]
theorem b4_13484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13484 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_13484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6333,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6333 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13485 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_13485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13485 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_13485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6334,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6334 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13486 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_13486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13486 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_13486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6336,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6336 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13487 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6340,w6588]
theorem b4_13487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13487 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_13487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6340,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6340 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13488 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6341,w6588]
theorem b4_13488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13488 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_13488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6341,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6341 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13489 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6342,w6588]
theorem b4_13489 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13489 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_13489 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6342,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6342 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13490 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6344,w6588]
theorem b4_13490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13490 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_13490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6344,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6344 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13491 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6345,w6588]
theorem b4_13491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13491 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_13491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6345,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6345 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13492 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6346,w6588]
theorem b4_13492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13492 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_13492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6346,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6346 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13493 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6351,w6588]
theorem b4_13493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13493 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_13493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6351,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6351 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13494 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6352,w6588]
theorem b4_13494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13494 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_13494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6352,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6352 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13495 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6353,w6588]
theorem b4_13495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13495 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_13495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6353,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6353 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13496 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6355,w6588]
theorem b4_13496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13496 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))] s4_13496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6355,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6355 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13497 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6356,w6588]
theorem b4_13497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13497 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))] s4_13497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6356,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6356 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13498 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6357,w6588]
theorem b4_13498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13498 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_13498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6357,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6357 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13499 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6363,w6588]
theorem b4_13499 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13499 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true))] s4_13499 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6363,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6363 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13500 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6364,w6588]
theorem b4_13500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13500 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_13500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6364,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6364 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13501 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6365,w6588]
theorem b4_13501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13501 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_13501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6365,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6365 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13502 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6366,w6588]
theorem b4_13502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13502 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true))] s4_13502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6366,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6366 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13503 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6367,w6588]
theorem b4_13503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13503 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_13503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6367,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6367 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13504 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6368,w6588]
theorem b4_13504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13504 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_13504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6368,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6368 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13505 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6370,w6588]
theorem b4_13505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13505 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(8,true))] s4_13505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6370,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6370 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
