import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_383 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720]
theorem b5_383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_383 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(9,true),(5,true))] s5_383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_390 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_390 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_390 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(9,true),(5,true))] s5_390 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_409 : List (BitVec 512) := [w197,w2864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_409 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_409 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(0,false),(5,true))] s5_409 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_197,v4_2864,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_197 (PetersenWireProjection.cons pc4_2864 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_414 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_414 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_414 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(0,false),(5,true))] s5_414 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_197,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_197 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_449 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_449 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_449 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_449 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_204,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_204 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_451 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_451 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_451 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,false),(5,true))] s5_451 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_204,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_204 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_478 : List (BitVec 512) := [w267,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_478 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_478 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s5_478 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_267,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_267 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_484 : List (BitVec 512) := [w277,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_484 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_484 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_484 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_277,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_277 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_532 : List (BitVec 512) := [w311,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_532 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_532 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_532 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_311,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_311 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_533 : List (BitVec 512) := [w312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_533 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_533 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_533 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_534 : List (BitVec 512) := [w315,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_534 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_534 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_534 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_315,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_315 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_535 : List (BitVec 512) := [w316,w2442,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_535 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_535 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(4,true)),(false,(7,true),(0,true))] s5_535 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2442,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2442 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_536 : List (BitVec 512) := [w316,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_536 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_536 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_536 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_537 : List (BitVec 512) := [w316,w2890,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_537 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_537 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,false),(4,true))] s5_537 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_2890,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_2890 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_538 : List (BitVec 512) := [w316,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_538 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_538 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_538 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_539 : List (BitVec 512) := [w316,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_539 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_539 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_539 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_540 : List (BitVec 512) := [w316,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_540 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_540 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))] s5_540 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3303,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3303 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_541 : List (BitVec 512) := [w316,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_541 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_541 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(4,true)),(false,(4,true),(0,true))] s5_541 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3328,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3328 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_542 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_542 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_542 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_542 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_543 : List (BitVec 512) := [w316,w3766,w4344,w4724,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_543 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_543 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(1,false),(0,true))] s5_543 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4724,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4724 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_544 : List (BitVec 512) := [w316,w3766,w4344,w4726,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_544 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_544 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(4,true),(3,true)),(false,(1,false),(0,true))] s5_544 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4726,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4726 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_545 : List (BitVec 512) := [w316,w3766,w4344,w4727,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_545 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_545 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(8,true),(5,true)),(false,(1,true),(0,false))] s5_545 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4727,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4727 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_546 : List (BitVec 512) := [w316,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_546 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_546 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(9,true),(8,true)),(false,(5,true),(7,true))] s5_546 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4716,v4_5135,v4_5393,v4_5698,v4_6179,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl)))))))))) (by decide +kernel)
def s5_628 : List (BitVec 512) := [w428,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_628 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_628 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(0,false),(6,true))] s5_628 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_428,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_428 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_772 : List (BitVec 512) := [w521,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b5_772 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_772 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_772 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_521,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_521 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_773 : List (BitVec 512) := [w522,w1863,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_773 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_773 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(7,true)),(false,(0,true),(9,true))] s5_773 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_1863,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_1863 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_774 : List (BitVec 512) := [w522,w1875,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_774 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_774 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(1,true),(5,false))] s5_774 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_1875,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_775 : List (BitVec 512) := [w522,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_775 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_775 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_775 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_776 : List (BitVec 512) := [w522,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6720]
theorem b5_776 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_776 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_776 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_777 : List (BitVec 512) := [w522,w2681,w2852,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_777 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_777 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(1,true),(5,false))] s5_777 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_2852,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_778 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_778 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_778 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_778 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_779 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_779 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_779 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s5_779 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_780 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_780 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_780 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s5_780 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_781 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b5_781 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_781 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(4,true))] s5_781 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_782 : List (BitVec 512) := [w522,w3766,w4344,w4716,w5393,w5585,w5956,w6189,w6300,w6588]
theorem b5_782 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_782 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(7,true)),(false,(0,false),(9,true))] s5_782 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6189,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6189 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_892 : List (BitVec 512) := [w597,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_892 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_892 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_892 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_597,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_597 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_894 : List (BitVec 512) := [w599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_894 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_894 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_894 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_599,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_599 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_907 : List (BitVec 512) := [w628,w2087,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_907 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_907 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(0,true),(5,true)),(false,(2,true),(6,false))] s5_907 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_2087,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_2087 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_916 : List (BitVec 512) := [w628,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_916 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_918 : List (BitVec 512) := [w628,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_918 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_918 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_918 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3280,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_925 : List (BitVec 512) := [w632,w1819,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_925 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_925 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true)),(false,(2,true),(6,false))] s5_925 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_1819,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_936 : List (BitVec 512) := [w635,w1819,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_936 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_936 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(2,true),(6,false))] s5_936 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1819,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_952 : List (BitVec 512) := [w637,w1819,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_952 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_952 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_952 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_637,v4_1819,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_637 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_953 : List (BitVec 512) := [w637,w2087,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_953 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_637,v4_2087,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_637 (PetersenWireProjection.cons pc4_2087 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_997 : List (BitVec 512) := [w752,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_997 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_752,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_752 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_998 : List (BitVec 512) := [w752,w4344,w4716,w4813,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_998 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_752,v4_4344,v4_4716,v4_4813,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_752 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4813 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1105 : List (BitVec 512) := [w865,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1105 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1105 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1105 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_865,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_865 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1108 : List (BitVec 512) := [w872,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1108 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1108 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1108 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_872,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_872 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1109 : List (BitVec 512) := [w873,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1109 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1109 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1109 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_873,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_873 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1111 : List (BitVec 512) := [w877,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1111 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1111 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1111 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_877,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_877 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1112 : List (BitVec 512) := [w878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1112 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1112 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1112 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_878,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1114 : List (BitVec 512) := [w880,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1114 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1114 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1114 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_880,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_880 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1116 : List (BitVec 512) := [w882,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1116 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1116 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_1116 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_882,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_882 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1482 : List (BitVec 512) := [w972,w2864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_1482 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1482 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1482 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_972,v4_2864,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_972 (PetersenWireProjection.cons pc4_2864 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl)))))))))) (by decide +kernel)
def s5_1487 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1487 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1487 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1487 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_972,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_972 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1607 : List (BitVec 512) := [w1042,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1607 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1042,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1042 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1608 : List (BitVec 512) := [w1042,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1608 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true)),(false,(0,true),(2,true))] s5_1608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1042,v4_3901,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1042 (PetersenWireProjection.cons pc4_3901 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1609 : List (BitVec 512) := [w1043,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1609 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1609 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1609 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1043,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1043 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1611 : List (BitVec 512) := [w1047,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1611 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1611 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1611 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1047,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1047 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1612 : List (BitVec 512) := [w1048,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1612 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1612 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1612 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1048,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1048 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1613 : List (BitVec 512) := [w1049,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1613 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1613 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1613 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1049,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1049 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1615 : List (BitVec 512) := [w1053,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1615 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1615 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1615 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1053,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1053 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1616 : List (BitVec 512) := [w1054,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1616 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1616 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1616 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1054,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1054 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1618 : List (BitVec 512) := [w1057,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1618 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1618 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1618 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1057,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1057 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
