import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_1504 : List (BitVec 512) := [w1170,w1909,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1504 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1504 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,true))] s3_1504 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1909,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1909 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1505 : List (BitVec 512) := [w1170,w1911,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1505 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1505 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,true),(7,true))] s3_1505 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1911,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1911 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1506 : List (BitVec 512) := [w1170,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1506 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1506 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true))] s3_1506 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1507 : List (BitVec 512) := [w1170,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_1507 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1507 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true))] s3_1507 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))))) (by decide +kernel)
def s3_1508 : List (BitVec 512) := [w1170,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_1508 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1508 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s3_1508 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1509 : List (BitVec 512) := [w1170,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_1509 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1509 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s3_1509 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1510 : List (BitVec 512) := [w1170,w2819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1510 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1510 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,true))] s3_1510 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2819,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2819 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1511 : List (BitVec 512) := [w1170,w2836,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1511 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1511 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,true),(3,true))] s3_1511 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2836,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2836 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1512 : List (BitVec 512) := [w1170,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1512 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1512 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true))] s3_1512 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2837,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2837 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1513 : List (BitVec 512) := [w1170,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1513 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1513 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true))] s3_1513 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2837,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2837 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1514 : List (BitVec 512) := [w1170,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1514 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1514 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true))] s3_1514 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2852,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2852 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1515 : List (BitVec 512) := [w1170,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1515 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1515 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true))] s3_1515 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2852,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2852 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1516 : List (BitVec 512) := [w1170,w2878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1516 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1516 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s3_1516 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2878,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2878 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1517 : List (BitVec 512) := [w1170,w2878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1517 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1517 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s3_1517 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_2878,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_2878 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))))) (by decide +kernel)
def s3_1518 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1518 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1518 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true))] s3_1518 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1519 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_1519 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1519 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(7,true))] s3_1519 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6136,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6136 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1520 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1520 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1520 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true))] s3_1520 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1521 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_1521 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1521 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true))] s3_1521 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6436,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6436 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1522 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_1522 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1522 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(8,true))] s3_1522 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1523 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_1523 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1523 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(8,true),(7,true))] s3_1523 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1524 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_1524 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1524 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s3_1524 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6748] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6748 rfl)))))))))))) (by decide +kernel)
def s3_1525 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_1525 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1525 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(3,true),(2,true))] s3_1525 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6785] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6785 rfl)))))))))))) (by decide +kernel)
def s3_1526 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_1526 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1526 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(3,true),(2,true))] s3_1526 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl)))))))))))) (by decide +kernel)
def s3_1527 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_1527 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1527 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true))] s3_1527 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))))) (by decide +kernel)
def s3_1528 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_1528 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1528 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false))] s3_1528 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1529 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_1529 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1529 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(7,true))] s3_1529 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1530 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_1530 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1530 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_1530 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1531 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b3_1531 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1531 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false))] s3_1531 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1532 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_1532 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1532 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(7,true))] s3_1532 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1533 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_1533 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1533 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(2,true))] s3_1533 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))))) (by decide +kernel)
def s3_1534 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6807]
theorem b3_1534 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1534 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,false))] s3_1534 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588,v1_6807] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6807 rfl)))))))))))) (by decide +kernel)
def s3_1535 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6832]
theorem b3_1535 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1535 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(6,true),(2,true))] s3_1535 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl)))))))))))) (by decide +kernel)
def s3_1536 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_1536 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1536 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(8,true))] s3_1536 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))))) (by decide +kernel)
def s3_1537 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_1537 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1537 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false))] s3_1537 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1538 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_1538 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1538 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_1538 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1539 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_1539 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1539 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s3_1539 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1540 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_1540 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1540 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(8,true))] s3_1540 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1541 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_1541 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1541 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(8,true))] s3_1541 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6489,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6489 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1542 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_1542 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1542 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(2,true))] s3_1542 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))))) (by decide +kernel)
def s3_1543 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_1543 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1543 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,false))] s3_1543 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6813] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6813 rfl)))))))))))) (by decide +kernel)
def s3_1544 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_1544 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1544 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(3,true),(6,true))] s3_1544 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl)))))))))))) (by decide +kernel)
def s3_1545 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_1545 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1545 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true))] s3_1545 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))))) (by decide +kernel)
def s3_1546 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1546 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1546 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true))] s3_1546 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1547 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b3_1547 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1547 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_1547 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6136,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6136 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1548 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b3_1548 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1548 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_1548 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1549 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b3_1549 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1549 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(7,true))] s3_1549 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1550 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b3_1550 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1550 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true))] s3_1550 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1551 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6720]
theorem b3_1551 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1551 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(4,true),(3,true))] s3_1551 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))))) (by decide +kernel)
def s3_1552 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6785]
theorem b3_1552 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1552 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(2,true),(7,true))] s3_1552 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588,v1_6785] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6785 rfl)))))))))))) (by decide +kernel)
def s3_1553 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6852]
theorem b3_1553 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1553 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(4,true))] s3_1553 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588,v1_6852] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6852 rfl)))))))))))) (by decide +kernel)
def s3_1554 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6873]
theorem b3_1554 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1554 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(8,true),(4,true))] s3_1554 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))))) (by decide +kernel)
def s3_1555 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_1555 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1555 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(7,true))] s3_1555 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6136,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6136 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1556 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b3_1556 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1556 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_1556 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1557 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_1557 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1557 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_1557 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1558 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6389,w6588]
theorem b3_1558 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1558 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(7,true))] s3_1558 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1559 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6690]
theorem b3_1559 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1559 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(7,true))] s3_1559 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))))) (by decide +kernel)
def s3_1560 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6720]
theorem b3_1560 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1560 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s3_1560 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))))) (by decide +kernel)
def s3_1561 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6866]
theorem b3_1561 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1561 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_1561 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588,v1_6866] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6866 rfl)))))))))))) (by decide +kernel)
def s3_1562 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_1562 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1562 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_1562 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1563 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_1563 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1563 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s3_1563 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1564 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6436,w6588]
theorem b3_1564 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1564 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,false),(3,true))] s3_1564 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6436,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6436 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1565 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6478,w6588]
theorem b3_1565 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1565 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,false))] s3_1565 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1566 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6720]
theorem b3_1566 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1566 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true))] s3_1566 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl)))))))))))) (by decide +kernel)
def s3_1567 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6785]
theorem b3_1567 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1567 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(2,true),(8,true))] s3_1567 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588,v1_6785] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6785 rfl)))))))))))) (by decide +kernel)
end NineCert
