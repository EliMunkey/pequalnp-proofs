import NinePin25
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1097 : List (BitVec 512) := [w859,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1097 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1097 := by
  intro m le c
  apply rejects_sound r25 i7 8 tgt (small25 adj) hot25 [(false,(6,true),(4,true))] s5_1097 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v25_859,v25_3258,v25_4344,v25_4716,v25_5135,v25_5393,v25_5585,v25_5956,v25_6300,v25_6588] (PetersenWireProjection.cons pc25_859 (PetersenWireProjection.cons pc25_3258 (PetersenWireProjection.cons pc25_4344 (PetersenWireProjection.cons pc25_4716 (PetersenWireProjection.cons pc25_5135 (PetersenWireProjection.cons pc25_5393 (PetersenWireProjection.cons pc25_5585 (PetersenWireProjection.cons pc25_5956 (PetersenWireProjection.cons pc25_6300 (PetersenWireProjection.cons pc25_6588 rfl)))))))))) (by decide +kernel)
end NineCert
