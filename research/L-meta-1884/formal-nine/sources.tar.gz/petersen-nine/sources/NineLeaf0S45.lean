import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7281 : List (BitVec 512) := [w1292,w3289,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7281 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7281 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(7,true))] s4_7281 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3289,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3289 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7282 : List (BitVec 512) := [w1292,w3291,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7282 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7282 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7282 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3291,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3291 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7283 : List (BitVec 512) := [w1292,w3297,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7283 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7283 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7283 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3297,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7284 : List (BitVec 512) := [w1292,w3299,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7284 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7284 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(8,true))] s4_7284 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3299,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3299 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7285 : List (BitVec 512) := [w1292,w3307,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7285 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7285 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true))] s4_7285 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3307,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3307 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7286 : List (BitVec 512) := [w1292,w3315,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7286 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7286 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7286 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3315,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3315 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7296 : List (BitVec 512) := [w1292,w3335,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7296 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7297 : List (BitVec 512) := [w1292,w3411,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7297 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7297 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7297 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7298 : List (BitVec 512) := [w1292,w3567,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7298 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7299 : List (BitVec 512) := [w1292,w3572,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7299 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7300 : List (BitVec 512) := [w1292,w3620,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7300 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7301 : List (BitVec 512) := [w1292,w3628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7301 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true))] s4_7301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7302 : List (BitVec 512) := [w1292,w3643,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7302 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7303 : List (BitVec 512) := [w1292,w3649,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7303 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7304 : List (BitVec 512) := [w1292,w3652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7304 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true))] s4_7304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3652,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3652 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7305 : List (BitVec 512) := [w1292,w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7305 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7305 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true))] s4_7305 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7306 : List (BitVec 512) := [w1292,w3689,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7306 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7307 : List (BitVec 512) := [w1292,w3704,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7307 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3704,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3704 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7308 : List (BitVec 512) := [w1292,w3766,w3829,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7308 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_3829,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3829 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7320 : List (BitVec 512) := [w1292,w3766,w4344,w4602,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7320 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7334 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w4814,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7334 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7346 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5203,w5393,w5956,w6179,w6300,w6588]
theorem b4_7346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7346 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7360 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5474,w5956,w6179,w6300,w6588]
theorem b4_7360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7381 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6124,w6300,w6588]
theorem b4_7381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(7,true))] s4_7381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6124,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7396 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6432,w6588]
theorem b4_7396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7396 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(8,true))] s4_7396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6432,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6432 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7411 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6538,w6588]
theorem b4_7411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7411 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true))] s4_7411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7464 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6048,w6179,w6300,w6588]
theorem b4_7464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7464 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7473 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6195,w6300,w6588]
theorem b4_7473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7473 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7481 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6377,w6588]
theorem b4_7481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7490 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6667]
theorem b4_7490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7490 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_7505 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6048,w6179,w6300,w6588]
theorem b4_7505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7505 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_7505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_7589 : List (BitVec 512) := [w1312,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7589 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7590 : List (BitVec 512) := [w1312,w2203,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7590 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2203,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7623 : List (BitVec 512) := [w1312,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7623 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7623 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7623 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7624 : List (BitVec 512) := [w1312,w2552,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7624 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7624 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7624 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2552,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7695 : List (BitVec 512) := [w1312,w3193,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7695 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7695 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7695 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3193,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7696 : List (BitVec 512) := [w1312,w3193,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3193,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7697 : List (BitVec 512) := [w1312,w3193,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7697 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true))] s4_7697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3193,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7698 : List (BitVec 512) := [w1312,w3197,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7698 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_7698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3197,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3197 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7701 : List (BitVec 512) := [w1312,w3230,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7701 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3230,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7702 : List (BitVec 512) := [w1312,w3230,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_7702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(1,false))] s4_7702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3230,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7703 : List (BitVec 512) := [w1312,w3230,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_7703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7703 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(7,true))] s4_7703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3230,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7704 : List (BitVec 512) := [w1312,w3230,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7704 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true))] s4_7704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3230,v0_3766,v0_4344,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3230 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7705 : List (BitVec 512) := [w1312,w3242,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7705 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3242,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3242 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7706 : List (BitVec 512) := [w1312,w3242,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7706 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3242,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3242 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7707 : List (BitVec 512) := [w1312,w3246,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7707 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3246,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3246 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7708 : List (BitVec 512) := [w1312,w3246,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3246,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3246 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7709 : List (BitVec 512) := [w1312,w3248,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7709 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3248,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7710 : List (BitVec 512) := [w1312,w3248,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7710 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3248,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7712 : List (BitVec 512) := [w1312,w3268,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_7712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7712 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true))] s4_7712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3268,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3268 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7713 : List (BitVec 512) := [w1312,w3268,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7713 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3268,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3268 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7714 : List (BitVec 512) := [w1312,w3280,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7714 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(1,false))] s4_7714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3280,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3280 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7718 : List (BitVec 512) := [w1312,w3283,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7718 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3283,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7719 : List (BitVec 512) := [w1312,w3283,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b4_7719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7719 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(7,true))] s4_7719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3283,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7720 : List (BitVec 512) := [w1312,w3283,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7720 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7720 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7720 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3283,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7721 : List (BitVec 512) := [w1312,w3284,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7721 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7721 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_7721 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3284,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3284 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7722 : List (BitVec 512) := [w1312,w3288,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7722 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7722 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(7,true))] s4_7722 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3288,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3288 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7723 : List (BitVec 512) := [w1312,w3295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7723 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7723 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(7,true))] s4_7723 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3295,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3295 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7724 : List (BitVec 512) := [w1312,w3297,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7724 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7724 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7724 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3297,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_7725 : List (BitVec 512) := [w1312,w3297,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b4_7725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(8,true))] s4_7725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3297,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7726 : List (BitVec 512) := [w1312,w3297,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7726 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3297,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3297 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_7727 : List (BitVec 512) := [w1312,w3298,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7727 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(8,true))] s4_7727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3298,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3298 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7728 : List (BitVec 512) := [w1312,w3307,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7728 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true))] s4_7728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3307,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3307 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_7729 : List (BitVec 512) := [w1312,w3318,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7729 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(9,true),(0,true))] s4_7729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3318,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3318 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
end NineCert
