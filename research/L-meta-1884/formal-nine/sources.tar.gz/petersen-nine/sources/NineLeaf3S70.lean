import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_16313 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s4_16313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4483,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4483 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16316 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s4_16316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4483,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4483 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16327 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_16327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16327 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s4_16327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4483,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4483 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16334 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_16334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16334 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(5,true),(2,true))] s4_16334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16335 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_16335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(5,true),(7,true))] s4_16335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16336 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6620]
theorem b4_16336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16336 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(8,true))] s4_16336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6620] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6620 rfl))))))))))) (by decide +kernel)
def s4_16337 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(8,true),(2,true))] s4_16337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_16338 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_16338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(5,true),(8,true))] s4_16338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_16339 : List (BitVec 512) := [w3766,w4344,w4491,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_16339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(7,true),(8,true))] s4_16339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4491,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4491 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_16343 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16343 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true))] s4_16343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16355 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16355 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true))] s4_16355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16361 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_16361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16361 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true))] s4_16361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16367 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16367 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true))] s4_16367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16375 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16375 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(6,true))] s4_16375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16377 : List (BitVec 512) := [w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16377 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true))] s4_16377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4499,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4499 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16389 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16389 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true))] s4_16389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16401 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16401 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true))] s4_16401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16407 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_16407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16407 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true))] s4_16407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16413 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16413 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(6,true))] s4_16413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16418 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_16418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16418 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(6,true))] s4_16418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16419 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_16419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16419 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(6,true))] s4_16419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16422 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16422 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(6,true))] s4_16422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16424 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16424 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true))] s4_16424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4502,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4502 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16433 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_16433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16433 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(5,true),(2,true))] s4_16433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16434 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6344,w6588]
theorem b4_16434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16434 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(7,true))] s4_16434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6344,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6344 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16435 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16435 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(2,true),(7,true))] s4_16435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16436 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_16436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16436 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(5,true),(7,true))] s4_16436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16437 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_16437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16437 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(2,true),(8,true))] s4_16437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_16438 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_16438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16438 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(5,true),(8,true))] s4_16438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_16439 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_16439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16439 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(7,true),(8,true))] s4_16439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_16440 : List (BitVec 512) := [w3766,w4344,w4506,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_16440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16440 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(2,true),(8,true))] s4_16440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4506,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4506 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_16444 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16444 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s4_16444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16456 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16456 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true))] s4_16456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16462 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_16462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16462 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,true),(0,true))] s4_16462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16468 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16468 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true))] s4_16468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16475 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16475 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s4_16475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16477 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16477 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s4_16477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16479 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16479 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s4_16479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_16480 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_16480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16480 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s4_16480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_16491 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16491 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true))] s4_16491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16503 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16503 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true))] s4_16503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16509 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_16509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16509 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s4_16509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16515 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16515 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true))] s4_16515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16522 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16522 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s4_16522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16524 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16524 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s4_16524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16529 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_16529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16529 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s4_16529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_16530 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_16530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16530 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s4_16530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4516,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4516 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_16539 : List (BitVec 512) := [w3766,w4344,w4518,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16539 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4518,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4518 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16540 : List (BitVec 512) := [w3766,w4344,w4518,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16540 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4518,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4518 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16541 : List (BitVec 512) := [w3766,w4344,w4518,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16541 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4518,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4518 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_16545 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16545 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16557 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16557 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16563 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_16563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16563 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16570 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16570 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16577 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16577 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_16579 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16579 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(6,true))] s4_16579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_16586 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16586 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_16588 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_16588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16588 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_16588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_16607 : List (BitVec 512) := [w3766,w4344,w4528,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16607 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(7,true),(6,true))] s4_16607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4528,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4528 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16608 : List (BitVec 512) := [w3766,w4344,w4528,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_16608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16608 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(8,true),(6,true))] s4_16608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4528,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4528 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_16609 : List (BitVec 512) := [w3766,w4344,w4528,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16609 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(8,true),(7,true))] s4_16609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4528,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4528 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_16613 : List (BitVec 512) := [w3766,w4344,w4544,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16613 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(5,true))] s4_16613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4544,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4544 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16622 : List (BitVec 512) := [w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_16622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16622 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(5,true),(0,true))] s4_16622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4544,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4544 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_16628 : List (BitVec 512) := [w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16628 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16628 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(5,true))] s4_16628 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4544,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4544 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
