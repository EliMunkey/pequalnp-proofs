import NinePin45
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1262 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6807]
theorem b4_1262 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1262 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1262 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6785,v45_6807] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_1265 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_1265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1265 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_1265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_1266 : List (BitVec 512) := [w192,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b4_1266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1266 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_1266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588,v45_6890] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6890 rfl))))))))))) (by decide +kernel)
def s4_2034 : List (BitVec 512) := [w357,w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b4_2034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2034 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_2038 : List (BitVec 512) := [w357,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_2038 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2038 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s4_2038 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_1384,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2044 : List (BitVec 512) := [w357,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2044 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2045 : List (BitVec 512) := [w357,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2045 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_2046 : List (BitVec 512) := [w357,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_2046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2046 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(5,true))] s4_2046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6832] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6832 rfl))))))))))) (by decide +kernel)
def s4_2053 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_2053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2053 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5848,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2060 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_2060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2060 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_2060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2068 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_2068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2068 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(5,true))] s4_2068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6868] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6868 rfl))))))))))) (by decide +kernel)
def s4_2069 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6616]
theorem b4_2069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2069 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6616] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6616 rfl)))))))))) (by decide +kernel)
def s4_2070 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6616,w6832]
theorem b4_2070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2070 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_2070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6616,v45_6832] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6616 (PetersenWireProjection.cons pc45_6832 rfl))))))))))) (by decide +kernel)
def s4_2071 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_2071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2071 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_2072 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b4_2072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2072 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_2075 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_2075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2075 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2076 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b4_2076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2076 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_2077 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_2077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2077 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(5,true))] s4_2077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6588,v45_6832] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6832 rfl))))))))))) (by decide +kernel)
def s4_2866 : List (BitVec 512) := [w628,w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_2866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2866 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2868 : List (BitVec 512) := [w628,w1328,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2868 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(5,true))] s4_2868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_1328,v45_3766,v45_4344,v45_5135,v45_5393,v45_5585,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_1328 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2876 : List (BitVec 512) := [w628,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2876 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true)),(false,(5,true),(0,true))] s4_2876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2681,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2681 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2879 : List (BitVec 512) := [w628,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2879 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2880 : List (BitVec 512) := [w628,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2880 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_2881 : List (BitVec 512) := [w628,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2881 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_2881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_2898 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_2898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2898 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2900 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_2900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2900 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_2900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2902 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2902 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_2902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_2907 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_2907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2907 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_2907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6821] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6821 rfl))))))))))) (by decide +kernel)
def s4_2909 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6643]
theorem b4_2909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2909 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6643] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6643 rfl)))))))))) (by decide +kernel)
def s4_2910 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6643,w6720]
theorem b4_2910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2910 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true))] s4_2910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6643,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6643 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_2911 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_2911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2911 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_2913 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b4_2913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2913 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_2916 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_2916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2916 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_2917 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5148,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2917 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_2917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_4716,v45_5148,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5148 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_2918 : List (BitVec 512) := [w628,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_2918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2918 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_2918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_2919 : List (BitVec 512) := [w628,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_2919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2919 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_2919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_3766,v45_4344,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_7093 : List (BitVec 512) := [w1246,w3766,w4344,w4716,w5135,w5393,w5585,w5648,w5956,w6300,w6690]
theorem b4_7093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7093 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(1,true))] s4_7093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1246,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5648,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1246 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5648 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7096 : List (BitVec 512) := [w1246,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_7096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7096 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1246,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1246 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7115 : List (BitVec 512) := [w1260,w3766,w4344,w4716,w5135,w5393,w5585,w5659,w5956,w6300,w6690]
theorem b4_7115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7115 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,false))] s4_7115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1260,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5659,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1260 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5659 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7118 : List (BitVec 512) := [w1260,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_7118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7118 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1260,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1260 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7146 : List (BitVec 512) := [w1283,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7146 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7146 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7146 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1283,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1283 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7148 : List (BitVec 512) := [w1283,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_7148 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7148 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7148 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1283,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1283 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7149 : List (BitVec 512) := [w1283,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7149 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7149 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_7149 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1283,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1283 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7150 : List (BitVec 512) := [w1283,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7150 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7150 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7150 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1283,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1283 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_7158 : List (BitVec 512) := [w1290,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7158 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7159 : List (BitVec 512) := [w1290,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_7159 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7159 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7159 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7160 : List (BitVec 512) := [w1290,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7160 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1290,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1290 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_7168 : List (BitVec 512) := [w1292,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7168 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(3,true))] s4_7168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1635,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1635 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7171 : List (BitVec 512) := [w1292,w1651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7171 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(3,true))] s4_7171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1651,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1651 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7173 : List (BitVec 512) := [w1292,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7173 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(3,true))] s4_7173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1664,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1664 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7175 : List (BitVec 512) := [w1292,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_7175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7175 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(3,true))] s4_7175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1664,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1664 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7178 : List (BitVec 512) := [w1292,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7178 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7178 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(3,true))] s4_7178 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1669,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1669 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7179 : List (BitVec 512) := [w1292,w1875,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_7179 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7179 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(1,true))] s4_7179 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1875,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1875 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7180 : List (BitVec 512) := [w1292,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7180 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7180 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(1,true))] s4_7180 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1883,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1883 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7181 : List (BitVec 512) := [w1292,w1895,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7181 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7181 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(1,true))] s4_7181 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1895,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1895 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7183 : List (BitVec 512) := [w1292,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7183 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7183 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(1,true))] s4_7183 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1908,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1908 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7184 : List (BitVec 512) := [w1292,w1908,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_7184 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7184 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(1,true))] s4_7184 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1908,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1908 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7187 : List (BitVec 512) := [w1292,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b4_7187 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7187 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,false),(1,true))] s4_7187 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_1912,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_1912 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7190 : List (BitVec 512) := [w1292,w2140,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6478,w6588]
theorem b4_7190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7190 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2140,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6478,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2140 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7191 : List (BitVec 512) := [w1292,w2140,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6389,w6588]
theorem b4_7191 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7191 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7191 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2140,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2140 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7193 : List (BitVec 512) := [w1292,w2164,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300]
theorem b4_7193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7193 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 rfl)))))))))) (by decide +kernel)
def s4_7195 : List (BitVec 512) := [w1292,w2164,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6807]
theorem b4_7195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7195 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7199 : List (BitVec 512) := [w1292,w2164,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785]
theorem b4_7199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7199 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6785] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 rfl)))))))))) (by decide +kernel)
def s4_7200 : List (BitVec 512) := [w1292,w2164,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785,w6807]
theorem b4_7200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7200 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_2164,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6785,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
end NineCert
