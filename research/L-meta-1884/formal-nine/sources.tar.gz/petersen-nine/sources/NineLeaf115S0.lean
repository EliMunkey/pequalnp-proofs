import NinePin115
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_320 : List (BitVec 512) := [w24,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_320 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_24,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6908] (PetersenWireProjection.cons pc115_24 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6908 rfl))))))))))) (by decide +kernel)
def s4_453 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_453 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_28,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6908] (PetersenWireProjection.cons pc115_28 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6908 rfl))))))))))) (by decide +kernel)
def s4_463 : List (BitVec 512) := [w29,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_463 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_29,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_29 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_465 : List (BitVec 512) := [w29,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_465 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_29,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6908] (PetersenWireProjection.cons pc115_29 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6908 rfl))))))))))) (by decide +kernel)
def s4_1957 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_1957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1957 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_1957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_332,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6866] (PetersenWireProjection.cons pc115_332 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6866 rfl))))))))))) (by decide +kernel)
def s4_1959 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_1959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1959 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_1959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_332,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6908] (PetersenWireProjection.cons pc115_332 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6908 rfl))))))))))) (by decide +kernel)
def s4_1969 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_1969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1969 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_1969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_332,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_6179,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_332 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6179 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_2066 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_2066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2066 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_357,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6857] (PetersenWireProjection.cons pc115_357 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6857 rfl))))))))))) (by decide +kernel)
def s4_2286 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_2286 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2286 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2286 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6852] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6852 rfl))))))))))) (by decide +kernel)
def s4_2291 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_2291 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2291 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2291 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6869] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6869 rfl))))))))))) (by decide +kernel)
def s4_2293 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_2293 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2293 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2293 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6908] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6908 rfl))))))))))) (by decide +kernel)
def s4_2295 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618,w6832]
theorem b4_2295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2295 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6618,v115_6832] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6618 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_2299 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6300,w6588,w6832]
theorem b4_2299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2299 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5993,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5993 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_2307 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5402,w5585,w5956,w6300,w6588,w6832]
theorem b4_2307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2307 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_3766,v115_4344,v115_4716,v115_5135,v115_5402,v115_5585,v115_5956,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5402 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_2312 : List (BitVec 512) := [w362,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2312 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_362,v115_1883,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_362 (PetersenWireProjection.cons pc115_1883 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl))))))))))) (by decide +kernel)
def s4_2318 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_2318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2318 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_362,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_362 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_2346 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_2346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2346 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_365,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6852] (PetersenWireProjection.cons pc115_365 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6852 rfl))))))))))) (by decide +kernel)
def s4_2362 : List (BitVec 512) := [w366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_2362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2362 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_2362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_366,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588,v115_6832] (PetersenWireProjection.cons pc115_366 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_9547 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6832,w6868]
theorem b4_9547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9547 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_9547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_1384,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6832,v115_6868] (PetersenWireProjection.cons pc115_1384 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6832 (PetersenWireProjection.cons pc115_6868 rfl))))))))))) (by decide +kernel)
def s4_9557 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6201,w6300,w6832]
theorem b4_9557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9557 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_9557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_1384,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_6179,v115_6201,v115_6300,v115_6832] (PetersenWireProjection.cons pc115_1384 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6179 (PetersenWireProjection.cons pc115_6201 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_9729 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6225,w6300,w6832]
theorem b4_9729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9729 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_9729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_1388,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_6179,v115_6225,v115_6300,v115_6832] (PetersenWireProjection.cons pc115_1388 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6179 (PetersenWireProjection.cons pc115_6225 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6832 rfl))))))))))) (by decide +kernel)
def s4_12516 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6553,w6588]
theorem b4_12516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12516 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_12516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6543,v115_6553,v115_6588] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6543 (PetersenWireProjection.cons pc115_6553 (PetersenWireProjection.cons pc115_6588 rfl))))))))))) (by decide +kernel)
def s4_12518 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6572,w6588]
theorem b4_12518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12518 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_12518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6543,v115_6572,v115_6588] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6543 (PetersenWireProjection.cons pc115_6572 (PetersenWireProjection.cons pc115_6588 rfl))))))))))) (by decide +kernel)
def s4_12519 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6910]
theorem b4_12519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12519 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_12519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6543,v115_6588,v115_6910] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6543 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6910 rfl))))))))))) (by decide +kernel)
def s4_13014 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6061,w6101,w6300,w6543,w6588]
theorem b4_13014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13014 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s4_13014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2488,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_6061,v115_6101,v115_6300,v115_6543,v115_6588] (PetersenWireProjection.cons pc115_2488 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6061 (PetersenWireProjection.cons pc115_6101 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6543 (PetersenWireProjection.cons pc115_6588 rfl))))))))))) (by decide +kernel)
def s5_78 : List (BitVec 512) := [w24,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_78 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_78 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_78 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_24,v115_2527,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_24 (PetersenWireProjection.cons pc115_2527 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_103 : List (BitVec 512) := [w28,w2175,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_103 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_103 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_103 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_28,v115_2175,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_28 (PetersenWireProjection.cons pc115_2175 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_105 : List (BitVec 512) := [w28,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_105 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_105 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_105 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_28,v115_2527,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_28 (PetersenWireProjection.cons pc115_2527 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_115 : List (BitVec 512) := [w30,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_115 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_115 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_115 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_30,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_30 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_516 : List (BitVec 512) := [w294,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_516 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_516 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_516 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_294,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_294 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_525 : List (BitVec 512) := [w303,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_525 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_525 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_525 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_303,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_303 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_549 : List (BitVec 512) := [w319,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_549 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_549 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_549 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_319,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_319 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_560 : List (BitVec 512) := [w332,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_560 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_560 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_560 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_332,v115_2527,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_332 (PetersenWireProjection.cons pc115_2527 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_573 : List (BitVec 512) := [w357,w2175,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_573 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_357,v115_2175,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_357 (PetersenWireProjection.cons pc115_2175 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_575 : List (BitVec 512) := [w357,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_575 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_575 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_575 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_357,v115_2527,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_357 (PetersenWireProjection.cons pc115_2527 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_592 : List (BitVec 512) := [w360,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_592 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_592 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_592 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_360,v115_2527,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_360 (PetersenWireProjection.cons pc115_2527 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_609 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6619]
theorem b5_609 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_609 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_609 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_362,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6619] (PetersenWireProjection.cons pc115_362 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6619 rfl)))))))))) (by decide +kernel)
def s5_611 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5585,w5994,w6300,w6588]
theorem b5_611 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_611 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_611 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_362,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5994,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_362 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5994 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_622 : List (BitVec 512) := [w369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_622 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_622 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_622 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_369,v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_369 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3636 : List (BitVec 512) := [w2379,w3766,w4344,w4716,w5135,w5585,w5956,w6010,w6300,w6588]
theorem b5_3636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3636 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2379,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6010,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2379 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6010 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3661 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6114,w6300,w6588]
theorem b5_3661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3661 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2381,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6114,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2381 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6114 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3669 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6839]
theorem b5_3669 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3669 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3669 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2381,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588,v115_6839] (PetersenWireProjection.cons pc115_2381 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6839 rfl)))))))))) (by decide +kernel)
def s5_3670 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w6017,w6101,w6300,w6588]
theorem b5_3670 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3670 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3670 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2381,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_6017,v115_6101,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2381 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6017 (PetersenWireProjection.cons pc115_6101 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3683 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6076,w6300,w6588]
theorem b5_3683 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3683 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3683 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2382,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6076,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2382 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6076 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3688 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6840]
theorem b5_3688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3688 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2382,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6588,v115_6840] (PetersenWireProjection.cons pc115_2382 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6840 rfl)))))))))) (by decide +kernel)
def s5_3691 : List (BitVec 512) := [w2383,w3766,w4344,w4716,w5135,w5585,w5956,w6020,w6300,w6588]
theorem b5_3691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3691 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2383,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6020,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2383 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6020 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3717 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6078,w6300,w6588]
theorem b5_3717 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3717 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3717 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2387,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6078,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2387 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6078 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3718 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6116,w6300,w6588]
theorem b5_3718 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3718 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3718 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2387,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6116,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2387 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6116 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3731 : List (BitVec 512) := [w2388,w3766,w4344,w4716,w5135,w5585,w5956,w6027,w6300,w6588]
theorem b5_3731 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3731 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3731 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2388,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6027,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2388 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6027 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3734 : List (BitVec 512) := [w2389,w3766,w4344,w4716,w5135,w5585,w5956,w6028,w6300,w6588]
theorem b5_3734 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3734 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3734 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2389,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6028,v115_6300,v115_6588] (PetersenWireProjection.cons pc115_2389 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6028 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3901 : List (BitVec 512) := [w2468,w2690,w3766,w4344,w4716,w5585,w6101,w6300,w6522,w6588]
theorem b5_3901 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3901 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3901 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_2690,v115_3766,v115_4344,v115_4716,v115_5585,v115_6101,v115_6300,v115_6522,v115_6588] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_2690 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_6101 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6522 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_3907 : List (BitVec 512) := [w2468,w2701,w3766,w4344,w4716,w5585,w5956,w6300,w6588,w6912]
theorem b5_3907 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3907 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_3907 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_2701,v115_3766,v115_4344,v115_4716,v115_5585,v115_5956,v115_6300,v115_6588,v115_6912] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_2701 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6912 rfl)))))))))) (by decide +kernel)
def s5_4189 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6526,w6588]
theorem b5_4189 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4189 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_4189 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6526,v115_6588] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6526 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_4197 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4197 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4197 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_4197 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2468,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6578,v115_6588] (PetersenWireProjection.cons pc115_2468 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6578 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_4266 : List (BitVec 512) := [w2469,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6524,w6588]
theorem b5_4266 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4266 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_4266 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2469,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6524,v115_6588] (PetersenWireProjection.cons pc115_2469 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6524 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_4269 : List (BitVec 512) := [w2470,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6526,w6588]
theorem b5_4269 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4269 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_4269 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2470,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6526,v115_6588] (PetersenWireProjection.cons pc115_2470 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6526 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_4272 : List (BitVec 512) := [w2471,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6527,w6588]
theorem b5_4272 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4272 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_4272 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_2471,v115_3766,v115_4344,v115_4716,v115_5135,v115_5585,v115_5956,v115_6300,v115_6527,v115_6588] (PetersenWireProjection.cons pc115_2471 (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6527 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_5776 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5319,w5585,w5956,w6300,w6553,w6588]
theorem b5_5776 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5776 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_5776 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_3766,v115_4344,v115_4716,v115_5135,v115_5319,v115_5585,v115_5956,v115_6300,v115_6553,v115_6588] (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5319 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6553 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_5955 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618,w6908]
theorem b5_5955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5955 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_5955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_3766,v115_4344,v115_4716,v115_5135,v115_5393,v115_5585,v115_5956,v115_6300,v115_6618,v115_6908] (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5393 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6618 (PetersenWireProjection.cons pc115_6908 rfl)))))))))) (by decide +kernel)
def s5_6177 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5402,w5585,w5956,w6300,w6588,w6869]
theorem b5_6177 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6177 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_6177 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_3766,v115_4344,v115_4716,v115_5135,v115_5402,v115_5585,v115_5956,v115_6300,v115_6588,v115_6869] (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5402 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6588 (PetersenWireProjection.cons pc115_6869 rfl)))))))))) (by decide +kernel)
def s5_6179 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5454,w5585,w5956,w6300,w6572,w6588]
theorem b5_6179 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6179 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_6179 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_3766,v115_4344,v115_4716,v115_5135,v115_5454,v115_5585,v115_5956,v115_6300,v115_6572,v115_6588] (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5454 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6572 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
def s5_6181 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5455,w5585,w5956,w6300,w6575,w6588]
theorem b5_6181 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6181 := by
  intro m le c
  apply rejects_sound r115 i8 7 tgt (small115 adj) hot115 [] s5_6181 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v115_3766,v115_4344,v115_4716,v115_5135,v115_5455,v115_5585,v115_5956,v115_6300,v115_6575,v115_6588] (PetersenWireProjection.cons pc115_3766 (PetersenWireProjection.cons pc115_4344 (PetersenWireProjection.cons pc115_4716 (PetersenWireProjection.cons pc115_5135 (PetersenWireProjection.cons pc115_5455 (PetersenWireProjection.cons pc115_5585 (PetersenWireProjection.cons pc115_5956 (PetersenWireProjection.cons pc115_6300 (PetersenWireProjection.cons pc115_6575 (PetersenWireProjection.cons pc115_6588 rfl)))))))))) (by decide +kernel)
end NineCert
