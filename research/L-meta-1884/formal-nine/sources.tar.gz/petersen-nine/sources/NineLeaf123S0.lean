import NinePin123
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_56 : List (BitVec 512) := [w2468,w3591,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_56 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_56 := by
  intro m le c
  apply rejects_sound r123 i7 6 tgt (small123 adj) hot123 [] s6_56 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v123_2468,v123_3591,v123_4344,v123_4716,v123_5135,v123_5585,v123_5956,v123_6300,v123_6588] (PetersenWireProjection.cons pc123_2468 (PetersenWireProjection.cons pc123_3591 (PetersenWireProjection.cons pc123_4344 (PetersenWireProjection.cons pc123_4716 (PetersenWireProjection.cons pc123_5135 (PetersenWireProjection.cons pc123_5585 (PetersenWireProjection.cons pc123_5956 (PetersenWireProjection.cons pc123_6300 (PetersenWireProjection.cons pc123_6588 rfl))))))))) (by decide +kernel)
end NineCert
