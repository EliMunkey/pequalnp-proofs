import NinePin450
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4726 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6553,w6588]
theorem b3_4726 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4726 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s3_4726 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_3766,v450_4344,v450_4716,v450_4926,v450_5135,v450_5393,v450_5585,v450_5956,v450_6300,v450_6522,v450_6553,v450_6588] (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_4926 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5393 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6522 (PetersenWireProjection.cons pc450_6553 (PetersenWireProjection.cons pc450_6588 rfl)))))))))))) (by decide +kernel)
def s4_5634 : List (BitVec 512) := [w1119,w2143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5634 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5634 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s4_5634 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_1119,v450_2143,v450_3766,v450_4344,v450_4716,v450_5135,v450_5393,v450_5585,v450_5956,v450_6300,v450_6588] (PetersenWireProjection.cons pc450_1119 (PetersenWireProjection.cons pc450_2143 (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5393 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6588 rfl))))))))))) (by decide +kernel)
def s4_5657 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_5657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5657 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s4_5657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_1119,v450_2468,v450_3766,v450_4344,v450_4716,v450_5135,v450_5585,v450_5956,v450_6300,v450_6522,v450_6588] (PetersenWireProjection.cons pc450_1119 (PetersenWireProjection.cons pc450_2468 (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6522 (PetersenWireProjection.cons pc450_6588 rfl))))))))))) (by decide +kernel)
def s4_8497 : List (BitVec 512) := [w1353,w2141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8497 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s4_8497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_1353,v450_2141,v450_3766,v450_4344,v450_4716,v450_5135,v450_5393,v450_5585,v450_5956,v450_6300,v450_6588] (PetersenWireProjection.cons pc450_1353 (PetersenWireProjection.cons pc450_2141 (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5393 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6588 rfl))))))))))) (by decide +kernel)
def s4_12348 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6553,w6588]
theorem b4_12348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12348 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s4_12348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_2468,v450_3766,v450_4344,v450_4716,v450_4926,v450_5135,v450_5585,v450_5956,v450_6300,v450_6553,v450_6588] (PetersenWireProjection.cons pc450_2468 (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_4926 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6553 (PetersenWireProjection.cons pc450_6588 rfl))))))))))) (by decide +kernel)
def s4_16217 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16217 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16217 := by
  intro m le c
  apply rejects_sound r450 i4 3 tgt (small450 adj) hot450 [] s4_16217 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v450_3766,v450_4344,v450_4416,v450_4716,v450_5135,v450_5393,v450_5585,v450_5956,v450_6300,v450_6422,v450_6588] (PetersenWireProjection.cons pc450_3766 (PetersenWireProjection.cons pc450_4344 (PetersenWireProjection.cons pc450_4416 (PetersenWireProjection.cons pc450_4716 (PetersenWireProjection.cons pc450_5135 (PetersenWireProjection.cons pc450_5393 (PetersenWireProjection.cons pc450_5585 (PetersenWireProjection.cons pc450_5956 (PetersenWireProjection.cons pc450_6300 (PetersenWireProjection.cons pc450_6422 (PetersenWireProjection.cons pc450_6588 rfl))))))))))) (by decide +kernel)
end NineCert
