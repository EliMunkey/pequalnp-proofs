import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11644 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4808,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11644 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_11644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4808,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4808 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11645 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11645 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_11645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4810,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4810 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11646 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_11646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11646 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_11646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11647 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w6522,w6588,w6873]
theorem b4_11647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11647 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true))] s4_11647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11648 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_11648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11648 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true))] s4_11648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5750,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5750 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11649 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_11649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11649 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_11649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5760,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5760 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11650 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6389,w6522,w6588]
theorem b4_11650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11650 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(5,true),(3,true))] s4_11650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11651 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w6300,w6522,w6588]
theorem b4_11651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11651 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true))] s4_11651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11652 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b4_11652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11652 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_11652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5981,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5981 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11653 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_11653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11653 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s4_11653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5992,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5992 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11654 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_11654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11654 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s4_11654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5993,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5993 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11655 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_11655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11655 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_11655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5995,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5995 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11656 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5996,w6300,w6588]
theorem b4_11656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11656 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_11656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5996,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5996 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11657 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5998,w6300,w6588]
theorem b4_11657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11657 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_11657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5998,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5998 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11658 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6002,w6300,w6588]
theorem b4_11658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11658 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_11658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6002,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6002 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11659 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6003,w6300,w6588]
theorem b4_11659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11659 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(0,true),(4,true))] s4_11659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6003,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6003 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11660 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_11660 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11660 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_11660 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6004,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6004 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11661 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6300,w6588]
theorem b4_11661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11661 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_11661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6006,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6006 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11662 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_11662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11662 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6014,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6014 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11663 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_11663 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11663 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11663 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6017,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6017 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11664 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_11664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11664 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6019,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6019 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11665 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_11665 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11665 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11665 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6023,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6023 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11666 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_11666 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11666 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11666 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6024,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6024 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11667 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_11667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11667 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6026,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6026 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11668 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_11668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11668 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6087,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6087 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11669 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6097,w6300,w6588]
theorem b4_11669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11669 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(1,true),(0,true))] s4_11669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6097,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6097 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11670 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_11670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11670 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6099,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6099 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11671 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11671 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11672 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6321,w6588]
theorem b4_11672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11672 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6321,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6321 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11673 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6330,w6588]
theorem b4_11673 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11673 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11673 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6330,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6330 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11674 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b4_11674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11674 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6331,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6331 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11675 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6333,w6588]
theorem b4_11675 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11675 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11675 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6333,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6333 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11676 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_11676 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11676 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11676 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6334,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6334 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11677 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_11677 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11677 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11677 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6336,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6336 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11678 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6340,w6588]
theorem b4_11678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11678 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6340,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6340 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11679 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6341,w6588]
theorem b4_11679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11679 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true))] s4_11679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6341,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6341 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11680 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6342,w6588]
theorem b4_11680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11680 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6342,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6342 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11681 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6344,w6588]
theorem b4_11681 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11681 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11681 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6344,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6344 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11682 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6351,w6588]
theorem b4_11682 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11682 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11682 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6351,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6351 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11683 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6352,w6588]
theorem b4_11683 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11683 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11683 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6352,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6352 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11684 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6353,w6588]
theorem b4_11684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11684 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6353,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6353 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11685 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6355,w6588]
theorem b4_11685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11685 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(5,true))] s4_11685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6355,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6355 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11686 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6356,w6588]
theorem b4_11686 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11686 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(5,true))] s4_11686 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6356,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6356 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11687 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6357,w6588]
theorem b4_11687 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11687 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11687 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6357,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6357 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11688 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11688 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11688 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false))] s4_11688 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11689 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11689 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11689 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false))] s4_11689 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11690 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_11690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11690 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(6,true)),(false,(1,false),(0,false))] s4_11690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11691 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11691 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s4_11691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11692 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_11692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11692 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_11692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_11693 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_11693 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11693 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false))] s4_11693 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6859] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6859 rfl))))))))))) (by decide +kernel)
def s4_11694 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_11694 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11694 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(8,true),(2,true)),(false,(1,false),(0,false))] s4_11694 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6897] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6897 rfl))))))))))) (by decide +kernel)
def s4_11695 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_11695 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11695 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false))] s4_11695 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6910] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6910 rfl))))))))))) (by decide +kernel)
def s4_11696 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_11696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11696 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(1,false))] s4_11696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6857] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11697 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_11697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11697 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(9,true),(0,false))] s4_11697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6890] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_11698 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_11698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11698 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(9,true),(1,false))] s4_11698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11699 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_11699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11699 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(5,true),(1,false))] s4_11699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11700 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873]
theorem b4_11700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11700 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_11700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11701 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_11701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11701 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(5,true),(0,false))] s4_11701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_11702 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_11702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11702 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_11702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11703 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6785,w6873]
theorem b4_11703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11703 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_11703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11704 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6553,w6588]
theorem b4_11704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11704 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(0,false))] s4_11704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11705 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6572,w6588]
theorem b4_11705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11705 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s4_11705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11706 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6575,w6588]
theorem b4_11706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11706 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true))] s4_11706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11707 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588,w6748]
theorem b4_11707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11707 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,false),(9,true))] s4_11707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
end NineCert
