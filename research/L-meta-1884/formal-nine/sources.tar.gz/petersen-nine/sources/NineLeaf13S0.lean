import NinePin13
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2474 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w4716,w5147,w5393,w5585,w5956,w6300]
theorem b5_2474 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2474 := by
  intro m le c
  apply rejects_sound r13 i7 10 tgt (small13 adj) hot13 [(false,(0,true),(1,true)),(false,(2,true),(0,true))] s5_2474 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v13_1312,v13_2681,v13_3766,v13_4344,v13_4716,v13_5147,v13_5393,v13_5585,v13_5956,v13_6300] (PetersenWireProjection.cons pc13_1312 (PetersenWireProjection.cons pc13_2681 (PetersenWireProjection.cons pc13_3766 (PetersenWireProjection.cons pc13_4344 (PetersenWireProjection.cons pc13_4716 (PetersenWireProjection.cons pc13_5147 (PetersenWireProjection.cons pc13_5393 (PetersenWireProjection.cons pc13_5585 (PetersenWireProjection.cons pc13_5956 (PetersenWireProjection.cons pc13_6300 rfl)))))))))) (by decide +kernel)
def s5_2531 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5147,w5393,w5585,w5956,w6300,w6813]
theorem b5_2531 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2531 := by
  intro m le c
  apply rejects_sound r13 i7 10 tgt (small13 adj) hot13 [(false,(0,true),(1,true)),(false,(2,true),(0,true))] s5_2531 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v13_1312,v13_3766,v13_4344,v13_4716,v13_5147,v13_5393,v13_5585,v13_5956,v13_6300,v13_6813] (PetersenWireProjection.cons pc13_1312 (PetersenWireProjection.cons pc13_3766 (PetersenWireProjection.cons pc13_4344 (PetersenWireProjection.cons pc13_4716 (PetersenWireProjection.cons pc13_5147 (PetersenWireProjection.cons pc13_5393 (PetersenWireProjection.cons pc13_5585 (PetersenWireProjection.cons pc13_5956 (PetersenWireProjection.cons pc13_6300 (PetersenWireProjection.cons pc13_6813 rfl)))))))))) (by decide +kernel)
end NineCert
