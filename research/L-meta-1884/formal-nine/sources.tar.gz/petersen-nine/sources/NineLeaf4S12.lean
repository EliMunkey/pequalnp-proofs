import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1871 : List (BitVec 512) := [w316,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1871 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s4_1871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1872 : List (BitVec 512) := [w316,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1872 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true)),(false,(6,true),(9,true))] s4_1872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1873 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_1873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1873 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(7,true))] s4_1873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5621,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5621 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1874 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1874 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_1874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1875 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_1875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1875 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s4_1875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1876 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_1876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1876 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true))] s4_1876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1877 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_1877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1877 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(4,true))] s4_1877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6334,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6334 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1878 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_1878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1878 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_1878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1879 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_1879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1879 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_1879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1880 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_1880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1880 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true))] s4_1880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1881 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_1881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1881 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,false),(7,true))] s4_1881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6478,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6478 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1882 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_1882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1882 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s4_1882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1883 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_1883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1883 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s4_1883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1884 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1884 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_1884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_1886 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_1886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1886 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(3,true))] s4_1886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6859] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6859 rfl))))))))))) (by decide +kernel)
def s4_1887 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_1887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1887 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(4,true))] s4_1887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6868] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6868 rfl))))))))))) (by decide +kernel)
def s4_1888 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_1888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1888 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s4_1888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6869] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6869 rfl))))))))))) (by decide +kernel)
def s4_1889 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_1889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1889 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,false),(4,true))] s4_1889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6910] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6910 rfl))))))))))) (by decide +kernel)
def s4_1890 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_1890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1890 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(4,true))] s4_1890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6912] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6912 rfl))))))))))) (by decide +kernel)
def s4_1891 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_1891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1891 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s4_1891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6917] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6917 rfl))))))))))) (by decide +kernel)
def s4_1892 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_1892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1892 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(5,true),(3,true))] s4_1892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1893 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_1893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1893 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(5,true),(3,true))] s4_1893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6857] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_1894 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_1894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1894 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_1894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1895 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_1895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1895 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(8,true),(7,true))] s4_1895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1896 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6857]
theorem b4_1896 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1896 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(8,true),(7,true))] s4_1896 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_1897 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_1897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1897 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(9,true),(8,true))] s4_1897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_1898 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832]
theorem b4_1898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1898 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(5,true)),(false,(9,true),(6,true))] s4_1898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1899 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_1899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1899 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s4_1899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1900 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_1900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1900 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(9,true),(8,true))] s4_1900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_6179,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1901 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_1901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1901 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s4_1901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1902 : List (BitVec 512) := [w316,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_1902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1902 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_1902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1903 : List (BitVec 512) := [w316,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_1903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1903 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(3,true),(7,true))] s4_1903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1904 : List (BitVec 512) := [w316,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6832]
theorem b4_1904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1904 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(7,true),(3,true)),(false,(6,true),(4,true))] s4_1904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_316,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_316 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_1924 : List (BitVec 512) := [w332,w2881,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1924 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(3,false),(0,false))] s4_1924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_332,v4_2881,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_332 (PetersenWireProjection.cons pc4_2881 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1930 : List (BitVec 512) := [w332,w3766,w4344,w4706,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1930 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(3,false),(0,false))] s4_1930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_332,v4_3766,v4_4344,v4_4706,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_332 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4706 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_1953 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_1953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1953 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(3,false),(0,false))] s4_1953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_332,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_332 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_2050 : List (BitVec 512) := [w357,w3766,w4344,w4706,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2050 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2050 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(1,false),(0,true))] s4_2050 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_357,v4_3766,v4_4344,v4_4706,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_357 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4706 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2080 : List (BitVec 512) := [w360,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2080 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2083 : List (BitVec 512) := [w360,w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2083 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2095 : List (BitVec 512) := [w360,w1590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2095 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_1590,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_1590 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2105 : List (BitVec 512) := [w360,w1819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2105 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_1819,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2121 : List (BitVec 512) := [w360,w2087,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2121 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2087,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2087 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2154 : List (BitVec 512) := [w360,w2808,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2154 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2808,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2808 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2155 : List (BitVec 512) := [w360,w2825,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2155 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2155 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2155 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2825,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2825 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2156 : List (BitVec 512) := [w360,w2840,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2156 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2156 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2156 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2840,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2840 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2157 : List (BitVec 512) := [w360,w2864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2157 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2157 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2157 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2864,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2864 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2158 : List (BitVec 512) := [w360,w2881,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2158 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,false))] s4_2158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2881,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2881 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2160 : List (BitVec 512) := [w360,w2945,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2160 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_2945,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_2945 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2205 : List (BitVec 512) := [w360,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2205 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2206 : List (BitVec 512) := [w360,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2206 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2206 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2206 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2207 : List (BitVec 512) := [w360,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2207 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2207 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2207 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2208 : List (BitVec 512) := [w360,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2208 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2208 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2208 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2209 : List (BitVec 512) := [w360,w3766,w4344,w4706,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2209 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4706,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4706 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2210 : List (BitVec 512) := [w360,w3766,w4344,w4716,w4723,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2210 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2210 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2210 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_4723,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4723 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2212 : List (BitVec 512) := [w360,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2212 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2241 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5592,w5956,w6300,w6588]
theorem b4_2241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2241 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5592,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5592 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2258 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_2258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2258 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2269 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_2269 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2269 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2269 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2279 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2279 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2279 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true))] s4_2279 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2287 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_2287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2287 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,false))] s4_2287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_360,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_360 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_2331 : List (BitVec 512) := [w365,w3766,w4344,w4706,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2331 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(4,false),(0,false))] s4_2331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_365,v4_3766,v4_4344,v4_4706,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_365 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4706 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2347 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_2347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2347 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(4,false),(0,false))] s4_2347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_365,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_365 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_2547 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_2547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2547 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(3,true))] s4_2547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4584,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4584 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2548 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b4_2548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2548 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(7,true))] s4_2548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5654,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5654 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
