import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17625 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6155,w6300,w6553,w6588]
theorem b4_17625 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17625 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true))] s4_17625 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6155,v1_6300,v1_6553,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6155 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6553 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_17626 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6155,w6300,w6588,w6859]
theorem b4_17626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17626 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_17626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6155,v1_6300,v1_6588,v1_6859] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6155 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6859 rfl))))))))))) (by decide +kernel)
def s4_17629 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6244,w6300,w6588]
theorem b4_17629 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17629 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(0,false))] s4_17629 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6244,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6244 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_17642 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6244,w6300,w6588]
theorem b4_17642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17642 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6237,v1_6244,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6237 (PetersenWireProjection.cons pc1_6244 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_17650 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6244,w6300,w6588]
theorem b4_17650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17650 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6244,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6244 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_17655 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6504,w6588]
theorem b4_17655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17655 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_17655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6499,v1_6504,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6499 (PetersenWireProjection.cons pc1_6504 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_17661 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6504,w6588]
theorem b4_17661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17661 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_17661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6504,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6504 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_17664 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6581,w6588]
theorem b4_17664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17664 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_17664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6572,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6572 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_17668 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6581,w6588]
theorem b4_17668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17668 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_17668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_17795 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6824]
theorem b4_17795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17795 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(5,true),(4,true))] s4_17795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6824] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6824 rfl))))))))))) (by decide +kernel)
def s4_17796 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6825]
theorem b4_17796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17796 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(3,true))] s4_17796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6825] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6825 rfl))))))))))) (by decide +kernel)
def s4_17803 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6861]
theorem b4_17803 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17803 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,false),(7,true)),(false,(4,true),(5,true))] s4_17803 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6861] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6861 rfl))))))))))) (by decide +kernel)
def s4_17804 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6862]
theorem b4_17804 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17804 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(3,true))] s4_17804 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6862] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6862 rfl))))))))))) (by decide +kernel)
def s4_17813 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6899]
theorem b4_17813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17813 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(5,true))] s4_17813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6899] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6899 rfl))))))))))) (by decide +kernel)
def s4_17814 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6900]
theorem b4_17814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17814 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(5,true),(3,true))] s4_17814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720,v1_6900] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6900 rfl))))))))))) (by decide +kernel)
def s4_17833 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6762,w6857]
theorem b4_17833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17833 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(5,true),(1,false))] s4_17833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6762,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_17834 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6763,w6857]
theorem b4_17834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17834 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(3,true))] s4_17834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6763,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6763 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_17835 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6764,w6832]
theorem b4_17835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17835 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(5,true),(8,true))] s4_17835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6764,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6764 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_17849 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6824,w6832]
theorem b4_17849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17849 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(5,true),(8,true))] s4_17849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6824,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6824 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_17857 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6862]
theorem b4_17857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17857 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(5,true),(3,true))] s4_17857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6832,v1_6862] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6862 rfl))))))))))) (by decide +kernel)
def s4_17862 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6871]
theorem b4_17862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17862 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(3,true))] s4_17862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6832,v1_6871] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6871 rfl))))))))))) (by decide +kernel)
def s4_17866 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6899]
theorem b4_17866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17866 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(8,true))] s4_17866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6832,v1_6899] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6899 rfl))))))))))) (by decide +kernel)
def s4_17872 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6914]
theorem b4_17872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17872 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(3,true))] s4_17872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6832,v1_6914] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6914 rfl))))))))))) (by decide +kernel)
def s4_17883 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6860]
theorem b4_17883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17883 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(5,true),(3,true))] s4_17883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6857,v1_6860] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6857 (PetersenWireProjection.cons pc1_6860 rfl))))))))))) (by decide +kernel)
def s4_17884 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6862]
theorem b4_17884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17884 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(5,true),(1,false))] s4_17884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6857,v1_6862] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6857 (PetersenWireProjection.cons pc1_6862 rfl))))))))))) (by decide +kernel)
def s4_17905 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6748,w6898]
theorem b4_17905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17905 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(5,true),(9,true))] s4_17905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6748,v1_6898] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6748 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_17906 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756,w6821]
theorem b4_17906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17906 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,false),(3,true))] s4_17906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756,v1_6821] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 (PetersenWireProjection.cons pc1_6821 rfl))))))))))) (by decide +kernel)
def s4_17907 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756,w6859]
theorem b4_17907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17907 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,false),(0,false))] s4_17907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756,v1_6859] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 (PetersenWireProjection.cons pc1_6859 rfl))))))))))) (by decide +kernel)
def s4_17908 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756,w6869]
theorem b4_17908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17908 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true))] s4_17908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756,v1_6869] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 (PetersenWireProjection.cons pc1_6869 rfl))))))))))) (by decide +kernel)
def s4_17909 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6756,w6897]
theorem b4_17909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17909 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,false),(9,true))] s4_17909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6756,v1_6897] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 (PetersenWireProjection.cons pc1_6897 rfl))))))))))) (by decide +kernel)
def s4_17910 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6762,w6807]
theorem b4_17910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17910 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(5,true),(4,true))] s4_17910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762,v1_6807] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6807 rfl))))))))))) (by decide +kernel)
def s4_17911 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6762,w6813]
theorem b4_17911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17911 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(3,true))] s4_17911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762,v1_6813] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_17912 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6762,w6852]
theorem b4_17912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17912 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,false),(7,true)),(false,(4,true),(5,true))] s4_17912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762,v1_6852] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6852 rfl))))))))))) (by decide +kernel)
def s4_17913 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6762,w6857]
theorem b4_17913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17913 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(3,true))] s4_17913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_17914 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6762,w6890]
theorem b4_17914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17914 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(5,true))] s4_17914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762,v1_6890] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_17915 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6763,w6890]
theorem b4_17915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17915 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(5,true),(0,false))] s4_17915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6763,v1_6890] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6763 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_17924 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890,w6899]
theorem b4_17924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17924 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(5,true),(0,false))] s4_17924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6890,v1_6899] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6890 (PetersenWireProjection.cons pc1_6899 rfl))))))))))) (by decide +kernel)
def s4_17926 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6899]
theorem b4_17926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17926 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(5,true),(0,false))] s4_17926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6899] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6899 rfl)))))))))) (by decide +kernel)
def s4_17927 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6756,w6857]
theorem b4_17927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17927 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(1,false),(3,true))] s4_17927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6748,v1_6756,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6748 (PetersenWireProjection.cons pc1_6756 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_17928 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6762,w6832]
theorem b4_17928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17928 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(5,true),(8,true))] s4_17928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6748,v1_6762,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6748 (PetersenWireProjection.cons pc1_6762 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_17944 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6720,w6756]
theorem b4_17944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17944 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s4_17944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6389,v1_6522,v1_6720,v1_6756] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_17947 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6748,w6873]
theorem b4_17947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17947 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(5,true),(9,true))] s4_17947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6748,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6748 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17948 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6813,w6873]
theorem b4_17948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17948 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(9,true))] s4_17948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17949 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6857,w6873]
theorem b4_17949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17949 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(9,true))] s4_17949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6857,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6857 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17950 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6873,w6890]
theorem b4_17950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17950 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(5,true))] s4_17950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6873,v1_6890] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_17951 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6873,w6904]
theorem b4_17951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17951 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(6,true)),(false,(4,true),(5,true))] s4_17951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6873,v1_6904] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6904 rfl))))))))))) (by decide +kernel)
def s4_17952 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6720,w6873,w6908]
theorem b4_17952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17952 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(5,true),(4,true))] s4_17952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6720,v1_6873,v1_6908] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_17953 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6807,w6873]
theorem b4_17953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17953 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(9,true))] s4_17953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6807,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6807 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17954 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6813,w6873]
theorem b4_17954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17954 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(9,true))] s4_17954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17955 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6866,w6873]
theorem b4_17955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17955 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(9,true))] s4_17955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6866,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6866 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17956 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6873,w6890]
theorem b4_17956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17956 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(7,true))] s4_17956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6873,v1_6890] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_17957 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6873,w6895]
theorem b4_17957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17957 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(5,true),(7,true))] s4_17957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6873,v1_6895] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6895 rfl))))))))))) (by decide +kernel)
def s4_17958 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6785,w6873,w6908]
theorem b4_17958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17958 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(5,true),(7,true))] s4_17958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6785,v1_6873,v1_6908] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_17959 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6813,w6873]
theorem b4_17959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17959 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(5,true),(1,false))] s4_17959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s4_17970 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6501,w6720,w6873]
theorem b4_17970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17970 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_17970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6464,v1_6501,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17978 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6763,w6873]
theorem b4_17978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17978 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_17978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6464,v1_6720,v1_6763,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6763 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_17985 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6898]
theorem b4_17985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_17985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6464,v1_6720,v1_6873,v1_6898] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_17994 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6501,w6720,w6873]
theorem b4_17994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17994 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_17994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6501,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s4_18002 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6555,w6720,w6873]
theorem b4_18002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18002 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_18002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6555,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_18008 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6898]
theorem b4_18008 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18008 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_18008 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6720,v1_6873,v1_6898] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_18040 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6147,w6300,w6690,w6857]
theorem b4_18040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18040 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(5,true),(3,true))] s4_18040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6690,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_18041 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6154,w6389,w6522,w6588]
theorem b4_18041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18041 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s4_18041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6154,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6154 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_18042 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6154,w6522,w6588,w6873]
theorem b4_18042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18042 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(3,true)),(false,(8,true),(9,true))] s4_18042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6154,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6154 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_18066 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6555,w6588,w6873]
theorem b4_18066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18066 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(3,true)),(false,(8,true),(9,true))] s4_18066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6555,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
end NineCert
