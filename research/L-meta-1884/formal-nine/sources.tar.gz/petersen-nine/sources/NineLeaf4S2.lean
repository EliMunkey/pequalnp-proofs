import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_1132 : List (BitVec 512) := [w1076,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1132 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1132 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_1132 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1133 : List (BitVec 512) := [w1076,w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1133 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1133 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_1133 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1312,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1134 : List (BitVec 512) := [w1076,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1134 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1134 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_1134 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1353,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1135 : List (BitVec 512) := [w1076,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1135 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1135 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_1135 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1136 : List (BitVec 512) := [w1076,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1136 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1136 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_1136 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1137 : List (BitVec 512) := [w1076,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1137 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1137 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_1137 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1403,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1138 : List (BitVec 512) := [w1076,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1138 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1138 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_1138 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1403,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1139 : List (BitVec 512) := [w1076,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1139 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(3,true))] s3_1139 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1599,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1599 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1140 : List (BitVec 512) := [w1076,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1140 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1140 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true))] s3_1140 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1618,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1618 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1141 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1141 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1141 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true))] s3_1141 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1142 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1142 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1142 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true))] s3_1142 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1143 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1143 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1143 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true))] s3_1143 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1144 : List (BitVec 512) := [w1076,w1644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1144 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1144 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(4,true))] s3_1144 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1644,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1644 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1145 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_1145 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1145 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false))] s3_1145 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1146 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1146 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1146 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false))] s3_1146 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1147 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_1147 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1147 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false))] s3_1147 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1148 : List (BitVec 512) := [w1076,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1148 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1148 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s3_1148 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1650,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1650 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1149 : List (BitVec 512) := [w1076,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1149 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1149 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s3_1149 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1650,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1650 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1150 : List (BitVec 512) := [w1076,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1150 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1150 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(4,true))] s3_1150 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1664,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1664 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1151 : List (BitVec 512) := [w1076,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1151 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1151 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(4,true))] s3_1151 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1664,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1664 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl)))))))))))) (by decide +kernel)
def s3_1152 : List (BitVec 512) := [w1076,w1665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1152 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1152 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,false))] s3_1152 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1665,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1665 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1153 : List (BitVec 512) := [w1076,w1668,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1153 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1153 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(4,true))] s3_1153 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1668,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1668 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1154 : List (BitVec 512) := [w1076,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1154 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1154 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true))] s3_1154 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1672,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1672 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1155 : List (BitVec 512) := [w1076,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1155 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1155 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(7,true))] s3_1155 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1832,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1832 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1156 : List (BitVec 512) := [w1076,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1156 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1156 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true))] s3_1156 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1157 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1157 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1157 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s3_1157 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1158 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1158 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1158 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s3_1158 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1159 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1159 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1159 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s3_1159 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1160 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1160 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1160 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s3_1160 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1161 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1161 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1161 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true))] s3_1161 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1162 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1162 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1162 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true))] s3_1162 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1163 : List (BitVec 512) := [w1076,w1892,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1163 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1163 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true))] s3_1163 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1892,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1892 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1164 : List (BitVec 512) := [w1076,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1164 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1164 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true))] s3_1164 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1894,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1894 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1165 : List (BitVec 512) := [w1076,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1165 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1165 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true))] s3_1165 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1166 : List (BitVec 512) := [w1076,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1166 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1166 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true))] s3_1166 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl)))))))))))) (by decide +kernel)
def s3_1167 : List (BitVec 512) := [w1076,w1909,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1167 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1167 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,false))] s3_1167 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1909,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1909 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1168 : List (BitVec 512) := [w1076,w1911,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1168 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1168 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s3_1168 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1911,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1911 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1169 : List (BitVec 512) := [w1076,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1169 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1169 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true))] s3_1169 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1170 : List (BitVec 512) := [w1076,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_1170 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1170 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true))] s3_1170 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))))) (by decide +kernel)
def s3_1171 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_1171 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1171 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s3_1171 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1172 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_1172 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1172 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s3_1172 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1173 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b3_1173 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1173 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s3_1173 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1174 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_1174 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1174 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s3_1174 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s3_1175 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b3_1175 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1175 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s3_1175 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s3_1176 : List (BitVec 512) := [w1076,w2819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1176 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1176 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_1176 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2819,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1177 : List (BitVec 512) := [w1076,w2836,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1177 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1177 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s3_1177 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2836,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2836 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1178 : List (BitVec 512) := [w1076,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1178 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1178 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1178 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1179 : List (BitVec 512) := [w1076,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1179 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1179 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1179 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1180 : List (BitVec 512) := [w1076,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1180 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1180 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1180 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2852,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1181 : List (BitVec 512) := [w1076,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1181 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1181 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1181 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2852,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1182 : List (BitVec 512) := [w1076,w2852,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1182 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1182 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1182 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2852,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1183 : List (BitVec 512) := [w1076,w2852,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1183 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1183 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1183 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2852,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1184 : List (BitVec 512) := [w1076,w2878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1184 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1184 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s3_1184 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2878,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1185 : List (BitVec 512) := [w1076,w2878,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1185 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1185 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s3_1185 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2878,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl)))))))))))) (by decide +kernel)
def s3_1186 : List (BitVec 512) := [w1076,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1186 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1186 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s3_1186 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2878,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1187 : List (BitVec 512) := [w1076,w2878,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1187 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1187 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s3_1187 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2878,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s3_1188 : List (BitVec 512) := [w1076,w2879,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1188 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1188 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_1188 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2879,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2879 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1189 : List (BitVec 512) := [w1076,w2879,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1189 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1189 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_1189 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2879,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2879 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1190 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1190 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1190 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_1190 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1191 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_1191 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1191 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s3_1191 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1192 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1192 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1192 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1192 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1193 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_1193 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1193 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1193 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1194 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_1194 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1194 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s3_1194 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1195 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_1195 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1195 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s3_1195 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
