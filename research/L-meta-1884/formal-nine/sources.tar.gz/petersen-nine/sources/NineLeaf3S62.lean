import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_15405 : List (BitVec 512) := [w3766,w4225,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6353,w6588]
theorem b4_15405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15405 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_15405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4225,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6353,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4225 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6353 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15406 : List (BitVec 512) := [w3766,w4225,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15406 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4225,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4225 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15407 : List (BitVec 512) := [w3766,w4228,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6356,w6588]
theorem b4_15407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15407 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))] s4_15407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4228,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6356,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4228 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6356 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15408 : List (BitVec 512) := [w3766,w4228,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15408 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4228,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4228 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15409 : List (BitVec 512) := [w3766,w4229,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6357,w6588]
theorem b4_15409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15409 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s4_15409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4229,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6357,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4229 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6357 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15410 : List (BitVec 512) := [w3766,w4229,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15410 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4229,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4229 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15411 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6351,w6588]
theorem b4_15411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15411 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(0,true),(7,true))] s4_15411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6351,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6351 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15412 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6352,w6588]
theorem b4_15412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15412 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(4,true)),(false,(0,true),(7,true))] s4_15412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6352,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6352 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15413 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6355,w6588]
theorem b4_15413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15413 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,true),(7,true))] s4_15413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6355,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6355 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15414 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15414 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15415 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_15415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15415 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_15416 : List (BitVec 512) := [w3766,w4231,w4716,w5135,w5393,w5585,w5956,w6300,w6355,w6588,w6690]
theorem b4_15416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15416 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,true),(7,true))] s4_15416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6355,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6355 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_15417 : List (BitVec 512) := [w3766,w4231,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_15417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15417 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_15418 : List (BitVec 512) := [w3766,w4236,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_15418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15418 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4236,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4236 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15419 : List (BitVec 512) := [w3766,w4236,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6365,w6588]
theorem b4_15419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15419 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_15419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4236,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6365,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4236 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6365 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15420 : List (BitVec 512) := [w3766,w4236,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15420 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4236,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4236 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15421 : List (BitVec 512) := [w3766,w4239,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6367,w6588]
theorem b4_15421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15421 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_15421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4239,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6367,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4239 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6367 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15422 : List (BitVec 512) := [w3766,w4239,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15422 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4239,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4239 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15423 : List (BitVec 512) := [w3766,w4240,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6368,w6588]
theorem b4_15423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15423 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_15423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4240,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6368,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4240 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6368 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15424 : List (BitVec 512) := [w3766,w4240,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15424 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4240,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4240 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15425 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6363,w6588]
theorem b4_15425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15425 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(0,true),(7,true))] s4_15425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6363,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6363 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15426 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6364,w6588]
theorem b4_15426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15426 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(7,true))] s4_15426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6364,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6364 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15427 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6366,w6588]
theorem b4_15427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15427 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(7,true))] s4_15427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6366,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6366 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15428 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15428 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15429 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_15429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15429 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_15430 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6389,w6588]
theorem b4_15430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15430 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15431 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_15431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15431 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15432 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_15432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15432 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s4_15432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15433 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_15433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15433 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(5,true))] s4_15433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6499,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6499 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15434 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_15434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15434 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_15434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6553,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6553 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15435 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_15435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15435 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(6,true))] s4_15435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6575,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6575 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15436 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15436 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15437 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_15437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15437 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s4_15437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_15438 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_15438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15438 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_15438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_15439 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_15439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15439 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(8,true))] s4_15439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_15440 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_15440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15440 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6897 rfl))))))))))) (by decide +kernel)
def s4_15441 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_15441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15441 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,false),(6,true))] s4_15441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6906] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6906 rfl))))))))))) (by decide +kernel)
def s4_15442 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_15442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15442 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,false),(7,true))] s4_15442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6912] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6912 rfl))))))))))) (by decide +kernel)
def s4_15443 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_15443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15443 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_15443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15444 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6478,w6588]
theorem b4_15444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15444 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s4_15444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15445 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6489,w6588]
theorem b4_15445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15445 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s4_15445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15446 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6543,w6588]
theorem b4_15446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15446 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_15446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15447 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_15447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15447 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_15447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15448 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6785]
theorem b4_15448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15448 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_15448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15449 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6832]
theorem b4_15449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15449 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true))] s4_15449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15450 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6890]
theorem b4_15450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15450 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_15450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15451 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588,w6895]
theorem b4_15451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15451 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15452 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_15452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15452 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(6,true),(8,true))] s4_15452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15453 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_15453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15453 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15454 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6785]
theorem b4_15454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15454 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(5,true),(8,true))] s4_15454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15455 : List (BitVec 512) := [w3766,w4243,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6436,w6588]
theorem b4_15455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15455 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s4_15455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15456 : List (BitVec 512) := [w3766,w4243,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_15456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15456 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(3,true),(6,true))] s4_15456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15457 : List (BitVec 512) := [w3766,w4243,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b4_15457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15457 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(7,true))] s4_15457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15458 : List (BitVec 512) := [w3766,w4243,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_15458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15458 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s4_15458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15459 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6436,w6588]
theorem b4_15459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15459 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(5,true),(6,true))] s4_15459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15460 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6179,w6389,w6422,w6588]
theorem b4_15460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15460 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(6,true),(5,true))] s4_15460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15461 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588,w6785]
theorem b4_15461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15461 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(5,true))] s4_15461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15462 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588,w6832]
theorem b4_15462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15462 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(6,true))] s4_15462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_15463 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6478,w6588]
theorem b4_15463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15463 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(7,true),(2,true))] s4_15463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15464 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6489,w6588]
theorem b4_15464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15464 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s4_15464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15465 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6543,w6588]
theorem b4_15465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15465 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(7,true),(2,true))] s4_15465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15466 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6549,w6588]
theorem b4_15466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15466 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_15466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15467 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588,w6785]
theorem b4_15467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15467 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(7,true),(2,true))] s4_15467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15468 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588,w6832]
theorem b4_15468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15468 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(7,true),(2,true))] s4_15468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
end NineCert
