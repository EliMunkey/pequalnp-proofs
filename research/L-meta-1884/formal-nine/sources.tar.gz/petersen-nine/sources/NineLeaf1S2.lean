import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_1332 : List (BitVec 512) := [w1119,w2797,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1332 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1332 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1332 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_2797,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_2797 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1356 : List (BitVec 512) := [w1119,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1356 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1356 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1356 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1364 : List (BitVec 512) := [w1119,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1364 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1364 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1364 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1384 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1384 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1384 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1384 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1385 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1385 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1385 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1385 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1386 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1386 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1386 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1386 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1387 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1387 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1387 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1387 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1388 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1388 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1388 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1388 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1389 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5083,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1389 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1389 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1389 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5083,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5083 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1390 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5166,w5393,w5585,w5956,w6300,w6588]
theorem b3_1390 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1390 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1390 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5166,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5166 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1392 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b3_1392 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1392 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1392 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1393 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b3_1393 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1393 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1393 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1403 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b3_1403 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1403 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1403 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1413 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b3_1413 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1413 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1413 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1423 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b3_1423 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1423 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1423 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1433 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b3_1433 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1433 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1433 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1444 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b3_1444 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1444 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1444 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s3_1457 : List (BitVec 512) := [w1119,w3766,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b3_1457 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1457 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true))] s3_1457 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1458 : List (BitVec 512) := [w1151,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1458 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1458 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true))] s3_1458 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1459 : List (BitVec 512) := [w1151,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1459 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1459 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s3_1459 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1460 : List (BitVec 512) := [w1153,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1460 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1460 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s3_1460 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1461 : List (BitVec 512) := [w1153,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1461 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1461 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s3_1461 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1462 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1462 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1462 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true))] s3_1462 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1463 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1463 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1463 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s3_1463 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1464 : List (BitVec 512) := [w1156,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1464 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1464 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_1464 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1156,v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1156 (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1465 : List (BitVec 512) := [w1156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1465 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1465 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s3_1465 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1156,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1156 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1466 : List (BitVec 512) := [w1159,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1466 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1466 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1466 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1467 : List (BitVec 512) := [w1159,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1467 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1467 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1467 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1468 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1468 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1468 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true))] s3_1468 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1469 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1469 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1469 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s3_1469 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1470 : List (BitVec 512) := [w1164,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1470 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1470 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_1470 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1471 : List (BitVec 512) := [w1164,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1471 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1471 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_1471 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1472 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1472 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1472 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true))] s3_1472 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1473 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1473 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1473 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s3_1473 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s3_1474 : List (BitVec 512) := [w1170,w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1474 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1474 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true))] s3_1474 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1475 : List (BitVec 512) := [w1170,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1475 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1475 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s3_1475 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1476 : List (BitVec 512) := [w1170,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1476 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1476 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s3_1476 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1477 : List (BitVec 512) := [w1170,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1477 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1477 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s3_1477 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1478 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b3_1478 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1478 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1478 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s3_1479 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1479 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1479 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1479 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1480 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b3_1480 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1480 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1480 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s3_1481 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1481 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1481 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s3_1481 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1482 : List (BitVec 512) := [w1170,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1482 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1482 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_1482 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1483 : List (BitVec 512) := [w1170,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1483 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1483 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s3_1483 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1484 : List (BitVec 512) := [w1170,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1484 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1484 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_1484 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1599,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1599 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1485 : List (BitVec 512) := [w1170,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1485 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1485 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1485 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1618,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1618 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1486 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1486 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1486 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_1486 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1487 : List (BitVec 512) := [w1170,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1487 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1487 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_1487 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1488 : List (BitVec 512) := [w1170,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_1488 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1488 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true))] s3_1488 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1489 : List (BitVec 512) := [w1170,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1489 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1489 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true))] s3_1489 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1490 : List (BitVec 512) := [w1170,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1490 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1490 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_1490 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1491 : List (BitVec 512) := [w1170,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1491 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1491 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_1491 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1492 : List (BitVec 512) := [w1170,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1492 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1492 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_1492 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1493 : List (BitVec 512) := [w1170,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1493 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1493 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_1493 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))))) (by decide +kernel)
def s3_1494 : List (BitVec 512) := [w1170,w1665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1494 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1494 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(0,true))] s3_1494 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1665,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1665 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1495 : List (BitVec 512) := [w1170,w1668,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1495 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1495 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,true),(8,true))] s3_1495 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1668,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1668 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1496 : List (BitVec 512) := [w1170,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1496 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1496 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(7,true))] s3_1496 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1832,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1832 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1497 : List (BitVec 512) := [w1170,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1497 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1497 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,true))] s3_1497 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1867,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1867 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1498 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1498 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1498 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true))] s3_1498 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1499 : List (BitVec 512) := [w1170,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1499 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1499 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true))] s3_1499 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1500 : List (BitVec 512) := [w1170,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1500 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1500 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true))] s3_1500 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1891,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1891 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl)))))))))))) (by decide +kernel)
def s3_1501 : List (BitVec 512) := [w1170,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1501 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1501 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true))] s3_1501 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1891,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1891 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1502 : List (BitVec 512) := [w1170,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1502 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1502 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(7,true))] s3_1502 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1908,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s3_1503 : List (BitVec 512) := [w1170,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_1503 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1503 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(7,true))] s3_1503 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1908,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl)))))))))))) (by decide +kernel)
end NineCert
