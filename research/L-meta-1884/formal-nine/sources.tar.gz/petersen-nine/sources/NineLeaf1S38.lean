import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1124 : List (BitVec 512) := [w895,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1124 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1124 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1124 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_895,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_895 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1125 : List (BitVec 512) := [w896,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1125 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1125 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1125 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_896,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_896 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1126 : List (BitVec 512) := [w898,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1126 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1126 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1126 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_898,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_898 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1127 : List (BitVec 512) := [w899,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1127 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_899,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_899 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1513 : List (BitVec 512) := [w985,w2555,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1513 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1513 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1513 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_985,v1_2555,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_985 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1518 : List (BitVec 512) := [w985,w3766,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b5_1518 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1518 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1518 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_985,v1_3766,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_985 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1571 : List (BitVec 512) := [w1009,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1571 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1571 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1571 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1009,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1009 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1572 : List (BitVec 512) := [w1010,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1572 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1572 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1572 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1010,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1010 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1573 : List (BitVec 512) := [w1011,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1573 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1011,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1011 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1578 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5090,w5393,w5585,w5956,w6300,w6588]
theorem b5_1578 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1578 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1578 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1022,v1_3766,v1_4344,v1_4716,v1_5090,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1022 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5090 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1587 : List (BitVec 512) := [w1025,w3766,w4344,w4716,w5089,w5393,w5585,w5956,w6300,w6588]
theorem b5_1587 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1587 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1587 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1025,v1_3766,v1_4344,v1_4716,v1_5089,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1025 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5089 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1593 : List (BitVec 512) := [w1026,w3766,w4344,w4716,w5088,w5393,w5585,w5956,w6300,w6588]
theorem b5_1593 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1593 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_1593 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1026,v1_3766,v1_4344,v1_4716,v1_5088,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1026 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5088 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1601 : List (BitVec 512) := [w1028,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1601 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1601 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1601 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1028,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1028 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1602 : List (BitVec 512) := [w1029,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1602 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1602 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1602 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1029,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1029 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1603 : List (BitVec 512) := [w1033,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1603 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1603 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1603 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1033,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1033 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1604 : List (BitVec 512) := [w1034,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1604 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1604 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1604 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1034,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1034 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1605 : List (BitVec 512) := [w1036,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1605 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1605 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1605 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1036,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1036 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1606 : List (BitVec 512) := [w1037,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1606 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1606 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_1606 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1037,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1037 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1879 : List (BitVec 512) := [w1101,w2180,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1879 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1879 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_1879 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1101,v1_2180,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1101 (PetersenWireProjection.cons pc1_2180 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1888 : List (BitVec 512) := [w1101,w3766,w4344,w4716,w5135,w5197,w5585,w5956,w6300,w6588]
theorem b5_1888 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1888 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_1888 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1101,v1_3766,v1_4344,v1_4716,v1_5135,v1_5197,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1101 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5197 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1889 : List (BitVec 512) := [w1105,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1889 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1889 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1889 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1105,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1105 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1904 : List (BitVec 512) := [w1119,w2468,w2555,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1904 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1904 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_1904 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_2468,v1_2555,v1_3766,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1911 : List (BitVec 512) := [w1119,w2468,w3766,w4716,w5135,w5205,w5585,w5956,w6300,w6588]
theorem b5_1911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1911 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_1911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_2468,v1_3766,v1_4716,v1_5135,v1_5205,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1916 : List (BitVec 512) := [w1119,w2555,w3766,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1916 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(5,true),(9,true))] s5_1916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_2555,v1_3766,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1917 : List (BitVec 512) := [w1119,w2659,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1917 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(5,true),(9,true))] s5_1917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_2659,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_2659 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1963 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6555,w6588]
theorem b5_1963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1963 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(5,true),(9,true))] s5_1963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6555,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1969 : List (BitVec 512) := [w1119,w3766,w5135,w5205,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1969 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1969 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(5,true),(9,true))] s5_1969 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1119,v1_3766,v1_5135,v1_5205,v1_5393,v1_5585,v1_6101,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1119 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1983 : List (BitVec 512) := [w1130,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1983 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1983 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1983 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1130,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1130 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1984 : List (BitVec 512) := [w1131,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1984 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1984 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1984 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1131,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1131 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1985 : List (BitVec 512) := [w1133,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1985 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1985 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1133,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1133 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1986 : List (BitVec 512) := [w1136,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1986 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1986 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1136,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1136 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1987 : List (BitVec 512) := [w1137,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1987 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1987 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1987 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1137,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1137 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1988 : List (BitVec 512) := [w1138,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1988 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1988 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1988 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1138,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1138 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1989 : List (BitVec 512) := [w1139,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1989 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1989 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1139,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1139 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1990 : List (BitVec 512) := [w1140,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1990 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1990 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s5_1990 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1140,v1_3901,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1140 (PetersenWireProjection.cons pc1_3901 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1991 : List (BitVec 512) := [w1142,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1991 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1991 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1991 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1142,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1142 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1992 : List (BitVec 512) := [w1143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1992 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1992 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1992 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1143,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1143 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1993 : List (BitVec 512) := [w1144,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1993 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1993 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_1993 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1144,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1144 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1994 : List (BitVec 512) := [w1146,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1994 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1994 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1994 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1146,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1146 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1995 : List (BitVec 512) := [w1147,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1995 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1995 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1995 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1147,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1147 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1996 : List (BitVec 512) := [w1148,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1996 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1996 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1148,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1148 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1997 : List (BitVec 512) := [w1149,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1997 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1149,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1149 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1998 : List (BitVec 512) := [w1150,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1998 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1150,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1150 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1999 : List (BitVec 512) := [w1151,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1999 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2000 : List (BitVec 512) := [w1152,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2000 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2000 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2000 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1152,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1152 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2001 : List (BitVec 512) := [w1153,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2001 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2001 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_2001 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2002 : List (BitVec 512) := [w1153,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2002 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2002 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_2002 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3197,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3197 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2003 : List (BitVec 512) := [w1153,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2003 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2003 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(2,true),(0,false)),(false,(2,true),(0,true))] s5_2003 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2004 : List (BitVec 512) := [w1154,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2004 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2004 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2004 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1154,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1154 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2005 : List (BitVec 512) := [w1155,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2005 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2005 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s5_2005 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2006 : List (BitVec 512) := [w1155,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2006 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2006 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s5_2006 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2007 : List (BitVec 512) := [w1157,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2007 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2007 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2007 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1157,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1157 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2008 : List (BitVec 512) := [w1159,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2008 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2008 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true)),(false,(7,true),(0,true))] s5_2008 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_2443,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_2443 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2009 : List (BitVec 512) := [w1159,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2009 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2009 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s5_2009 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_2494,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2010 : List (BitVec 512) := [w1160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2010 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2010 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2010 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1160,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1160 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2011 : List (BitVec 512) := [w1161,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2011 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2011 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s5_2011 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2012 : List (BitVec 512) := [w1161,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2012 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2012 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s5_2012 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3293,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2013 : List (BitVec 512) := [w1163,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2013 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2013 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2013 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1163,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1163 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2014 : List (BitVec 512) := [w1164,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2014 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2014 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_2014 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2015 : List (BitVec 512) := [w1165,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2015 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2015 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2015 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1165,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1165 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2016 : List (BitVec 512) := [w1167,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2016 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2016 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s5_2016 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2017 : List (BitVec 512) := [w1167,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2017 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2017 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true))] s5_2017 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3303,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3303 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2018 : List (BitVec 512) := [w1168,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2018 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2018 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2018 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1168,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1168 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_2019 : List (BitVec 512) := [w1169,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2019 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2019 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_2019 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1169,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1169 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
end NineCert
