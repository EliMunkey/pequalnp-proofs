import NinePin112
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4651 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6237,w6300,w6588]
theorem b3_4651 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4651 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4651 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6237,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))))) (by decide +kernel)
def s3_4656 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6499,w6588]
theorem b3_4656 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4656 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4656 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl)))))))))))) (by decide +kernel)
def s3_4661 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6821]
theorem b3_4661 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4661 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4661 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6821] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6821 rfl)))))))))))) (by decide +kernel)
def s3_4830 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6237,w6300,w6588]
theorem b3_4830 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4830 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4830 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5848,v112_5956,v112_6237,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))))) (by decide +kernel)
def s3_4832 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6499,w6588]
theorem b3_4832 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4832 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4832 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5848,v112_5956,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl)))))))))))) (by decide +kernel)
def s3_4837 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588,w6821]
theorem b3_4837 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4837 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s3_4837 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5848,v112_5956,v112_6300,v112_6588,v112_6821] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6821 rfl)))))))))))) (by decide +kernel)
def s4_658 : List (BitVec 512) := [w75,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_658 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_75,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6690] (PetersenWireProjection.cons pc112_75 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_659 : List (BitVec 512) := [w75,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_659 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_75,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6890] (PetersenWireProjection.cons pc112_75 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_8330 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b4_8330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8330 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8374 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6821]
theorem b4_8374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8374 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8394 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6748]
theorem b4_8394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8394 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6748] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6748 rfl))))))))))) (by decide +kernel)
def s4_8396 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6807]
theorem b4_8396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8396 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6807] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 rfl))))))))))) (by decide +kernel)
def s4_8398 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6821]
theorem b4_8398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8398 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8450 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6821]
theorem b4_8450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8450 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8454 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6821]
theorem b4_8454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8454 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6748,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6748 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8458 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6821]
theorem b4_8458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8458 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6807,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 (PetersenWireProjection.cons pc112_6821 rfl))))))))))) (by decide +kernel)
def s4_8478 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6690]
theorem b4_8478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8478 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_8478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5848,v112_5956,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_9453 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6868]
theorem b4_9453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9453 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9474 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6868]
theorem b4_9474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9474 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6061,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9500 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6807]
theorem b4_9500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9500 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6807] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 rfl))))))))))) (by decide +kernel)
def s4_9502 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6852]
theorem b4_9502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9502 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6852] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6852 rfl))))))))))) (by decide +kernel)
def s4_9504 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6868]
theorem b4_9504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9504 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9540 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6868]
theorem b4_9540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9540 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9545 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6868]
theorem b4_9545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9545 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6807,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9549 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6868]
theorem b4_9549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9549 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6852,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6852 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_9570 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6690]
theorem b4_9570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9570 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_9574 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6690]
theorem b4_9574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9574 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_9574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6061,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_10132 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6905]
theorem b4_10132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10132 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690,v112_6905] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10133 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6910]
theorem b4_10133 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10133 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10133 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690,v112_6910] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 (PetersenWireProjection.cons pc112_6910 rfl))))))))))) (by decide +kernel)
def s4_10138 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6890]
theorem b4_10138 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10138 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10138 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6807,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_10139 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6890]
theorem b4_10139 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10139 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10139 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6852,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6852 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_10143 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890,w6905]
theorem b4_10143 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10143 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10143 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6890,v112_6905] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6890 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10479 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6905]
theorem b4_10479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10479 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6300,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10510 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6890]
theorem b4_10510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10510 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6389,v112_6890] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_10511 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6905]
theorem b4_10511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10511 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6389,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10533 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6807]
theorem b4_10533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10533 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6478,v112_6807] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6807 rfl))))))))))) (by decide +kernel)
def s4_10535 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6890]
theorem b4_10535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10535 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6478,v112_6890] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_10537 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6905]
theorem b4_10537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10537 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6478,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10563 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6905]
theorem b4_10563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10563 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10567 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6905]
theorem b4_10567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10567 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6807,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6807 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10571 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890,w6905]
theorem b4_10571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10571 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6890,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6890 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_10593 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6690]
theorem b4_10593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10593 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_10593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6300,v112_6478,v112_6690] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_12874 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6553,w6588]
theorem b4_12874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12874 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12876 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6572,w6588]
theorem b4_12876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12876 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12887 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588,w6910]
theorem b4_12887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12887 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6588,v112_6910] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6910 rfl))))))))))) (by decide +kernel)
def s4_12895 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6136,w6300,w6543,w6588]
theorem b4_12895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12895 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6136,v112_6300,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12905 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6543,w6588]
theorem b4_12905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12905 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6201,v112_6300,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12926 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6478,w6588]
theorem b4_12926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12926 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6478,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12931 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6553,w6588]
theorem b4_12931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12931 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12933 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6572,w6588]
theorem b4_12933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12933 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12943 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588,w6890]
theorem b4_12943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12943 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6588,v112_6890] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_12944 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588,w6910]
theorem b4_12944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12944 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6588,v112_6910] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6910 rfl))))))))))) (by decide +kernel)
def s4_12951 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6436,w6543,w6588]
theorem b4_12951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12951 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6436,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6436 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12959 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6478,w6543,w6588]
theorem b4_12959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12959 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6478,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12969 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6553,w6588]
theorem b4_12969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12969 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12972 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6572,w6588]
theorem b4_12972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12972 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_12981 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6852]
theorem b4_12981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12981 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6588,v112_6852] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6852 rfl))))))))))) (by decide +kernel)
def s4_12983 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6890]
theorem b4_12983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12983 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6588,v112_6890] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6890 rfl))))))))))) (by decide +kernel)
def s4_12985 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588,w6910]
theorem b4_12985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12985 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_12985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6588,v112_6910] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6910 rfl))))))))))) (by decide +kernel)
def s4_13023 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b4_13023 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13023 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13023 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_4926,v112_5135,v112_5585,v112_5956,v112_6300,v112_6389,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13027 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6389,w6543,w6588]
theorem b4_13027 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13027 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13027 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_5135,v112_5585,v112_5698,v112_5956,v112_6300,v112_6389,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13029 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6543,w6588,w6690]
theorem b4_13029 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13029 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13029 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6543,v112_6588,v112_6690] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6690 rfl))))))))))) (by decide +kernel)
def s4_13032 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6553,w6588]
theorem b4_13032 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13032 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13032 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5585,v112_5956,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13041 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6553,w6588]
theorem b4_13041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13041 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
end NineCert
