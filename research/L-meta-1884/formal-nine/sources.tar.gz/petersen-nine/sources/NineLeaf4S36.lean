import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3036 : List (BitVec 512) := [w1388,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3036 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_3036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_3059 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3059 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3059 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_3059 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1390,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1390 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_3139 : List (BitVec 512) := [w1403,w3766,w4344,w4674,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_3139 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s5_3139 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4674,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3173 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6522,w6588]
theorem b5_3173 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3173 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s5_3173 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3240 : List (BitVec 512) := [w1411,w3766,w4344,w4750,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3240 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3240 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s5_3240 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4750,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4750 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_3314 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3314 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3314 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(6,true),(0,true))] s5_3314 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1417,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1417 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_3645 : List (BitVec 512) := [w2381,w3766,w4344,w4652,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3645 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true)),(false,(8,true),(0,true))] s5_3645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2381,v4_3766,v4_4344,v4_4652,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2381 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4652 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3646 : List (BitVec 512) := [w2381,w3766,w4344,w4663,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3646 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3646 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true)),(false,(8,true),(0,true))] s5_3646 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2381,v4_3766,v4_4344,v4_4663,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2381 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4663 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3676 : List (BitVec 512) := [w2382,w3766,w4344,w4665,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3676 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3676 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3676 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2382,v4_3766,v4_4344,v4_4665,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2382 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4665 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3684 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6113,w6300,w6588]
theorem b5_3684 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3684 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3684 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2382,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6113,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2382 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6113 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3701 : List (BitVec 512) := [w2387,w3766,w4344,w4647,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3701 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3701 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true)),(false,(8,true),(0,true))] s5_3701 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2387,v4_3766,v4_4344,v4_4647,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2387 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4647 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3702 : List (BitVec 512) := [w2387,w3766,w4344,w4664,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3702 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3702 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true)),(false,(8,true),(0,true))] s5_3702 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2387,v4_3766,v4_4344,v4_4664,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2387 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4664 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3837 : List (BitVec 512) := [w2468,w2473,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3837 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3837 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_3837 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2473,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2473 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3863 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4644,w4716,w5585,w5956,w6300,w6588]
theorem b5_3863 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3863 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3863 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4644,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4644 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3864 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4659,w4716,w5585,w5956,w6300,w6588]
theorem b5_3864 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3864 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3864 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4659,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3865 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4669,w4716,w5585,w5956,w6300,w6588]
theorem b5_3865 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3865 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3865 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4669,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3866 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4674,w4716,w5585,w5956,w6300,w6588]
theorem b5_3866 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3866 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3866 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4674,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3867 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4678,w4716,w5585,w5956,w6300,w6588]
theorem b5_3867 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3867 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3867 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4678,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3868 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4678,w4716,w5585,w5956,w6300,w6720]
theorem b5_3868 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3868 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_3868 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4678,v4_4716,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_3869 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w4800,w5585,w5956,w6300,w6588]
theorem b5_3869 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3869 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3869 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_4800,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4800 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3872 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w4926,w5585,w5956,w6300,w6588]
theorem b5_3872 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3872 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3872 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_4926,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3876 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5769,w5956,w6300,w6588]
theorem b5_3876 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3876 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_3876 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3877 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6101,w6300,w6588]
theorem b5_3877 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3877 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3877 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3878 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6422,w6588]
theorem b5_3878 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3878 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3878 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3884 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6549,w6588]
theorem b5_3884 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3884 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(2,true),(6,false))] s5_3884 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3992 : List (BitVec 512) := [w2468,w3766,w3939,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3992 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3992 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_3992 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_3995 : List (BitVec 512) := [w2468,w3766,w3959,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3995 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3995 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_3995 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_3959,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3959 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4102 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4964,w5135,w5585,w5956,w6300,w6588]
theorem b5_4102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4102 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s5_4102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_4964,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4964 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4139 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5802,w5956,w6300,w6588]
theorem b5_4139 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s5_4139 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5802,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5802 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4232 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6718,w6873]
theorem b5_4232 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4232 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_4232 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6522,v4_6718,v4_6873] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6718 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_4241 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6088,w6389,w6522,w6588]
theorem b5_4241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4241 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s5_4241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6088,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4242 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6088,w6522,w6588,w6873]
theorem b5_4242 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4242 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_4242 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6088,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_4245 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6522,w6720,w6873]
theorem b5_4245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4245 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_4245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6101,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_4343 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w4716,w5135,w5769,w5956,w6300,w6588]
theorem b5_4343 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4343 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4343 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4344 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_4344 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4344 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4344 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4345 : List (BitVec 512) := [w2488,w3766,w4344,w4650,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4345 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4345 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4345 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4650,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4650 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4347 : List (BitVec 512) := [w2488,w3766,w4344,w4652,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4347 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4347 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4347 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4652,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4652 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4349 : List (BitVec 512) := [w2488,w3766,w4344,w4659,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4349 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4349 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4349 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4351 : List (BitVec 512) := [w2488,w3766,w4344,w4666,w4716,w5135,w5585,w6101,w6300,w6588]
theorem b5_4351 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4351 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4351 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4352 : List (BitVec 512) := [w2488,w3766,w4344,w4666,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_4352 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4352 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4352 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4666,v4_5135,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4353 : List (BitVec 512) := [w2488,w3766,w4344,w4668,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4353 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4353 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4353 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4668,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4668 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4354 : List (BitVec 512) := [w2488,w3766,w4344,w4669,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4354 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4354 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4354 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4355 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w4716,w5135,w5585,w5956,w6422,w6588]
theorem b5_4355 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4355 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4355 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5585,v4_5956,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4356 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_4356 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4356 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4356 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_4357 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w5135,w5585,w5956,w6389,w6422,w6588]
theorem b5_4357 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4357 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4357 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_5135,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4358 : List (BitVec 512) := [w2488,w3766,w4344,w4673,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4358 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4358 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4358 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4673,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4673 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4359 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w4716,w5135,w5585,w6101,w6300,w6588]
theorem b5_4359 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4359 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4359 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_4716,v4_5135,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4360 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_4360 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4360 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4360 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_4361 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_4361 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4361 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4361 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_5135,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4362 : List (BitVec 512) := [w2488,w3766,w4344,w4677,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4362 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4362 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4362 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4677,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4677 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4363 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_4363 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4363 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4363 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_4364 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_4364 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4364 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4364 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_4365 : List (BitVec 512) := [w2488,w3766,w4344,w4680,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4365 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4365 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4365 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4680,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4680 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4366 : List (BitVec 512) := [w2488,w3766,w4344,w4682,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4366 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4366 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4366 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4682,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4367 : List (BitVec 512) := [w2488,w3766,w4344,w4704,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4367 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4367 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4367 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4704,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4368 : List (BitVec 512) := [w2488,w3766,w4344,w4708,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4368 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4368 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4368 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4708,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4708 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4369 : List (BitVec 512) := [w2488,w3766,w4344,w4712,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4369 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4369 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4369 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4712,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4712 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4370 : List (BitVec 512) := [w2488,w3766,w4344,w4715,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4370 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4370 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4370 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4715,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4715 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4458 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6033,w6300,w6588]
theorem b5_4458 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4458 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4458 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6033,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6033 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4483 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6364,w6588]
theorem b5_4483 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4483 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4483 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6364,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6364 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4487 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6436,w6588]
theorem b5_4487 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4487 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4487 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4502 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6553,w6588]
theorem b5_4502 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4502 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4502 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6553,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6553 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4564 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6089,w6101,w6300,w6588]
theorem b5_4564 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4564 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4564 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6089,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6089 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4565 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6089,w6300,w6543,w6588]
theorem b5_4565 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4565 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4565 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6089,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6089 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
