import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12423 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5730,w5956,w6300,w6522,w6588]
theorem b4_12423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12423 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5730,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12424 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5730,w5956,w6300,w6588]
theorem b4_12424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12424 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5730,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12437 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5810,w5956,w6300,w6588]
theorem b4_12437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12437 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12443 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6048,w6300,w6588]
theorem b4_12443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12443 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12448 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6377,w6588]
theorem b4_12448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12448 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12452 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b4_12452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12452 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12453 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6538,w6588]
theorem b4_12453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12453 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12463 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5810,w5956,w6300,w6522,w6588]
theorem b4_12463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12463 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5810,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12464 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5810,w5956,w6300,w6588]
theorem b4_12464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12464 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12476 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6543,w6588]
theorem b4_12476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12476 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12477 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6549,w6588]
theorem b4_12477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12477 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12478 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6567,w6588]
theorem b4_12478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12478 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12479 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6300,w6588,w6908]
theorem b4_12479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12479 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_12480 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6389,w6522,w6588]
theorem b4_12480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12480 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12481 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6048,w6522,w6588,w6873]
theorem b4_12481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6048,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12504 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b4_12504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12504 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12508 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6667,w6690]
theorem b4_12508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12508 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(9,true))] s4_12508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6667,v0_6690] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_12509 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6667,w6785]
theorem b4_12509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12509 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6667,v0_6785] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_12515 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6546,w6588]
theorem b4_12515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12515 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12520 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6546,w6588]
theorem b4_12520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12520 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6546,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6546 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12521 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6551,w6588]
theorem b4_12521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12521 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6551,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6551 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12525 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6667,w6690]
theorem b4_12525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12525 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(9,true))] s4_12525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s4_12526 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6667,w6785]
theorem b4_12526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12526 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s4_12537 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6417,w6522,w6588]
theorem b4_12537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12537 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6417,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12541 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6538,w6588]
theorem b4_12541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12541 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12548 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6538,w6588]
theorem b4_12548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12548 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12555 : List (BitVec 512) := [w2488,w3335,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12555 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12556 : List (BitVec 512) := [w2488,w3335,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12556 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12556 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12556 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12557 : List (BitVec 512) := [w2488,w3335,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12557 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12558 : List (BitVec 512) := [w2488,w3335,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12558 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12559 : List (BitVec 512) := [w2488,w3411,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12559 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12559 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12559 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12560 : List (BitVec 512) := [w2488,w3411,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12560 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12560 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12560 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12561 : List (BitVec 512) := [w2488,w3411,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12561 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12562 : List (BitVec 512) := [w2488,w3411,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12562 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12563 : List (BitVec 512) := [w2488,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12563 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12564 : List (BitVec 512) := [w2488,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12564 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12565 : List (BitVec 512) := [w2488,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12565 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12566 : List (BitVec 512) := [w2488,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12566 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12567 : List (BitVec 512) := [w2488,w3573,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12567 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3573,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3573 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12568 : List (BitVec 512) := [w2488,w3573,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3573,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3573 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12569 : List (BitVec 512) := [w2488,w3573,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12569 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3573,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3573 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12570 : List (BitVec 512) := [w2488,w3573,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12570 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3573,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3573 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12571 : List (BitVec 512) := [w2488,w3577,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12571 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12572 : List (BitVec 512) := [w2488,w3577,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12572 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12572 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12572 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12573 : List (BitVec 512) := [w2488,w3577,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12573 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12573 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12573 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12574 : List (BitVec 512) := [w2488,w3577,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12574 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12575 : List (BitVec 512) := [w2488,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12575 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12576 : List (BitVec 512) := [w2488,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12576 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12577 : List (BitVec 512) := [w2488,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12577 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12578 : List (BitVec 512) := [w2488,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12578 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12579 : List (BitVec 512) := [w2488,w3626,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12579 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12580 : List (BitVec 512) := [w2488,w3626,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12580 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12581 : List (BitVec 512) := [w2488,w3626,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12581 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12581 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12581 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12582 : List (BitVec 512) := [w2488,w3649,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12582 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12582 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12582 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12583 : List (BitVec 512) := [w2488,w3649,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12583 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12584 : List (BitVec 512) := [w2488,w3649,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12584 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12585 : List (BitVec 512) := [w2488,w3649,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12585 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12586 : List (BitVec 512) := [w2488,w3651,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12586 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12587 : List (BitVec 512) := [w2488,w3651,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12587 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12587 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12587 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12588 : List (BitVec 512) := [w2488,w3651,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12588 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12589 : List (BitVec 512) := [w2488,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12589 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12590 : List (BitVec 512) := [w2488,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12590 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_12590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12591 : List (BitVec 512) := [w2488,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12591 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12591 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12591 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12592 : List (BitVec 512) := [w2488,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12592 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12592 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_12592 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
