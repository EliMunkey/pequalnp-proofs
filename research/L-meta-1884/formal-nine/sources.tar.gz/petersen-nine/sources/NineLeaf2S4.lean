import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2930 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_2930 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2930 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true))] s3_2930 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2931 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_2931 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2931 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true))] s3_2931 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_2932 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_2932 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2932 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false))] s3_2932 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl)))))))))))) (by decide +kernel)
def s3_2933 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_2933 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2933 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true))] s3_2933 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))))) (by decide +kernel)
def s3_2934 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_2934 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2934 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(6,true))] s3_2934 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))))) (by decide +kernel)
def s3_2935 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_2935 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2935 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_2935 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2936 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b3_2936 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2936 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true))] s3_2936 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2937 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b3_2937 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2937 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true))] s3_2937 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2938 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6588]
theorem b3_2938 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2938 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(7,true))] s3_2938 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2939 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b3_2939 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2939 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(6,true))] s3_2939 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2940 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b3_2940 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2940 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s3_2940 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2941 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6720]
theorem b3_2941 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2941 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true))] s3_2941 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))))) (by decide +kernel)
def s3_2942 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6785]
theorem b3_2942 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2942 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(8,true))] s3_2942 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_2943 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6852]
theorem b3_2943 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2943 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true))] s3_2943 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl)))))))))))) (by decide +kernel)
def s3_2944 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6873]
theorem b3_2944 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2944 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true))] s3_2944 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))))) (by decide +kernel)
def s3_2945 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_2945 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2945 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(2,true))] s3_2945 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2946 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_2946 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2946 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(6,true))] s3_2946 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2947 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b3_2947 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2947 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true))] s3_2947 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2948 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6464,w6588]
theorem b3_2948 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2948 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true))] s3_2948 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2949 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_2949 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2949 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false))] s3_2949 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2950 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6690]
theorem b3_2950 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2950 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(3,true))] s3_2950 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_2951 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6785]
theorem b3_2951 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2951 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true))] s3_2951 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_2952 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6857]
theorem b3_2952 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2952 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false))] s3_2952 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl)))))))))))) (by decide +kernel)
def s3_2953 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_2953 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2953 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true))] s3_2953 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))))) (by decide +kernel)
def s3_2954 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_2954 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2954 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true))] s3_2954 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2955 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b3_2955 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2955 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false))] s3_2955 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2956 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_2956 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2956 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s3_2956 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2957 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6389,w6588]
theorem b3_2957 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2957 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(6,true))] s3_2957 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2958 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6422,w6588]
theorem b3_2958 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2958 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true))] s3_2958 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2959 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6567,w6588]
theorem b3_2959 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2959 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,false))] s3_2959 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2960 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6690]
theorem b3_2960 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2960 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(8,true))] s3_2960 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_2961 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6720]
theorem b3_2961 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2961 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(6,true))] s3_2961 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))))) (by decide +kernel)
def s3_2962 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6866]
theorem b3_2962 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2962 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(8,true))] s3_2962 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl)))))))))))) (by decide +kernel)
def s3_2963 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6873]
theorem b3_2963 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2963 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true))] s3_2963 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))))) (by decide +kernel)
def s3_2964 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_2964 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2964 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true))] s3_2964 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2965 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_2965 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2965 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(6,true))] s3_2965 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2966 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6436,w6588]
theorem b3_2966 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2966 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,false),(7,true))] s3_2966 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2967 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6478,w6588]
theorem b3_2967 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2967 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false))] s3_2967 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2968 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b3_2968 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2968 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s3_2968 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2969 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6720]
theorem b3_2969 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2969 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(4,true))] s3_2969 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))))) (by decide +kernel)
def s3_2970 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6785]
theorem b3_2970 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2970 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(2,true),(4,true))] s3_2970 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_2971 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6832]
theorem b3_2971 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2971 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(2,true))] s3_2971 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))))) (by decide +kernel)
def s3_2972 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6890]
theorem b3_2972 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2972 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,false),(8,true))] s3_2972 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl)))))))))))) (by decide +kernel)
def s3_2973 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6436,w6588]
theorem b3_2973 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2973 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true))] s3_2973 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2974 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6489,w6588]
theorem b3_2974 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2974 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true))] s3_2974 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2975 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6549,w6588]
theorem b3_2975 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2975 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true))] s3_2975 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2976 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6690]
theorem b3_2976 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2976 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(8,true),(2,true))] s3_2976 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_2977 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6785]
theorem b3_2977 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2977 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(8,true),(6,true))] s3_2977 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_2978 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6832]
theorem b3_2978 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2978 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(7,true))] s3_2978 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))))) (by decide +kernel)
def s3_2979 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6895]
theorem b3_2979 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2979 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true))] s3_2979 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl)))))))))))) (by decide +kernel)
def s3_2980 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_2980 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2980 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(4,true))] s3_2980 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2981 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6478,w6588]
theorem b3_2981 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2981 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true))] s3_2981 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2982 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6489,w6588]
theorem b3_2982 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2982 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true))] s3_2982 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2983 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6567,w6588]
theorem b3_2983 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2983 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true))] s3_2983 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2984 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6690]
theorem b3_2984 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2984 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(8,true))] s3_2984 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_2985 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6720]
theorem b3_2985 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2985 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(7,true),(8,true))] s3_2985 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))))) (by decide +kernel)
def s3_2986 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6832]
theorem b3_2986 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2986 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(6,true))] s3_2986 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))))) (by decide +kernel)
def s3_2987 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6904]
theorem b3_2987 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2987 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(8,true))] s3_2987 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588,v2_6904] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6904 rfl)))))))))))) (by decide +kernel)
def s3_2988 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b3_2988 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2988 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true))] s3_2988 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2989 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_2989 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2989 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true))] s3_2989 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2990 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_2990 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2990 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s3_2990 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2991 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6549,w6588]
theorem b3_2991 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2991 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false))] s3_2991 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2992 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6567,w6588]
theorem b3_2992 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2992 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false))] s3_2992 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2993 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6690]
theorem b3_2993 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2993 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true))] s3_2993 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
end NineCert
