import NinePin164
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_979 : List (BitVec 512) := [w160,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_979 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_160,v164_1915,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588] (PetersenWireProjection.cons pc164_160 (PetersenWireProjection.cons pc164_1915 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 rfl))))))))))) (by decide +kernel)
def s4_1537 : List (BitVec 512) := [w200,w1420,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_1537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1537 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_1537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_200,v164_1420,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6522,v164_6588] (PetersenWireProjection.cons pc164_200 (PetersenWireProjection.cons pc164_1420 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6522 (PetersenWireProjection.cons pc164_6588 rfl))))))))))) (by decide +kernel)
def s4_7583 : List (BitVec 512) := [w1312,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7583 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_7583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_1312,v164_1913,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6720] (PetersenWireProjection.cons pc164_1312 (PetersenWireProjection.cons pc164_1913 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6720 rfl))))))))))) (by decide +kernel)
def s4_7584 : List (BitVec 512) := [w1312,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7584 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_7584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_1312,v164_1913,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6785] (PetersenWireProjection.cons pc164_1312 (PetersenWireProjection.cons pc164_1913 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6785 rfl))))))))))) (by decide +kernel)
def s4_7585 : List (BitVec 512) := [w1312,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7585 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_7585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_1312,v164_1913,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6813] (PetersenWireProjection.cons pc164_1312 (PetersenWireProjection.cons pc164_1913 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6813 rfl))))))))))) (by decide +kernel)
def s4_16536 : List (BitVec 512) := [w3766,w4344,w4517,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16536 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4517,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6720] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4517 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6720 rfl))))))))))) (by decide +kernel)
def s4_16537 : List (BitVec 512) := [w3766,w4344,w4517,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_16537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16537 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4517,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6785] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4517 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6785 rfl))))))))))) (by decide +kernel)
def s4_16538 : List (BitVec 512) := [w3766,w4344,w4517,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_16538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16538 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4517,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6813] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4517 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6813 rfl))))))))))) (by decide +kernel)
def s4_16589 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_16589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16589 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4519,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6895] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4519 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6895 rfl))))))))))) (by decide +kernel)
def s4_16595 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_16595 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16595 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16595 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4519,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6720,v164_6873] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4519 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6720 (PetersenWireProjection.cons pc164_6873 rfl))))))))))) (by decide +kernel)
def s4_16603 : List (BitVec 512) := [w3766,w4344,w4520,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16603 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4520,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6720] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4520 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6720 rfl))))))))))) (by decide +kernel)
def s4_16604 : List (BitVec 512) := [w3766,w4344,w4520,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16604 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4520,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6873] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4520 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6873 rfl))))))))))) (by decide +kernel)
def s4_16605 : List (BitVec 512) := [w3766,w4344,w4520,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_16605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16605 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s4_16605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4520,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6300,v164_6588,v164_6895] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4520 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6300 (PetersenWireProjection.cons pc164_6588 (PetersenWireProjection.cons pc164_6895 rfl))))))))))) (by decide +kernel)
def s5_1489 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_1489 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1489 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s5_1489 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_972,v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6522,v164_6588] (PetersenWireProjection.cons pc164_972 (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6522 (PetersenWireProjection.cons pc164_6588 rfl)))))))))) (by decide +kernel)
def s5_6054 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6518,w6813,w6873]
theorem b5_6054 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6054 := by
  intro m le c
  apply rejects_sound r164 i7 6 tgt (small164 adj) hot164 [] s5_6054 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v164_3766,v164_4344,v164_4716,v164_5135,v164_5393,v164_5585,v164_5956,v164_6518,v164_6813,v164_6873] (PetersenWireProjection.cons pc164_3766 (PetersenWireProjection.cons pc164_4344 (PetersenWireProjection.cons pc164_4716 (PetersenWireProjection.cons pc164_5135 (PetersenWireProjection.cons pc164_5393 (PetersenWireProjection.cons pc164_5585 (PetersenWireProjection.cons pc164_5956 (PetersenWireProjection.cons pc164_6518 (PetersenWireProjection.cons pc164_6813 (PetersenWireProjection.cons pc164_6873 rfl)))))))))) (by decide +kernel)
end NineCert
