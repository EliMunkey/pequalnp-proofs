import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11778 : List (BitVec 512) := [w2384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11778 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11779 : List (BitVec 512) := [w2385,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_11779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11779 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2385,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6024,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2385 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6024 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11780 : List (BitVec 512) := [w2385,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11780 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2385,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2385 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11781 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_11781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11781 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2387,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6026,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2387 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6026 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11782 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11782 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2387,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2387 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11783 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_11783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11783 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2387,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2387 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11788 : List (BitVec 512) := [w2390,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6031,w6300,w6588]
theorem b4_11788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11788 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s4_11788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2390,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6031,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2390 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6031 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11789 : List (BitVec 512) := [w2390,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11789 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s4_11789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2390,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2390 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11790 : List (BitVec 512) := [w2393,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_11790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11790 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11791 : List (BitVec 512) := [w2393,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_11791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11791 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11792 : List (BitVec 512) := [w2393,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11792 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11793 : List (BitVec 512) := [w2393,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11793 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_11793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11794 : List (BitVec 512) := [w2393,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11794 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_11794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11795 : List (BitVec 512) := [w2393,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_11795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11795 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_11795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11796 : List (BitVec 512) := [w2393,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11796 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11797 : List (BitVec 512) := [w2393,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11797 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11798 : List (BitVec 512) := [w2393,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11798 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11799 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11799 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s4_11799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11800 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_11800 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11800 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(0,false),(5,true))] s4_11800 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11801 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11801 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s4_11801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11802 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_11802 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11802 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(7,true))] s4_11802 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11803 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_11803 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11803 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(0,false),(9,true))] s4_11803 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11804 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_11804 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11804 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true))] s4_11804 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6859] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6859 rfl))))))))))) (by decide +kernel)
def s4_11805 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_11805 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11805 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_11805 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6868] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6868 rfl))))))))))) (by decide +kernel)
def s4_11806 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_11806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11806 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(0,false),(8,true))] s4_11806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_11807 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_11807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11807 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(0,false),(7,true))] s4_11807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6904] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6904 rfl))))))))))) (by decide +kernel)
def s4_11808 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_11808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11808 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(9,true))] s4_11808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6910] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6910 rfl))))))))))) (by decide +kernel)
def s4_11809 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_11809 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11809 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(9,true),(8,true))] s4_11809 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11810 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_11810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11810 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(9,true),(7,true))] s4_11810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11811 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_11811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11811 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(5,true),(7,true))] s4_11811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11812 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_11812 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11812 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(4,true),(8,true))] s4_11812 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11813 : List (BitVec 512) := [w2393,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_11813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11813 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(7,true),(5,true))] s4_11813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11814 : List (BitVec 512) := [w2393,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_11814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11814 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(8,true),(5,true))] s4_11814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11815 : List (BitVec 512) := [w2393,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_11815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11815 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(8,true),(9,true))] s4_11815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11816 : List (BitVec 512) := [w2393,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_11816 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11816 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true))] s4_11816 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11817 : List (BitVec 512) := [w2393,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6720]
theorem b4_11817 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11817 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true))] s4_11817 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11818 : List (BitVec 512) := [w2393,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6690]
theorem b4_11818 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11818 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(3,true),(9,true))] s4_11818 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11819 : List (BitVec 512) := [w2393,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588,w6690]
theorem b4_11819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11819 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(3,true),(9,true))] s4_11819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11820 : List (BitVec 512) := [w2393,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6690]
theorem b4_11820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11820 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(3,true)),(false,(3,true),(4,true))] s4_11820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11821 : List (BitVec 512) := [w2407,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_11821 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11821 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11821 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2407,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6087,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2407 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6087 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11822 : List (BitVec 512) := [w2407,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11822 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2407,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2407 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11825 : List (BitVec 512) := [w2409,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_11825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11825 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2409,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6099,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2409 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6099 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11826 : List (BitVec 512) := [w2409,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11826 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2409,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2409 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11827 : List (BitVec 512) := [w2410,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_11827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11827 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false))] s4_11827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11828 : List (BitVec 512) := [w2410,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_11828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11828 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false))] s4_11828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11829 : List (BitVec 512) := [w2410,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11829 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false))] s4_11829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11830 : List (BitVec 512) := [w2410,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6588,w6720]
theorem b4_11830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11830 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true))] s4_11830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11831 : List (BitVec 512) := [w2410,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11831 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11832 : List (BitVec 512) := [w2410,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11832 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11833 : List (BitVec 512) := [w2410,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_11833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11833 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11834 : List (BitVec 512) := [w2410,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_11834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11834 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true))] s4_11834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11835 : List (BitVec 512) := [w2410,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11835 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true))] s4_11835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11836 : List (BitVec 512) := [w2410,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11836 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true))] s4_11836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11837 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_11837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11837 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_11837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5621,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5621 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11838 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5636,w5956,w6300,w6588]
theorem b4_11838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11838 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(7,true))] s4_11838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5636,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5636 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11839 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_11839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11839 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_11839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5665,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5665 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11840 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w6300,w6522,w6588]
theorem b4_11840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11840 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_11840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11841 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11841 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s4_11841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11842 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_11842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11842 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6334,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6334 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11843 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6353,w6588]
theorem b4_11843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11843 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6353,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6353 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11844 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6371,w6588]
theorem b4_11844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11844 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_11844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6371,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6371 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11845 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_11845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11845 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(3,true))] s4_11845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11846 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11846 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(0,false),(3,true))] s4_11846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11847 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11847 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s4_11847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
