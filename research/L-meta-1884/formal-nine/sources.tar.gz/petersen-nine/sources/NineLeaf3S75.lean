import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_849 : List (BitVec 512) := [w586,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_849 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_849 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_849 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_586,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_586 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_850 : List (BitVec 512) := [w587,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_850 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_850 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_850 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_587,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_587 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_851 : List (BitVec 512) := [w588,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_851 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_851 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_851 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_588,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_588 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_852 : List (BitVec 512) := [w589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_852 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_852 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_852 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_589,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_589 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_853 : List (BitVec 512) := [w590,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_853 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_853 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true))] s5_853 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_590,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_590 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_854 : List (BitVec 512) := [w591,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_854 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_854 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_854 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_591,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_591 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_855 : List (BitVec 512) := [w592,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_855 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_855 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_855 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_592,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_592 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_856 : List (BitVec 512) := [w593,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_856 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_856 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true))] s5_856 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_593,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_593 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_857 : List (BitVec 512) := [w594,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_857 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_857 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true))] s5_857 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_594,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_594 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_858 : List (BitVec 512) := [w595,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_858 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_858 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_858 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_595,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_595 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_859 : List (BitVec 512) := [w596,w1867,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_859 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_859 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,false))] s5_859 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1867,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1867 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_860 : List (BitVec 512) := [w596,w1908,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_860 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_860 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true))] s5_860 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1908,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1908 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_861 : List (BitVec 512) := [w596,w2124,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_861 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_861 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(4,true))] s5_861 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2124,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2124 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_862 : List (BitVec 512) := [w596,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_862 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_862 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false))] s5_862 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_863 : List (BitVec 512) := [w596,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_863 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_863 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_863 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2468,v3_2681,v3_3766,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_864 : List (BitVec 512) := [w596,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_864 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_864 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_864 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_865 : List (BitVec 512) := [w596,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_865 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_865 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_865 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_866 : List (BitVec 512) := [w596,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_866 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_866 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_866 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_867 : List (BitVec 512) := [w596,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_867 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_867 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_867 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_868 : List (BitVec 512) := [w596,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_868 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_868 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_868 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2529,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2529 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_869 : List (BitVec 512) := [w596,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_869 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_869 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(6,false))] s5_869 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2681,v3_3258,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_870 : List (BitVec 512) := [w596,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_870 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_870 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_870 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_871 : List (BitVec 512) := [w596,w2681,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_871 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_871 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_871 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2681,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_872 : List (BitVec 512) := [w596,w2681,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_872 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_872 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_872 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_2681,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_873 : List (BitVec 512) := [w596,w3177,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_873 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_873 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false))] s5_873 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3177,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3177 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_874 : List (BitVec 512) := [w596,w3179,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_874 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_874 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,false))] s5_874 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3179,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3179 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_875 : List (BitVec 512) := [w596,w3182,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_875 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_875 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s5_875 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3182,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_876 : List (BitVec 512) := [w596,w3183,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_876 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_876 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false))] s5_876 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3183,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3183 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_877 : List (BitVec 512) := [w596,w3256,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_877 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_877 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(5,true)),(false,(2,true),(0,true))] s5_877 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3256,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3256 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_878 : List (BitVec 512) := [w596,w3258,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_878 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_878 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_878 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3258,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_879 : List (BitVec 512) := [w596,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_879 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_879 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_879 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3293,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_880 : List (BitVec 512) := [w596,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_880 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_880 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_880 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_881 : List (BitVec 512) := [w596,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_881 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_881 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_881 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_882 : List (BitVec 512) := [w596,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_882 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_882 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_882 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_883 : List (BitVec 512) := [w596,w3323,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_883 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_883 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(5,true)),(false,(2,true),(0,true))] s5_883 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3323,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3323 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_884 : List (BitVec 512) := [w596,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_884 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_884 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_884 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_885 : List (BitVec 512) := [w596,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6690]
theorem b5_885 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_885 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s5_885 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_886 : List (BitVec 512) := [w596,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_886 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_886 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(8,true),(4,true))] s5_886 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_887 : List (BitVec 512) := [w596,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_887 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_887 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_887 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4344,v3_5135,v3_5393,v3_5769,v3_5956,v3_6464,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_888 : List (BitVec 512) := [w596,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_888 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_888 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s5_888 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_889 : List (BitVec 512) := [w596,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_889 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_889 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s5_889 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_890 : List (BitVec 512) := [w596,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6720]
theorem b5_890 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_890 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(2,true))] s5_890 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_891 : List (BitVec 512) := [w596,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_891 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_891 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(2,true))] s5_891 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_913 : List (BitVec 512) := [w628,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690]
theorem b5_913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_913 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(5,false),(0,false)),(false,(4,true),(1,true))] s5_913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_628,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_628 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_929 : List (BitVec 512) := [w632,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690]
theorem b5_929 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_929 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,false),(0,false)),(false,(4,true),(1,true))] s5_929 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_632,v3_2681,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_632 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_955 : List (BitVec 512) := [w637,w3156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_955 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s5_955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_637,v3_3156,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300] (PetersenWireProjection.cons pc3_637 (PetersenWireProjection.cons pc3_3156 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 rfl)))))))))) (by decide +kernel)
def s5_959 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_959 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_959 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,false),(9,true))] s5_959 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_637,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_637 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_961 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_961 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_961 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s5_961 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_637,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_637 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1100 : List (BitVec 512) := [w863,w2677,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1100 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1100 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1100 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_863,v3_2677,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_863 (PetersenWireProjection.cons pc3_2677 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1101 : List (BitVec 512) := [w863,w2678,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1101 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1101 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1101 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_863,v3_2678,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_863 (PetersenWireProjection.cons pc3_2678 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1102 : List (BitVec 512) := [w863,w2679,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1102 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_863,v3_2679,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_863 (PetersenWireProjection.cons pc3_2679 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1103 : List (BitVec 512) := [w863,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1103 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1103 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1103 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_863,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_863 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1104 : List (BitVec 512) := [w864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1104 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1104 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1104 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_864,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_864 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1106 : List (BitVec 512) := [w870,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1106 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_870,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_870 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1107 : List (BitVec 512) := [w871,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1107 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1107 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1107 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_871,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_871 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1110 : List (BitVec 512) := [w876,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1110 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1110 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1110 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_876,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_876 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1113 : List (BitVec 512) := [w879,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1113 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1113 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1113 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_879,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_879 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1115 : List (BitVec 512) := [w881,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1115 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1115 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_1115 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_881,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_881 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1117 : List (BitVec 512) := [w883,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1117 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1117 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_1117 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_883,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_883 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1128 : List (BitVec 512) := [w906,w2677,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1128 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_906,v3_2677,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_906 (PetersenWireProjection.cons pc3_2677 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1129 : List (BitVec 512) := [w906,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1129 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_906,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_906 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1130 : List (BitVec 512) := [w907,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1130 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1130 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1130 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_907,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_907 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1132 : List (BitVec 512) := [w912,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1132 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_912,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_912 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1133 : List (BitVec 512) := [w913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1133 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1133 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1133 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_913,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_913 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
