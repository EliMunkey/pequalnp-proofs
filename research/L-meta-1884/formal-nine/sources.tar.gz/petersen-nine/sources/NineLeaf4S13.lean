import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_2549 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2549 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(3,true))] s4_2549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2550 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6720]
theorem b4_2550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2550 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(3,true))] s4_2550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2551 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_2551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2551 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s4_2551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2552 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6720]
theorem b4_2552 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2552 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s4_2552 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2553 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_2553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2553 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s4_2553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2554 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_2554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2554 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s4_2554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2555 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_2555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2555 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(4,true))] s4_2555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2556 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6720]
theorem b4_2556 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2556 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(4,true))] s4_2556 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2557 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_2557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2557 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(5,true))] s4_2557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6748] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s4_2558 : List (BitVec 512) := [w522,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_2558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2558 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(5,true))] s4_2558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_2559 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_2559 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2559 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_2559 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2560 : List (BitVec 512) := [w522,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_2560 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2560 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_2560 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_2561 : List (BitVec 512) := [w522,w3766,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b4_2561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2561 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(7,true))] s4_2561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_522,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5654,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_522 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5654 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_2864 : List (BitVec 512) := [w628,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2864 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(0,true),(5,true))] s4_2864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2865 : List (BitVec 512) := [w628,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2865 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2867 : List (BitVec 512) := [w628,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2867 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2871 : List (BitVec 512) := [w628,w2087,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2871 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(0,true),(5,true))] s4_2871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_2087,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_2087 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2885 : List (BitVec 512) := [w628,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2885 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(0,true),(5,true))] s4_2885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2886 : List (BitVec 512) := [w628,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2886 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_2886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2887 : List (BitVec 512) := [w628,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2887 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2893 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2893 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2894 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2894 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2895 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_2895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2895 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2897 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_2897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2897 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_2897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2899 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_2899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2899 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_2899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2901 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2901 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_2901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_628,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_628 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_2920 : List (BitVec 512) := [w632,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2920 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2921 : List (BitVec 512) := [w632,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2921 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_2921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2922 : List (BitVec 512) := [w632,w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2922 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_2922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_1369,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2925 : List (BitVec 512) := [w632,w1819,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2925 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_1819,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2935 : List (BitVec 512) := [w632,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2935 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2936 : List (BitVec 512) := [w632,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2936 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_3766,v4_4344,v4_4716,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2942 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2942 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2944 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_2944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2944 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_2944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2946 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2946 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_2946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_632,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_632 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_2965 : List (BitVec 512) := [w635,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2965 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_2965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2966 : List (BitVec 512) := [w635,w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2966 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_2966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2969 : List (BitVec 512) := [w635,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2969 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_2969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2970 : List (BitVec 512) := [w635,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2970 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_2970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_2975 : List (BitVec 512) := [w635,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2975 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_2975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2980 : List (BitVec 512) := [w635,w1590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2980 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_2980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1590,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1590 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2990 : List (BitVec 512) := [w635,w1819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2990 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_2990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1819,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_2991 : List (BitVec 512) := [w635,w1819,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2991 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_2991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1819,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_2992 : List (BitVec 512) := [w635,w1819,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2992 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s4_2992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_1819,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_1819 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_3022 : List (BitVec 512) := [w635,w2808,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3022 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3022 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3022 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_2808,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_2808 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3026 : List (BitVec 512) := [w635,w2864,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3026 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3026 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3026 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_2864,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_2864 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3053 : List (BitVec 512) := [w635,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3053 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3054 : List (BitVec 512) := [w635,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3054 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3055 : List (BitVec 512) := [w635,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_3055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3055 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_3055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_3056 : List (BitVec 512) := [w635,w3766,w4344,w4678,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3056 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_3056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4678,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_3057 : List (BitVec 512) := [w635,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3057 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3059 : List (BitVec 512) := [w635,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3059 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3080 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3080 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3086 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_3086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3086 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_3088 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3088 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_3088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_3092 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3092 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_3092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_635,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_3158 : List (BitVec 512) := [w752,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3158 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s4_3158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_752,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_752 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_3159 : List (BitVec 512) := [w752,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6663]
theorem b4_3159 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3159 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_3159 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_752,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6663] (PetersenWireProjection.cons pc4_752 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6663 rfl))))))))))) (by decide +kernel)
def s4_3810 : List (BitVec 512) := [w867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3810 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_3810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_3811 : List (BitVec 512) := [w867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6660]
theorem b4_3811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3811 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(0,true)),(false,(0,true),(6,true))] s4_3811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6660] (PetersenWireProjection.cons pc4_867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6660 rfl))))))))))) (by decide +kernel)
def s4_3814 : List (BitVec 512) := [w869,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3814 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_3814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_869,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_869 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_3815 : List (BitVec 512) := [w869,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6658]
theorem b4_3815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3815 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s4_3815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_869,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6658] (PetersenWireProjection.cons pc4_869 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6658 rfl))))))))))) (by decide +kernel)
def s4_3818 : List (BitVec 512) := [w875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3818 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3818 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_3818 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_3819 : List (BitVec 512) := [w875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6655]
theorem b4_3819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3819 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(6,true))] s4_3819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6655] (PetersenWireProjection.cons pc4_875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6655 rfl))))))))))) (by decide +kernel)
end NineCert
