import NinePin112
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1503 : List (BitVec 512) := [w975,w3766,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1503 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1503 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1503 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_975,v112_3766,v112_4428,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_975 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4428 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_1516 : List (BitVec 512) := [w985,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6698]
theorem b5_1516 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1516 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1516 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_985,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6698] (PetersenWireProjection.cons pc112_985 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6698 rfl)))))))))) (by decide +kernel)
def s5_1528 : List (BitVec 512) := [w989,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6701]
theorem b5_1528 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1528 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1528 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_989,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6701] (PetersenWireProjection.cons pc112_989 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6701 rfl)))))))))) (by decide +kernel)
def s5_1549 : List (BitVec 512) := [w1002,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6706]
theorem b5_1549 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1549 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1549 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1002,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6706] (PetersenWireProjection.cons pc112_1002 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6706 rfl)))))))))) (by decide +kernel)
def s5_1581 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6711]
theorem b5_1581 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1581 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1581 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1022,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6711] (PetersenWireProjection.cons pc112_1022 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6711 rfl)))))))))) (by decide +kernel)
def s5_1585 : List (BitVec 512) := [w1022,w3766,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1585 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1585 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1585 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1022,v112_3766,v112_4589,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1022 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4589 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_1590 : List (BitVec 512) := [w1025,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6713]
theorem b5_1590 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1590 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1590 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1025,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6713] (PetersenWireProjection.cons pc112_1025 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6713 rfl)))))))))) (by decide +kernel)
def s5_1596 : List (BitVec 512) := [w1026,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6714]
theorem b5_1596 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1596 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1596 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1026,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6714] (PetersenWireProjection.cons pc112_1026 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6714 rfl)))))))))) (by decide +kernel)
def s5_2582 : List (BitVec 512) := [w1328,w2166,w3766,w4344,w4716,w5135,w5393,w5848,w5956,w6300]
theorem b5_2582 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2582 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2582 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2166,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5848,v112_5956,v112_6300] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2166 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 rfl)))))))))) (by decide +kernel)
def s5_2583 : List (BitVec 512) := [w1328,w2166,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6821]
theorem b5_2583 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2583 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2583 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2166,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2166 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2594 : List (BitVec 512) := [w1328,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6748]
theorem b5_2594 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2594 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2594 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2683,v112_3766,v112_4344,v112_4716,v112_5393,v112_5585,v112_5956,v112_6300,v112_6748] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2683 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6748 rfl)))))))))) (by decide +kernel)
def s5_2595 : List (BitVec 512) := [w1328,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6821]
theorem b5_2595 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2595 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2595 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2683,v112_3766,v112_4344,v112_4716,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2683 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2600 : List (BitVec 512) := [w1328,w2687,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6821]
theorem b5_2600 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2600 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2600 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2687,v112_3766,v112_4344,v112_4716,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2687 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2603 : List (BitVec 512) := [w1328,w2880,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6300]
theorem b5_2603 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2603 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2603 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2880,v112_3766,v112_4344,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2880 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 rfl)))))))))) (by decide +kernel)
def s5_2604 : List (BitVec 512) := [w1328,w2880,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2604 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2604 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2604 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_2880,v112_3766,v112_4344,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_2880 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2606 : List (BitVec 512) := [w1328,w3177,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300]
theorem b5_2606 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2606 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2606 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3177,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3177 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 rfl)))))))))) (by decide +kernel)
def s5_2607 : List (BitVec 512) := [w1328,w3177,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2607 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3177,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3177 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2616 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2616 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2616 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2616 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3258,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3258 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2624 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2624 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2624 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2624 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3280,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3280 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2627 : List (BitVec 512) := [w1328,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2627 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3321,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3321 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2629 : List (BitVec 512) := [w1328,w3323,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2629 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2629 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2629 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3323,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3323 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2667 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_2667 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2667 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2667 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1328,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1328 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_2862 : List (BitVec 512) := [w1384,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w6201,w6300]
theorem b5_2862 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2862 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2862 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_1912,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_6201,v112_6300] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_1912 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 rfl)))))))))) (by decide +kernel)
def s5_2863 : List (BitVec 512) := [w1384,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6868]
theorem b5_2863 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2863 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2863 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_1912,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_1912 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_2888 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6868]
theorem b5_2888 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2888 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2888 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3258,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3258 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_2890 : List (BitVec 512) := [w1384,w3258,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_2890 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2890 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2890 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3258,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3258 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_2902 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6868]
theorem b5_2902 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2902 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2902 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3293,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3293 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_2903 : List (BitVec 512) := [w1384,w3293,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_2903 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2903 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2903 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3293,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3293 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_2906 : List (BitVec 512) := [w1384,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6868]
theorem b5_2906 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2906 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2906 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3321,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3321 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_2908 : List (BitVec 512) := [w1384,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6868]
theorem b5_2908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2908 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3328,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6868] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3328 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_2934 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2934 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2934 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2934 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6821] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6821 rfl)))))))))) (by decide +kernel)
def s5_2936 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6859]
theorem b5_2936 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2936 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2936 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6859] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6859 rfl)))))))))) (by decide +kernel)
def s5_2939 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6870]
theorem b5_2939 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2939 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_2939 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1384,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6870] (PetersenWireProjection.cons pc112_1384 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6870 rfl)))))))))) (by decide +kernel)
def s5_3060 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_3060 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3060 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3060 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1390,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6748] (PetersenWireProjection.cons pc112_1390 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6748 rfl)))))))))) (by decide +kernel)
def s5_3063 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6870]
theorem b5_3063 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3063 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3063 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1390,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6870] (PetersenWireProjection.cons pc112_1390 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6870 rfl)))))))))) (by decide +kernel)
def s5_3066 : List (BitVec 512) := [w1403,w1664,w3182,w3766,w4716,w5135,w5393,w5585,w5956,w6890]
theorem b5_3066 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3066 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3066 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_1664,v112_3182,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_1664 (PetersenWireProjection.cons pc112_3182 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_3078 : List (BitVec 512) := [w1403,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6890]
theorem b5_3078 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3078 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_1664,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_1664 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_3082 : List (BitVec 512) := [w1403,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6890]
theorem b5_3082 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3082 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3082 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_1669,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_1669 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_3118 : List (BitVec 512) := [w1403,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6890]
theorem b5_3118 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3118 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3118 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1403,v112_2528,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6890] (PetersenWireProjection.cons pc112_1403 (PetersenWireProjection.cons pc112_2528 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_3243 : List (BitVec 512) := [w1415,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6478]
theorem b5_3243 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3243 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3243 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_1669,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6478] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_1669 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6478 rfl)))))))))) (by decide +kernel)
def s5_3244 : List (BitVec 512) := [w1415,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6905]
theorem b5_3244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3244 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_1669,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_1669 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
def s5_3260 : List (BitVec 512) := [w1415,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6905]
theorem b5_3260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3260 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3258,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3258 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
def s5_3268 : List (BitVec 512) := [w1415,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6905]
theorem b5_3268 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3268 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3268 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3303,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3303 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
def s5_3271 : List (BitVec 512) := [w1415,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6905]
theorem b5_3271 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3271 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3271 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3321,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3321 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
def s5_3273 : List (BitVec 512) := [w1415,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6905]
theorem b5_3273 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3273 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3273 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3332,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6905] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3332 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
def s5_3304 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_3304 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3304 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3304 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1415,v112_3766,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6201,v112_6300,v112_6690] (PetersenWireProjection.cons pc112_1415 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_3317 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6907]
theorem b5_3317 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3317 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3317 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1417,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6907] (PetersenWireProjection.cons pc112_1417 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6907 rfl)))))))))) (by decide +kernel)
def s5_3327 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b5_3327 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3327 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3327 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1423,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6890] (PetersenWireProjection.cons pc112_1423 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_3328 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6918]
theorem b5_3328 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3328 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3328 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_1423,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6918] (PetersenWireProjection.cons pc112_1423 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6918 rfl)))))))))) (by decide +kernel)
def s5_3748 : List (BitVec 512) := [w2400,w3766,w4344,w4716,w5135,w5585,w5956,w6076,w6300,w6588]
theorem b5_3748 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3748 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3748 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2400,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6076,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2400 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6076 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_3752 : List (BitVec 512) := [w2402,w3766,w4344,w4716,w5135,w5585,w5956,w6078,w6300,w6588]
theorem b5_3752 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3752 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3752 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2402,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6078,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2402 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6078 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_3756 : List (BitVec 512) := [w2404,w3766,w4344,w4716,w5135,w5585,w5956,w6082,w6300,w6588]
theorem b5_3756 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3756 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3756 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2404,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6082,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2404 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6082 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_3760 : List (BitVec 512) := [w2406,w3766,w4344,w4716,w5135,w5585,w5956,w6084,w6300,w6588]
theorem b5_3760 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3760 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_3760 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2406,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6084,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2406 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6084 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4282 : List (BitVec 512) := [w2488,w3293,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_4282 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4282 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4282 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3293,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6201,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3293 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4285 : List (BitVec 512) := [w2488,w3303,w4344,w4716,w5135,w5585,w5956,w6300,w6478,w6588]
theorem b5_4285 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4285 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3303,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6478,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3303 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6478 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4289 : List (BitVec 512) := [w2488,w3312,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b5_4289 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4289 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4289 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3312,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3312 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4290 : List (BitVec 512) := [w2488,w3312,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_4290 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4290 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4290 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3312,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3312 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4472 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6237,w6300,w6588]
theorem b5_4472 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4472 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4472 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6237,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4496 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6499,w6588]
theorem b5_4496 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4496 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4496 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4508 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4508 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4508 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4508 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4527 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6859]
theorem b5_4527 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4527 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4527 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6859] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6859 rfl)))))))))) (by decide +kernel)
def s5_4530 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6868]
theorem b5_4530 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4530 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4530 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6868] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6868 rfl)))))))))) (by decide +kernel)
def s5_4535 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6897]
theorem b5_4535 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4535 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4535 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6897] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6897 rfl)))))))))) (by decide +kernel)
def s5_4538 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6905]
theorem b5_4538 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4538 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4538 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6905] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6905 rfl)))))))))) (by decide +kernel)
end NineCert
