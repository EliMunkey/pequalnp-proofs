import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5689 : List (BitVec 512) := [w1119,w2855,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5689 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5689 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(4,true))] s4_5689 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_2855,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_2855 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5690 : List (BitVec 512) := [w1119,w2859,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5690 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(8,true),(4,true))] s4_5690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_2859,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_2859 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5749 : List (BitVec 512) := [w1119,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5749 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s4_5749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5750 : List (BitVec 512) := [w1119,w3766,w4344,w4672,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5750 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s4_5750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4672,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4672 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5751 : List (BitVec 512) := [w1119,w3766,w4344,w4674,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5751 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s4_5751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4674,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5778 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_5778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5778 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(8,true))] s4_5778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5783 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_5783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5783 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(8,true))] s4_5783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5793 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6720]
theorem b4_5793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5793 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(4,true))] s4_5793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6464,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5798 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_5798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5798 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(4,true))] s4_5798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5806 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6720]
theorem b4_5806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5806 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(8,true),(4,true))] s4_5806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5811 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_5811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5811 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(8,true),(4,true))] s4_5811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5844 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_5844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5844 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(8,true),(4,true))] s4_5844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5849 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_5849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5849 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(4,true))] s4_5849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6355 : List (BitVec 512) := [w1231,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_6355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6355 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_6355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_6356 : List (BitVec 512) := [w1231,w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_6356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6356 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_6356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_1312,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_6699 : List (BitVec 512) := [w1231,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6699 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_6699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6806 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_6806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6806 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true))] s4_6806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6809 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_6809 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6809 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(8,true))] s4_6809 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_5993,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_5993 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6837 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_6837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6837 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(8,true))] s4_6837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6849 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_6849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6849 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(8,true))] s4_6849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6853 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b4_6853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6853 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(4,true))] s4_6853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6331,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6331 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6881 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_6881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6881 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_6881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_6939 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6813]
theorem b4_6939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6939 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_6939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6785,v4_6813] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7145 : List (BitVec 512) := [w1281,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7145 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7145 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true))] s4_7145 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1281,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1281 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7161 : List (BitVec 512) := [w1292,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7161 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7161 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_7161 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7323 : List (BitVec 512) := [w1292,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_7323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7323 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_7323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7324 : List (BitVec 512) := [w1292,w3766,w4344,w4659,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7324 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_7324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7325 : List (BitVec 512) := [w1292,w3766,w4344,w4659,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7325 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_7325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4659,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7326 : List (BitVec 512) := [w1292,w3766,w4344,w4667,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7326 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_7326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7327 : List (BitVec 512) := [w1292,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6422,w6588]
theorem b4_7327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7327 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_7327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7328 : List (BitVec 512) := [w1292,w3766,w4344,w4669,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7328 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_7328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7329 : List (BitVec 512) := [w1292,w3766,w4344,w4669,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_7329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7329 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_7329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4669,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7330 : List (BitVec 512) := [w1292,w3766,w4344,w4674,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7330 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_7330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4674,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7331 : List (BitVec 512) := [w1292,w3766,w4344,w4678,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7331 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_7331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7332 : List (BitVec 512) := [w1292,w3766,w4344,w4687,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7332 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_7332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4687,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4687 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7367 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_7367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7367 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_7367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7418 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7418 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_7418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_7681 : List (BitVec 512) := [w1312,w2836,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7681 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7681 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(8,true))] s4_7681 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2836,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2836 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7682 : List (BitVec 512) := [w1312,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7682 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7682 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(8,true))] s4_7682 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7684 : List (BitVec 512) := [w1312,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7684 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_7684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_2852,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7772 : List (BitVec 512) := [w1312,w3766,w3968,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7772 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_3968,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7810 : List (BitVec 512) := [w1312,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7810 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_7810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4392,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4392 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_7822 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7822 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7823 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w4716,w5135,w5393,w5956,w6225,w6300,w6588]
theorem b4_7823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7823 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(8,true))] s4_7823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7824 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_7824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7824 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(8,true))] s4_7824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7825 : List (BitVec 512) := [w1312,w3766,w4344,w4654,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_7825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7825 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4654,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7826 : List (BitVec 512) := [w1312,w3766,w4344,w4654,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7826 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true))] s4_7826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4654,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7827 : List (BitVec 512) := [w1312,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7827 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7828 : List (BitVec 512) := [w1312,w3766,w4344,w4660,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7828 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4660,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4660 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7829 : List (BitVec 512) := [w1312,w3766,w4344,w4666,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7829 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7830 : List (BitVec 512) := [w1312,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7830 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7831 : List (BitVec 512) := [w1312,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7831 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7832 : List (BitVec 512) := [w1312,w3766,w4344,w4674,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7832 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_7832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4674,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7833 : List (BitVec 512) := [w1312,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7833 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7834 : List (BitVec 512) := [w1312,w3766,w4344,w4678,w5135,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_7834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7834 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(5,true),(0,true))] s4_7834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4678,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7835 : List (BitVec 512) := [w1312,w3766,w4344,w4704,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7835 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_7835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4704,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7836 : List (BitVec 512) := [w1312,w3766,w4344,w4704,w5135,w5393,w5585,w5956,w6300,w6785,w6813]
theorem b4_7836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7836 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_7836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4704,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6785,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7837 : List (BitVec 512) := [w1312,w3766,w4344,w4704,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7837 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_7837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4704,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl)))))))))) (by decide +kernel)
def s4_7838 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4737,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7838 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4737,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4737 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7840 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7840 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7841 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4930,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7841 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(3,true))] s4_7841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4930,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4930 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7904 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5613,w5956,w6300,w6813]
theorem b4_7904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7904 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5613,v4_5956,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7919 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6720]
theorem b4_7919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7919 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true))] s4_7919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_7942 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6720]
theorem b4_7942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7942 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(8,true))] s4_7942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_5993,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_5993 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
end NineCert
