import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4583 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_4583 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4583 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4583 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4584 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_4584 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4584 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true))] s3_4584 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4585 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4585 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4585 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true))] s3_4585 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4586 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4586 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4586 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4586 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4587 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_4587 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4587 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true))] s3_4587 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl)))))))))))) (by decide +kernel)
def s3_4588 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_4588 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4588 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true))] s3_4588 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl)))))))))))) (by decide +kernel)
def s3_4589 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_4589 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4589 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true))] s3_4589 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))))) (by decide +kernel)
def s3_4590 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4590 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4590 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true))] s3_4590 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_4591 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_4591 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4591 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4591 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4592 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_4592 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4592 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4592 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4593 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_4593 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4593 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4593 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4594 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4594 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4594 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true))] s3_4594 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4595 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4595 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4595 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4595 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4596 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5203,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_4596 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4596 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true))] s3_4596 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl)))))))))))) (by decide +kernel)
def s3_4597 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5848,w5956,w6300,w6588]
theorem b3_4597 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4597 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4597 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4598 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6136,w6300,w6588]
theorem b3_4598 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4598 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4598 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4599 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6179,w6300,w6588]
theorem b3_4599 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4599 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4599 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4600 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6436,w6588]
theorem b3_4600 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4600 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true))] s3_4600 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4601 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6522,w6588]
theorem b3_4601 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4601 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4601 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4602 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6588,w6748]
theorem b3_4602 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4602 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true))] s3_4602 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl)))))))))))) (by decide +kernel)
def s3_4603 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6588,w6785]
theorem b3_4603 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4603 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true))] s3_4603 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl)))))))))))) (by decide +kernel)
def s3_4604 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6588,w6832]
theorem b3_4604 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4604 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true))] s3_4604 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))))) (by decide +kernel)
def s3_4605 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5474,w5585,w5956,w6300,w6588,w6873]
theorem b3_4605 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4605 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true))] s3_4605 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_4644 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5860,w5956,w6300,w6588]
theorem b3_4644 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4644 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4644 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4658 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_4658 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4658 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4658 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4664 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5860,w5956,w6300,w6588]
theorem b3_4664 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4664 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4664 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4683 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6146,w6300,w6588]
theorem b3_4683 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4683 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4683 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4692 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_4692 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4692 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4692 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4697 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6146,w6300,w6588]
theorem b3_4697 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4697 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4697 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4700 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6195,w6300,w6588]
theorem b3_4700 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4700 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4700 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4710 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6195,w6300,w6588]
theorem b3_4710 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4710 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4710 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4718 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6474,w6588]
theorem b3_4718 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4718 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(2,true))] s3_4718 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6474,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6474 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4724 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6538,w6588]
theorem b3_4724 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4724 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4724 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4730 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6538,w6588]
theorem b3_4730 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4730 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4730 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4736 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6805]
theorem b3_4736 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4736 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(1,true),(2,true))] s3_4736 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6805] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6805 rfl))))))))))) (by decide +kernel)
def s3_4741 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6667,w6785]
theorem b3_4741 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4741 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(1,true),(2,true))] s3_4741 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s3_4748 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6377,w6464,w6588]
theorem b3_4748 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4748 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(2,true))] s3_4748 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4755 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_4755 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4755 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4755 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4756 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_4756 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4756 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4756 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4757 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_4757 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4757 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_4757 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4758 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_4758 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4758 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true))] s3_4758 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4759 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4759 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4759 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_4759 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4760 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_4760 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4760 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true))] s3_4760 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl))))))))))) (by decide +kernel)
def s3_4761 : List (BitVec 512) := [w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4761 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4761 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true))] s3_4761 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_4762 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_4762 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4762 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_4762 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4763 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_4763 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4763 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_4763 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4764 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_4764 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4764 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false))] s3_4764 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5698,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4765 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_4765 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4765 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_4765 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4766 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_4766 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4766 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(8,true))] s3_4766 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl)))))))))))) (by decide +kernel)
def s3_4767 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_4767 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4767 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_4767 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4768 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_4768 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4768 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4768 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4769 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_4769 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4769 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true))] s3_4769 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4770 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_4770 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4770 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4770 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4771 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_4771 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4771 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true))] s3_4771 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4772 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_4772 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4772 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true))] s3_4772 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))))) (by decide +kernel)
def s3_4773 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_4773 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4773 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4773 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4774 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_4774 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4774 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(1,true))] s3_4774 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4775 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_4775 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4775 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(5,true))] s3_4775 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4776 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b3_4776 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4776 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true))] s3_4776 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4777 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_4777 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4777 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s3_4777 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4778 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6300,w6588,w6857]
theorem b3_4778 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4778 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,false))] s3_4778 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588,v0_6857] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6857 rfl)))))))))))) (by decide +kernel)
def s3_4779 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_4779 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4779 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s3_4779 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_4780 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_4780 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4780 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_4780 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4781 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_4781 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4781 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true))] s3_4781 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
