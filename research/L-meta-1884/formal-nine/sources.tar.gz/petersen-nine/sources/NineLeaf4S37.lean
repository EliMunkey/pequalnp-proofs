import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4566 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6089,w6300,w6588]
theorem b5_4566 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4566 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_4566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6089,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6089 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))) (by decide +kernel)
def s5_4589 : List (BitVec 512) := [w2488,w3766,w4671,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_4589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4589 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4671,v4_4716,v4_4926,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4590 : List (BitVec 512) := [w2488,w3766,w4671,w4926,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b5_4590 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4590 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4590 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4671,v4_4926,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4593 : List (BitVec 512) := [w2488,w3766,w4716,w4915,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_4593 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4593 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4593 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4716,v4_4915,v4_4926,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4915 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4594 : List (BitVec 512) := [w2488,w3766,w4716,w4915,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b5_4594 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4594 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4594 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4716,v4_4915,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4915 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4595 : List (BitVec 512) := [w2488,w3766,w4716,w4915,w5135,w5585,w5956,w6300,w6588]
theorem b5_4595 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4595 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4595 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4716,v4_4915,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4915 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))) (by decide +kernel)
def s5_4598 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5585,w5956,w6389,w6422,w6588]
theorem b5_4598 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4598 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_4598 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4716,v4_4926,v4_5135,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4678 : List (BitVec 512) := [w2496,w3766,w4344,w4654,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4678 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4678 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,false)),(false,(0,false),(5,true)),(false,(8,true),(0,true))] s5_4678 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2496,v4_3766,v4_4344,v4_4654,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2496 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4679 : List (BitVec 512) := [w2496,w3766,w4344,w4668,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4679 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4679 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(5,true)),(false,(8,true),(0,true))] s5_4679 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2496,v4_3766,v4_4344,v4_4668,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2496 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4668 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4680 : List (BitVec 512) := [w2496,w3766,w4344,w4673,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4680 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4680 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,false),(9,true)),(false,(8,true),(0,true))] s5_4680 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2496,v4_3766,v4_4344,v4_4673,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2496 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4673 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4681 : List (BitVec 512) := [w2496,w3766,w4344,w4677,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4681 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4681 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false)),(false,(8,true),(0,true))] s5_4681 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2496,v4_3766,v4_4344,v4_4677,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2496 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4677 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_4721 : List (BitVec 512) := [w2497,w3766,w4344,w4646,w4716,w5135,w5769,w5956,w6300,w6588]
theorem b5_4721 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4721 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(0,false),(7,true)),(false,(7,true),(0,true))] s5_4721 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2497,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2497 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5201 : List (BitVec 512) := [w3766,w3944,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5201 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5201 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5201 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3944,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3944 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5202 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5202 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5202 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5202 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5203 : List (BitVec 512) := [w3766,w3947,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5203 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5203 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5203 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3947,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3947 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5211 : List (BitVec 512) := [w3766,w3960,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5211 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3960,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3960 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5212 : List (BitVec 512) := [w3766,w3961,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5212 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5212 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5212 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3961,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3961 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5213 : List (BitVec 512) := [w3766,w3962,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5213 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5213 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5213 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3962,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3962 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5214 : List (BitVec 512) := [w3766,w3963,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5214 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5214 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5214 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3963,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3963 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5215 : List (BitVec 512) := [w3766,w3964,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5215 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5215 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5215 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3964,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3964 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5216 : List (BitVec 512) := [w3766,w3967,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5216 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5216 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5216 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3967,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3967 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5217 : List (BitVec 512) := [w3766,w3968,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5217 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3968,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3968 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5228 : List (BitVec 512) := [w3766,w3980,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5228 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5228 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5228 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3980,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3980 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5229 : List (BitVec 512) := [w3766,w3981,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5229 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5229 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5229 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3981,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3981 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5230 : List (BitVec 512) := [w3766,w3982,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5230 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5230 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5230 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3982,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3982 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5231 : List (BitVec 512) := [w3766,w3984,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5231 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5231 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5231 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3984,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3984 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5232 : List (BitVec 512) := [w3766,w3985,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5232 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5232 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5232 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3985,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3985 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5233 : List (BitVec 512) := [w3766,w3988,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5233 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5233 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5233 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3988,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3988 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5234 : List (BitVec 512) := [w3766,w3989,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5234 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5234 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5234 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3989,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3989 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5462 : List (BitVec 512) := [w3766,w4344,w4348,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5462 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5462 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(0,true),(4,true))] s5_5462 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4348,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4348 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5514 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6610]
theorem b5_5514 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5514 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s5_5514 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4403,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4403 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl)))))))))) (by decide +kernel)
def s5_5528 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5528 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5528 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s5_5528 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4404,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4404 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5547 : List (BitVec 512) := [w3766,w4344,w4414,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5547 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5547 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s5_5547 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4414,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4414 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5550 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5550 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5550 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s5_5550 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4416,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4416 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5583 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5471,w5585,w6101,w6300,w6588]
theorem b5_5583 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5583 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true)),(false,(1,true),(7,true))] s5_5583 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4483,v4_4716,v4_5135,v4_5471,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5600 : List (BitVec 512) := [w3766,w4344,w4504,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_5600 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5600 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s5_5600 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4504,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4504 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5615 : List (BitVec 512) := [w3766,w4344,w4517,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_5615 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5615 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_5615 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4517,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4517 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5619 : List (BitVec 512) := [w3766,w4344,w4520,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_5619 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5619 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_5619 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4520,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4520 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5646 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b5_5646 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5646 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s5_5646 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4563,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4563 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5653 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b5_5653 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5653 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s5_5653 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4572,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4572 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5687 : List (BitVec 512) := [w3766,w4344,w4667,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5687 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5687 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s5_5687 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4667,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5688 : List (BitVec 512) := [w3766,w4344,w4668,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_5688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5688 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,false),(1,true))] s5_5688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4668,v4_4716,v4_5200,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4668 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5200 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5689 : List (BitVec 512) := [w3766,w4344,w4671,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_5689 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5689 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,false),(1,true))] s5_5689 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4671,v4_4716,v4_5200,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5200 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5690 : List (BitVec 512) := [w3766,w4344,w4673,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5690 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s5_5690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4673,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4673 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5737 : List (BitVec 512) := [w3766,w4344,w4716,w4927,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5737 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5737 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true)),(false,(0,true),(4,true))] s5_5737 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4927,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4927 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5739 : List (BitVec 512) := [w3766,w4344,w4716,w4929,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5739 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5739 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(8,true)),(false,(0,true),(4,true))] s5_5739 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4929,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4929 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5740 : List (BitVec 512) := [w3766,w4344,w4716,w4932,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5740 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5740 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s5_5740 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4932,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4932 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5741 : List (BitVec 512) := [w3766,w4344,w4716,w4934,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5741 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5741 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(4,true))] s5_5741 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4934,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4934 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5742 : List (BitVec 512) := [w3766,w4344,w4716,w4935,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5742 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5742 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s5_5742 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4935,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4935 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5744 : List (BitVec 512) := [w3766,w4344,w4716,w4937,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5744 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5744 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(4,true))] s5_5744 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4937,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4937 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5791 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6609]
theorem b5_5791 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5791 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s5_5791 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6609] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6609 rfl)))))))))) (by decide +kernel)
def s5_5804 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6549,w6588]
theorem b5_5804 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5804 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_5804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5750,v4_5956,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5805 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5750,w6101,w6522,w6588]
theorem b5_5805 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5805 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_5805 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5750,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5812 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6522,w6720]
theorem b5_5812 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5812 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_5812 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5767,v4_5956,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5767 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5821 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5775,w5956,w6300,w6588]
theorem b5_5821 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5821 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_5821 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5775,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5775 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5822 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5777,w5956,w6300,w6588]
theorem b5_5822 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5822 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_5822 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5777,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5777 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5828 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5784,w5956,w6300,w6588]
theorem b5_5828 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5828 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s5_5828 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5784,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5784 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5829 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5786,w5956,w6300,w6588]
theorem b5_5829 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5829 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s5_5829 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5786,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5786 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5831 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5794,w5956,w6300,w6588]
theorem b5_5831 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5831 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s5_5831 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5794,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5794 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5834 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5796,w5956,w6300,w6588]
theorem b5_5834 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5834 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s5_5834 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5796,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5796 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5851 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5844,w5956,w6300,w6720]
theorem b5_5851 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5851 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false)),(false,(0,true),(4,true))] s5_5851 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5844,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5844 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5853 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5845,w5956,w6300,w6588]
theorem b5_5853 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5853 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false)),(false,(0,true),(4,true))] s5_5853 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5845,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5845 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5892 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6143,w6300,w6588]
theorem b5_5892 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5892 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(6,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false))] s5_5892 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6143,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6143 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5894 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6210,w6300,w6588]
theorem b5_5894 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5894 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,false),(0,true)),(false,(0,true),(8,true))] s5_5894 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6210,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6210 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
