import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_8854 : List (BitVec 512) := [w1374,w2427,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8854 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_8854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_8855 : List (BitVec 512) := [w1374,w2427,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_8855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8855 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_8855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8856 : List (BitVec 512) := [w1374,w2427,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8856 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_8857 : List (BitVec 512) := [w1374,w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8857 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(1,false))] s4_8857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8858 : List (BitVec 512) := [w1374,w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8858 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(1,false))] s4_8858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8859 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8859 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s4_8859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8860 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8860 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6866] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_8861 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8861 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_8861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_8862 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b4_8862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8862 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_8862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8863 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8863 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_8864 : List (BitVec 512) := [w1374,w2443,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8864 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_8864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2443,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2443 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8867 : List (BitVec 512) := [w1374,w2449,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8867 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(3,true))] s4_8867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2449,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2449 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8868 : List (BitVec 512) := [w1374,w2450,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8868 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(8,true))] s4_8868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2450,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2450 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8870 : List (BitVec 512) := [w1374,w2494,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8870 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(1,false))] s4_8870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8874 : List (BitVec 512) := [w1374,w2513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s4_8874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2513,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8875 : List (BitVec 512) := [w1374,w2515,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8875 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2515,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2515 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_8876 : List (BitVec 512) := [w1374,w2519,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8876 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_8876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2519,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2519 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_8877 : List (BitVec 512) := [w1374,w2522,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2522,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6866] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2522 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_9130 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6720]
theorem b4_9130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9130 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s4_9130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_9131 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6866]
theorem b4_9131 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9131 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9131 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6866] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_9132 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6300,w6832]
theorem b4_9132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9132 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_9132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_9133 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5479,w5956,w6179,w6300,w6785]
theorem b4_9133 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9133 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_9133 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5956,v2_6179,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_9134 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5485,w5585,w5956,w6300,w6588]
theorem b4_9134 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9134 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_9134 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5485,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5485 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9135 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6588]
theorem b4_9135 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9135 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(8,true))] s4_9135 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9166 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6720]
theorem b4_9166 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9166 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s4_9166 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_9167 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6866]
theorem b4_9167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9167 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6866] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_9168 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w6179,w6300,w6832]
theorem b4_9168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9168 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_9168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_9203 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6247,w6300,w6588]
theorem b4_9203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9203 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(1,false))] s4_9203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6247,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6247 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9261 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6246,w6300,w6832]
theorem b4_9261 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9261 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_9261 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6246,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_9276 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6863]
theorem b4_9276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9276 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_9276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832,v2_6863] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6863 rfl))))))))))) (by decide +kernel)
def s4_9280 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6451,w6522,w6588]
theorem b4_9280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9280 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_9280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9285 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6246,w6300,w6522,w6588]
theorem b4_9285 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9285 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_9285 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6246,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9290 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5884,w6179,w6300,w6832]
theorem b4_9290 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9290 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_9290 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s4_9306 : List (BitVec 512) := [w1384,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9306 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9307 : List (BitVec 512) := [w1384,w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_9307 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9307 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9307 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9308 : List (BitVec 512) := [w1384,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9308 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9310 : List (BitVec 512) := [w1384,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9310 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9310 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9310 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9311 : List (BitVec 512) := [w1384,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_9311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9311 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_9311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9312 : List (BitVec 512) := [w1384,w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9312 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(9,true))] s4_9312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9313 : List (BitVec 512) := [w1384,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9313 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9314 : List (BitVec 512) := [w1384,w2393,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9314 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2393,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9315 : List (BitVec 512) := [w1384,w2427,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9315 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_9315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9316 : List (BitVec 512) := [w1384,w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9316 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9317 : List (BitVec 512) := [w1384,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9317 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9318 : List (BitVec 512) := [w1384,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9318 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9377 : List (BitVec 512) := [w1384,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9377 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9390 : List (BitVec 512) := [w1384,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9390 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9422 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b4_9422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9422 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9423 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5258,w5393,w5585,w5956,w6300,w6588]
theorem b4_9423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9423 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(9,true))] s4_9423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5258,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5258 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9424 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b4_9424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9424 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9425 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5289,w5393,w5585,w5956,w6300,w6588]
theorem b4_9425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9425 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9426 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5294,w5393,w5585,w5956,w6300,w6588]
theorem b4_9426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9426 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_9426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5294,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5294 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9427 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5295,w5393,w5585,w5956,w6300,w6588]
theorem b4_9427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9427 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5295,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5295 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9428 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b4_9428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9428 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9429 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b4_9429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9429 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9430 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5332,w5393,w5585,w5956,w6300,w6588]
theorem b4_9430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9430 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5332,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5332 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9431 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5437,w5585,w5956,w6300,w6588]
theorem b4_9431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9431 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5437,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5437 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9433 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_9433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9433 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9434 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b4_9434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9434 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9460 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_9460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9460 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9461 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5887,w5956,w6300,w6588]
theorem b4_9461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9461 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(9,true))] s4_9461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5887,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5887 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9481 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b4_9481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9481 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9482 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6162,w6300,w6588]
theorem b4_9482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9482 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_9482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6162,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6162 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_9510 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6246,w6300,w6588]
theorem b4_9510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9510 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_9510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6246,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
