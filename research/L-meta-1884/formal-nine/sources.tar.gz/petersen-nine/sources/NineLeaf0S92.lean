import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17864 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6894]
theorem b4_17864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17864 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(9,true),(7,true))] s4_17864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832,v0_6894] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 (PetersenWireProjection.cons pc0_6894 rfl))))))))))) (by decide +kernel)
def s4_17869 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6909]
theorem b4_17869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17869 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(9,true),(2,true))] s4_17869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832,v0_6909] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 (PetersenWireProjection.cons pc0_6909 rfl))))))))))) (by decide +kernel)
def s4_17875 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6851,w6857]
theorem b4_17875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17875 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(9,true),(2,true))] s4_17875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6851,v0_6857] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6851 (PetersenWireProjection.cons pc0_6857 rfl))))))))))) (by decide +kernel)
def s4_17876 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6851,w6866]
theorem b4_17876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17876 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(5,true)),(false,(9,true),(2,true))] s4_17876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6851,v0_6866] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6851 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_17877 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6851,w6890]
theorem b4_17877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17877 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(9,true),(7,true))] s4_17877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6851,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6851 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_17878 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6851,w6908]
theorem b4_17878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17878 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(9,true),(2,true))] s4_17878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6851,v0_6908] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6851 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_17881 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6858]
theorem b4_17881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17881 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(9,true),(1,false))] s4_17881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6857,v0_6858] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6857 (PetersenWireProjection.cons pc0_6858 rfl))))))))))) (by decide +kernel)
def s4_17893 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6858]
theorem b4_17893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17893 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(9,true),(1,false))] s4_17893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6858] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6858 rfl)))))))))) (by decide +kernel)
def s4_17896 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6715,w6720,w6807]
theorem b4_17896 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17896 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,false)),(false,(9,true),(3,true))] s4_17896 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6715,v0_6720,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6807 rfl))))))))))) (by decide +kernel)
def s4_17897 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6715,w6720,w6890]
theorem b4_17897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17897 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,false),(7,true)),(false,(3,true),(9,true))] s4_17897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6715,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_17898 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6715,w6807,w6832]
theorem b4_17898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17898 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,false)),(false,(9,true),(7,true))] s4_17898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6715,v0_6807,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6807 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_17903 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6745,w6890]
theorem b4_17903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17903 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_17903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6745,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6745 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_17922 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890,w6894]
theorem b4_17922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17922 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_17922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890,v0_6894] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 (PetersenWireProjection.cons pc0_6894 rfl))))))))))) (by decide +kernel)
def s4_17937 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6389,w6720,w6890]
theorem b4_17937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_17937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6389,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_17938 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6464,w6690,w6720]
theorem b4_17938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17938 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(8,true)),(false,(9,true),(3,true))] s4_17938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6464,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_17939 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6464,w6690,w6832]
theorem b4_17939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17939 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(8,true)),(false,(9,true),(7,true))] s4_17939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6464,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_17965 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6474,w6720,w6873]
theorem b4_17965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true))] s4_17965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6474,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6474 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_17976 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6745,w6873]
theorem b4_17976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true))] s4_17976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6720,v0_6745,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6745 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_17982 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6889]
theorem b4_17982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17982 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true))] s4_17982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6720,v0_6873,v0_6889] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 (PetersenWireProjection.cons pc0_6889 rfl))))))))))) (by decide +kernel)
def s4_17999 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6538,w6720,w6873]
theorem b4_17999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17999 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_17999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6538,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18005 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6889]
theorem b4_18005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18005 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_18005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873,v0_6889] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 (PetersenWireProjection.cons pc0_6889 rfl))))))))))) (by decide +kernel)
def s4_18014 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6061,w6300,w6720,w6873]
theorem b4_18014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18014 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(8,true)),(false,(9,true),(3,true))] s4_18014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6061,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18015 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6061,w6300,w6785,w6873]
theorem b4_18015 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18015 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(8,true)),(false,(9,true),(6,true))] s4_18015 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6061,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18016 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6061,w6464,w6588,w6873]
theorem b4_18016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18016 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(8,true)),(false,(8,true),(6,true))] s4_18016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6061,v0_6464,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18017 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6300,w6690,w6720]
theorem b4_18017 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18017 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(5,true)),(false,(9,true),(2,true))] s4_18017 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_18018 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6300,w6720,w6873]
theorem b4_18018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18018 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(6,true)),(false,(9,true),(8,true))] s4_18018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18019 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6389,w6422,w6588]
theorem b4_18019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18019 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(6,true),(5,true)),(false,(8,true),(2,true))] s4_18019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_18020 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6567,w6588,w6873]
theorem b4_18020 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18020 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(8,true),(9,true))] s4_18020 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6567,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18035 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6124,w6389,w6522,w6588]
theorem b4_18035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18035 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_18035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6124,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_18036 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6124,w6522,w6588,w6873]
theorem b4_18036 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18036 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_18036 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6124,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18052 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6538,w6588]
theorem b4_18052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18052 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_18052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_18063 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6538,w6588,w6873]
theorem b4_18063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18063 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_18063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6538,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_18092 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6195,w6300,w6690,w6832]
theorem b4_18092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18092 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(7,true),(9,true))] s4_18092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6195,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_18099 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832,w6851]
theorem b4_18099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18099 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(7,true),(9,true))] s4_18099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6690,v0_6832,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 (PetersenWireProjection.cons pc0_6851 rfl))))))))))) (by decide +kernel)
def s4_18104 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6851]
theorem b4_18104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18104 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(7,true),(9,true))] s4_18104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6690,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6851 rfl)))))))))) (by decide +kernel)
def s4_18119 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5476,w5585,w5956,w6300,w6588]
theorem b4_18119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18119 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5476,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5476 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_18120 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5476,w5585,w5956,w6300,w6588,w6690]
theorem b4_18120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18120 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5476,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5476 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_18137 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_18137 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18137 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18137 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s4_18138 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690,w6715]
theorem b4_18138 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18138 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18138 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690,v0_6715] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6715 rfl))))))))))) (by decide +kernel)
def s4_18144 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6715]
theorem b4_18144 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18144 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18144 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6715] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6715 rfl)))))))))) (by decide +kernel)
def s4_18150 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6667,w6690]
theorem b4_18150 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18150 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_18150 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_0 : List (BitVec 512) := [w0,w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_0 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_0 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_0 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2381,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1 : List (BitVec 512) := [w0,w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_1 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2382,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2382 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2 : List (BitVec 512) := [w0,w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_2 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2387,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3 : List (BitVec 512) := [w0,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4 : List (BitVec 512) := [w0,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5 : List (BitVec 512) := [w0,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_5 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_6 : List (BitVec 512) := [w0,w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_6 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_6 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2492,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_7 : List (BitVec 512) := [w0,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_7 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_7 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_7 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_8 : List (BitVec 512) := [w0,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_8 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_8 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_8 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_9 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_9 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_9 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_9 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_10 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_10 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_10 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s5_10 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_11 : List (BitVec 512) := [w1,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_11 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_11 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_11 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_14 : List (BitVec 512) := [w4,w2175,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_14 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_14 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_14 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_2175,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_2175 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_15 : List (BitVec 512) := [w4,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_15 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_15 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_15 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_16 : List (BitVec 512) := [w4,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_16 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_16 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_16 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_2494,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_2494 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_17 : List (BitVec 512) := [w4,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_17 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_17 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_17 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_18 : List (BitVec 512) := [w4,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_18 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_18 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_18 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_2530,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_2530 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_19 : List (BitVec 512) := [w4,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_19 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_19 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_19 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_4,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_4 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_30 : List (BitVec 512) := [w9,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_30 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_30 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_30 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_9,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_9 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_31 : List (BitVec 512) := [w9,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_31 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_31 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_31 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_9,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_9 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_32 : List (BitVec 512) := [w9,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_32 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_32 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_32 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_9,v0_2529,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_9 (PetersenWireProjection.cons pc0_2529 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_33 : List (BitVec 512) := [w9,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_33 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_33 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_33 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_9,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_9 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_44 : List (BitVec 512) := [w14,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_44 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_44 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_44 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_14,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_14 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
