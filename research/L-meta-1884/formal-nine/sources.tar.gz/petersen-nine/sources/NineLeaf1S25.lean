import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_8578 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6447,w6588]
theorem b4_8578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8578 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(9,true))] s4_8578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6447,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6447 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8590 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6501,w6588]
theorem b4_8590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8590 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(7,true),(9,true))] s4_8590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6501,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8622 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6422,w6444,w6588]
theorem b4_8622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8622 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(9,true))] s4_8622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6422,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8632 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5769,w5861,w5956,w6300,w6588]
theorem b4_8632 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8632 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_8632 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8659 : List (BitVec 512) := [w1369,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8659 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8665 : List (BitVec 512) := [w1369,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8665 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8665 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8665 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8666 : List (BitVec 512) := [w1369,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8666 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8666 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8666 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8667 : List (BitVec 512) := [w1369,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8667 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8668 : List (BitVec 512) := [w1369,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8668 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8669 : List (BitVec 512) := [w1369,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8669 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8670 : List (BitVec 512) := [w1369,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8670 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8671 : List (BitVec 512) := [w1369,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8671 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8692 : List (BitVec 512) := [w1369,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8692 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8700 : List (BitVec 512) := [w1369,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8700 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8710 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8710 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8711 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8711 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8712 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8712 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8713 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8713 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8714 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8714 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8715 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5067,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8715 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8715 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8715 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5067,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5067 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8716 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5182,w5393,w5585,w5956,w6300,w6588]
theorem b4_8716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8716 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5182,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5182 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8718 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_8718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8718 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8719 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_8719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8719 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8729 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_8729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8729 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8739 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_8739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8739 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8754 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b4_8754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8754 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8767 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b4_8767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8767 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8779 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_8779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8779 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_8779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_8838 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8838 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8839 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8839 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8840 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8840 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8841 : List (BitVec 512) := [w1374,w2313,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8841 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_8841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_8882 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8882 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8883 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8883 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8884 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8884 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8885 : List (BitVec 512) := [w1374,w2555,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8885 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_8885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_8886 : List (BitVec 512) := [w1374,w2555,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8886 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true))] s4_8886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2555,v1_3766,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8887 : List (BitVec 512) := [w1374,w2561,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8887 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_8887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2561,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2561 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8888 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8888 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8889 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8889 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8890 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8890 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8891 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w5135,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_8891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8891 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8892 : List (BitVec 512) := [w1374,w2589,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8892 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_8893 : List (BitVec 512) := [w1374,w2590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8893 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_8893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2590,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2590 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8894 : List (BitVec 512) := [w1374,w2597,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8894 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true))] s4_8894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2597,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2597 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8895 : List (BitVec 512) := [w1374,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8895 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8896 : List (BitVec 512) := [w1374,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8896 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8896 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8896 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8897 : List (BitVec 512) := [w1374,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8897 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8898 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8898 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8899 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8899 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8900 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_8900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8900 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_8900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8901 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6832]
theorem b4_8901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8901 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s4_8902 : List (BitVec 512) := [w1374,w2645,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8902 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(1,false))] s4_8902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2645,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2645 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8903 : List (BitVec 512) := [w1374,w2646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8903 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(1,false))] s4_8903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8904 : List (BitVec 512) := [w1374,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8904 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true))] s4_8904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8905 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8905 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2681,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8911 : List (BitVec 512) := [w1374,w2684,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8911 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_8911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2684,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2684 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_8912 : List (BitVec 512) := [w1374,w2692,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8912 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2692,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2692 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8984 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8984 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_8984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8985 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_8985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_8986 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_8986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_8987 : List (BitVec 512) := [w1374,w3766,w4004,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8987 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_8987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_8988 : List (BitVec 512) := [w1374,w3766,w4012,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8988 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_8988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4012,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4012 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9020 : List (BitVec 512) := [w1374,w3766,w4344,w4403,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b4_9020 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_9020 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4403,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
end NineCert
