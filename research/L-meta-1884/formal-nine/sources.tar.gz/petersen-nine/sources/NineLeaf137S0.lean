import NinePin137
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_9 : List (BitVec 512) := [w505,w2534,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b6_9 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_9 := by
  intro m le c
  apply rejects_sound r137 i7 6 tgt (small137 adj) hot137 [] s6_9 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v137_505,v137_2534,v137_3766,v137_4344,v137_4716,v137_5135,v137_5585,v137_5956,v137_6300] (PetersenWireProjection.cons pc137_505 (PetersenWireProjection.cons pc137_2534 (PetersenWireProjection.cons pc137_3766 (PetersenWireProjection.cons pc137_4344 (PetersenWireProjection.cons pc137_4716 (PetersenWireProjection.cons pc137_5135 (PetersenWireProjection.cons pc137_5585 (PetersenWireProjection.cons pc137_5956 (PetersenWireProjection.cons pc137_6300 rfl))))))))) (by decide +kernel)
end NineCert
