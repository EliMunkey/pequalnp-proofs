import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3058 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6785]
theorem b3_3058 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3058 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(8,true))] s3_3058 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s3_3059 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6852]
theorem b3_3059 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3059 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true))] s3_3059 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s3_3060 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6873]
theorem b3_3060 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3060 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true))] s3_3060 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s3_3061 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b3_3061 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3061 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true))] s3_3061 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3062 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6389,w6588]
theorem b3_3062 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3062 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(6,true))] s3_3062 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3063 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6436,w6588]
theorem b3_3063 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3063 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,false),(7,true))] s3_3063 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3064 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6478,w6588]
theorem b3_3064 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3064 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false))] s3_3064 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3065 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b3_3065 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3065 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s3_3065 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3066 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6720]
theorem b3_3066 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3066 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(4,true))] s3_3066 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s3_3067 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6785]
theorem b3_3067 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3067 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(2,true),(4,true))] s3_3067 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s3_3068 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6832]
theorem b3_3068 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3068 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(2,true))] s3_3068 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_3069 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6890]
theorem b3_3069 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3069 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,false),(8,true))] s3_3069 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s3_3070 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_3070 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3070 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s3_3070 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3071 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_3071 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3071 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s3_3071 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3072 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b3_3072 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3072 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(4,true),(2,true))] s3_3072 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3073 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_3073 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3073 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(4,true),(2,true))] s3_3073 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3074 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b3_3074 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3074 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(3,true),(7,true))] s3_3074 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3075 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3075 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3075 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_3075 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3076 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3076 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3076 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_3076 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3077 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_3077 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3077 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_3077 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3078 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_3078 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3078 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(4,true))] s3_3078 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3079 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3079 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3079 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_3079 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3080 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_3080 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3080 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(8,true))] s3_3080 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_3081 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3081 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3081 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_3081 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3082 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3082 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3082 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_3082 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3083 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_3083 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3083 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_3083 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3084 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_3084 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3084 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(4,true))] s3_3084 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3085 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3085 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3085 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_3085 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3086 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_3086 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3086 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(8,true))] s3_3086 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s3_3087 : List (BitVec 512) := [w2302,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3087 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3087 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(7,true),(3,true))] s3_3087 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3088 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3088 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3088 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(7,true),(3,true))] s3_3088 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3089 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_3089 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3089 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s3_3089 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3090 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3090 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3090 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s3_3090 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3091 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3091 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3091 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_3091 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3092 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3092 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3092 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true))] s3_3092 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3093 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_3093 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3093 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false))] s3_3093 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3094 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_3094 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3094 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true))] s3_3094 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3095 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_3095 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3095 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s3_3095 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3096 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_3096 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3096 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true))] s3_3096 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))))) (by decide +kernel)
def s3_3097 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3097 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3097 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_3097 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3098 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3098 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3098 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true))] s3_3098 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3099 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_3099 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3099 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false))] s3_3099 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3100 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_3100 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3100 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true))] s3_3100 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3101 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3101 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3101 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s3_3101 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3102 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_3102 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3102 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true))] s3_3102 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s3_3103 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_3103 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3103 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(6,true),(7,true))] s3_3103 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3104 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b3_3104 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3104 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(6,true),(3,true))] s3_3104 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3105 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b3_3105 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3105 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(6,true),(3,true))] s3_3105 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_3106 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3106 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3106 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_3106 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3107 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_3107 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3107 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true))] s3_3107 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3108 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_3108 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3108 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_3108 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3109 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_3109 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3109 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true))] s3_3109 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3110 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_3110 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3110 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_3110 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3111 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_3111 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3111 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s3_3111 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3112 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_3112 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3112 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true))] s3_3112 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_3113 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3113 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3113 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_3113 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3114 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_3114 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3114 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true))] s3_3114 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3115 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_3115 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3115 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_3115 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3116 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_3116 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3116 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true))] s3_3116 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3117 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_3117 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3117 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_3117 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3118 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3118 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3118 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s3_3118 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3119 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_3119 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3119 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true))] s3_3119 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s3_3120 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b3_3120 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3120 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(6,true),(7,true))] s3_3120 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3121 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b3_3121 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3121 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(6,true),(7,true))] s3_3121 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
