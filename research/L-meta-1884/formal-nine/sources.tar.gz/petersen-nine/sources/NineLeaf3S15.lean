import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4228 : List (BitVec 512) := [w3766,w4273,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6489,w6588]
theorem b3_4228 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4228 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(2,true))] s3_4228 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4273,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4273 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4229 : List (BitVec 512) := [w3766,w4273,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4229 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4229 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s3_4229 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4273,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4273 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4230 : List (BitVec 512) := [w3766,w4273,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_4230 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s3_4230 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4273,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4273 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4231 : List (BitVec 512) := [w3766,w4273,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4231 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4231 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4231 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4273,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4273 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4232 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4232 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4232 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4232 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4233 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4233 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4233 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4233 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4234 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_4234 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4234 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4234 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4235 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_4235 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4235 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4235 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4236 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_4236 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4236 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(5,true))] s3_4236 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4237 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_4237 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4237 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4237 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4238 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_4238 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4238 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4238 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4239 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6549,w6588]
theorem b3_4239 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4239 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false))] s3_4239 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4240 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6567,w6588]
theorem b3_4240 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4240 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,false))] s3_4240 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4241 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6690]
theorem b3_4241 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4241 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4241 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_4242 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6720]
theorem b3_4242 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4242 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(2,true))] s3_4242 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_4243 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6785]
theorem b3_4243 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4243 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(7,true),(6,true))] s3_4243 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_4244 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6908]
theorem b3_4244 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4244 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,false))] s3_4244 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl)))))))))))) (by decide +kernel)
def s3_4245 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_4245 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4245 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4245 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4246 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b3_4246 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4246 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false))] s3_4246 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4247 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b3_4247 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4247 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,false))] s3_4247 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4248 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_4248 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4248 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4248 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_4249 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_4249 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4249 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s3_4249 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s3_4250 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_4250 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4250 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_4250 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s3_4251 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b3_4251 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,false))] s3_4251 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s3_4252 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_4252 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4252 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4252 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4253 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b3_4253 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4253 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4253 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4254 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b3_4254 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4254 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(7,true),(8,true))] s3_4254 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4255 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b3_4255 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4255 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s3_4255 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4256 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b3_4256 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4256 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(5,true))] s3_4256 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4257 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_4257 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4257 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4257 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4258 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_4258 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_4258 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4259 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_4259 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4259 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4259 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4260 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_4260 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4260 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s3_4260 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4261 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_4261 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4261 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_4261 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4262 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6549,w6588]
theorem b3_4262 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4262 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s3_4262 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4263 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_4263 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4263 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_4263 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4264 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6549,w6588]
theorem b3_4264 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4264 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false))] s3_4264 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4265 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4265 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4265 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4266 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b3_4266 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4266 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s3_4266 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4267 : List (BitVec 512) := [w3766,w4292,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4267 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4267 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4267 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4268 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6567,w6588]
theorem b3_4268 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4268 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false))] s3_4268 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4269 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_4269 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4269 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s3_4269 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4270 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6567,w6588]
theorem b3_4270 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4270 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_4270 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4271 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4271 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4271 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s3_4271 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4272 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6567,w6588]
theorem b3_4272 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4272 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,false))] s3_4272 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_4273 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4273 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4273 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_4273 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4274 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b3_4274 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4274 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_4274 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4275 : List (BitVec 512) := [w3766,w4294,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4275 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4275 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4275 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4276 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4276 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4276 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4276 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4277 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4277 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4277 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4277 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4278 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_4278 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4278 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4278 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4279 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_4279 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4279 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s3_4279 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4280 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_4280 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4280 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_4280 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4281 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_4281 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4281 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true))] s3_4281 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4282 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_4282 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4282 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_4282 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_4283 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_4283 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4283 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s3_4283 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_4284 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4284 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4284 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_4284 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_4285 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_4285 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4285 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4285 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_4286 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6890]
theorem b3_4286 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4286 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4286 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl)))))))))))) (by decide +kernel)
def s3_4287 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6895]
theorem b3_4287 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4287 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s3_4287 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_4288 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6904]
theorem b3_4288 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4288 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s3_4288 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_4289 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b3_4289 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4289 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_4289 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s3_4290 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b3_4290 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4290 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s3_4290 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s3_4291 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b3_4291 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4291 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s3_4291 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
end NineCert
