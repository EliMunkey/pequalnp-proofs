import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7953 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6720]
theorem b4_7953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7953 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(8,true))] s4_7953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_7958 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6813]
theorem b4_7958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7958 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7959 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6104,w6300,w6588]
theorem b4_7959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7959 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,true),(8,true))] s4_7959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6104,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6104 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7960 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_7960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7960 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(8,true))] s4_7960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_7974 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b4_7974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7974 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(8,true))] s4_7974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_7992 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6720]
theorem b4_7992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7992 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_7992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_7997 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6813]
theorem b4_7997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7997 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(7,true),(5,true))] s4_7997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_7998 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_7998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7998 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_7998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8011 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6720]
theorem b4_8011 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8011 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(8,true),(4,true))] s4_8011 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8017 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_8017 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8017 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(8,true),(4,true))] s4_8017 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8075 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_8075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8075 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_8075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8082 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_8082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8082 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(8,true))] s4_8082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8083 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_8083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8083 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(8,true),(4,true))] s4_8083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8087 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5613,w5956,w6300,w6785,w6813]
theorem b4_8087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8087 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(0,true))] s4_8087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5613,v4_5956,v4_6300,v4_6785,v4_6813] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_8093 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b4_8093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8093 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(7,true))] s4_8093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8149 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5613,w5769,w5956,w6300,w6720]
theorem b4_8149 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8149 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s4_8149 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5613,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8212 : List (BitVec 512) := [w1312,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_8212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8212 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(3,true),(4,true))] s4_8212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8310 : List (BitVec 512) := [w1328,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8310 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8310 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8310 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8311 : List (BitVec 512) := [w1328,w3766,w4344,w4646,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_8311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8311 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8312 : List (BitVec 512) := [w1328,w3766,w4344,w4646,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_8312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8312 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8313 : List (BitVec 512) := [w1328,w3766,w4344,w4654,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8313 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4654,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8314 : List (BitVec 512) := [w1328,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8314 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8315 : List (BitVec 512) := [w1328,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8315 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8316 : List (BitVec 512) := [w1328,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8316 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8317 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8317 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8327 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8327 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8371 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6720]
theorem b4_8371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8371 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8375 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5703,w5956,w6300,w6588]
theorem b4_8375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8375 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5703,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5703 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8382 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8382 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8393 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6720]
theorem b4_8393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8393 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8414 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_8414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8414 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8427 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_8427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8427 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8439 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_8439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8439 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8451 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8451 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s4_8451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1328,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1328 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_8533 : List (BitVec 512) := [w1353,w3766,w4344,w4646,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_8533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8533 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_8533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8534 : List (BitVec 512) := [w1353,w3766,w4344,w4646,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_8534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8534 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_8534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8535 : List (BitVec 512) := [w1353,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6422,w6588]
theorem b4_8535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8535 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_8535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8536 : List (BitVec 512) := [w1353,w3766,w4344,w4669,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_8536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8536 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_8536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4669,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8537 : List (BitVec 512) := [w1353,w3766,w4344,w4672,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8537 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_8537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4672,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4672 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8702 : List (BitVec 512) := [w1369,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8702 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8703 : List (BitVec 512) := [w1369,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8703 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8704 : List (BitVec 512) := [w1369,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8704 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8705 : List (BitVec 512) := [w1369,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8705 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8706 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8706 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4716,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8737 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_8737 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8737 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8737 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8765 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_8765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8765 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8777 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_8777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8777 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8789 : List (BitVec 512) := [w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8789 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s4_8789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1369,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1369 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_8815 : List (BitVec 512) := [w1374,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8815 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_8815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8913 : List (BitVec 512) := [w1374,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8913 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_8913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_8914 : List (BitVec 512) := [w1374,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8914 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_8914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_8983 : List (BitVec 512) := [w1374,w3766,w3963,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8983 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_8983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_3963,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3963 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9039 : List (BitVec 512) := [w1374,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9039 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9040 : List (BitVec 512) := [w1374,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9040 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6866] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6866 rfl))))))))))) (by decide +kernel)
def s4_9041 : List (BitVec 512) := [w1374,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9041 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s4_9041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_9043 : List (BitVec 512) := [w1374,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9043 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9043 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9043 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9044 : List (BitVec 512) := [w1374,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9044 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s4_9044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_9045 : List (BitVec 512) := [w1374,w3766,w4344,w4668,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9045 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4668,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4668 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9046 : List (BitVec 512) := [w1374,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9046 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9047 : List (BitVec 512) := [w1374,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9047 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9048 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9048 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9049 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9049 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9050 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9050 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9050 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9050 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6866] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6866 rfl))))))))))) (by decide +kernel)
def s4_9051 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9051 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s4_9051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6832] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
end NineCert
