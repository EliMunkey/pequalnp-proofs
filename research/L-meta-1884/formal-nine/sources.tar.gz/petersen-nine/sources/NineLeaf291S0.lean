import NinePin291
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2808 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6478,w6588]
theorem b3_2808 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2808 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s3_2808 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1415,v291_3766,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6389,v291_6478,v291_6588] (PetersenWireProjection.cons pc291_1415 (PetersenWireProjection.cons pc291_3766 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6389 (PetersenWireProjection.cons pc291_6478 (PetersenWireProjection.cons pc291_6588 rfl)))))))))))) (by decide +kernel)
def s4_7103 : List (BitVec 512) := [w1252,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7103 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s4_7103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1252,v291_1891,v291_3766,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6588] (PetersenWireProjection.cons pc291_1252 (PetersenWireProjection.cons pc291_1891 (PetersenWireProjection.cons pc291_3766 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6588 rfl))))))))))) (by decide +kernel)
def s4_7105 : List (BitVec 512) := [w1252,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_7105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7105 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s4_7105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1252,v291_3766,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6389,v291_6588] (PetersenWireProjection.cons pc291_1252 (PetersenWireProjection.cons pc291_3766 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6389 (PetersenWireProjection.cons pc291_6588 rfl))))))))))) (by decide +kernel)
def s4_7125 : List (BitVec 512) := [w1268,w2852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7125 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s4_7125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1268,v291_2852,v291_3766,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6588] (PetersenWireProjection.cons pc291_1268 (PetersenWireProjection.cons pc291_2852 (PetersenWireProjection.cons pc291_3766 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6588 rfl))))))))))) (by decide +kernel)
def s4_7127 : List (BitVec 512) := [w1268,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_7127 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7127 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s4_7127 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1268,v291_3766,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6389,v291_6588] (PetersenWireProjection.cons pc291_1268 (PetersenWireProjection.cons pc291_3766 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6389 (PetersenWireProjection.cons pc291_6588 rfl))))))))))) (by decide +kernel)
def s4_10384 : List (BitVec 512) := [w1415,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10384 := by
  intro m le c
  apply rejects_sound r291 i5 4 tgt (small291 adj) hot291 [] s4_10384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v291_1415,v291_3303,v291_4344,v291_4716,v291_5135,v291_5393,v291_5585,v291_5956,v291_6300,v291_6389,v291_6588] (PetersenWireProjection.cons pc291_1415 (PetersenWireProjection.cons pc291_3303 (PetersenWireProjection.cons pc291_4344 (PetersenWireProjection.cons pc291_4716 (PetersenWireProjection.cons pc291_5135 (PetersenWireProjection.cons pc291_5393 (PetersenWireProjection.cons pc291_5585 (PetersenWireProjection.cons pc291_5956 (PetersenWireProjection.cons pc291_6300 (PetersenWireProjection.cons pc291_6389 (PetersenWireProjection.cons pc291_6588 rfl))))))))))) (by decide +kernel)
end NineCert
