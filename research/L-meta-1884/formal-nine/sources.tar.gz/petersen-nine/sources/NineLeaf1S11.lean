import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1418 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_1418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1418 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1429 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_1429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1429 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1442 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_1442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1442 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1454 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b4_1454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1454 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1465 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b4_1465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1465 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1474 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_1474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1474 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_1483 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6898]
theorem b4_1483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1483 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6898] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_1501 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6588,w6873]
theorem b4_1501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1501 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1525 : List (BitVec 512) := [w200,w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1525 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1542 : List (BitVec 512) := [w200,w1845,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1542 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1542 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,false),(5,true))] s4_1542 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_1845,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_1845 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1553 : List (BitVec 512) := [w200,w2113,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1553 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_2113,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_2113 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1561 : List (BitVec 512) := [w200,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1561 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1570 : List (BitVec 512) := [w200,w2989,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1570 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_2989,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_2989 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1590 : List (BitVec 512) := [w200,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1590 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1597 : List (BitVec 512) := [w200,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1597 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1607 : List (BitVec 512) := [w200,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1607 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1608 : List (BitVec 512) := [w200,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1608 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1609 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1609 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1610 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1610 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1611 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5122,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1611 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5122,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5122 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1612 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5124,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1612 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5124,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5124 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1613 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5140,w5393,w5585,w5956,w6300,w6588]
theorem b4_1613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1613 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5140,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5140 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1615 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_1615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1615 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1616 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_1616 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1616 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1616 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1618 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_1618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1618 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1627 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_1627 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1627 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1627 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1639 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b4_1639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1639 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1649 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6898]
theorem b4_1649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1649 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6898] (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_1905 : List (BitVec 512) := [w328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1905 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true))] s4_1905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1907 : List (BitVec 512) := [w332,w339,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1907 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_339,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1922 : List (BitVec 512) := [w332,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6832]
theorem b4_1922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1922 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1923 : List (BitVec 512) := [w332,w2688,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1923 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_2688,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_2688 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1932 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5110,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1932 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_3766,v1_4344,v1_4716,v1_5110,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5110 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1955 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6860]
theorem b4_1955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1955 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6860] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6860 rfl))))))))))) (by decide +kernel)
def s4_1968 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6588,w6832]
theorem b4_1968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1968 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_332,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_332 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1971 : List (BitVec 512) := [w333,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1971 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true))] s4_1971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_333,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_333 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1972 : List (BitVec 512) := [w334,w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1972 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(8,true))] s4_1972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_334,v1_360,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_334 (PetersenWireProjection.cons pc1_360 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1973 : List (BitVec 512) := [w334,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1973 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_1973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_334,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_334 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1974 : List (BitVec 512) := [w334,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1974 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true))] s4_1974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_334,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_334 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1975 : List (BitVec 512) := [w336,w364,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1975 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,false),(5,true))] s4_1975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_336,v1_364,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_336 (PetersenWireProjection.cons pc1_364 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1976 : List (BitVec 512) := [w336,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1976 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_1976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_336,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_336 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1977 : List (BitVec 512) := [w336,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1977 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true))] s4_1977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_336,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_336 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1978 : List (BitVec 512) := [w337,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1978 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true))] s4_1978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_337,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_337 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1979 : List (BitVec 512) := [w339,w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1979 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(2,true),(6,true)),(false,(1,false),(0,true))] s4_1979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_357,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_357 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1980 : List (BitVec 512) := [w339,w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1980 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(1,false),(0,true))] s4_1980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_360,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_360 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1981 : List (BitVec 512) := [w339,w364,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1981 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(8,true),(2,true)),(false,(1,false),(0,true))] s4_1981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_364,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_364 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1982 : List (BitVec 512) := [w339,w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1982 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(4,true),(7,true)),(false,(1,true),(0,false))] s4_1982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_365,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_365 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1983 : List (BitVec 512) := [w339,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b4_1983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1983 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_1983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1366,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6857] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1366 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_1984 : List (BitVec 512) := [w339,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_1984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1984 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_1984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1985 : List (BitVec 512) := [w339,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s4_1985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1599,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1599 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1986 : List (BitVec 512) := [w339,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s4_1986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1618,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1618 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1987 : List (BitVec 512) := [w339,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1987 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s4_1987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1626,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1626 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1988 : List (BitVec 512) := [w339,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1988 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_1988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1674,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1674 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1989 : List (BitVec 512) := [w339,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6690,w6832]
theorem b4_1989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1989 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(5,true),(8,true))] s4_1989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1908,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6690,v1_6832] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1908 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1990 : List (BitVec 512) := [w339,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_1990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1990 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(8,true),(0,true))] s4_1990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_1991 : List (BitVec 512) := [w339,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1991 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(6,true))] s4_1991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2104,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2104 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1992 : List (BitVec 512) := [w339,w2140,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1992 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true))] s4_1992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2140,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2140 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1993 : List (BitVec 512) := [w339,w2141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1993 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,true),(6,true))] s4_1993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2141,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2141 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1994 : List (BitVec 512) := [w339,w2169,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1994 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(7,true))] s4_1994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2169,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2169 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1995 : List (BitVec 512) := [w339,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1995 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true))] s4_1995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2175,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2175 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1996 : List (BitVec 512) := [w339,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_1996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_1996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1997 : List (BitVec 512) := [w339,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_1997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1997 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_1997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_1998 : List (BitVec 512) := [w339,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_1998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1998 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_1998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_1999 : List (BitVec 512) := [w339,w2819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,true))] s4_1999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_2819,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_2819 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
