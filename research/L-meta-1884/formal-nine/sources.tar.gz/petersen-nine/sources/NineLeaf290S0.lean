import NinePin290
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3120 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3120 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s4_3120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_637,v290_3766,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5698,v290_5956,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_637 (PetersenWireProjection.cons pc290_3766 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5698 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl))))))))))) (by decide +kernel)
def s4_3121 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_3121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3121 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s4_3121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_637,v290_3766,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6061,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_637 (PetersenWireProjection.cons pc290_3766 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6061 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl))))))))))) (by decide +kernel)
def s4_3123 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_3123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3123 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s4_3123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_637,v290_3766,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6201,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_637 (PetersenWireProjection.cons pc290_3766 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6201 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl))))))))))) (by decide +kernel)
def s4_8918 : List (BitVec 512) := [w1374,w2838,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8918 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s4_8918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_1374,v290_2838,v290_3766,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_1374 (PetersenWireProjection.cons pc290_2838 (PetersenWireProjection.cons pc290_3766 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl))))))))))) (by decide +kernel)
def s4_9332 : List (BitVec 512) := [w1384,w2838,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9332 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s4_9332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_1384,v290_2838,v290_3766,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_1384 (PetersenWireProjection.cons pc290_2838 (PetersenWireProjection.cons pc290_3766 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl))))))))))) (by decide +kernel)
def s5_956 : List (BitVec 512) := [w637,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_956 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_956 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s5_956 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_637,v290_3258,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_637 (PetersenWireProjection.cons pc290_3258 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl)))))))))) (by decide +kernel)
def s5_957 : List (BitVec 512) := [w637,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_957 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_957 := by
  intro m le c
  apply rejects_sound r290 i5 4 tgt (small290 adj) hot290 [] s5_957 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v290_637,v290_3293,v290_4344,v290_4716,v290_5135,v290_5393,v290_5585,v290_5956,v290_6300,v290_6588] (PetersenWireProjection.cons pc290_637 (PetersenWireProjection.cons pc290_3293 (PetersenWireProjection.cons pc290_4344 (PetersenWireProjection.cons pc290_4716 (PetersenWireProjection.cons pc290_5135 (PetersenWireProjection.cons pc290_5393 (PetersenWireProjection.cons pc290_5585 (PetersenWireProjection.cons pc290_5956 (PetersenWireProjection.cons pc290_6300 (PetersenWireProjection.cons pc290_6588 rfl)))))))))) (by decide +kernel)
end NineCert
