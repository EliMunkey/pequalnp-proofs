import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3505 : List (BitVec 512) := [w2288,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3505 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3505 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(3,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s5_3505 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2288,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2288 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3506 : List (BitVec 512) := [w2290,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3506 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3506 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_3506 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2290,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2290 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3507 : List (BitVec 512) := [w2291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3507 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3507 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_3507 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2291,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2291 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3511 : List (BitVec 512) := [w2302,w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3511 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3511 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_3511 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3512 : List (BitVec 512) := [w2302,w2683,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b5_3512 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3512 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(9,true))] s5_3512 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2683,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3513 : List (BitVec 512) := [w2302,w2683,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3513 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3513 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(4,true),(6,true))] s5_3513 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2683,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3514 : List (BitVec 512) := [w2302,w2690,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b5_3514 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3514 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(4,true),(9,true))] s5_3514 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2690,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3515 : List (BitVec 512) := [w2302,w3766,w4344,w4805,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3515 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3515 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,false),(0,true)),(false,(0,true),(9,true))] s5_3515 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4805,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4805 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3516 : List (BitVec 512) := [w2302,w3766,w4344,w4808,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3516 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3516 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s5_3516 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4808,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4808 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3517 : List (BitVec 512) := [w2302,w3766,w4344,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3517 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3517 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,false),(0,true)),(false,(0,true),(9,true))] s5_3517 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4810,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4810 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3518 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b5_3518 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3518 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true)),(false,(9,true),(5,true))] s5_3518 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3519 : List (BitVec 512) := [w2302,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_3519 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3519 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true)),(false,(6,true),(4,true))] s5_3519 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4926,v2_5135,v2_5393,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3520 : List (BitVec 512) := [w2302,w3766,w5135,w5393,w5585,w5956,w6101,w6389,w6549,w6588]
theorem b5_3520 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3520 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(5,true),(3,true)),(false,(9,true),(4,true))] s5_3520 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6389,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3521 : List (BitVec 512) := [w2302,w3766,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_3521 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3521 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true)),(false,(6,true),(4,true))] s5_3521 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_5135,v2_5393,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s5_3522 : List (BitVec 512) := [w2303,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3522 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3522 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false))] s5_3522 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2303,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2303 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3523 : List (BitVec 512) := [w2304,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3523 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3523 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_3523 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2304,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2304 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3524 : List (BitVec 512) := [w2305,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3524 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3524 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_3524 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2305,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2305 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3525 : List (BitVec 512) := [w2306,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3525 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3525 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true)),(false,(1,true),(0,false))] s5_3525 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2306,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2306 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3526 : List (BitVec 512) := [w2307,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3526 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3526 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_3526 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2307,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2307 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3527 : List (BitVec 512) := [w2308,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3527 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3527 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(8,true),(3,true)),(false,(1,true),(0,false))] s5_3527 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2308,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2308 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3533 : List (BitVec 512) := [w2326,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3533 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3533 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(5,true))] s5_3533 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3534 : List (BitVec 512) := [w2326,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3534 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3534 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(9,true),(8,true)),(false,(7,true),(0,true))] s5_3534 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2681,v2_3258,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3535 : List (BitVec 512) := [w2326,w2681,w3766,w4344,w4716,w5393,w5956,w6179,w6300,w6588]
theorem b5_3535 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3535 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(3,true)),(false,(8,true),(5,true))] s5_3535 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3536 : List (BitVec 512) := [w2326,w2687,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3536 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3536 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_3536 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2687,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2687 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3537 : List (BitVec 512) := [w2326,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3537 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3537 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(8,true))] s5_3537 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3538 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_3538 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3538 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true)),(false,(5,true),(8,true))] s5_3538 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3539 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w6179,w6300,w6588,w6832]
theorem b5_3539 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3539 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(9,true)),(false,(5,true),(8,true))] s5_3539 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_3540 : List (BitVec 512) := [w2326,w3258,w4716,w5135,w5393,w5956,w6179,w6300,w6389,w6588]
theorem b5_3540 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3540 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(3,true)),(false,(5,true),(8,true))] s5_3540 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3541 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5667,w5956,w6300,w6588]
theorem b5_3541 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3541 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(8,true))] s5_3541 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5667,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5667 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3542 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588,w6908]
theorem b5_3542 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3542 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(1,false),(5,true)),(false,(8,true),(5,true))] s5_3542 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl)))))))))) (by decide +kernel)
def s5_3543 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6588,w6873]
theorem b5_3543 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3543 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true)),(false,(5,true),(8,true))] s5_3543 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3544 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5200,w5393,w5956,w6179,w6300,w6588]
theorem b5_3544 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3544 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(7,true),(3,true)),(false,(1,true),(7,true))] s5_3544 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5200,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5200 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3545 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_3545 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3545 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(6,true),(2,true)),(false,(9,true),(3,true)),(false,(8,true),(5,true))] s5_3545 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6300,v2_6690,v2_6832] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_3546 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_3546 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3546 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true)),(false,(6,true),(4,true))] s5_3546 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3547 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5956,w6179,w6389,w6422,w6588]
theorem b5_3547 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3547 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(7,true),(3,true)),(false,(6,true),(4,true))] s5_3547 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3548 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w6179,w6389,w6522,w6588]
theorem b5_3548 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3548 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true)),(false,(6,true),(4,true))] s5_3548 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_6179,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s5_3549 : List (BitVec 512) := [w2326,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_3549 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3549 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true)),(false,(10,true),(4,true))] s5_3549 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3550 : List (BitVec 512) := [w2327,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3550 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3550 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3550 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2327,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2327 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3551 : List (BitVec 512) := [w2328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3551 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3551 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3551 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3552 : List (BitVec 512) := [w2329,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3552 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3552 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3552 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2329,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2329 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3553 : List (BitVec 512) := [w2330,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3553 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3553 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3553 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2330,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2330 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3554 : List (BitVec 512) := [w2331,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3554 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3554 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3554 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2331,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2331 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3555 : List (BitVec 512) := [w2332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3555 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3555 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_3555 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2332,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2332 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3556 : List (BitVec 512) := [w2333,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3556 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3556 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true)),(false,(0,false),(8,true))] s5_3556 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2333,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2333 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3558 : List (BitVec 512) := [w2336,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_3558 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3558 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true)),(false,(6,true),(5,true))] s5_3558 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2336,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2336 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3561 : List (BitVec 512) := [w2341,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3561 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3561 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s5_3561 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3562 : List (BitVec 512) := [w2341,w2686,w3766,w4344,w4716,w5393,w5956,w6300,w6464,w6588]
theorem b5_3562 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3562 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(8,true),(6,true))] s5_3562 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3563 : List (BitVec 512) := [w2341,w2686,w3766,w4344,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b5_3563 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3563 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(6,true),(9,true))] s5_3563 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2686,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3564 : List (BitVec 512) := [w2341,w2696,w3766,w4344,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b5_3564 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3564 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(9,true))] s5_3564 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_2696,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3565 : List (BitVec 512) := [w2341,w3766,w4344,w4426,w5135,w5393,w5585,w5956,w6422,w6588]
theorem b5_3565 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3565 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true)),(false,(1,true),(4,true))] s5_3565 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4426,v2_5135,v2_5393,v2_5585,v2_5956,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4426 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3566 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5623,w5956,w6300,w6588]
theorem b5_3566 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3566 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(8,true))] s5_3566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5623,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5623 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3567 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5657,w5956,w6300,w6588]
theorem b5_3567 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3567 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(8,true))] s5_3567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5657,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5657 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3568 : List (BitVec 512) := [w2341,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6813,w6873]
theorem b5_3568 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3568 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true)),(false,(8,true),(6,true))] s5_3568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6464,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3569 : List (BitVec 512) := [w2341,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_3569 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3569 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(10,true),(6,true))] s5_3569 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_4344,v2_5135,v2_5393,v2_5769,v2_5956,v2_6464,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3570 : List (BitVec 512) := [w2341,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_3570 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3570 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true)),(false,(8,true),(9,true))] s5_3570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2341,v2_3766,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3571 : List (BitVec 512) := [w2342,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3571 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3571 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_3571 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2342,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2342 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3572 : List (BitVec 512) := [w2343,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3572 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3572 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_3572 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2343,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2343 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3573 : List (BitVec 512) := [w2344,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3573 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s5_3573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2344,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2344 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3574 : List (BitVec 512) := [w2345,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3574 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3574 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_3574 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2345,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2345 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3575 : List (BitVec 512) := [w2346,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3575 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3575 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_3575 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2346,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2346 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3576 : List (BitVec 512) := [w2347,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3576 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3576 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_3576 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2347,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2347 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3577 : List (BitVec 512) := [w2348,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3577 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3577 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s5_3577 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2348,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2348 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3580 : List (BitVec 512) := [w2351,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3580 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3580 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s5_3580 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2351,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2351 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3581 : List (BitVec 512) := [w2352,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3581 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3581 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(2,false))] s5_3581 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
