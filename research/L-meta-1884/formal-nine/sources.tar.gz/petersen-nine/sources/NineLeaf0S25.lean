import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4782 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_4782 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4782 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4782 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4783 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_4783 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4783 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true))] s3_4783 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4784 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_4784 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4784 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false))] s3_4784 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4785 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_4785 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4785 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true))] s3_4785 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4786 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b3_4786 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4786 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(1,true))] s3_4786 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s3_4787 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b3_4787 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4787 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(8,true),(1,true))] s3_4787 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s3_4788 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b3_4788 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4788 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s3_4788 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_4789 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b3_4789 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4789 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(8,true),(7,true))] s3_4789 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_4790 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b3_4790 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4790 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(7,true),(1,true))] s3_4790 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4791 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_4791 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4791 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(7,true),(1,true))] s3_4791 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4807 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5730,w5848,w5956,w6300,w6588]
theorem b3_4807 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4807 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_4807 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5730,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4808 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5730,w5956,w6101,w6300,w6588]
theorem b3_4808 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4808 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_4808 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5730,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4809 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5730,w5956,w6300,w6522,w6588]
theorem b3_4809 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4809 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_4809 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5730,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4823 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5860,w5956,w6300,w6588]
theorem b3_4823 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4823 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_4823 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4839 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5860,w5956,w6300,w6588]
theorem b3_4839 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4839 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_4839 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4845 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6124,w6300,w6588]
theorem b3_4845 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4845 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_4845 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6124,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4852 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6124,w6300,w6588]
theorem b3_4852 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4852 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_4852 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6124,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4861 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6538,w6588]
theorem b3_4861 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4861 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_4861 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4867 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6667,w6807]
theorem b3_4867 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4867 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,false))] s3_4867 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6667,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6807 rfl))))))))))) (by decide +kernel)
def s3_4875 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5730,w5848,w5956,w6300,w6588]
theorem b3_4875 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4875 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_4875 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5730,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4876 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5730,w5956,w6101,w6300,w6588]
theorem b3_4876 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4876 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_4876 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5730,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4883 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5848,w5956,w6300,w6588]
theorem b3_4883 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4883 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_4883 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4884 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6225,w6300,w6588]
theorem b3_4884 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4884 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4884 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4885 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6300,w6389,w6588]
theorem b3_4885 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4885 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true))] s3_4885 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4886 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6300,w6489,w6588]
theorem b3_4886 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4886 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4886 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4887 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6300,w6588,w6690]
theorem b3_4887 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4887 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true))] s3_4887 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))))) (by decide +kernel)
def s3_4888 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6300,w6588,w6813]
theorem b3_4888 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4888 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_4888 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6588,v0_6813] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6813 rfl)))))))))))) (by decide +kernel)
def s3_4889 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5810,w5956,w6300,w6588,w6873]
theorem b3_4889 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4889 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true))] s3_4889 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5810,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_4890 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5860,w5956,w6300,w6588]
theorem b3_4890 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4890 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_4890 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4906 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5860,w5956,w6300,w6588]
theorem b3_4906 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4906 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_4906 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4919 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6232,w6300,w6588]
theorem b3_4919 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4919 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4919 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6225,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4927 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6232,w6300,w6588]
theorem b3_4927 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4927 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4927 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4932 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6417,w6588]
theorem b3_4932 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4932 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true))] s3_4932 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6417,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4937 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6496,w6588]
theorem b3_4937 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4937 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6489,v0_6496,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6496 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_4943 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6496,w6588]
theorem b3_4943 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4943 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4943 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6496,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6496 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4946 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6538,w6588]
theorem b3_4946 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4946 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true))] s3_4946 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4951 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6715]
theorem b3_4951 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4951 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(2,true))] s3_4951 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6715] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6715 rfl))))))))))) (by decide +kernel)
def s3_4957 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6667,w6690]
theorem b3_4957 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4957 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(2,true))] s3_4957 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6667,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s3_4965 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6377,w6389,w6588]
theorem b3_4965 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true))] s3_4965 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4969 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6048,w6061,w6300,w6588]
theorem b3_4969 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4969 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(2,true))] s3_4969 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_6048,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4974 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5810,w5848,w5956,w6300,w6588]
theorem b3_4974 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4974 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_4974 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5810,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4975 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5810,w5956,w6225,w6300,w6588]
theorem b3_4975 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_4975 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5810,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4976 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5810,w5956,w6300,w6489,w6588]
theorem b3_4976 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_4976 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5810,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4977 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5810,w5956,w6300,w6588,w6813]
theorem b3_4977 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4977 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_4977 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588,v0_6813] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s3_4978 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5860,w5956,w6300,w6588]
theorem b3_4978 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4978 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4978 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_4997 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5860,w5956,w6300,w6588]
theorem b3_4997 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4997 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_4997 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5860,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5860 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_5002 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6146,w6300,w6588]
theorem b3_5002 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5002 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_5002 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_5009 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6146,w6300,w6588]
theorem b3_5009 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5009 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_5009 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_5011 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6232,w6300,w6588]
theorem b3_5011 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5011 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_5011 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_5014 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6232,w6300,w6588]
theorem b3_5014 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5014 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_5014 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_5018 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6690,w6748]
theorem b3_5018 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5018 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,false))] s3_5018 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690,v0_6748] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6748 rfl))))))))))) (by decide +kernel)
def s3_5019 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6690,w6807]
theorem b3_5019 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5019 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,false))] s3_5019 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6807 rfl))))))))))) (by decide +kernel)
def s3_5020 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6690,w6852]
theorem b3_5020 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5020 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(6,true))] s3_5020 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690,v0_6852] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6852 rfl))))))))))) (by decide +kernel)
def s3_5021 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6690,w6890]
theorem b3_5021 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5021 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true))] s3_5021 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6690,v0_6890] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s3_5022 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6785,w6807]
theorem b3_5022 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5022 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(1,true))] s3_5022 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6807 rfl))))))))))) (by decide +kernel)
def s3_5023 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6785,w6813]
theorem b3_5023 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5023 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true))] s3_5023 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785,v0_6813] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s3_5024 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6785,w6866]
theorem b3_5024 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5024 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(6,true))] s3_5024 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785,v0_6866] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s3_5025 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6785,w6904]
theorem b3_5025 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5025 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s3_5025 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785,v0_6904] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6904 rfl))))))))))) (by decide +kernel)
def s3_5026 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6667,w6807]
theorem b3_5026 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5026 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(1,true))] s3_5026 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6667,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s3_5035 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6715,w6720]
theorem b3_5035 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5035 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(1,true))] s3_5035 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6715,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s3_5036 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6715,w6832]
theorem b3_5036 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5036 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(8,true),(1,true))] s3_5036 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6715,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6715 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s3_5037 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6745]
theorem b3_5037 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5037 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(1,true))] s3_5037 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720,v0_6745] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6745 rfl))))))))))) (by decide +kernel)
def s3_5049 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6745]
theorem b3_5049 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5049 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(1,true))] s3_5049 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6745] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6745 rfl)))))))))) (by decide +kernel)
def s3_5054 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6851]
theorem b3_5054 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5054 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(8,true),(1,true))] s3_5054 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832,v0_6851] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 (PetersenWireProjection.cons pc0_6851 rfl))))))))))) (by decide +kernel)
end NineCert
