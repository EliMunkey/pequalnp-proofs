import NineUnconditional
import catalogue.NineRelabel

open PetersenInducedCostTable
namespace NineCert

/-- Every nine-vertex induced subgraph of the Petersen graph requires at least fifteen signed binary gates. -/
theorem all_deletions (s : Fin 1024) (h : (vertices s.val).length = 9) : lower s.val 15 :=
  PetersenNineRelabel.lower_bound 15 fifteen s h

#print axioms all_deletions
end NineCert
