import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_14213 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14213 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s4_14213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14214 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6499,w6588]
theorem b4_14214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14214 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false)),(false,(0,false),(8,true))] s4_14214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14215 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14215 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14215 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s4_14215 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14216 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6499,w6588]
theorem b4_14216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14216 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true))] s4_14216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14217 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_14217 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14217 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s4_14217 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14218 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6499,w6588]
theorem b4_14218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14218 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,false),(1,true)),(false,(0,false),(6,true))] s4_14218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14219 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14219 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s4_14219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14220 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6499,w6588]
theorem b4_14220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14220 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,false),(1,true)),(false,(0,false),(6,true))] s4_14220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14221 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_14221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14221 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,false),(1,true))] s4_14221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14222 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_14222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14222 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s4_14222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14223 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14223 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_14223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s4_14224 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_14224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14224 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s4_14224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14225 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_14225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14225 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_14225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6553,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6553 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14226 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_14226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14226 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false)),(false,(0,false),(6,true))] s4_14226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14227 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_14227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14227 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,false)),(false,(0,false),(3,true))] s4_14227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6575,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6575 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14228 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_14228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14228 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true))] s4_14228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl))))))))))) (by decide +kernel)
def s4_14229 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_14229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14229 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,false)),(false,(0,false),(3,true))] s4_14229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl))))))))))) (by decide +kernel)
def s4_14230 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_14230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14230 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(8,true),(2,true))] s4_14230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14231 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_14231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14231 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,false)),(false,(8,true),(2,true))] s4_14231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14232 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_14232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14232 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(8,true)),(false,(8,true),(0,false))] s4_14232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_14233 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_14233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14233 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_14233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14234 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6785,w6873]
theorem b4_14234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14234 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_14234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14235 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6588,w6873]
theorem b4_14235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14235 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,false)),(false,(8,true),(9,true))] s4_14235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6567,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14236 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_14236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14236 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_14236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14237 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_14237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14237 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_14237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14238 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b4_14238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14238 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(1,true)),(false,(8,true),(7,true))] s4_14238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14239 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_14239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14239 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(5,true),(1,true))] s4_14239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14240 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_14240 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14240 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s4_14240 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14241 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588,w6785]
theorem b4_14241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14241 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s4_14241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6522,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14242 : List (BitVec 512) := [w3672,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14242 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s4_14242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3672,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3672 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14243 : List (BitVec 512) := [w3673,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14243 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s4_14243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3673,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3673 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14244 : List (BitVec 512) := [w3674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14244 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s4_14244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3674,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3674 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14245 : List (BitVec 512) := [w3674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14245 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_14245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3674,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3674 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14246 : List (BitVec 512) := [w3678,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14246 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14246 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s4_14246 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3678,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3678 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14247 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14247 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s4_14247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14248 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_14248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14248 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(2,true))] s4_14248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14249 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_14249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14249 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true))] s4_14249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14250 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_14250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14250 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,false),(2,true))] s4_14250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14251 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_14251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14251 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false))] s4_14251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14252 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_14252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14252 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(0,false),(2,true))] s4_14252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14253 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_14253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14253 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,false),(3,true))] s4_14253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6553,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6553 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14254 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_14254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14254 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(0,false),(5,true))] s4_14254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14255 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_14255 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14255 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,false),(6,true))] s4_14255 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14256 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_14256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14256 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true))] s4_14256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14257 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14257 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true))] s4_14257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14258 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_14258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14258 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(8,true))] s4_14258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6852] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6852 rfl))))))))))) (by decide +kernel)
def s4_14259 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_14259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14259 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,false),(8,true))] s4_14259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_14260 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_14260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14260 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(0,false),(8,true))] s4_14260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_14261 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_14261 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14261 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true))] s4_14261 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6910] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6910 rfl))))))))))) (by decide +kernel)
def s4_14262 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_14262 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14262 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(7,true),(2,true))] s4_14262 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14263 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_14263 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14263 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(7,true),(8,true))] s4_14263 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14264 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_14264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14264 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(6,true),(2,true))] s4_14264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6061,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14265 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_14265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14265 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s4_14265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14266 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_14266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14266 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(1,false))] s4_14266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14267 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_14267 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14267 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(6,true),(5,true))] s4_14267 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14268 : List (BitVec 512) := [w3682,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14268 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14268 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(1,true),(2,true))] s4_14268 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14269 : List (BitVec 512) := [w3682,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_14269 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14269 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(1,true),(5,true))] s4_14269 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14270 : List (BitVec 512) := [w3682,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6690]
theorem b4_14270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14270 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(1,true),(8,true))] s4_14270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14271 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14271 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true))] s4_14271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14272 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_14272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14272 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,false),(1,true))] s4_14272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14273 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_14273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14273 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,false),(5,true))] s4_14273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14274 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_14274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14274 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(1,true))] s4_14274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6436,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6436 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14275 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_14275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14275 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s4_14275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14276 : List (BitVec 512) := [w3683,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_14276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14276 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,false))] s4_14276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
