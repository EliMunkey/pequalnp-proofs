import NinePin273
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4499 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6542,w6588]
theorem b5_4499 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4499 := by
  intro m le c
  apply rejects_sound r273 i6 5 tgt (small273 adj) hot273 [] s5_4499 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v273_2488,v273_3766,v273_4344,v273_4716,v273_5135,v273_5585,v273_5956,v273_6300,v273_6542,v273_6588] (PetersenWireProjection.cons pc273_2488 (PetersenWireProjection.cons pc273_3766 (PetersenWireProjection.cons pc273_4344 (PetersenWireProjection.cons pc273_4716 (PetersenWireProjection.cons pc273_5135 (PetersenWireProjection.cons pc273_5585 (PetersenWireProjection.cons pc273_5956 (PetersenWireProjection.cons pc273_6300 (PetersenWireProjection.cons pc273_6542 (PetersenWireProjection.cons pc273_6588 rfl)))))))))) (by decide +kernel)
end NineCert
