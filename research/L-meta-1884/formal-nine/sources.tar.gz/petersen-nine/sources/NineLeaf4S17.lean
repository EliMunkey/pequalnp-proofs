import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5144 : List (BitVec 512) := [w1076,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_5144 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5144 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true)),(false,(5,true),(9,true))] s4_5144 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5145 : List (BitVec 512) := [w1076,w1915,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5145 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5145 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true))] s4_5145 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1915,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5146 : List (BitVec 512) := [w1076,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5146 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5146 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,false),(3,true)),(false,(9,true),(0,true))] s4_5146 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1916,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1916 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5147 : List (BitVec 512) := [w1076,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5147 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5147 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true))] s4_5147 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1917,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1917 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5148 : List (BitVec 512) := [w1076,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5148 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5148 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true))] s4_5148 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1917,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1917 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5149 : List (BitVec 512) := [w1076,w1919,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5149 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5149 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_5149 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1919,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1919 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5150 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5150 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5150 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_5150 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4583,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4583 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5151 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_5151 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5151 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5151 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_4800,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4800 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5152 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_5152 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5152 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5152 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5153 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_5153 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5153 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_5153 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5652,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5652 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5154 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_5154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5154 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(8,true))] s4_5154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5155 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_5155 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5155 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5155 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5156 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_5156 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5156 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s4_5156 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5157 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6720]
theorem b4_5157 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5157 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5157 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5158 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_5158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5158 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(1,false))] s4_5158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5159 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_5159 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5159 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5159 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5160 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_5160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5160 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(1,false))] s4_5160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6567,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6567 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5161 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5161 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5161 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s4_5161 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5162 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_5162 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5162 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_5162 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6640] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6640 rfl))))))))))) (by decide +kernel)
def s4_5163 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_5163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5163 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(4,true))] s4_5163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5164 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_5164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5164 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5165 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_5165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5165 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(8,true))] s4_5165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl))))))))))) (by decide +kernel)
def s4_5166 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_5166 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5166 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(1,false))] s4_5166 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_5167 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b4_5167 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5167 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5167 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5168 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_5168 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5168 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s4_5168 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5169 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_5169 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5169 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s4_5169 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5170 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_5170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5170 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5171 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_5171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5171 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(9,true))] s4_5171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_6179,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5172 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b4_5172 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5172 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5172 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5173 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_5173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5173 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5174 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_5174 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5174 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5174 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5175 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_5175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5175 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5176 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_5176 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5176 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_5176 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5177 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_5177 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5177 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5177 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5178 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5178 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5178 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5178 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5179 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_5179 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5179 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5179 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5180 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_5180 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5180 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5180 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5181 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_5181 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5181 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5181 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5182 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5182 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5182 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5182 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5183 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b4_5183 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5183 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5183 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5184 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_5184 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5184 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_5184 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5185 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6588]
theorem b4_5185 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5185 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,false)),(false,(7,true),(0,true))] s4_5185 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5186 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6464,w6588]
theorem b4_5186 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5186 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s4_5186 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5187 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_5187 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5187 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s4_5187 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6567,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6567 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5188 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5188 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5188 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s4_5188 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5189 : List (BitVec 512) := [w1076,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_5189 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5189 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5189 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5190 : List (BitVec 512) := [w1076,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_5190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5190 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_5191 : List (BitVec 512) := [w1076,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_5191 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5191 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_5191 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5192 : List (BitVec 512) := [w1076,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_5192 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5192 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_5192 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_5193 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_5193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5193 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(3,true))] s4_5193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4584,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4584 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5194 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b4_5194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5194 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(0,true),(7,true))] s4_5194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5654,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5654 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5195 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_5195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5195 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(3,true))] s4_5195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5196 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6720]
theorem b4_5196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5196 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(7,true))] s4_5196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5197 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_5197 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5197 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s4_5197 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5198 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6720]
theorem b4_5198 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5198 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(8,true))] s4_5198 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6061,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5199 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5199 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s4_5199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5200 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_5200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5200 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s4_5200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5201 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_5201 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5201 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(4,true))] s4_5201 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5202 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6720]
theorem b4_5202 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5202 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(4,true))] s4_5202 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5203 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_5203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5203 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(3,true),(5,true))] s4_5203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6748] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s4_5204 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_5204 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5204 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(5,true))] s4_5204 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_5205 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5205 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_5205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5206 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_5206 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5206 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_5206 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5207 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_5207 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5207 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_5207 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
end NineCert
