import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_606 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_606 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_607 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_607 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(8,true),(5,true))] s4_607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_608 : List (BitVec 512) := [w70,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_608 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(1,true),(2,true))] s4_608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_609 : List (BitVec 512) := [w70,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_609 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(1,true))] s4_609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_610 : List (BitVec 512) := [w70,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b4_610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_610 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(2,true),(0,false))] s4_610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_660 : List (BitVec 512) := [w80,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_660 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_660 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_660 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_80,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_80 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_664 : List (BitVec 512) := [w81,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_664 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_81,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_81 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_665 : List (BitVec 512) := [w82,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_665 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_665 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_665 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_82,v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_82 (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_666 : List (BitVec 512) := [w82,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_666 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_666 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_666 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_82,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_82 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_667 : List (BitVec 512) := [w82,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_667 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_82,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_82 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_668 : List (BitVec 512) := [w84,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_84,v0_200,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_84 (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_669 : List (BitVec 512) := [w84,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_669 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_84,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_84 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_670 : List (BitVec 512) := [w84,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_670 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_84,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_84 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_671 : List (BitVec 512) := [w93,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_671 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s4_671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_93,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_93 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_672 : List (BitVec 512) := [w98,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_672 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s4_672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_98,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_98 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_673 : List (BitVec 512) := [w99,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_673 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_673 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_673 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_99,v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_99 (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_674 : List (BitVec 512) := [w99,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_674 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_99,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_99 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_675 : List (BitVec 512) := [w99,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_675 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_675 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s4_675 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_99,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_99 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_676 : List (BitVec 512) := [w101,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_676 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_676 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_676 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_101,v0_200,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_101 (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_677 : List (BitVec 512) := [w101,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_677 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_677 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_677 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_101,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_101 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_678 : List (BitVec 512) := [w101,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_678 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s4_678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_101,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_101 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_679 : List (BitVec 512) := [w103,w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_679 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_160,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_680 : List (BitVec 512) := [w103,w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_680 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_192,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_192 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_681 : List (BitVec 512) := [w103,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_681 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_681 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_681 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_682 : List (BitVec 512) := [w103,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_682 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_682 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_682 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_200,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_683 : List (BitVec 512) := [w103,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_683 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_683 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,false),(1,true)),(false,(9,true),(0,true))] s4_683 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_684 : List (BitVec 512) := [w103,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_684 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(6,true))] s4_684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1832,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1832 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_685 : List (BitVec 512) := [w103,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_685 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true))] s4_685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1867,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1867 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_686 : List (BitVec 512) := [w103,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_686 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_686 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(6,true))] s4_686 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1875,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1875 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_687 : List (BitVec 512) := [w103,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_687 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_687 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(8,true),(9,true))] s4_687 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1894,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1894 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_688 : List (BitVec 512) := [w103,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_688 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_688 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(7,true))] s4_688 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1915,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1915 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_689 : List (BitVec 512) := [w103,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_689 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_689 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,false),(1,true)),(false,(7,true),(0,true))] s4_689 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1916,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1916 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_690 : List (BitVec 512) := [w103,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_690 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(7,true))] s4_690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1917,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1917 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_691 : List (BitVec 512) := [w103,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_691 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true))] s4_691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2104,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2104 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_692 : List (BitVec 512) := [w103,w2125,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_692 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(5,true))] s4_692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2125,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2125 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_693 : List (BitVec 512) := [w103,w2143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_693 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_693 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(8,true),(9,true))] s4_693 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2143,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2143 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_694 : List (BitVec 512) := [w103,w2171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_694 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_694 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(2,true),(6,true))] s4_694 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2171,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2171 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_695 : List (BitVec 512) := [w103,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785,w6873]
theorem b4_695 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_695 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s4_695 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2171,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2171 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_696 : List (BitVec 512) := [w103,w2172,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(6,true))] s4_696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2172,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2172 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_697 : List (BitVec 512) := [w103,w2173,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_697 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(6,true))] s4_697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2173,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2173 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_698 : List (BitVec 512) := [w103,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_698 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_699 : List (BitVec 512) := [w103,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_699 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_700 : List (BitVec 512) := [w103,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_700 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_701 : List (BitVec 512) := [w103,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_701 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_702 : List (BitVec 512) := [w103,w3075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true))] s4_702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3075,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3075 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_703 : List (BitVec 512) := [w103,w3123,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_703 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,true),(1,true))] s4_703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3123,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3123 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_704 : List (BitVec 512) := [w103,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_704 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(9,true),(3,true))] s4_704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3182,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3182 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_705 : List (BitVec 512) := [w103,w3183,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_705 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(2,true))] s4_705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3183,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3183 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_706 : List (BitVec 512) := [w103,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_706 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4519,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4519 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_707 : List (BitVec 512) := [w103,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_707 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4571,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4571 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_708 : List (BitVec 512) := [w103,w3766,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_4785,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4785 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_709 : List (BitVec 512) := [w103,w3766,w4344,w4716,w4796,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_709 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_4796,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4796 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_710 : List (BitVec 512) := [w103,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_710 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_4810,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4810 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_711 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_711 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(5,true))] s4_711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_712 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_712 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(6,true))] s4_712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_713 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_713 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true))] s4_713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_714 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_714 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,false),(0,false))] s4_714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6897] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6897 rfl))))))))))) (by decide +kernel)
def s4_715 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_715 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_715 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(1,false),(0,false))] s4_715 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6905] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6905 rfl))))))))))) (by decide +kernel)
def s4_716 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_716 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(6,true))] s4_716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6906] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6906 rfl))))))))))) (by decide +kernel)
def s4_717 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_717 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_717 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s4_717 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl))))))))))) (by decide +kernel)
def s4_718 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_718 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(1,true)),(false,(3,true),(9,true))] s4_718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_719 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_719 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(1,false))] s4_719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_720 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873]
theorem b4_720 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_720 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true))] s4_720 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_721 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_721 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_721 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_721 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
end NineCert
