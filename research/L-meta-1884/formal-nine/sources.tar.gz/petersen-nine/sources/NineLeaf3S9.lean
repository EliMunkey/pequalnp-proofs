import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2752 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b3_2752 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2752 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2752 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_2753 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_2753 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2753 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2753 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_2760 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6389,w6588]
theorem b3_2760 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2760 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2760 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_2761 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_2761 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2761 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2761 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_2772 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6690]
theorem b3_2772 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2772 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2772 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_2777 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6690]
theorem b3_2777 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2777 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2777 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_2785 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b3_2785 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2785 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2785 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_2791 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b3_2791 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2791 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s3_2791 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s3_2899 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_2899 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2899 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_2899 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_2900 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_2900 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2900 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_2900 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3311 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3311 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3311 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3312 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3312 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3312 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3312 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3313 : List (BitVec 512) := [w2468,w3766,w4057,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3313 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3313 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4057,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4057 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3314 : List (BitVec 512) := [w2468,w3766,w4057,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3314 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3314 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3314 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4057,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4057 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3315 : List (BitVec 512) := [w2468,w3766,w4079,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3315 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3315 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3315 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3316 : List (BitVec 512) := [w2468,w3766,w4079,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3316 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3316 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3317 : List (BitVec 512) := [w2468,w3766,w4146,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3317 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3317 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3318 : List (BitVec 512) := [w2468,w3766,w4146,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3318 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3318 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3318 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3319 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3319 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3319 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3320 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3320 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3320 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3320 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3321 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3321 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3321 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3321 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3322 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3322 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3322 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3322 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3323 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_3323 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3323 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3323 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3324 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_3324 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_3324 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3863 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3863 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3863 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3863 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3864 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3864 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3864 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3864 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3865 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_3865 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3865 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_3865 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3866 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_3866 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3866 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3866 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3867 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3867 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3867 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3867 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3868 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_3868 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3868 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_3868 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_3869 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3869 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3869 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3869 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3870 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_3870 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3870 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3870 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3871 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_3871 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3871 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s3_3871 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3872 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b3_3872 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3872 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3872 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3873 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b3_3873 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3873 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s3_3873 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3874 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_3874 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3874 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3874 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3875 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6720]
theorem b3_3875 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3875 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_3875 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_3876 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6807]
theorem b3_3876 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3876 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s3_3876 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl)))))))))))) (by decide +kernel)
def s3_3877 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6832]
theorem b3_3877 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3877 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_3877 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3878 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_3878 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3878 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s3_3878 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3879 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_3879 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3879 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3879 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3880 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_3880 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3880 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3880 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3881 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_3881 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3881 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3881 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3882 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_3882 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3882 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3882 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3883 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_3883 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3883 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_3883 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3884 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_3884 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3884 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(5,true))] s3_3884 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3885 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_3885 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3885 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3885 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3886 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_3886 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3886 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s3_3886 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_3887 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_3887 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3887 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s3_3887 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl)))))))))))) (by decide +kernel)
def s3_3888 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_3888 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3888 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true))] s3_3888 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3889 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_3889 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3889 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true))] s3_3889 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3890 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3890 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3890 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3890 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3891 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b3_3891 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3891 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_3891 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3892 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b3_3892 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3892 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s3_3892 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3893 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6588]
theorem b3_3893 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3893 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_3893 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3894 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6588]
theorem b3_3894 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3894 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3894 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3895 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b3_3895 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3895 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3895 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3896 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6785]
theorem b3_3896 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3896 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_3896 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_3897 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6852]
theorem b3_3897 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3897 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true))] s3_3897 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl)))))))))))) (by decide +kernel)
def s3_3898 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6873]
theorem b3_3898 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3898 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s3_3898 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3899 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b3_3899 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3899 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_3899 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3900 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_3900 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3900 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(5,true))] s3_3900 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3901 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b3_3901 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3901 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_3901 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3902 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6464,w6588]
theorem b3_3902 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3902 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(6,true),(2,true))] s3_3902 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
