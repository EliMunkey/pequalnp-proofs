import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1338 : List (BitVec 512) := [w967,w3157,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1338 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true))] s5_1338 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3157,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3157 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1339 : List (BitVec 512) := [w967,w3158,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1339 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s5_1339 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3158,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3158 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1340 : List (BitVec 512) := [w967,w3162,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1340 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1340 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s5_1340 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3162,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3162 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1341 : List (BitVec 512) := [w967,w3164,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1341 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1341 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s5_1341 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3164,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3164 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1342 : List (BitVec 512) := [w967,w3166,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1342 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1342 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_1342 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3166,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3166 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1343 : List (BitVec 512) := [w967,w3167,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1343 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1343 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_1343 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3167,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3167 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1344 : List (BitVec 512) := [w967,w3168,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1344 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1344 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(9,true))] s5_1344 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3168,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3168 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1345 : List (BitVec 512) := [w967,w3174,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1345 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1345 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(9,true))] s5_1345 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3174,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3174 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1346 : List (BitVec 512) := [w967,w3175,w3766,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1346 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1346 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_1346 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3175,v3_3766,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3175 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1347 : List (BitVec 512) := [w967,w3176,w3766,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_1347 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1347 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(6,true),(7,true)),(false,(6,true),(7,true))] s5_1347 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3176,v3_3766,v3_4716,v3_5135,v3_5393,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3176 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1348 : List (BitVec 512) := [w967,w3181,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1348 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1348 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,false))] s5_1348 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3181,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3181 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1349 : List (BitVec 512) := [w967,w3182,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1349 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1349 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s5_1349 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3182,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1350 : List (BitVec 512) := [w967,w3182,w3766,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1350 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1350 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(8,true),(7,true))] s5_1350 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3182,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1351 : List (BitVec 512) := [w967,w3182,w3766,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b5_1351 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1351 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(5,true),(6,true)),(false,(8,true),(7,true))] s5_1351 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3182,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1352 : List (BitVec 512) := [w967,w3182,w3935,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_1352 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1352 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(7,true),(6,true)),(false,(1,false),(2,true))] s5_1352 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3182,v3_3935,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3935 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1353 : List (BitVec 512) := [w967,w3185,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1353 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1353 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(5,true)),(false,(1,false),(0,false))] s5_1353 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3185,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3185 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1354 : List (BitVec 512) := [w967,w3187,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1354 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1354 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false))] s5_1354 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3187,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3187 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1355 : List (BitVec 512) := [w967,w3188,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1355 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1355 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false))] s5_1355 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3188,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3188 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1356 : List (BitVec 512) := [w967,w3197,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1356 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1356 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(0,false))] s5_1356 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3197,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3197 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1357 : List (BitVec 512) := [w967,w3199,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1357 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1357 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(0,false))] s5_1357 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3199,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3199 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1358 : List (BitVec 512) := [w967,w3202,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1358 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1358 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(0,false))] s5_1358 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3202,v3_4413,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3202 (PetersenWireProjection.cons pc3_4413 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1359 : List (BitVec 512) := [w967,w3209,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1359 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1359 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(2,true),(0,false))] s5_1359 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3209,v3_4428,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3209 (PetersenWireProjection.cons pc3_4428 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1360 : List (BitVec 512) := [w967,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1360 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1360 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false))] s5_1360 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1361 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b5_1361 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1361 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(5,true))] s5_1361 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1362 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_1362 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1362 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(5,true))] s5_1362 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1363 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1363 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1363 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(2,true),(5,true))] s5_1363 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1364 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_1364 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1364 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(2,true),(5,true))] s5_1364 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1365 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b5_1365 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1365 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(5,true))] s5_1365 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1366 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_1366 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1366 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(5,true))] s5_1366 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1367 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b5_1367 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1367 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(2,true)),(false,(0,false),(6,true))] s5_1367 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1368 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b5_1368 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1368 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(7,true)),(false,(7,true),(6,true))] s5_1368 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1369 : List (BitVec 512) := [w967,w3258,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b5_1369 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1369 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(8,true)),(false,(7,true),(6,true))] s5_1369 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_1370 : List (BitVec 512) := [w967,w3258,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b5_1370 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1370 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(2,true),(7,true)),(false,(3,true),(6,true))] s5_1370 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1371 : List (BitVec 512) := [w967,w3258,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b5_1371 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1371 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(2,true),(8,true)),(false,(3,true),(6,true))] s5_1371 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3258,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_1372 : List (BitVec 512) := [w967,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1372 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1372 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(1,true),(0,true))] s5_1372 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3280,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3280 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1373 : List (BitVec 512) := [w967,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1373 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1373 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_1373 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1374 : List (BitVec 512) := [w967,w3293,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1374 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1374 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_1374 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1375 : List (BitVec 512) := [w967,w3293,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_1375 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1375 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_1375 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1376 : List (BitVec 512) := [w967,w3293,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b5_1376 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1376 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_1376 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1377 : List (BitVec 512) := [w967,w3293,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_1377 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1377 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true))] s5_1377 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1378 : List (BitVec 512) := [w967,w3293,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1378 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1378 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(1,true),(0,true)),(false,(7,true),(3,true))] s5_1378 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3293,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1379 : List (BitVec 512) := [w967,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1379 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(1,true),(0,true))] s5_1379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1380 : List (BitVec 512) := [w967,w3321,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1380 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1380 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_1380 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3321,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1381 : List (BitVec 512) := [w967,w3321,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_1381 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1381 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_1381 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3321,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3321 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1382 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1382 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1382 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1382 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1383 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1383 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_1383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1384 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6812]
theorem b5_1384 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1384 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(7,false),(0,true)),(false,(0,true),(9,true))] s5_1384 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6812] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6812 rfl)))))))))) (by decide +kernel)
def s5_1385 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_1385 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1385 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_1385 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1386 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6690]
theorem b5_1386 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1386 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_1386 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1387 : List (BitVec 512) := [w967,w3766,w4348,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1387 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1387 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s5_1387 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4348,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4348 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1388 : List (BitVec 512) := [w967,w3766,w4351,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1388 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1388 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,false),(9,true))] s5_1388 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4351,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4351 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1389 : List (BitVec 512) := [w967,w3766,w4355,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1389 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1389 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s5_1389 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4355,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4355 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1390 : List (BitVec 512) := [w967,w3766,w4369,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1390 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1390 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s5_1390 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4369,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4369 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1391 : List (BitVec 512) := [w967,w3766,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1391 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1391 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s5_1391 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1392 : List (BitVec 512) := [w967,w3766,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1392 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1392 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s5_1392 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1393 : List (BitVec 512) := [w967,w3766,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1393 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1393 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,true))] s5_1393 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4402,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4402 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1394 : List (BitVec 512) := [w967,w3766,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1394 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1394 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,true))] s5_1394 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4402,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4402 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1395 : List (BitVec 512) := [w967,w3766,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1395 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1395 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s5_1395 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1396 : List (BitVec 512) := [w967,w3766,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1396 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1396 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s5_1396 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1397 : List (BitVec 512) := [w967,w3766,w4404,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1397 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1397 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s5_1397 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4404,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4404 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1398 : List (BitVec 512) := [w967,w3766,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1398 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1398 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true))] s5_1398 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4412,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4412 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1399 : List (BitVec 512) := [w967,w3766,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1399 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1399 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true))] s5_1399 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4412,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4412 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1400 : List (BitVec 512) := [w967,w3766,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1400 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1400 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s5_1400 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4413,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4413 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1401 : List (BitVec 512) := [w967,w3766,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_1401 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1401 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s5_1401 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4413,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4413 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
end NineCert
