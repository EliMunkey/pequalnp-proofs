import NinePin218
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12327 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w4964,w5135,w5585,w5956,w6300,w6588]
theorem b4_12327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12327 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s4_12327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_2468,v218_3766,v218_4344,v218_4716,v218_4926,v218_4964,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_2468 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_4926 (PetersenWireProjection.cons pc218_4964 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl))))))))))) (by decide +kernel)
def s5_1565 : List (BitVec 512) := [w1007,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b5_1565 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1565 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s5_1565 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_1007,v218_3766,v218_4344,v218_4716,v218_4800,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_1007 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_4800 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl)))))))))) (by decide +kernel)
def s5_1914 : List (BitVec 512) := [w1119,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1914 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s5_1914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_1119,v218_2494,v218_3766,v218_4344,v218_4716,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_1119 (PetersenWireProjection.cons pc218_2494 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl)))))))))) (by decide +kernel)
def s5_1982 : List (BitVec 512) := [w1129,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1982 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1982 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s5_1982 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_1129,v218_2468,v218_3766,v218_4344,v218_4716,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_1129 (PetersenWireProjection.cons pc218_2468 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl)))))))))) (by decide +kernel)
def s5_4051 : List (BitVec 512) := [w2468,w3766,w4344,w4381,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4051 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4051 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s5_4051 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_2468,v218_3766,v218_4344,v218_4381,v218_4716,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_2468 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4381 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl)))))))))) (by decide +kernel)
def s5_4073 : List (BitVec 512) := [w2468,w3766,w4344,w4534,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4073 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4073 := by
  intro m le c
  apply rejects_sound r218 i6 5 tgt (small218 adj) hot218 [] s5_4073 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v218_2468,v218_3766,v218_4344,v218_4534,v218_4716,v218_5135,v218_5585,v218_5956,v218_6300,v218_6588] (PetersenWireProjection.cons pc218_2468 (PetersenWireProjection.cons pc218_3766 (PetersenWireProjection.cons pc218_4344 (PetersenWireProjection.cons pc218_4534 (PetersenWireProjection.cons pc218_4716 (PetersenWireProjection.cons pc218_5135 (PetersenWireProjection.cons pc218_5585 (PetersenWireProjection.cons pc218_5956 (PetersenWireProjection.cons pc218_6300 (PetersenWireProjection.cons pc218_6588 rfl)))))))))) (by decide +kernel)
end NineCert
