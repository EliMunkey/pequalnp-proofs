import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4907 : List (BitVec 512) := [w3535,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4907 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4907 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4907 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3535,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3535 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4908 : List (BitVec 512) := [w3536,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4908 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3536,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3536 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4909 : List (BitVec 512) := [w3537,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4909 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4909 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4909 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3537,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3537 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4910 : List (BitVec 512) := [w3540,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4910 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3540,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3540 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4911 : List (BitVec 512) := [w3542,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4911 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3542,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3542 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4912 : List (BitVec 512) := [w3543,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4912 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4912 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4912 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3543,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3543 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4913 : List (BitVec 512) := [w3545,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_4913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(7,true),(6,true)),(false,(3,true),(7,true)),(false,(9,true),(3,true))] s5_4913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3545,v0_3766,v0_4926,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4914 : List (BitVec 512) := [w3546,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4914 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3546,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3546 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4915 : List (BitVec 512) := [w3550,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4915 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4915 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4915 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3550,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3550 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4916 : List (BitVec 512) := [w3550,w4344,w4716,w4932,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4916 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(3,true)),(false,(1,true),(0,false))] s5_4916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3550,v0_4344,v0_4716,v0_4932,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3550 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4932 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4917 : List (BitVec 512) := [w3550,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4917 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3550,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3550 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4918 : List (BitVec 512) := [w3551,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4918 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4918 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4918 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3551,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3551 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4919 : List (BitVec 512) := [w3551,w4344,w4716,w4934,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4919 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4919 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(2,true)),(false,(1,true),(0,false))] s5_4919 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3551,v0_4344,v0_4716,v0_4934,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3551 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4934 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4920 : List (BitVec 512) := [w3551,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4920 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4920 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4920 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3551,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3551 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4921 : List (BitVec 512) := [w3552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4921 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4922 : List (BitVec 512) := [w3553,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4922 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4922 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4922 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3553,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3553 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4923 : List (BitVec 512) := [w3556,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4923 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4923 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4923 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3556,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3556 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4924 : List (BitVec 512) := [w3556,w4344,w4716,w4941,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4924 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(2,true),(3,true)),(false,(1,true),(0,false))] s5_4924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3556,v0_4344,v0_4716,v0_4941,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3556 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4941 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4925 : List (BitVec 512) := [w3556,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4925 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4925 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4925 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3556,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3556 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4926 : List (BitVec 512) := [w3557,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4926 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3557,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3557 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4927 : List (BitVec 512) := [w3557,w4344,w4716,w4944,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4927 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4927 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(3,true),(2,true)),(false,(1,true),(0,false))] s5_4927 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3557,v0_4344,v0_4716,v0_4944,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3557 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4944 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4928 : List (BitVec 512) := [w3557,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4928 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4928 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4928 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3557,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3557 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4929 : List (BitVec 512) := [w3558,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4929 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4929 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4929 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3558,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3558 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4930 : List (BitVec 512) := [w3560,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3560,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3560 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4931 : List (BitVec 512) := [w3561,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4931 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4931 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4931 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3561,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3561 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4932 : List (BitVec 512) := [w3562,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4932 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4932 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4932 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3562,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3562 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4933 : List (BitVec 512) := [w3563,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4933 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4933 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4933 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3563,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3563 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4934 : List (BitVec 512) := [w3564,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4934 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4934 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4934 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3564,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3564 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4935 : List (BitVec 512) := [w3565,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4935 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4935 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4935 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3565,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3565 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4936 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_4936 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4936 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_4936 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4937 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_4937 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_4937 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4938 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_4938 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4938 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_4938 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4939 : List (BitVec 512) := [w3567,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_4939 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4939 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(2,true)),(false,(6,true),(3,true)),(false,(3,true),(10,true))] s5_4939 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_4940 : List (BitVec 512) := [w3582,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_4940 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4940 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(7,true),(6,true)),(false,(3,true),(10,true))] s5_4940 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_4941 : List (BitVec 512) := [w3582,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_4941 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4941 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true)),(false,(3,true),(9,true))] s5_4941 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4942 : List (BitVec 512) := [w3582,w4344,w4716,w4753,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4942 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4942 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s5_4942 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_4753,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4753 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4943 : List (BitVec 512) := [w3582,w4344,w4716,w4771,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4943 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4943 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s5_4943 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_4771,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4771 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4944 : List (BitVec 512) := [w3582,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4944 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4944 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s5_4944 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_4785,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4785 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4945 : List (BitVec 512) := [w3582,w4344,w4716,w4796,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_4945 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4945 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(2,true),(6,true)),(false,(1,true),(4,true))] s5_4945 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_4796,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4796 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4946 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b5_4946 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4946 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s5_4946 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4947 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b5_4947 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4947 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false))] s5_4947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl)))))))))) (by decide +kernel)
def s5_4948 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b5_4948 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s5_4948 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4949 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b5_4949 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4949 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s5_4949 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4950 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b5_4950 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4950 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true))] s5_4950 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4951 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5621,w5698,w5956,w6300,w6588]
theorem b5_4951 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4951 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(6,true),(2,true)),(false,(1,true),(7,true))] s5_4951 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5621,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5621 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4952 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5665,w5698,w5956,w6300,w6588]
theorem b5_4952 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4952 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true)),(false,(1,false),(0,true)),(false,(0,true),(7,true))] s5_4952 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5665,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5665 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4953 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5666,w5698,w5956,w6300,w6588]
theorem b5_4953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4953 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(5,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(7,true))] s5_4953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5666,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5666 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4954 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5667,w5698,w5956,w6300,w6588]
theorem b5_4954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(7,true))] s5_4954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5667,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5667 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4955 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5672,w5698,w5956,w6300,w6588]
theorem b5_4955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4955 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(7,true))] s5_4955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5672,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5672 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4956 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w5767,w5956,w6300,w6588]
theorem b5_4956 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4956 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,true)),(false,(7,true),(3,true))] s5_4956 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5767,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5767 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4957 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b5_4957 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4957 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true)),(false,(0,false),(6,true))] s5_4957 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4958 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b5_4958 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4958 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true)),(false,(7,true),(6,true))] s5_4958 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4959 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b5_4959 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4959 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(8,true)),(false,(7,true),(6,true))] s5_4959 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_4960 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6908]
theorem b5_4960 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4960 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(1,false),(8,true)),(false,(7,true),(8,true))] s5_4960 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl)))))))))) (by decide +kernel)
def s5_4961 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w6179,w6522,w6588,w6873]
theorem b5_4961 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4961 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(8,true),(7,true)),(false,(8,true),(7,true))] s5_4961 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4962 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5698,w6225,w6300,w6522,w6588]
theorem b5_4962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4962 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(6,true),(2,true)),(false,(8,true),(1,false))] s5_4962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6225,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4963 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5471,w5698,w5769,w5956,w6300,w6588]
theorem b5_4963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4963 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(6,true),(2,true)),(false,(1,true),(6,true))] s5_4963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5471,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4964 : List (BitVec 512) := [w3582,w4716,w4793,w5135,w5393,w5698,w5956,w6300,w6588,w6690]
theorem b5_4964 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4964 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(2,true),(6,true)),(false,(1,true),(4,true))] s5_4964 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_4793,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4793 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_4965 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b5_4965 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(5,true)),(false,(8,true),(2,true))] s5_4965 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4966 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6690]
theorem b5_4966 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4966 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(1,true)),(false,(3,true),(6,true))] s5_4966 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_4967 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6890]
theorem b5_4967 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4967 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true)),(false,(1,false),(9,true)),(false,(3,true),(7,true))] s5_4967 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_4968 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6832]
theorem b5_4968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4968 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(6,true),(2,true)),(false,(10,true),(3,true))] s5_4968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_4969 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6389,w6522,w6588]
theorem b5_4969 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4969 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(6,true),(2,true)),(false,(3,true),(9,true))] s5_4969 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4970 : List (BitVec 512) := [w3582,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_4970 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4970 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(7,true),(6,true)),(false,(3,true),(10,true))] s5_4970 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))) (by decide +kernel)
end NineCert
