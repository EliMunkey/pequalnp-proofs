import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3033 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6241,w6300,w6832]
theorem b5_3033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3033 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s5_3033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_3037 : List (BitVec 512) := [w1388,w3766,w4344,w5098,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_3037 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3037 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3037 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3038 : List (BitVec 512) := [w1388,w3766,w4344,w5098,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_3038 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3038 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3038 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3043 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w5873,w5956,w6300,w6720]
theorem b5_3043 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3043 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3047 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w5956,w6243,w6300,w6720]
theorem b5_3047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3047 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3049 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w6101,w6147,w6300,w6720]
theorem b5_3049 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3049 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3049 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3056 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_3056 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3056 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(1,false),(0,false)),(false,(0,true),(6,true))] s5_3056 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1390,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1390 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_3068 : List (BitVec 512) := [w1403,w1664,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6873]
theorem b5_3068 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3068 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(0,true)),(false,(10,true),(1,true))] s5_3068 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_1664,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3069 : List (BitVec 512) := [w1403,w1664,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6890]
theorem b5_3069 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3069 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true)),(false,(10,true),(2,true))] s5_3069 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_1664,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6890 rfl)))))))))) (by decide +kernel)
def s5_3096 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5059,w5585,w5956,w6522,w6588]
theorem b5_3096 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true)),(false,(7,true),(0,true))] s5_3096 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2468,v1_3766,v1_4344,v1_4716,v1_5059,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3106 : List (BitVec 512) := [w1403,w2488,w3766,w4344,w4716,w5059,w5585,w5956,w6300,w6588]
theorem b5_3106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3106 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(1,false)),(false,(7,true),(0,true))] s5_3106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2488,v1_3766,v1_4344,v1_4716,v1_5059,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3119 : List (BitVec 512) := [w1403,w2615,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3119 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(7,true),(3,true)),(false,(6,true),(1,true))] s5_3119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2615,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_3120 : List (BitVec 512) := [w1403,w2641,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3120 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,false),(8,true)),(false,(3,true),(8,true)),(false,(6,true),(1,true))] s5_3120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2641,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2641 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_3140 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6464,w6873]
theorem b5_3140 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3140 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(7,true)),(false,(6,true),(1,true))] s5_3140 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6464,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3141 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6522,w6588]
theorem b5_3141 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3141 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s5_3141 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3142 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6522,w6873]
theorem b5_3142 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3142 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(8,true),(9,true)),(false,(6,true),(1,true))] s5_3142 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6522,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3143 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6522,w6890]
theorem b5_3143 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3143 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true)),(false,(10,true),(9,true))] s5_3143 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6522,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6890 rfl)))))))))) (by decide +kernel)
def s5_3144 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w6101,w6522,w6588]
theorem b5_3144 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3144 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true)),(false,(10,true),(9,true))] s5_3144 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_6101,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3145 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w6179,w6522,w6588]
theorem b5_3145 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3145 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(7,true)),(false,(10,true),(9,true))] s5_3145 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_6179,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3146 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5193,w5393,w5585,w5956,w6873]
theorem b5_3146 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3146 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true)),(false,(6,true),(1,true))] s5_3146 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5193,v1_5393,v1_5585,v1_5956,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5193 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3164 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6501,w6873]
theorem b5_3164 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3164 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(7,true)),(false,(6,true),(1,true))] s5_3164 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6501,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3171 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6555,w6873]
theorem b5_3171 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3171 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(8,true),(9,true)),(false,(6,true),(1,true))] s5_3171 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6555,v1_6873] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3206 : List (BitVec 512) := [w1403,w3766,w4716,w5059,w5393,w5585,w5698,w5956,w6522,w6588]
theorem b5_3206 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3206 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_3206 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4716,v1_5059,v1_5393,v1_5585,v1_5698,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3249 : List (BitVec 512) := [w1415,w2615,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3249 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3249 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_3249 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2615,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_3250 : List (BitVec 512) := [w1415,w2654,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6873]
theorem b5_3250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3250 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true)),(false,(10,true),(6,true))] s5_3250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_2654,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6873] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_2654 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3289 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6501,w6873]
theorem b5_3289 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3289 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true)),(false,(10,true),(6,true))] s5_3289 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6501,v1_6873] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_3303 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6690]
theorem b5_3303 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3303 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_3303 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1415,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_3322 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_3322 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3322 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_3322 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1423,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1423 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_3344 : List (BitVec 512) := [w1723,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b5_3344 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3344 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,false),(0,false))] s5_3344 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1723,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300,v1_6572,v1_6588] (PetersenWireProjection.cons pc1_1723 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6572 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3345 : List (BitVec 512) := [w1723,w3766,w4344,w4716,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b5_3345 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3345 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s5_3345 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1723,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_6179,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1723 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3353 : List (BitVec 512) := [w2180,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3353 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3353 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_3353 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2180,v1_2468,v1_3258,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2180 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3354 : List (BitVec 512) := [w2180,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6736]
theorem b5_3354 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3354 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,false),(6,true))] s5_3354 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2180,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6736] (PetersenWireProjection.cons pc1_2180 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6736 rfl)))))))))) (by decide +kernel)
def s5_3648 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w4993,w5135,w5585,w5956,w6300,w6588]
theorem b5_3648 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3648 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3648 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2381,v1_3766,v1_4344,v1_4716,v1_4993,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2381 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4993 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3649 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5017,w5135,w5585,w5956,w6300,w6588]
theorem b5_3649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3649 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2381,v1_3766,v1_4344,v1_4716,v1_5017,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2381 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5017 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3650 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5194,w5585,w5956,w6300,w6588]
theorem b5_3650 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3650 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3650 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2381,v1_3766,v1_4344,v1_4716,v1_5135,v1_5194,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2381 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5194 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3662 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6150,w6300,w6588]
theorem b5_3662 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3662 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3662 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2381,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6150,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2381 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6150 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3677 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5018,w5135,w5585,w5956,w6300,w6588]
theorem b5_3677 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3677 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3677 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2382,v1_3766,v1_4344,v1_4716,v1_5018,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2382 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5018 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3685 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6151,w6300,w6588]
theorem b5_3685 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3685 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3685 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2382,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6151,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2382 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6151 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3705 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w4988,w5135,w5585,w5956,w6300,w6588]
theorem b5_3705 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3705 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3705 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2387,v1_3766,v1_4344,v1_4716,v1_4988,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2387 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4988 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3706 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5019,w5135,w5585,w5956,w6300,w6588]
theorem b5_3706 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3706 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3706 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2387,v1_3766,v1_4344,v1_4716,v1_5019,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2387 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5019 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3707 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5196,w5585,w5956,w6300,w6588]
theorem b5_3707 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3707 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3707 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2387,v1_3766,v1_4344,v1_4716,v1_5135,v1_5196,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2387 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5196 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3719 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6152,w6300,w6588]
theorem b5_3719 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3719 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(0,true))] s5_3719 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2387,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6152,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2387 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6152 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3848 : List (BitVec 512) := [w2468,w2664,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3848 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3848 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true)),(false,(0,false),(2,false))] s5_3848 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3862 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4635,w4716,w5585,w5956,w6300,w6588]
theorem b5_3862 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3862 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3862 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2681,v1_3766,v1_4344,v1_4635,v1_4716,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3870 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w4802,w5585,w5956,w6300,w6588]
theorem b5_3870 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3870 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3870 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2681,v1_3766,v1_4344,v1_4716,v1_4802,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4802 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3874 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6588]
theorem b5_3874 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3874 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3874 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2681,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3889 : List (BitVec 512) := [w2468,w2682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3889 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3889 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,false),(6,true))] s5_3889 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2682,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2682 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3894 : List (BitVec 512) := [w2468,w2683,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3894 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3894 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true)),(false,(0,false),(6,true))] s5_3894 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2683,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2683 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_3902 : List (BitVec 512) := [w2468,w2701,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3902 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3902 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(5,true)),(false,(0,false),(2,false))] s5_3902 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_2701,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_2701 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4148 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5870,w5956,w6300,w6588]
theorem b5_4148 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4148 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true)),(false,(0,false),(8,true))] s5_4148 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5870,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5870 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4149 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5883,w5956,w6300,w6588]
theorem b5_4149 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4149 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(4,true)),(false,(0,false),(8,true))] s5_4149 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5883,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5883 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4198 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6581,w6588]
theorem b5_4198 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4198 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true)),(false,(0,false),(2,false))] s5_4198 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4207 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720,w6762]
theorem b5_4207 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4207 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(4,true))] s5_4207 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 rfl)))))))))) (by decide +kernel)
def s5_4236 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6555,w6720,w6873]
theorem b5_4236 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4236 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(10,true))] s5_4236 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6555,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_4237 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6555,w6785,w6873]
theorem b5_4237 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4237 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(7,true)),(false,(6,true),(10,true))] s5_4237 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6555,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_4247 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6555,w6588,w6873]
theorem b5_4247 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4247 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true)),(false,(6,true),(10,true))] s5_4247 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_6101,v1_6555,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_4250 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5861,w5956,w6522,w6785,w6873]
theorem b5_4250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4250 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(7,true)),(false,(6,true),(10,true))] s5_4250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5861,v1_5956,v1_6522,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_4255 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5239,w5585,w5956,w6300,w6690,w6720]
theorem b5_4255 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4255 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(4,true))] s5_4255 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_5135,v1_5239,v1_5585,v1_5956,v1_6300,v1_6690,v1_6720] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_4256 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5239,w5585,w5956,w6522,w6720,w6873]
theorem b5_4256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4256 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(10,true))] s5_4256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_5135,v1_5239,v1_5585,v1_5956,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_4278 : List (BitVec 512) := [w2488,w2664,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4278 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4278 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(8,true),(1,false))] s5_4278 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_2664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_2664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4341 : List (BitVec 512) := [w2488,w3766,w4344,w4638,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4341 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4341 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4341 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4638,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4638 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4342 : List (BitVec 512) := [w2488,w3766,w4344,w4639,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4342 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4342 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4342 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4639,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4639 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4379 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4992,w5135,w5585,w5956,w6300,w6588]
theorem b5_4379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4379 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_4992,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4992 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_4380 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4993,w5135,w5585,w5956,w6300,w6588]
theorem b5_4380 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4380 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4380 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_4993,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4993 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
end NineCert
