import NinePin136
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4912 : List (BitVec 512) := [w1007,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_4912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4912 := by
  intro m le c
  apply rejects_sound r136 i7 6 tgt (small136 adj) hot136 [] s4_4912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v136_1007,v136_2468,v136_3766,v136_4344,v136_4583,v136_4716,v136_5135,v136_5585,v136_5956,v136_6300,v136_6588] (PetersenWireProjection.cons pc136_1007 (PetersenWireProjection.cons pc136_2468 (PetersenWireProjection.cons pc136_3766 (PetersenWireProjection.cons pc136_4344 (PetersenWireProjection.cons pc136_4583 (PetersenWireProjection.cons pc136_4716 (PetersenWireProjection.cons pc136_5135 (PetersenWireProjection.cons pc136_5585 (PetersenWireProjection.cons pc136_5956 (PetersenWireProjection.cons pc136_6300 (PetersenWireProjection.cons pc136_6588 rfl))))))))))) (by decide +kernel)
def s5_899 : List (BitVec 512) := [w604,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_899 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_899 := by
  intro m le c
  apply rejects_sound r136 i7 6 tgt (small136 adj) hot136 [] s5_899 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v136_604,v136_2468,v136_3766,v136_4344,v136_4716,v136_5135,v136_5585,v136_5956,v136_6300,v136_6588] (PetersenWireProjection.cons pc136_604 (PetersenWireProjection.cons pc136_2468 (PetersenWireProjection.cons pc136_3766 (PetersenWireProjection.cons pc136_4344 (PetersenWireProjection.cons pc136_4716 (PetersenWireProjection.cons pc136_5135 (PetersenWireProjection.cons pc136_5585 (PetersenWireProjection.cons pc136_5956 (PetersenWireProjection.cons pc136_6300 (PetersenWireProjection.cons pc136_6588 rfl)))))))))) (by decide +kernel)
def s5_1562 : List (BitVec 512) := [w1007,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6708]
theorem b5_1562 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1562 := by
  intro m le c
  apply rejects_sound r136 i7 6 tgt (small136 adj) hot136 [] s5_1562 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v136_1007,v136_2468,v136_3766,v136_4344,v136_4716,v136_5135,v136_5585,v136_5956,v136_6300,v136_6708] (PetersenWireProjection.cons pc136_1007 (PetersenWireProjection.cons pc136_2468 (PetersenWireProjection.cons pc136_3766 (PetersenWireProjection.cons pc136_4344 (PetersenWireProjection.cons pc136_4716 (PetersenWireProjection.cons pc136_5135 (PetersenWireProjection.cons pc136_5585 (PetersenWireProjection.cons pc136_5956 (PetersenWireProjection.cons pc136_6300 (PetersenWireProjection.cons pc136_6708 rfl)))))))))) (by decide +kernel)
end NineCert
