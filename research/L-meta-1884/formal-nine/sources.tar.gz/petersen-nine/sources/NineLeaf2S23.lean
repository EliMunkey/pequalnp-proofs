import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10588 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5884,w5956,w6300,w6464,w6588]
theorem b4_10588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10588 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10591 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6389,w6588]
theorem b4_10591 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10591 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_10591 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10827 : List (BitVec 512) := [w2209,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_10827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10827 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2209,v2_3901,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2209 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10828 : List (BitVec 512) := [w2209,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10828 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2209,v2_3901,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2209 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10867 : List (BitVec 512) := [w2223,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_10867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10867 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10868 : List (BitVec 512) := [w2223,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_10868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10868 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_10868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10869 : List (BitVec 512) := [w2223,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10869 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10870 : List (BitVec 512) := [w2223,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10870 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10871 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b4_10871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10871 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10872 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_10872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10872 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10873 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b4_10873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_10873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10874 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_10874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_10874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10875 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10875 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_10875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10876 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10876 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_10876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4584,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4584 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10877 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b4_10877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_10877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5654,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5654 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10878 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10878 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s4_10878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10879 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6031,w6300,w6588]
theorem b4_10879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10879 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s4_10879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6031,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6031 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10880 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10880 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_10880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10881 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_10881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10881 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(7,true))] s4_10881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10882 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6361,w6588]
theorem b4_10882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10882 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))] s4_10882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6361,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6361 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10883 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10883 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(3,true))] s4_10883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10884 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_10884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10884 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(7,true))] s4_10884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10885 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_10885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10885 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(5,true))] s4_10885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10886 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_10886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10886 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(1,false))] s4_10886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_10887 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_10887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10887 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false))] s4_10887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_10888 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_10888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10888 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(1,false))] s4_10888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_10889 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_10889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10889 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(1,false))] s4_10889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_10890 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_10890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10890 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(9,true))] s4_10890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10891 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_10891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10891 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(9,true))] s4_10891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_10892 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_10892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10892 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(8,true))] s4_10892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10893 : List (BitVec 512) := [w2223,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6588,w6720]
theorem b4_10893 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10893 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true))] s4_10893 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10894 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10894 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_10894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10895 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588,w6720]
theorem b4_10895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10895 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_10895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10896 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10896 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10896 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(3,true))] s4_10896 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10897 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588,w6720]
theorem b4_10897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10897 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(3,true))] s4_10897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10898 : List (BitVec 512) := [w2223,w2683,w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6300,w6588]
theorem b4_10898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10898 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2683,v2_3766,v2_4344,v2_4716,v2_4926,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10899 : List (BitVec 512) := [w2223,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10899 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10900 : List (BitVec 512) := [w2223,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_10900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10900 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_10900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_10901 : List (BitVec 512) := [w2223,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_10901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10901 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_10902 : List (BitVec 512) := [w2223,w2686,w3766,w4344,w4716,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_10902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10902 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_10902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10903 : List (BitVec 512) := [w2223,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10903 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10904 : List (BitVec 512) := [w2223,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_10904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10904 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_10905 : List (BitVec 512) := [w2223,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_10905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10905 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_10906 : List (BitVec 512) := [w2223,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_10906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10906 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_10906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10907 : List (BitVec 512) := [w2223,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10907 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10908 : List (BitVec 512) := [w2223,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_10908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10908 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_10909 : List (BitVec 512) := [w2223,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_10909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10909 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_10909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_10910 : List (BitVec 512) := [w2223,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_10910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10910 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10911 : List (BitVec 512) := [w2223,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10911 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10912 : List (BitVec 512) := [w2223,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_10912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10912 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_10912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_10913 : List (BitVec 512) := [w2223,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_10913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10913 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_10913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_10914 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w4813,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10914 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(8,true))] s4_10914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_4813,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4813 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10915 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_10915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10915 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(1,false))] s4_10915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10916 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6047,w6300,w6588]
theorem b4_10916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10916 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s4_10916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6047,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6047 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10917 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_10917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10917 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true))] s4_10917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10918 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_10918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10918 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(1,false))] s4_10918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10919 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6376,w6588]
theorem b4_10919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10919 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(5,true))] s4_10919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6376,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6376 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10920 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_10920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10920 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(8,true))] s4_10920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10921 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10921 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(1,false))] s4_10921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10922 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_10922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10922 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true))] s4_10922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10923 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6663]
theorem b4_10923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10923 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(9,true))] s4_10923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6663] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6663 rfl))))))))))) (by decide +kernel)
def s4_10924 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_10924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10924 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(9,true))] s4_10924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_10925 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_10925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10925 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(9,true),(1,false))] s4_10925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6807] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6807 rfl))))))))))) (by decide +kernel)
def s4_10926 : List (BitVec 512) := [w2223,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_10926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10926 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(9,true))] s4_10926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
end NineCert
