import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1210 : List (BitVec 512) := [w967,w1803,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1210 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,false),(7,true))] s5_1210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1803,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1803 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1211 : List (BitVec 512) := [w967,w1866,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1211 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(5,true)),(false,(0,true),(7,true))] s5_1211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1866,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1866 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1212 : List (BitVec 512) := [w967,w1867,w2681,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1212 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1212 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,false)),(false,(8,true),(2,true)),(false,(4,true),(0,true))] s5_1212 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1867,v3_2681,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1867 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1213 : List (BitVec 512) := [w967,w1875,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1213 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1213 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(2,true),(6,false))] s5_1213 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1214 : List (BitVec 512) := [w967,w1875,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1214 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1214 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s5_1214 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1215 : List (BitVec 512) := [w967,w1875,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1215 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1215 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s5_1215 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1216 : List (BitVec 512) := [w967,w1875,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_1216 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1216 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(2,true)),(false,(7,true),(0,true))] s5_1216 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1217 : List (BitVec 512) := [w967,w1875,w3766,w4716,w5135,w5393,w5698,w6225,w6300,w6588]
theorem b5_1217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1217 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(1,false),(7,true))] s5_1217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1218 : List (BitVec 512) := [w967,w1875,w3766,w4716,w5135,w5471,w5698,w5956,w6300,w6588]
theorem b5_1218 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_1218 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_4716,v3_5135,v3_5471,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1219 : List (BitVec 512) := [w967,w1875,w3766,w5135,w5393,w5698,w5956,w6300,w6588,w6720]
theorem b5_1219 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(3,true),(9,true))] s5_1219 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1875,v3_3766,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1875 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_1220 : List (BitVec 512) := [w967,w1883,w3766,w4716,w5135,w5393,w5585,w6201,w6300,w6588]
theorem b5_1220 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1220 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1883,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1883 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1221 : List (BitVec 512) := [w967,w1883,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_1221 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1221 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1221 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1883,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1883 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1222 : List (BitVec 512) := [w967,w1891,w2488,w3766,w4716,w5135,w5585,w6061,w6300,w6588]
theorem b5_1222 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1222 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(0,true)),(false,(5,true),(1,true))] s5_1222 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1891,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1891 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1223 : List (BitVec 512) := [w967,w1891,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b5_1223 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1223 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(0,true))] s5_1223 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1891,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1891 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1224 : List (BitVec 512) := [w967,w1891,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_1224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(0,true))] s5_1224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1891,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1891 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1225 : List (BitVec 512) := [w967,w1895,w3766,w4716,w5135,w5393,w5585,w6201,w6300,w6588]
theorem b5_1225 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1225 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1225 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1895,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1895 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1226 : List (BitVec 512) := [w967,w1895,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_1226 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1226 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1226 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1895,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1895 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1227 : List (BitVec 512) := [w967,w1910,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b5_1227 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1227 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s5_1227 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1910,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1910 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1228 : List (BitVec 512) := [w967,w1910,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_1228 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1228 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true))] s5_1228 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1910,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1910 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1229 : List (BitVec 512) := [w967,w1912,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b5_1229 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1229 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s5_1229 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1912,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1912 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1230 : List (BitVec 512) := [w967,w1912,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_1230 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(6,true))] s5_1230 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1912,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1912 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1231 : List (BitVec 512) := [w967,w1912,w3766,w4716,w5135,w5393,w5585,w6201,w6300,w6588]
theorem b5_1231 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1231 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1231 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1912,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1912 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1232 : List (BitVec 512) := [w967,w1912,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_1232 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1232 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(6,true),(7,true))] s5_1232 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1912,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1912 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1233 : List (BitVec 512) := [w967,w1916,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b5_1233 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1233 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(6,true))] s5_1233 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1916,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1916 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1234 : List (BitVec 512) := [w967,w1916,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_1234 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1234 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(6,true))] s5_1234 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_1916,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_1916 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1235 : List (BitVec 512) := [w967,w2072,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1235 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1235 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,false),(6,true))] s5_1235 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2072,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2072 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1236 : List (BitVec 512) := [w967,w2122,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1236 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1236 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(6,true)),(false,(0,true),(6,true))] s5_1236 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2122,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2122 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1237 : List (BitVec 512) := [w967,w2123,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1237 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1237 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(6,true)),(false,(0,true),(6,true))] s5_1237 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2123,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2123 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1238 : List (BitVec 512) := [w967,w2124,w2681,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1238 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1238 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(4,true)),(false,(8,true),(2,true)),(false,(4,true),(0,true))] s5_1238 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2124,v3_2681,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2124 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1239 : List (BitVec 512) := [w967,w2140,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1239 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1239 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(5,true),(0,true))] s5_1239 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2140,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2140 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1240 : List (BitVec 512) := [w967,w2140,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1240 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1240 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(5,true),(0,true))] s5_1240 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2140,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2140 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1241 : List (BitVec 512) := [w967,w2144,w3766,w4716,w5135,w5393,w5956,w6201,w6300,w6588]
theorem b5_1241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1241 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(5,true)),(false,(7,true),(6,true))] s5_1241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2144,v3_3766,v3_4716,v3_5135,v3_5393,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2144 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1242 : List (BitVec 512) := [w967,w2164,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1242 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1242 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(1,true),(5,false))] s5_1242 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1243 : List (BitVec 512) := [w967,w2164,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1243 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1243 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(1,true),(5,false))] s5_1243 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2164,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2164 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1244 : List (BitVec 512) := [w967,w2166,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1244 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(5,true))] s5_1244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2166,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2166 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1245 : List (BitVec 512) := [w967,w2166,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1245 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(5,true))] s5_1245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2166,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2166 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1246 : List (BitVec 512) := [w967,w2171,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1246 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1246 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(2,true),(6,false))] s5_1246 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2171,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2171 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1247 : List (BitVec 512) := [w967,w2172,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1247 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1247 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_1247 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2172,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2172 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1248 : List (BitVec 512) := [w967,w2172,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1248 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_1248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2172,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2172 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1249 : List (BitVec 512) := [w967,w2173,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1249 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1249 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(6,true))] s5_1249 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2173,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2173 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1250 : List (BitVec 512) := [w967,w2175,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1250 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_1250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2175,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2175 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1251 : List (BitVec 512) := [w967,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_1251 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_1251 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_2681,v3_3766,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1252 : List (BitVec 512) := [w967,w2468,w3169,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1252 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1252 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s5_1252 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3169,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3169 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1253 : List (BitVec 512) := [w967,w2468,w3175,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1253 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3175,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3175 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1254 : List (BitVec 512) := [w967,w2468,w3176,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1254 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1254 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1254 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3176,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3176 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1255 : List (BitVec 512) := [w967,w2468,w3182,w3766,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_1255 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1255 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_1255 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3182,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1256 : List (BitVec 512) := [w967,w2468,w3186,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1256 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,false)),(false,(5,true),(1,true))] s5_1256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3186,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3186 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1257 : List (BitVec 512) := [w967,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1257 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1257 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1257 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3258,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1258 : List (BitVec 512) := [w967,w2468,w3258,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_1258 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1258 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3258,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1259 : List (BitVec 512) := [w967,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1259 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1259 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1259 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1260 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_1260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1260 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1261 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6690]
theorem b5_1261 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1261 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1261 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1262 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_1262 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1262 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s5_1262 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1263 : List (BitVec 512) := [w967,w2468,w3766,w4716,w5135,w5698,w6179,w6300,w6522,w6588]
theorem b5_1263 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1263 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s5_1263 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2468,v3_3766,v3_4716,v3_5135,v3_5698,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1264 : List (BitVec 512) := [w967,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1264 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1264 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1264 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1265 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b5_1265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1266 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6690]
theorem b5_1266 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1266 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1266 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1267 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_1267 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1267 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s5_1267 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1268 : List (BitVec 512) := [w967,w2488,w3766,w4716,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_1268 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1268 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_1268 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2488,v3_3766,v3_4716,v3_5135,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1269 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1269 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1269 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1269 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1270 : List (BitVec 512) := [w967,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_1270 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1270 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1270 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1271 : List (BitVec 512) := [w967,w2491,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_1271 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1271 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1271 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1272 : List (BitVec 512) := [w967,w2491,w3766,w4716,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_1272 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1272 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1272 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2491,v3_3766,v3_4716,v3_5135,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1273 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1273 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1273 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1273 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
