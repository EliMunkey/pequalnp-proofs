import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1688 : List (BitVec 512) := [w1076,w1910,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_1688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1688 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true))] s5_1688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1910,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1910 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1689 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1689 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1689 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s5_1689 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1690 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_1690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1690 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s5_1690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1691 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b5_1691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1691 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s5_1691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1692 : List (BitVec 512) := [w1076,w1917,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1692 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1692 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true))] s5_1692 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1917,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1917 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1693 : List (BitVec 512) := [w1076,w1917,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_1693 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1693 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true))] s5_1693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1917,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1917 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1694 : List (BitVec 512) := [w1076,w2391,w2852,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1694 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1694 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1694 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2391,v4_2852,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2391 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1695 : List (BitVec 512) := [w1076,w2391,w3766,w4344,w5135,w5585,w5956,w6033,w6300,w6588]
theorem b5_1695 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1695 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1695 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2391,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6033,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2391 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6033 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1696 : List (BitVec 512) := [w1076,w2392,w2885,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1696 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1696 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1696 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2392,v4_2885,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2392 (PetersenWireProjection.cons pc4_2885 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1697 : List (BitVec 512) := [w1076,w2392,w3766,w4344,w5135,w5585,w5956,w6037,w6300,w6588]
theorem b5_1697 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1697 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1697 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2392,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6037,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2392 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6037 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1698 : List (BitVec 512) := [w1076,w2442,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1698 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1698 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(4,true)),(false,(7,true),(0,true))] s5_1698 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2442,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2442 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1699 : List (BitVec 512) := [w1076,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_1699 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1699 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_1699 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1700 : List (BitVec 512) := [w1076,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6720]
theorem b5_1700 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1700 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(4,true)),(false,(7,true),(0,true))] s5_1700 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2681,v4_3766,v4_4344,v4_4716,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1701 : List (BitVec 512) := [w1076,w2468,w2795,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1701 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1701 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s5_1701 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2795,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2795 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1702 : List (BitVec 512) := [w1076,w2468,w2861,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1702 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1702 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(0,false)),(false,(7,true),(1,true))] s5_1702 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2861,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2861 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1703 : List (BitVec 512) := [w1076,w2468,w2876,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1703 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1703 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s5_1703 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2876,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2876 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1704 : List (BitVec 512) := [w1076,w2468,w2878,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1704 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1704 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_1704 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2878,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2878 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1705 : List (BitVec 512) := [w1076,w2468,w2879,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1705 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1705 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(4,true),(8,true)),(false,(7,true),(0,true))] s5_1705 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2879,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2879 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1706 : List (BitVec 512) := [w1076,w2468,w2889,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1706 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1706 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(0,false)),(false,(7,true),(1,true))] s5_1706 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_2889,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1707 : List (BitVec 512) := [w1076,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1707 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1707 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(8,true)),(false,(4,true),(0,true))] s5_1707 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3258,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1708 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1708 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1708 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1708 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1709 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_1709 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1709 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1709 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1710 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6720]
theorem b5_1710 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1710 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1710 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1711 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b5_1711 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1711 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1711 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1712 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6522,w6720]
theorem b5_1712 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1712 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1712 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1713 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_1713 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1713 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(1,false))] s5_1713 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1714 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6389,w6522,w6588]
theorem b5_1714 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1714 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s5_1714 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1715 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6101,w6522,w6588,w6873]
theorem b5_1715 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1715 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s5_1715 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_1716 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5585,w6225,w6300,w6522,w6588]
theorem b5_1716 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1716 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(9,true))] s5_1716 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1717 : List (BitVec 512) := [w1076,w2468,w3766,w4344,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_1717 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1717 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(4,true))] s5_1717 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2468,v4_3766,v4_4344,v4_5135,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1718 : List (BitVec 512) := [w1076,w2488,w2852,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1718 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1718 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_1718 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_2852,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1719 : List (BitVec 512) := [w1076,w2488,w2861,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1719 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1719 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1719 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_2861,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_2861 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1720 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1720 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1720 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1720 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1721 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_1721 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1721 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1721 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1722 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_1722 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1722 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1722 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1723 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_1723 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1723 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1723 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_5135,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1724 : List (BitVec 512) := [w1076,w2488,w3766,w4344,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_1724 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1724 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1724 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2488,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1725 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1725 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1725 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1725 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1726 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b5_1726 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1726 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1726 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1727 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w5956,w6101,w6300,w6720]
theorem b5_1727 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1727 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s5_1727 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1728 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w5956,w6225,w6300,w6588]
theorem b5_1728 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1728 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(9,true),(8,true))] s5_1728 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1729 : List (BitVec 512) := [w1076,w2491,w3766,w4344,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_1729 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1729 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(9,true))] s5_1729 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2491,v4_3766,v4_4344,v4_5135,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2491 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1730 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1730 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1730 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1730 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1731 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_1731 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1731 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1731 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1732 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w5135,w5585,w5956,w6225,w6300,w6588]
theorem b5_1732 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1732 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,false)),(false,(7,true),(0,true))] s5_1732 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1733 : List (BitVec 512) := [w1076,w2494,w3766,w4344,w5135,w5769,w5956,w6300,w6464,w6588]
theorem b5_1733 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1733 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1733 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2494,v4_3766,v4_4344,v4_5135,v4_5769,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1734 : List (BitVec 512) := [w1076,w2497,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_1734 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1734 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(0,false),(7,true)),(false,(7,true),(0,true))] s5_1734 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2497,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2497 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1735 : List (BitVec 512) := [w1076,w2497,w3766,w4344,w5135,w5585,w5956,w6225,w6300,w6588]
theorem b5_1735 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1735 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,false)),(false,(7,true),(0,true))] s5_1735 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2497,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2497 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1736 : List (BitVec 512) := [w1076,w2527,w2885,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1736 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1736 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_1736 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_2885,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_2885 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1737 : List (BitVec 512) := [w1076,w2527,w2889,w3766,w4344,w5135,w5585,w5956,w6300,w6588]
theorem b5_1737 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1737 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1737 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_2889,v4_3766,v4_4344,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_2889 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1738 : List (BitVec 512) := [w1076,w2527,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_1738 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1738 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1738 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2527,v4_3766,v4_4344,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1739 : List (BitVec 512) := [w1076,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1739 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1739 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_1739 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2529,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2529 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1740 : List (BitVec 512) := [w1076,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720]
theorem b5_1740 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1740 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_1740 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2529,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2529 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1741 : List (BitVec 512) := [w1076,w2681,w2852,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_1741 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1741 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(1,true),(5,false))] s5_1741 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_2852,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1742 : List (BitVec 512) := [w1076,w2681,w2852,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_1742 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1742 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(1,true),(5,false))] s5_1742 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_2852,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1743 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_1743 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1743 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_1743 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1744 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b5_1744 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1744 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s5_1744 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1745 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_1745 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1745 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(7,true),(8,true))] s5_1745 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1746 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1746 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1746 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s5_1746 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1747 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_1747 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1747 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(3,true))] s5_1747 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1748 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_1748 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1748 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(4,true))] s5_1748 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1749 : List (BitVec 512) := [w1076,w2681,w3766,w4344,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b5_1749 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1749 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(8,true),(4,true))] s5_1749 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1750 : List (BitVec 512) := [w1076,w2686,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b5_1750 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1750 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(1,true),(0,true)),(false,(8,true),(9,true))] s5_1750 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2686,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1751 : List (BitVec 512) := [w1076,w2686,w3766,w4344,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1751 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1751 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(1,true),(0,true)),(false,(8,true),(4,true))] s5_1751 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2686,v4_3766,v4_4344,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
