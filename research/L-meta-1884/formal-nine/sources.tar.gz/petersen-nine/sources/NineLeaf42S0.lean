import NinePin42
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5586 : List (BitVec 512) := [w1116,w1413,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5586 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_5586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_1116,v42_1413,v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_1116 (PetersenWireProjection.cons pc42_1413 (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_10525 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6904]
theorem b4_10525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10525 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [(false,(0,false),(2,true))] s4_10525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_1415,v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6464,v42_6904] (PetersenWireProjection.cons pc42_1415 (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6904 rfl))))))))))) (by decide +kernel)
def s4_15511 : List (BitVec 512) := [w3766,w4265,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_15511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15511 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_15511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4265,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6464,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4265 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_15512 : List (BitVec 512) := [w3766,w4265,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15512 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_15512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4265,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4265 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s4_15513 : List (BitVec 512) := [w3766,w4266,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_15513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15513 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_15513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4266,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6464,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4266 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_15514 : List (BitVec 512) := [w3766,w4266,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15514 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_15514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4266,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4266 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s4_16250 : List (BitVec 512) := [w3766,w4344,w4455,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16250 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [(false,(1,true),(4,true))] s4_16250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4455,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6101,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4455 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6101 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_16251 : List (BitVec 512) := [w3766,w4344,w4455,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_16251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16251 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_16251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4455,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6464,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4455 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_16252 : List (BitVec 512) := [w3766,w4344,w4455,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16252 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_16252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4455,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4455 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s4_16967 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16967 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_16967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4716,v42_4916,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6567,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_4916 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6567 (PetersenWireProjection.cons pc42_6588 rfl))))))))))) (by decide +kernel)
def s4_16969 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_16969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16969 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_16969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4716,v42_4916,v42_5135,v42_5393,v42_5585,v42_5956,v42_6464,v42_6588,v42_6873] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_4916 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6588 (PetersenWireProjection.cons pc42_6873 rfl))))))))))) (by decide +kernel)
def s4_17960 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6460,w6464,w6720,w6873]
theorem b4_17960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17960 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [(false,(4,true),(2,true))] s4_17960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6460,v42_6464,v42_6720,v42_6873] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6460 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6720 (PetersenWireProjection.cons pc42_6873 rfl))))))))))) (by decide +kernel)
def s4_17961 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6460,w6464,w6873]
theorem b4_17961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17961 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s4_17961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6460,v42_6464,v42_6873] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6460 (PetersenWireProjection.cons pc42_6464 (PetersenWireProjection.cons pc42_6873 rfl)))))))))) (by decide +kernel)
def s5_1508 : List (BitVec 512) := [w980,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1508 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1508 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s5_1508 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_980,v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_980 (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s5_2244 : List (BitVec 512) := [w1244,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2244 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s5_2244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_1244,v42_3766,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_1244 (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s5_5407 : List (BitVec 512) := [w3766,w4264,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5407 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5407 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s5_5407 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4264,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4264 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s5_5408 : List (BitVec 512) := [w3766,w4267,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5408 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5408 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s5_5408 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4267,v42_4344,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4267 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
def s5_5589 : List (BitVec 512) := [w3766,w4344,w4490,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5589 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5589 := by
  intro m le c
  apply rejects_sound r42 i7 8 tgt (small42 adj) hot42 [] s5_5589 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v42_3766,v42_4344,v42_4490,v42_4716,v42_5135,v42_5393,v42_5585,v42_5956,v42_6300,v42_6588] (PetersenWireProjection.cons pc42_3766 (PetersenWireProjection.cons pc42_4344 (PetersenWireProjection.cons pc42_4490 (PetersenWireProjection.cons pc42_4716 (PetersenWireProjection.cons pc42_5135 (PetersenWireProjection.cons pc42_5393 (PetersenWireProjection.cons pc42_5585 (PetersenWireProjection.cons pc42_5956 (PetersenWireProjection.cons pc42_6300 (PetersenWireProjection.cons pc42_6588 rfl)))))))))) (by decide +kernel)
end NineCert
