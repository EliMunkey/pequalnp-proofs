import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7392 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6690]
theorem b4_7392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7392 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(7,true))] s4_7392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_7397 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_7397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7397 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(7,true))] s4_7397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7407 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6690]
theorem b4_7407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7407 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true))] s4_7407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_7412 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_7412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7412 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true))] s4_7412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7440 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_7440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7440 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(7,true))] s4_7440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7441 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_7441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7441 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true))] s4_7441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7445 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_7445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7445 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_7445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7465 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6061,w6179,w6300,w6588]
theorem b4_7465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7465 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6061,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7472 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6180,w6300,w6588]
theorem b4_7472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7472 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6180,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6180 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7474 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6201,w6300,w6588]
theorem b4_7474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7474 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7482 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6389,w6588]
theorem b4_7482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7482 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7491 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6690]
theorem b4_7491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7491 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_7500 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6690]
theorem b4_7500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7500 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_7508 : List (BitVec 512) := [w1292,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7508 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_7508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7553 : List (BitVec 512) := [w1312,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7553 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_1328,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7685 : List (BitVec 512) := [w1312,w3075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7685 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3075,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3075 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7771 : List (BitVec 512) := [w1312,w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7771 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7779 : List (BitVec 512) := [w1312,w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7779 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7780 : List (BitVec 512) := [w1312,w3766,w4079,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7780 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4079,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7782 : List (BitVec 512) := [w1312,w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_7782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7782 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7783 : List (BitVec 512) := [w1312,w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7783 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7784 : List (BitVec 512) := [w1312,w3766,w4121,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7784 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4121,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7785 : List (BitVec 512) := [w1312,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7785 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7786 : List (BitVec 512) := [w1312,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w6061,w6300,w6588]
theorem b4_7786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7786 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7787 : List (BitVec 512) := [w1312,w3766,w4146,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7787 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4146,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7788 : List (BitVec 512) := [w1312,w3766,w4146,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_7788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7788 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4146,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7789 : List (BitVec 512) := [w1312,w3766,w4149,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7789 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4149,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4149 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7791 : List (BitVec 512) := [w1312,w3766,w4178,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7791 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4178,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4178 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7792 : List (BitVec 512) := [w1312,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7792 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7793 : List (BitVec 512) := [w1312,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b4_7793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7793 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7794 : List (BitVec 512) := [w1312,w3766,w4179,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7794 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7795 : List (BitVec 512) := [w1312,w3766,w4179,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_7795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7795 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4179,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7797 : List (BitVec 512) := [w1312,w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7797 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7798 : List (BitVec 512) := [w1312,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7798 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7799 : List (BitVec 512) := [w1312,w3766,w4303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7799 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7800 : List (BitVec 512) := [w1312,w3766,w4303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7800 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7800 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7800 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7801 : List (BitVec 512) := [w1312,w3766,w4303,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7801 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4303,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7802 : List (BitVec 512) := [w1312,w3766,w4303,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_7802 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7802 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_7802 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4303,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4303 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7803 : List (BitVec 512) := [w1312,w3766,w4316,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7803 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7803 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(9,true),(0,true))] s4_7803 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7804 : List (BitVec 512) := [w1312,w3766,w4316,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7804 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7804 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_7804 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4316,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7805 : List (BitVec 512) := [w1312,w3766,w4319,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7805 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7805 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_7805 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4319,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7806 : List (BitVec 512) := [w1312,w3766,w4321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7806 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(9,true),(0,true))] s4_7806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_7807 : List (BitVec 512) := [w1312,w3766,w4321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7807 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_7807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_7808 : List (BitVec 512) := [w1312,w3766,w4321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7808 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4321,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_7909 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_7909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7909 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s4_7909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8088 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5678,w5698,w5956,w6300,w6588]
theorem b4_8088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8088 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_8088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5678,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5678 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8089 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5678,w5769,w5956,w6300,w6588]
theorem b4_8089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8089 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_8089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5678,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5678 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8090 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5678,w5956,w6300,w6588]
theorem b4_8090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8090 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_8090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5678,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5678 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_8294 : List (BitVec 512) := [w1328,w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8294 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8294 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8294 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8295 : List (BitVec 512) := [w1328,w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8295 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8296 : List (BitVec 512) := [w1328,w3766,w3936,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8296 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_3936,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8299 : List (BitVec 512) := [w1328,w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8299 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8300 : List (BitVec 512) := [w1328,w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_8300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8300 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8301 : List (BitVec 512) := [w1328,w3766,w4079,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_8301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4079,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8302 : List (BitVec 512) := [w1328,w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8302 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s4_8302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8303 : List (BitVec 512) := [w1328,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8303 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8304 : List (BitVec 512) := [w1328,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8304 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8305 : List (BitVec 512) := [w1328,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8305 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8305 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8305 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8306 : List (BitVec 512) := [w1328,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8306 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8326 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_8326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_8369 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_8369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8369 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8370 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_8370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8370 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_8380 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_8380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8380 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true))] s4_8380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_8381 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6690]
theorem b4_8381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8381 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,true))] s4_8381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1328,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1328 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
end NineCert
