import NinePin275
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1567 : List (BitVec 512) := [w1007,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b5_1567 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1567 := by
  intro m le c
  apply rejects_sound r275 i6 5 tgt (small275 adj) hot275 [] s5_1567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v275_1007,v275_3766,v275_4344,v275_4716,v275_5135,v275_5585,v275_5652,v275_5956,v275_6300,v275_6588] (PetersenWireProjection.cons pc275_1007 (PetersenWireProjection.cons pc275_3766 (PetersenWireProjection.cons pc275_4344 (PetersenWireProjection.cons pc275_4716 (PetersenWireProjection.cons pc275_5135 (PetersenWireProjection.cons pc275_5585 (PetersenWireProjection.cons pc275_5652 (PetersenWireProjection.cons pc275_5956 (PetersenWireProjection.cons pc275_6300 (PetersenWireProjection.cons pc275_6588 rfl)))))))))) (by decide +kernel)
def s5_2419 : List (BitVec 512) := [w1299,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2419 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2419 := by
  intro m le c
  apply rejects_sound r275 i6 5 tgt (small275 adj) hot275 [] s5_2419 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v275_1299,v275_2468,v275_3766,v275_4344,v275_4716,v275_5135,v275_5585,v275_5956,v275_6300,v275_6588] (PetersenWireProjection.cons pc275_1299 (PetersenWireProjection.cons pc275_2468 (PetersenWireProjection.cons pc275_3766 (PetersenWireProjection.cons pc275_4344 (PetersenWireProjection.cons pc275_4716 (PetersenWireProjection.cons pc275_5135 (PetersenWireProjection.cons pc275_5585 (PetersenWireProjection.cons pc275_5956 (PetersenWireProjection.cons pc275_6300 (PetersenWireProjection.cons pc275_6588 rfl)))))))))) (by decide +kernel)
def s5_2574 : List (BitVec 512) := [w1319,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2574 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2574 := by
  intro m le c
  apply rejects_sound r275 i6 5 tgt (small275 adj) hot275 [] s5_2574 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v275_1319,v275_2468,v275_3766,v275_4344,v275_4716,v275_5135,v275_5585,v275_5956,v275_6300,v275_6588] (PetersenWireProjection.cons pc275_1319 (PetersenWireProjection.cons pc275_2468 (PetersenWireProjection.cons pc275_3766 (PetersenWireProjection.cons pc275_4344 (PetersenWireProjection.cons pc275_4716 (PetersenWireProjection.cons pc275_5135 (PetersenWireProjection.cons pc275_5585 (PetersenWireProjection.cons pc275_5956 (PetersenWireProjection.cons pc275_6300 (PetersenWireProjection.cons pc275_6588 rfl)))))))))) (by decide +kernel)
def s5_4053 : List (BitVec 512) := [w2468,w3766,w4344,w4388,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4053 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4053 := by
  intro m le c
  apply rejects_sound r275 i6 5 tgt (small275 adj) hot275 [] s5_4053 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v275_2468,v275_3766,v275_4344,v275_4388,v275_4716,v275_5135,v275_5585,v275_5956,v275_6300,v275_6588] (PetersenWireProjection.cons pc275_2468 (PetersenWireProjection.cons pc275_3766 (PetersenWireProjection.cons pc275_4344 (PetersenWireProjection.cons pc275_4388 (PetersenWireProjection.cons pc275_4716 (PetersenWireProjection.cons pc275_5135 (PetersenWireProjection.cons pc275_5585 (PetersenWireProjection.cons pc275_5956 (PetersenWireProjection.cons pc275_6300 (PetersenWireProjection.cons pc275_6588 rfl)))))))))) (by decide +kernel)
end NineCert
