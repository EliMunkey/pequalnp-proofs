import NinePin296
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7691 : List (BitVec 512) := [w1312,w3177,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7691 := by
  intro m le c
  apply rejects_sound r296 i5 4 tgt (small296 adj) hot296 [] s4_7691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v296_1312,v296_3177,v296_3766,v296_4344,v296_4716,v296_5135,v296_5393,v296_5585,v296_5956,v296_6300,v296_6785] (PetersenWireProjection.cons pc296_1312 (PetersenWireProjection.cons pc296_3177 (PetersenWireProjection.cons pc296_3766 (PetersenWireProjection.cons pc296_4344 (PetersenWireProjection.cons pc296_4716 (PetersenWireProjection.cons pc296_5135 (PetersenWireProjection.cons pc296_5393 (PetersenWireProjection.cons pc296_5585 (PetersenWireProjection.cons pc296_5956 (PetersenWireProjection.cons pc296_6300 (PetersenWireProjection.cons pc296_6785 rfl))))))))))) (by decide +kernel)
end NineCert
