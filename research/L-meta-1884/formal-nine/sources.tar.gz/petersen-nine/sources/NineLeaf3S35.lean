import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4470 : List (BitVec 512) := [w967,w3766,w4344,w4716,w4805,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4470 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(2,true))] s4_4470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_4805,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4805 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4471 : List (BitVec 512) := [w967,w3766,w4344,w4716,w4807,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4471 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(2,true))] s4_4471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_4807,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4807 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4472 : List (BitVec 512) := [w967,w3766,w4344,w4716,w4808,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4472 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(2,true))] s4_4472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_4808,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4808 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4473 : List (BitVec 512) := [w967,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4473 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(2,true))] s4_4473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_4810,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4810 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4474 : List (BitVec 512) := [w967,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4474 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_4474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4475 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5618,w5956,w6300,w6588]
theorem b4_4475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4475 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(0,true),(5,true))] s4_4475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5618,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5618 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4476 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5620,w5956,w6300,w6588]
theorem b4_4476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4476 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(7,true)),(false,(0,true),(5,true))] s4_4476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5620,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5620 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4477 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5621,w5956,w6300,w6588]
theorem b4_4477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4477 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_4477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5621,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5621 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4478 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_4478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4478 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_4478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5623,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5623 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4479 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5624,w5956,w6300,w6588]
theorem b4_4479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4479 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_4479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5624,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5624 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4480 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5626,w5956,w6300,w6588]
theorem b4_4480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4480 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s4_4480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5626,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5626 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4481 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5634,w5956,w6300,w6588]
theorem b4_4481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4481 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(5,true))] s4_4481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5634,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5634 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4482 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5635,w5956,w6300,w6588]
theorem b4_4482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4482 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(6,true)),(false,(0,true),(5,true))] s4_4482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5635,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5635 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4483 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5636,w5956,w6300,w6588]
theorem b4_4483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4483 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))] s4_4483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5636,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5636 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4484 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5638,w5956,w6300,w6588]
theorem b4_4484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4484 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(5,true))] s4_4484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5638,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5638 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4485 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5638,w5956,w6300,w6690]
theorem b4_4485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4485 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(5,true))] s4_4485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5638,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5638 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4486 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5639,w5956,w6300,w6588]
theorem b4_4486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4486 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true))] s4_4486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5639,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5639 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4487 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5640,w5956,w6300,w6588]
theorem b4_4487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4487 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_4487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5640,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5640 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4488 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5644,w5956,w6300,w6588]
theorem b4_4488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4488 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(5,true)),(false,(0,true),(5,true))] s4_4488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5644,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5644 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4489 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5645,w5956,w6300,w6588]
theorem b4_4489 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4489 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(5,true))] s4_4489 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5645,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5645 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4490 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5646,w5956,w6300,w6588]
theorem b4_4490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4490 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true))] s4_4490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5646,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5646 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4491 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5648,w5956,w6300,w6588]
theorem b4_4491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4491 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(5,true))] s4_4491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5648,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5648 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4492 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5648,w5956,w6300,w6690]
theorem b4_4492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4492 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(5,true))] s4_4492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5648,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5648 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4493 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5649,w5956,w6300,w6588]
theorem b4_4493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4493 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_4493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5649,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5649 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4494 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5650,w5956,w6300,w6588]
theorem b4_4494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4494 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_4494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5650,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5650 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4495 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5655,w5956,w6300,w6588]
theorem b4_4495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4495 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(5,true))] s4_4495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5655,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5655 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4496 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b4_4496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4496 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(5,true))] s4_4496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5656,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5656 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4497 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5657,w5956,w6300,w6588]
theorem b4_4497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4497 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_4497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5657,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5657 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4498 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5659,w5956,w6300,w6588]
theorem b4_4498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4498 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(5,true))] s4_4498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5659,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5659 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4499 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5659,w5956,w6300,w6690]
theorem b4_4499 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4499 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(5,true))] s4_4499 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5659,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5659 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4500 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5660,w5956,w6300,w6588]
theorem b4_4500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4500 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s4_4500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5660,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5660 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4501 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5662,w5956,w6300,w6588]
theorem b4_4501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4501 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_4501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5662,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5662 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4502 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_4502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4502 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(5,true))] s4_4502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5665,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5665 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4503 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5666,w5956,w6300,w6588]
theorem b4_4503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4503 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(5,true))] s4_4503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5666,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5666 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4504 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5667,w5956,w6300,w6588]
theorem b4_4504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4504 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(5,true))] s4_4504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5667,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5667 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4505 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5669,w5956,w6300,w6588]
theorem b4_4505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4505 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(5,true))] s4_4505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5669,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5669 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4506 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5670,w5956,w6300,w6588]
theorem b4_4506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4506 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,true))] s4_4506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5670,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5670 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4507 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5672,w5956,w6300,w6588]
theorem b4_4507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4507 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s4_4507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5672,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5672 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4508 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_4508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4508 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_4508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4509 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_4509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4509 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,false))] s4_4509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5750,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5750 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4510 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_4510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4510 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,false))] s4_4510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5760,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5760 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4511 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_4511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4511 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,true))] s4_4511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5767,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5767 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4512 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_4512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4512 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4513 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_4513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4513 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_4513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4514 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b4_4514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4514 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(0,true),(6,true))] s4_4514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5981,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5981 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4515 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_4515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4515 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(0,true),(6,true))] s4_4515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5992,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5992 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4516 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_4516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4516 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_4516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5993,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5993 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4517 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_4517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4517 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_4517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5995,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5995 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4518 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5996,w6300,w6588]
theorem b4_4518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4518 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_4518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5996,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5996 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4519 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5998,w6300,w6588]
theorem b4_4519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4519 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_4519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5998,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5998 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4520 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6002,w6300,w6588]
theorem b4_4520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4520 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(6,true))] s4_4520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6002,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6002 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4521 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6003,w6300,w6588]
theorem b4_4521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4521 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,false)),(false,(0,true),(6,true))] s4_4521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6003,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6003 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4522 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_4522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4522 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_4522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6004,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6004 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4523 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6300,w6588]
theorem b4_4523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4523 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(6,true))] s4_4523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6006,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6006 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4524 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6007,w6300,w6588]
theorem b4_4524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4524 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_4524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6007,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6007 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4525 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6009,w6300,w6588]
theorem b4_4525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4525 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_4525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6009,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6009 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4526 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_4526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4526 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(0,true),(6,true))] s4_4526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6014,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6014 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4527 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_4527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4527 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true))] s4_4527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6017,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6017 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4528 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_4528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4528 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_4528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6019,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6019 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4529 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_4529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4529 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,true),(6,true))] s4_4529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6023,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6023 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4530 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_4530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4530 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_4530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6024,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6024 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4531 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_4531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4531 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_4531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6026,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6026 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4532 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6032,w6300,w6588]
theorem b4_4532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4532 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(0,true),(6,true))] s4_4532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6032,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6032 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4533 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6033,w6300,w6588]
theorem b4_4533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4533 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(6,true))] s4_4533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6033,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6033 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
