import NinePin113
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4896 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6225,w6300,w6588]
theorem b3_4896 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4896 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4896 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6225,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))))) (by decide +kernel)
def s3_4897 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6237,w6300,w6588]
theorem b3_4897 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4897 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4897 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6237,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6237 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))))) (by decide +kernel)
def s3_4900 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6499,w6588]
theorem b3_4900 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4900 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4900 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6300,v113_6499,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6499 (PetersenWireProjection.cons pc113_6588 rfl)))))))))))) (by decide +kernel)
def s3_4903 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588,w6813]
theorem b3_4903 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4903 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4903 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6300,v113_6588,v113_6813] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6813 rfl)))))))))))) (by decide +kernel)
def s3_4904 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588,w6821]
theorem b3_4904 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4904 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4904 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6300,v113_6588,v113_6821] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6821 rfl)))))))))))) (by decide +kernel)
def s3_4920 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6237,w6300,w6588]
theorem b3_4920 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4920 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4920 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6225,v113_6237,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6237 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))))) (by decide +kernel)
def s3_4924 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6575,w6588]
theorem b3_4924 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4924 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s3_4924 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6225,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl)))))))))))) (by decide +kernel)
def s4_2908 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_2908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2908 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_2908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_628,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588,v113_6857] (PetersenWireProjection.cons pc113_628 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6857 rfl))))))))))) (by decide +kernel)
def s4_2951 : List (BitVec 512) := [w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_2951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2951 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_2951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_632,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588,v113_6813] (PetersenWireProjection.cons pc113_632 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_3094 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_3094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3094 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_3094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_635,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588,v113_6748] (PetersenWireProjection.cons pc113_635 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6748 rfl))))))))))) (by decide +kernel)
def s4_3119 : List (BitVec 512) := [w637,w2838,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3119 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_3119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_2838,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_2838 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_3125 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3125 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_3125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588,v113_6720] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6720 rfl))))))))))) (by decide +kernel)
def s4_8045 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6821]
theorem b4_8045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8045 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6720,v113_6821] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_8048 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6869]
theorem b4_8048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8048 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6720,v113_6869] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_8051 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6813]
theorem b4_8051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8051 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6748,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6748 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_8063 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6821]
theorem b4_8063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8063 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813,v113_6821] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_8068 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6857]
theorem b4_8068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8068 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813,v113_6857] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 (PetersenWireProjection.cons pc113_6857 rfl))))))))))) (by decide +kernel)
def s4_8070 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6869]
theorem b4_8070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8070 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813,v113_6869] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_8189 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6748]
theorem b4_8189 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8189 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8189 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6720,v113_6748] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6748 rfl))))))))))) (by decide +kernel)
def s4_8193 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6857]
theorem b4_8193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8193 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6720,v113_6857] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6857 rfl))))))))))) (by decide +kernel)
def s4_8199 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720,w6813]
theorem b4_8199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8199 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5956,v113_6101,v113_6300,v113_6720,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6101 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_8384 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6813]
theorem b4_8384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8384 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_8385 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6821]
theorem b4_8385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8385 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6821] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_8397 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6813]
theorem b4_8397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8397 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5848,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_8452 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6821]
theorem b4_8452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8452 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6720,v113_6821] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_8460 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6821]
theorem b4_8460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8460 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813,v113_6821] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_8471 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6720]
theorem b4_8471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8471 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_8471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5769,v113_5848,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl))))))))))) (by decide +kernel)
def s4_9674 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6813]
theorem b4_9674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9674 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_9676 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6869]
theorem b4_9676 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9676 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9676 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_9699 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6813]
theorem b4_9699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9699 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl))))))))))) (by decide +kernel)
def s4_9701 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6869]
theorem b4_9701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9701 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_9717 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6869]
theorem b4_9717 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9717 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9717 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6720,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_9721 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6869]
theorem b4_9721 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9721 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9721 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_9736 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6720]
theorem b4_9736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9736 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_9736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl))))))))))) (by decide +kernel)
def s4_13043 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6553,w6588]
theorem b4_13043 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13043 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13043 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2492,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6101,v113_6300,v113_6553,v113_6588] (PetersenWireProjection.cons pc113_2492 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6101 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6553 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13087 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6575,w6588]
theorem b4_13087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13087 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5769,v113_5956,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13090 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6575,w6588]
theorem b4_13090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13090 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6101,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6101 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13092 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6225,w6300,w6575,w6588]
theorem b4_13092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13092 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6225,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13094 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6575,w6588]
theorem b4_13094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13094 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6300,v113_6422,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6422 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13096 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6489,w6575,w6588]
theorem b4_13096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13096 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6300,v113_6489,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6489 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_13100 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6575,w6588]
theorem b4_13100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13100 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_13100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6300,v113_6549,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6549 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17294 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5775,w5956,w6300,w6588]
theorem b4_17294 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17294 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17294 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5775,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5775 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17295 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5777,w5956,w6300,w6588]
theorem b4_17295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17295 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5777,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5777 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17296 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5778,w5956,w6300,w6588]
theorem b4_17296 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17296 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17296 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5778,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5778 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17299 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5784,w5956,w6300,w6588]
theorem b4_17299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17299 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5784,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5784 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17300 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5786,w5956,w6300,w6588]
theorem b4_17300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17300 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5786,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5786 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17302 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5794,w5956,w6300,w6588]
theorem b4_17302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17302 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5794,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5794 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17303 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5796,w5956,w6300,w6588]
theorem b4_17303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17303 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5796,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5796 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17309 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6237,w6300,w6588]
theorem b4_17309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17309 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6237,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6237 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17327 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6578,w6588]
theorem b4_17327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17327 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6578,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6578 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17332 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6821]
theorem b4_17332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17332 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6588,v113_6821] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6821 rfl))))))))))) (by decide +kernel)
def s4_17339 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6870]
theorem b4_17339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17339 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6588,v113_6870] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6870 rfl))))))))))) (by decide +kernel)
def s4_17344 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6907]
theorem b4_17344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17344 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6588,v113_6907] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6907 rfl))))))))))) (by decide +kernel)
def s4_17487 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6575,w6588]
theorem b4_17487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17487 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5848,v113_5956,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17508 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6869]
theorem b4_17508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17508 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5848,v113_5956,v113_6300,v113_6588,v113_6869] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6869 rfl))))))))))) (by decide +kernel)
def s4_17515 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6906]
theorem b4_17515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17515 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5848,v113_5956,v113_6300,v113_6588,v113_6906] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6906 rfl))))))))))) (by decide +kernel)
def s4_17607 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6575,w6588]
theorem b4_17607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17607 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6136,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6136 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17613 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588,w6912]
theorem b4_17613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17613 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6136,v113_6300,v113_6588,v113_6912] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6136 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 (PetersenWireProjection.cons pc113_6912 rfl))))))))))) (by decide +kernel)
def s4_17630 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6499,w6588]
theorem b4_17630 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17630 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17630 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6499,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6499 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17632 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6578,w6588]
theorem b4_17632 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17632 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17632 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6578,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6578 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s4_17646 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6575,w6588]
theorem b4_17646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17646 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s4_17646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6237,v113_6300,v113_6575,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6237 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6575 (PetersenWireProjection.cons pc113_6588 rfl))))))))))) (by decide +kernel)
def s5_893 : List (BitVec 512) := [w598,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_893 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_893 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_893 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_598,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_598 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_896 : List (BitVec 512) := [w601,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_896 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_896 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_896 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_601,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_601 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_898 : List (BitVec 512) := [w603,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_898 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_898 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_898 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_603,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_603 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
end NineCert
