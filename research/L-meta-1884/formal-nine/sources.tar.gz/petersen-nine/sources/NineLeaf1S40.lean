import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2649 : List (BitVec 512) := [w1328,w3766,w4344,w5098,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_2649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2649 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2654 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5873,w5956,w6300,w6720]
theorem b5_2654 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2654 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2654 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2658 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5769,w5861,w5956,w6300,w6720]
theorem b5_2658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2658 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5861,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2661 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6748]
theorem b5_2661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2661 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(2,false),(6,true))] s5_2661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6748] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6748 rfl)))))))))) (by decide +kernel)
def s5_2666 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6690]
theorem b5_2666 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2666 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2666 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2768 : List (BitVec 512) := [w1374,w2443,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300]
theorem b5_2768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2768 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true)),(false,(7,true),(0,true))] s5_2768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2443,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2443 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2774 : List (BitVec 512) := [w1374,w2494,w3766,w4344,w4716,w5053,w5135,w5585,w5956,w6300]
theorem b5_2774 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2774 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(1,false)),(false,(7,true),(0,true))] s5_2774 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2494,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2787 : List (BitVec 512) := [w1374,w2589,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_2787 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2787 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s5_2787 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2589,v1_2681,v1_3766,v1_4344,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2788 : List (BitVec 512) := [w1374,w2590,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2788 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2788 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(5,true),(6,true))] s5_2788 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2590,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2590 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2789 : List (BitVec 512) := [w1374,w2644,w3766,w4344,w4716,w5135,w5393,w5698,w6300,w6832]
theorem b5_2789 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2789 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(7,true)),(false,(9,true),(6,true))] s5_2789 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_2790 : List (BitVec 512) := [w1374,w2646,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2790 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2790 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(5,true),(2,false))] s5_2790 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2646,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2792 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b5_2792 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2792 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s5_2792 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2681,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2813 : List (BitVec 512) := [w1374,w3766,w4344,w4403,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b5_2813 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2813 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s5_2813 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4403,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2817 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5025,w5135,w5393,w5585,w5956,w6300]
theorem b5_2817 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2817 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_2817 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5025,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5025 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2818 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6201,w6300]
theorem b5_2818 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2818 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(1,false))] s5_2818 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2819 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b5_2819 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2819 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s5_2819 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s5_2820 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6389]
theorem b5_2820 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2820 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true))] s5_2820 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 rfl)))))))))) (by decide +kernel)
def s5_2821 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6720]
theorem b5_2821 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2821 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s5_2821 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2822 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w6179,w6300,w6522]
theorem b5_2822 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2822 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s5_2822 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_6179,v1_6300,v1_6522] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 rfl)))))))))) (by decide +kernel)
def s5_2823 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5121,w5135,w5393,w5585,w5956,w6300]
theorem b5_2823 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2823 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s5_2823 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5121,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2824 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5121,w5393,w5585,w5956,w6300]
theorem b5_2824 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2824 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s5_2824 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5121,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s5_2825 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5121,w5393,w5585,w5956,w6300,w6869]
theorem b5_2825 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2825 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(0,false),(6,true))] s5_2825 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5121,v1_5393,v1_5585,v1_5956,v1_6300,v1_6869] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6869 rfl)))))))))) (by decide +kernel)
def s5_2838 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5698,w6241,w6300,w6832]
theorem b5_2838 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2838 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(7,true)),(false,(9,true),(6,true))] s5_2838 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_2844 : List (BitVec 512) := [w1374,w3766,w4344,w4748,w5098,w5393,w5585,w5956,w6300,w6720]
theorem b5_2844 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2844 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(5,true),(6,true))] s5_2844 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4748,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4748 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2845 : List (BitVec 512) := [w1374,w3766,w4344,w5098,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_2845 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2845 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(5,true),(2,false))] s5_2845 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2846 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5240,w5393,w5585,w5956,w6300,w6720]
theorem b5_2846 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2846 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(5,true),(6,true))] s5_2846 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_5135,v1_5240,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5240 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2850 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5393,w5585,w5956,w6243,w6300,w6720]
theorem b5_2850 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2850 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(5,true),(2,false))] s5_2850 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2868 : List (BitVec 512) := [w1384,w2589,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2868 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2868 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2868 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2589,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2869 : List (BitVec 512) := [w1384,w2615,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2869 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2869 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2869 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2615,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2870 : List (BitVec 512) := [w1384,w2641,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2870 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2870 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2870 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2641,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2641 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2871 : List (BitVec 512) := [w1384,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6832]
theorem b5_2871 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2871 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s5_2871 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_2872 : List (BitVec 512) := [w1384,w2644,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785]
theorem b5_2872 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2872 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(8,true),(6,true))] s5_2872 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_2873 : List (BitVec 512) := [w1384,w2645,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2873 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2873 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2873 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2645,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2645 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2881 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_2881 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2881 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s5_2881 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3258,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2895 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b5_2895 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2895 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_2895 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3293,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2917 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6300]
theorem b5_2917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2917 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2918 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5393,w5585,w5698,w5956,w6300]
theorem b5_2918 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2918 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s5_2918 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2919 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6061,w6300]
theorem b5_2919 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2919 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2919 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2920 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6201,w6300]
theorem b5_2920 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2920 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2920 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2921 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b5_2921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2921 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s5_2922 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6720]
theorem b5_2922 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2922 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2922 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2923 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5106,w5135,w5393,w5585,w5956,w6300]
theorem b5_2923 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2923 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s5_2923 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5106,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5106 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2924 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5116,w5135,w5393,w5585,w5956,w6300]
theorem b5_2924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2924 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5116,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5116 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2925 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5119,w5135,w5393,w5585,w5956,w6300]
theorem b5_2925 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2925 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s5_2925 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5119,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5119 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2926 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5120,w5135,w5393,w5585,w5956,w6300]
theorem b5_2926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2926 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_2926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5120,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5120 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_2944 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6241,w6300,w6832]
theorem b5_2944 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2944 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s5_2944 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_2953 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5956,w6241,w6300,w6785]
theorem b5_2953 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2953 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(8,true),(6,true))] s5_2953 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6241,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s5_2958 : List (BitVec 512) := [w1384,w3766,w4344,w5135,w5239,w5393,w5585,w5956,w6300,w6720]
theorem b5_2958 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2958 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_2958 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2968 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6690]
theorem b5_2968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2968 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2973 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5956,w6153,w6300,w6690]
theorem b5_2973 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2973 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2973 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6153,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2977 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5956,w6242,w6300,w6690]
theorem b5_2977 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2977 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(4,true),(6,true))] s5_2977 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6242,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6242 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl)))))))))) (by decide +kernel)
def s5_2997 : List (BitVec 512) := [w1388,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b5_2997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2997 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(2,false),(6,true))] s5_2997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_2998 : List (BitVec 512) := [w1388,w2613,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2998 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_2998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_2999 : List (BitVec 512) := [w1388,w2623,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2999 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_2999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2623,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3000 : List (BitVec 512) := [w1388,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6832]
theorem b5_3000 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3000 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true)),(false,(9,true),(6,true))] s5_3000 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_3001 : List (BitVec 512) := [w1388,w2646,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_3001 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3001 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_3001 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2646,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_3016 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5107,w5135,w5393,w5585,w5956,w6300]
theorem b5_3016 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3016 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_3016 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5107,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_3017 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300]
theorem b5_3017 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3017 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_3017 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s5_3018 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6813]
theorem b5_3018 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3018 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(2,false),(6,true))] s5_3018 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s5_3019 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5119,w5135,w5393,w5585,w5956,w6300]
theorem b5_3019 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3019 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s5_3019 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5119,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5119 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_3020 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5121,w5135,w5393,w5585,w5956,w6300]
theorem b5_3020 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_3020 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5121,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_3021 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5121,w5393,w5585,w5956,w6300]
theorem b5_3021 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_3021 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5121,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s5_3022 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5121,w5393,w5585,w5956,w6300,w6869]
theorem b5_3022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3022 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(1,false),(6,true))] s5_3022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5121,v1_5393,v1_5585,v1_5956,v1_6300,v1_6869] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5121 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6869 rfl)))))))))) (by decide +kernel)
def s5_3029 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6857]
theorem b5_3029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3029 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true)),(false,(2,false),(6,true))] s5_3029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6857] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6857 rfl)))))))))) (by decide +kernel)
end NineCert
