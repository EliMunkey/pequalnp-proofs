import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5035 : List (BitVec 512) := [w3654,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5035 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5035 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5035 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3654,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3654 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5036 : List (BitVec 512) := [w3657,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5036 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3657,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3657 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5037 : List (BitVec 512) := [w3658,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5037 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5037 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5037 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3658,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3658 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5038 : List (BitVec 512) := [w3659,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5038 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5038 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5038 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3659,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3659 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5039 : List (BitVec 512) := [w3661,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5039 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5039 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5039 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3661,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3661 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5040 : List (BitVec 512) := [w3662,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5040 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5040 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5040 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3662,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3662 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5041 : List (BitVec 512) := [w3663,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5041 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5041 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5041 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3663,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3663 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5042 : List (BitVec 512) := [w3668,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5042 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5042 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5042 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5043 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b5_5043 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5043 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s5_5043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5044 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5044 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5044 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5044 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5045 : List (BitVec 512) := [w3668,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b5_5045 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5045 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true))] s5_5045 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3668,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3668 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_5046 : List (BitVec 512) := [w3669,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_5046 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5046 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_5046 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_5047 : List (BitVec 512) := [w3669,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_5047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5047 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_5047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_5048 : List (BitVec 512) := [w3669,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_5048 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5048 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true)),(false,(3,true),(9,true))] s5_5048 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3669,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5049 : List (BitVec 512) := [w3670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5049 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5049 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5049 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3670,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3670 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5050 : List (BitVec 512) := [w3671,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5050 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5050 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5050 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3671,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3671 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5051 : List (BitVec 512) := [w3675,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5051 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5051 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5051 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3675,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3675 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5052 : List (BitVec 512) := [w3676,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5052 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5052 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5052 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3676,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3676 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5053 : List (BitVec 512) := [w3677,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5053 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5053 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5053 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3677,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3677 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5054 : List (BitVec 512) := [w3679,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5054 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5054 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5054 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3679,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3679 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5055 : List (BitVec 512) := [w3680,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5055 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5055 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5055 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3680,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3680 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5056 : List (BitVec 512) := [w3681,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5056 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5056 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5056 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3681,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5057 : List (BitVec 512) := [w3682,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5057 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5057 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_5057 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3682,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5058 : List (BitVec 512) := [w3684,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5058 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5058 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5058 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3684,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3684 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5059 : List (BitVec 512) := [w3686,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5059 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5059 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5059 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5060 : List (BitVec 512) := [w3686,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b5_5060 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5060 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s5_5060 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6166,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6166 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5061 : List (BitVec 512) := [w3686,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b5_5061 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5061 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s5_5061 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5062 : List (BitVec 512) := [w3686,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5062 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5062 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5062 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5063 : List (BitVec 512) := [w3686,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b5_5063 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5063 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true))] s5_5063 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_5064 : List (BitVec 512) := [w3687,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5064 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5064 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5064 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5065 : List (BitVec 512) := [w3688,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5065 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5065 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5065 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3688,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3688 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5066 : List (BitVec 512) := [w3688,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6578,w6588]
theorem b5_5066 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5066 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true)),(false,(0,false),(8,true)),(false,(2,false),(0,false))] s5_5066 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3688,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6578,v0_6588] (PetersenWireProjection.cons pc0_3688 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6578 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5067 : List (BitVec 512) := [w3688,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5067 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5067 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5067 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3688,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3688 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_5068 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5068 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5068 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5068 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5069 : List (BitVec 512) := [w3765,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5069 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5069 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_5069 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3765,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3765 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5070 : List (BitVec 512) := [w3766,w3770,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5070 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5070 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(0,false),(9,true))] s5_5070 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3770,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3770 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5071 : List (BitVec 512) := [w3766,w3772,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5071 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5071 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(5,true)),(false,(9,true),(0,true)),(false,(0,false),(9,true))] s5_5071 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3772,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3772 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5072 : List (BitVec 512) := [w3766,w3776,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5072 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5072 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(0,false),(8,true))] s5_5072 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3776,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3776 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5073 : List (BitVec 512) := [w3766,w3784,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5073 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5073 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true)),(false,(0,false),(10,true))] s5_5073 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3784,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3784 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5074 : List (BitVec 512) := [w3766,w3785,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5074 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5074 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(0,false),(7,true))] s5_5074 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3785,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3785 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5075 : List (BitVec 512) := [w3766,w3789,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5075 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5075 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(0,false),(4,true))] s5_5075 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3789,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3789 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5076 : List (BitVec 512) := [w3766,w3791,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5076 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5076 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(3,true)),(false,(0,false),(10,true))] s5_5076 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3791,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3791 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5077 : List (BitVec 512) := [w3766,w3793,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_5077 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5077 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(2,true)),(false,(7,true),(3,true))] s5_5077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3793,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3793 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5078 : List (BitVec 512) := [w3766,w3795,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5078 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5078 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(0,false),(10,true))] s5_5078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3795,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3795 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5079 : List (BitVec 512) := [w3766,w3799,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5079 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5079 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(0,false),(3,true))] s5_5079 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3799,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3799 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5080 : List (BitVec 512) := [w3766,w3800,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5080 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5080 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(2,true)),(false,(0,false),(10,true))] s5_5080 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3800,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3800 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5081 : List (BitVec 512) := [w3766,w3801,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5081 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5081 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5081 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3801,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3801 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5082 : List (BitVec 512) := [w3766,w3802,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5082 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5082 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5082 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3802,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3802 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5083 : List (BitVec 512) := [w3766,w3803,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5083 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5083 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5083 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3803,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3803 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5084 : List (BitVec 512) := [w3766,w3804,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5084 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5084 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5084 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3804,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3804 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5085 : List (BitVec 512) := [w3766,w3805,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5085 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5085 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5085 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3805,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3805 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5086 : List (BitVec 512) := [w3766,w3807,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5086 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5086 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5086 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3807,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3807 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5087 : List (BitVec 512) := [w3766,w3808,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5087 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5087 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5087 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3808,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3808 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5088 : List (BitVec 512) := [w3766,w3809,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5088 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5088 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(10,true))] s5_5088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3809,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3809 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5089 : List (BitVec 512) := [w3766,w3810,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5089 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5089 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3810,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3810 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5090 : List (BitVec 512) := [w3766,w3811,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5090 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5090 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5090 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3811,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3811 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5091 : List (BitVec 512) := [w3766,w3812,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5091 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5091 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5091 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3812,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3812 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5092 : List (BitVec 512) := [w3766,w3813,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5092 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5092 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5092 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3813,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3813 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5093 : List (BitVec 512) := [w3766,w3815,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5093 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5093 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5093 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3815,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3815 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5094 : List (BitVec 512) := [w3766,w3816,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5094 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5094 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_5094 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3816,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3816 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5095 : List (BitVec 512) := [w3766,w3818,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5095 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5095 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5095 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3818,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3818 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5096 : List (BitVec 512) := [w3766,w3819,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5096 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5096 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5096 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3819,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3819 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5097 : List (BitVec 512) := [w3766,w3820,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5097 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5097 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5097 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3820,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3820 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_5098 : List (BitVec 512) := [w3766,w3821,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5098 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5098 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(10,true))] s5_5098 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3821,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3821 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
