import NinePin221
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4849 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6237,w6300,w6588]
theorem b3_4849 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4849 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s3_4849 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_3766,v221_4344,v221_4716,v221_5135,v221_5393,v221_5585,v221_5698,v221_5956,v221_6101,v221_6237,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_3766 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5698 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6101 (PetersenWireProjection.cons pc221_6237 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl)))))))))))) (by decide +kernel)
def s4_1574 : List (BitVec 512) := [w200,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1574 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s4_1574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_200,v221_3182,v221_3766,v221_4344,v221_4716,v221_5135,v221_5393,v221_5585,v221_5956,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_200 (PetersenWireProjection.cons pc221_3182 (PetersenWireProjection.cons pc221_3766 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl))))))))))) (by decide +kernel)
def s4_16145 : List (BitVec 512) := [w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16145 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16145 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s4_16145 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_3766,v221_4344,v221_4413,v221_4716,v221_5135,v221_5393,v221_5585,v221_5956,v221_6101,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_3766 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4413 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6101 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl))))))))))) (by decide +kernel)
def s4_16741 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16741 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s4_16741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_3766,v221_4344,v221_4563,v221_4716,v221_5135,v221_5393,v221_5585,v221_5956,v221_6101,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_3766 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4563 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6101 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl))))))))))) (by decide +kernel)
def s4_16764 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16764 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s4_16764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_3766,v221_4344,v221_4571,v221_4716,v221_5135,v221_5393,v221_5585,v221_5956,v221_6101,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_3766 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4571 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6101 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl))))))))))) (by decide +kernel)
def s5_443 : List (BitVec 512) := [w200,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_443 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_443 := by
  intro m le c
  apply rejects_sound r221 i6 5 tgt (small221 adj) hot221 [] s5_443 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v221_200,v221_3935,v221_4344,v221_4716,v221_5135,v221_5393,v221_5585,v221_5956,v221_6300,v221_6588] (PetersenWireProjection.cons pc221_200 (PetersenWireProjection.cons pc221_3935 (PetersenWireProjection.cons pc221_4344 (PetersenWireProjection.cons pc221_4716 (PetersenWireProjection.cons pc221_5135 (PetersenWireProjection.cons pc221_5393 (PetersenWireProjection.cons pc221_5585 (PetersenWireProjection.cons pc221_5956 (PetersenWireProjection.cons pc221_6300 (PetersenWireProjection.cons pc221_6588 rfl)))))))))) (by decide +kernel)
end NineCert
