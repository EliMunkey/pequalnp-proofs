import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3675 : List (BitVec 512) := [w2382,w3766,w4159,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3675 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3675 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3675 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2382,v3_3766,v3_4159,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2382 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4159 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3698 : List (BitVec 512) := [w2387,w3766,w4084,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3698 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3698 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3698 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2387,v3_3766,v3_4084,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2387 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4084 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3699 : List (BitVec 512) := [w2387,w3766,w4160,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3699 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3699 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3699 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2387,v3_3766,v3_4160,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2387 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4160 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3836 : List (BitVec 512) := [w2468,w2472,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3836 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3836 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3836 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2472,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2472 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3855 : List (BitVec 512) := [w2468,w2681,w3766,w3936,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3855 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3855 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3855 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2681,v3_3766,v3_3936,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3856 : List (BitVec 512) := [w2468,w2681,w3766,w4007,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3856 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3856 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3856 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2681,v3_3766,v3_4007,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4007 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3857 : List (BitVec 512) := [w2468,w2681,w3766,w4079,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3857 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3857 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3857 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2681,v3_3766,v3_4079,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3858 : List (BitVec 512) := [w2468,w2681,w3766,w4179,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3858 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3858 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3858 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2681,v3_3766,v3_4179,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3859 : List (BitVec 512) := [w2468,w2681,w3766,w4276,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3859 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3859 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3859 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_2681,v3_3766,v3_4276,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3990 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3990 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3990 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3990 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3991 : List (BitVec 512) := [w2468,w3766,w3938,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3991 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3991 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3991 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3938,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3938 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3993 : List (BitVec 512) := [w2468,w3766,w3948,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3993 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3993 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3993 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3948,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3948 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3994 : List (BitVec 512) := [w2468,w3766,w3949,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3994 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3994 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3994 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3949,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3949 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3996 : List (BitVec 512) := [w2468,w3766,w4000,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_3996 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3996 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3996 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4000,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4000 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3997 : List (BitVec 512) := [w2468,w3766,w4040,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3997 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4040,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4040 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3998 : List (BitVec 512) := [w2468,w3766,w4055,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3998 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4055,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4055 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3999 : List (BitVec 512) := [w2468,w3766,w4056,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3999 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3999 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4056,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4056 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4000 : List (BitVec 512) := [w2468,w3766,w4057,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4000 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4000 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4000 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4057,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4057 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4001 : List (BitVec 512) := [w2468,w3766,w4079,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4001 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4001 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4001 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4002 : List (BitVec 512) := [w2468,w3766,w4081,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4002 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4002 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4002 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4081,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4081 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4004 : List (BitVec 512) := [w2468,w3766,w4088,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4004 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4004 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4004 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4088,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4088 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4005 : List (BitVec 512) := [w2468,w3766,w4091,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4005 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4005 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4005 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4091,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4091 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4007 : List (BitVec 512) := [w2468,w3766,w4121,w4344,w4716,w5135,w5698,w5956,w6300,w6588]
theorem b5_4007 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4007 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4007 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4008 : List (BitVec 512) := [w2468,w3766,w4121,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_4008 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4008 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s5_4008 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4121,v3_4716,v3_5135,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4009 : List (BitVec 512) := [w2468,w3766,w4121,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_4009 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4009 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s5_4009 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4121,v3_4716,v3_5135,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4010 : List (BitVec 512) := [w2468,w3766,w4145,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4010 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4010 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4010 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4145,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4145 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4011 : List (BitVec 512) := [w2468,w3766,w4146,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4011 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4011 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4011 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4016 : List (BitVec 512) := [w2468,w3766,w4163,w4926,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b5_4016 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4016 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4016 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4163,v3_4926,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4017 : List (BitVec 512) := [w2468,w3766,w4174,w4716,w5135,w5698,w6179,w6300,w6522,w6588]
theorem b5_4017 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4017 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s5_4017 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4174,v3_4716,v3_5135,v3_5698,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4174 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4018 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4018 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4018 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4018 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4022 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4022 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4023 : List (BitVec 512) := [w2468,w3766,w4276,w4716,w5135,w5585,w6101,w6389,w6522,w6588]
theorem b5_4023 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4023 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_4023 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4716,v3_5135,v3_5585,v3_6101,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4024 : List (BitVec 512) := [w2468,w3766,w4276,w4716,w5135,w5585,w6179,w6389,w6522,w6588]
theorem b5_4024 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4024 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s5_4024 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4716,v3_5135,v3_5585,v3_6179,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4025 : List (BitVec 512) := [w2468,w3766,w4278,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4025 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4278,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4278 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4026 : List (BitVec 512) := [w2468,w3766,w4279,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4026 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4279,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4279 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4029 : List (BitVec 512) := [w2468,w3766,w4287,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4029 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4287,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4287 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4030 : List (BitVec 512) := [w2468,w3766,w4292,w4344,w4716,w5135,w5585,w5956,w6389,w6588]
theorem b5_4030 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4030 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4030 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4031 : List (BitVec 512) := [w2468,w3766,w4292,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_4031 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4031 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4031 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4292,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4032 : List (BitVec 512) := [w2468,w3766,w4292,w4716,w5135,w5585,w5956,w6389,w6549,w6588]
theorem b5_4032 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4032 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s5_4032 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4292,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4033 : List (BitVec 512) := [w2468,w3766,w4296,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4033 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4296,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4296 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4034 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4034 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4035 : List (BitVec 512) := [w2468,w3766,w4298,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4035 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4035 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4035 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4298,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4298 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4036 : List (BitVec 512) := [w2468,w3766,w4299,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4036 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4299,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4299 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4037 : List (BitVec 512) := [w2468,w3766,w4303,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4037 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4037 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4037 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4303,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4038 : List (BitVec 512) := [w2468,w3766,w4306,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4038 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4038 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4038 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4306,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4306 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4039 : List (BitVec 512) := [w2468,w3766,w4312,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4039 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4039 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4039 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4312,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4312 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4040 : List (BitVec 512) := [w2468,w3766,w4316,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_4040 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4040 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4040 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_4041 : List (BitVec 512) := [w2468,w3766,w4316,w4716,w5135,w5585,w5956,w6300,w6588,w6748]
theorem b5_4041 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4041 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s5_4041 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_4042 : List (BitVec 512) := [w2468,w3766,w4316,w4716,w5135,w5585,w5956,w6300,w6690,w6720]
theorem b5_4042 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4042 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true))] s5_4042 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_4043 : List (BitVec 512) := [w2468,w3766,w4318,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4043 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4043 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4318,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4318 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4044 : List (BitVec 512) := [w2468,w3766,w4319,w4716,w5135,w5585,w5956,w6300,w6588,w6807]
theorem b5_4044 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4044 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s5_4044 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4319,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl)))))))))) (by decide +kernel)
def s5_4045 : List (BitVec 512) := [w2468,w3766,w4320,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4045 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4045 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4045 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4320,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4320 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4046 : List (BitVec 512) := [w2468,w3766,w4321,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4046 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4046 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_4046 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4321,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4321 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4047 : List (BitVec 512) := [w2468,w3766,w4341,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4047 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4341,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4341 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4048 : List (BitVec 512) := [w2468,w3766,w4342,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4048 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4048 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4048 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4342,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4342 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4049 : List (BitVec 512) := [w2468,w3766,w4344,w4366,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4049 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4049 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s5_4049 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4366,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4366 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4050 : List (BitVec 512) := [w2468,w3766,w4344,w4376,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4050 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4050 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_4050 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4376,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4376 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4052 : List (BitVec 512) := [w2468,w3766,w4344,w4382,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4052 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4052 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_4052 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4382,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4382 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4055 : List (BitVec 512) := [w2468,w3766,w4344,w4405,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_4055 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4055 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4055 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4056 : List (BitVec 512) := [w2468,w3766,w4344,w4415,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4056 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4056 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(8,true)),(false,(5,true),(1,true))] s5_4056 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4415,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4415 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4059 : List (BitVec 512) := [w2468,w3766,w4344,w4419,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4059 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4059 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(2,false),(0,false)),(false,(5,true),(1,true))] s5_4059 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4419,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4419 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4060 : List (BitVec 512) := [w2468,w3766,w4344,w4420,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4060 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4060 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(5,false),(0,false)),(false,(5,true),(1,true))] s5_4060 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4420,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4420 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4062 : List (BitVec 512) := [w2468,w3766,w4344,w4422,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4062 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4062 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(8,false)),(false,(5,true),(1,true))] s5_4062 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4422,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4422 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_4069 : List (BitVec 512) := [w2468,w3766,w4344,w4523,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4069 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4069 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_4069 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4523,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4523 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
