import NinePin30
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_8586 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6467,w6588]
theorem b4_8586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8586 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(1,true))] s4_8586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6467,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6467 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8593 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6852]
theorem b4_8593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8593 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6543,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8595 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_8595 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8595 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(2,true))] s4_8595 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6553,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6553 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8597 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_8597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8597 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(0,true))] s4_8597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6572,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6572 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8611 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6852]
theorem b4_8611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8611 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s4_8611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6748,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6748 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8612 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6852]
theorem b4_8612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8612 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true))] s4_8612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6807,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6807 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8613 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6857]
theorem b4_8613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8613 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s4_8613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6857] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6857 rfl))))))))))) (by decide +kernel)
def s4_8614 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6859]
theorem b4_8614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8614 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s4_8614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6859] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6859 rfl))))))))))) (by decide +kernel)
def s4_8615 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6866]
theorem b4_8615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8615 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(0,true))] s4_8615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6866] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6866 rfl))))))))))) (by decide +kernel)
def s4_8616 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6868]
theorem b4_8616 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8616 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(0,true))] s4_8616 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6868] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6868 rfl))))))))))) (by decide +kernel)
def s4_8617 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6890]
theorem b4_8617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8617 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s4_8617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6890] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6890 rfl))))))))))) (by decide +kernel)
def s4_8618 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6908]
theorem b4_8618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8618 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s4_8618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6908] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6908 rfl))))))))))) (by decide +kernel)
def s4_8619 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6910]
theorem b4_8619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8619 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(4,true))] s4_8619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852,v30_6910] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 (PetersenWireProjection.cons pc30_6910 rfl))))))))))) (by decide +kernel)
def s4_8625 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6852]
theorem b4_8625 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8625 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8625 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8626 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6201,w6300,w6588]
theorem b4_8626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8626 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6101,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8627 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_8627 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8627 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8627 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6101,v30_6300,v30_6543,v30_6588] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_8629 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8629 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8629 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8629 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6179,v30_6300,v30_6832] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6179 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6832 rfl)))))))))) (by decide +kernel)
def s4_8630 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6852]
theorem b4_8630 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8630 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8630 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6179,v30_6300,v30_6832,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6179 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6832 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8641 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_8641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8641 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5698,v30_5956,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5698 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_8642 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6852]
theorem b4_8642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8642 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5698,v30_5956,v30_6300,v30_6690,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5698 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_8643 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6690]
theorem b4_8643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8643 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(2,true))] s4_8643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5769,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5769 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8644 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6136,w6300,w6690]
theorem b4_8644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8644 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6136,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6136 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8645 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6690]
theorem b4_8645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8645 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6201,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8646 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6422,w6690]
theorem b4_8646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8646 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(1,true))] s4_8646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6422,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6422 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8647 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6464,w6690]
theorem b4_8647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8647 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(1,true))] s4_8647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6464,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6464 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8648 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6543,w6690]
theorem b4_8648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8648 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6543,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6543 (PetersenWireProjection.cons pc30_6690 rfl))))))))))) (by decide +kernel)
def s4_8649 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6748]
theorem b4_8649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8649 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s4_8649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690,v30_6748] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6748 rfl))))))))))) (by decide +kernel)
def s4_8650 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6807]
theorem b4_8650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8650 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true))] s4_8650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690,v30_6807] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6807 rfl))))))))))) (by decide +kernel)
def s4_8651 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6890]
theorem b4_8651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8651 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s4_8651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690,v30_6890] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6890 rfl))))))))))) (by decide +kernel)
def s4_8653 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b4_8653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8653 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6201,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_8655 : List (BitVec 512) := [w1353,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b4_8655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8655 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_8655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s4_9473 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6852]
theorem b4_9473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9473 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,false),(4,true))] s4_9473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1384,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1384 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_12858 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6136,w6300,w6588]
theorem b4_12858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12858 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_12858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6061,v30_6136,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6136 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_12862 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b4_12862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12862 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_12862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6061,v30_6201,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6201 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl))))))))))) (by decide +kernel)
def s4_12885 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588,w6852]
theorem b4_12885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12885 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s4_12885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6061,v30_6300,v30_6588,v30_6852] (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6852 rfl))))))))))) (by decide +kernel)
def s4_15117 : List (BitVec 512) := [w3766,w4170,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_15117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15117 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_15117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4170,v30_4344,v30_5135,v30_5393,v30_5585,v30_5956,v30_6101,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4170 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_15608 : List (BitVec 512) := [w3766,w4282,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_15608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15608 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s4_15608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4282,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6522,v30_6588] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s4_15609 : List (BitVec 512) := [w3766,w4282,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_15609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15609 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(4,true))] s4_15609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_3766,v30_4282,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6522,v30_6588,v30_6873] (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4282 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6522 (PetersenWireProjection.cons pc30_6588 (PetersenWireProjection.cons pc30_6873 rfl))))))))))) (by decide +kernel)
def s5_924 : List (BitVec 512) := [w631,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_924 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_631,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_631 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_926 : List (BitVec 512) := [w632,w1908,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_926 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_1908,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_1908 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_927 : List (BitVec 512) := [w632,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_927 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_927 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_927 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_928 : List (BitVec 512) := [w632,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6644]
theorem b5_928 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_928 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_928 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2681,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6300,v30_6644] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2681 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6644 rfl)))))))))) (by decide +kernel)
def s5_930 : List (BitVec 512) := [w632,w2681,w3766,w4344,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_930 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2681,v30_3766,v30_4344,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2681 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_931 : List (BitVec 512) := [w632,w2703,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_931 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_931 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_931 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_2703,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_2703 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_933 : List (BitVec 512) := [w632,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b5_933 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_933 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_933 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl))))))))) (by decide +kernel)
def s5_934 : List (BitVec 512) := [w632,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6720]
theorem b5_934 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_934 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true))] s5_934 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_632,v30_3766,v30_5135,v30_5393,v30_5585,v30_6061,v30_6101,v30_6300,v30_6690,v30_6720] (PetersenWireProjection.cons pc30_632 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6101 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 (PetersenWireProjection.cons pc30_6720 rfl)))))))))) (by decide +kernel)
def s5_1532 : List (BitVec 512) := [w992,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1532 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1532 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_1532 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_992,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_992 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_1627 : List (BitVec 512) := [w1067,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1627 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_1627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1067,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1067 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_2047 : List (BitVec 512) := [w1217,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2047 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_2047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1217,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1217 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_2672 : List (BitVec 512) := [w1352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2672 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2672 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [] s5_2672 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1352,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_5956,v30_6300,v30_6588] (PetersenWireProjection.cons pc30_1352 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6588 rfl)))))))))) (by decide +kernel)
def s5_2674 : List (BitVec 512) := [w1353,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6852]
theorem b5_2674 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2674 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s5_2674 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1910,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1910 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2675 : List (BitVec 512) := [w1353,w1910,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_2675 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2675 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true))] s5_2675 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1910,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1910 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2677 : List (BitVec 512) := [w1353,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6852]
theorem b5_2677 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2677 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true))] s5_2677 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1912,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1912 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2678 : List (BitVec 512) := [w1353,w1912,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_2678 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2678 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(0,true),(4,true))] s5_2678 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1912,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1912 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2680 : List (BitVec 512) := [w1353,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6852]
theorem b5_2680 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2680 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s5_2680 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1916,v30_3766,v30_4344,v30_4716,v30_5135,v30_5393,v30_5585,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1916 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2681 : List (BitVec 512) := [w1353,w1916,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_2681 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2681 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true))] s5_2681 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_1916,v30_3766,v30_4716,v30_5135,v30_5393,v30_5585,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_1916 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2683 : List (BitVec 512) := [w1353,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6852]
theorem b5_2683 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2683 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_2683 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2488,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2684 : List (BitVec 512) := [w1353,w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6690]
theorem b5_2684 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2684 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(6,true),(1,false))] s5_2684 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2488,v30_3766,v30_4716,v30_5135,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2488 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2686 : List (BitVec 512) := [w1353,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6852]
theorem b5_2686 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2686 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(1,true)),(false,(7,true),(0,true))] s5_2686 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2527,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2527 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2688 : List (BitVec 512) := [w1353,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6852]
theorem b5_2688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2688 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(1,true),(4,true)),(false,(7,true),(0,true))] s5_2688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2528,v30_3766,v30_4344,v30_4716,v30_5135,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2528 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5135 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2690 : List (BitVec 512) := [w1353,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6852]
theorem b5_2690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2690 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_2690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2683,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2683 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2691 : List (BitVec 512) := [w1353,w2683,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_2691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2691 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_2691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2683,v30_3766,v30_4716,v30_5393,v30_5585,v30_5956,v30_6061,v30_6300,v30_6690] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2683 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6061 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6690 rfl)))))))))) (by decide +kernel)
def s5_2694 : List (BitVec 512) := [w1353,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6852]
theorem b5_2694 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2694 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_2694 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2690,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2690 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
def s5_2696 : List (BitVec 512) := [w1353,w2691,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6852]
theorem b5_2696 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2696 := by
  intro m le c
  apply rejects_sound r30 i7 8 tgt (small30 adj) hot30 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_2696 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v30_1353,v30_2691,v30_3766,v30_4344,v30_4716,v30_5393,v30_5585,v30_5956,v30_6300,v30_6852] (PetersenWireProjection.cons pc30_1353 (PetersenWireProjection.cons pc30_2691 (PetersenWireProjection.cons pc30_3766 (PetersenWireProjection.cons pc30_4344 (PetersenWireProjection.cons pc30_4716 (PetersenWireProjection.cons pc30_5393 (PetersenWireProjection.cons pc30_5585 (PetersenWireProjection.cons pc30_5956 (PetersenWireProjection.cons pc30_6300 (PetersenWireProjection.cons pc30_6852 rfl)))))))))) (by decide +kernel)
end NineCert
