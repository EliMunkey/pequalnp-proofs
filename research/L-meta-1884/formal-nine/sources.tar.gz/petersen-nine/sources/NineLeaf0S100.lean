import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4579 : List (BitVec 512) := [w2488,w3766,w4344,w4814,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b5_4579 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4579 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(7,true))] s5_4579 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4814,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4597 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5585,w5956,w6377,w6389,w6588]
theorem b5_4597 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4597 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(4,true))] s5_4597 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4607 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6417,w6588]
theorem b5_4607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4607 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s5_4607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6417,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4609 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6377,w6389,w6588]
theorem b5_4609 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4609 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s5_4609 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4620 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6667,w6690]
theorem b5_4620 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4620 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(10,true))] s5_4620 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6667,v0_6690] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_4625 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w6048,w6061,w6300,w6588,w6690]
theorem b5_4625 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4625 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(10,true))] s5_4625 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_5135,v0_5585,v0_6048,v0_6061,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_4627 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5675,w5698,w5956,w6300,w6389,w6588]
theorem b5_4627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4627 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s5_4627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4716,v0_5135,v0_5675,v0_5698,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4630 : List (BitVec 512) := [w2488,w3766,w4814,w4926,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b5_4630 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4630 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(4,true))] s5_4630 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4814,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4633 : List (BitVec 512) := [w2492,w3545,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4633 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3545,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4634 : List (BitVec 512) := [w2492,w3642,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4634 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4634 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4634 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3642,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3642 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4635 : List (BitVec 512) := [w2492,w3664,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4635 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_4635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4636 : List (BitVec 512) := [w2492,w3684,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4636 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3684,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3684 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4642 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w4966,w5135,w5585,w5956,w6300,w6588]
theorem b5_4642 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4642 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4642 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4651 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6136,w6300,w6588]
theorem b5_4651 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4651 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4651 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4653 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6146,w6300,w6588]
theorem b5_4653 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4653 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4653 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4657 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6553,w6588]
theorem b5_4657 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4657 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4657 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6553,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6553 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4658 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6554,w6588]
theorem b5_4658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4658 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6554,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6554 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4662 : List (BitVec 512) := [w2492,w3766,w4344,w4814,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_4662 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4662 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4662 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2492,v0_3766,v0_4344,v0_4814,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2492 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4665 : List (BitVec 512) := [w2496,w3312,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4665 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4665 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4665 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3312,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3312 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4668 : List (BitVec 512) := [w2496,w3582,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4668 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4668 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4669 : List (BitVec 512) := [w2496,w3582,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_4669 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4669 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4669 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4670 : List (BitVec 512) := [w2496,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4670 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4670 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4670 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4671 : List (BitVec 512) := [w2496,w3644,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4671 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4671 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4671 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3644,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4672 : List (BitVec 512) := [w2496,w3644,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_4672 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4672 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4672 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3644,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4673 : List (BitVec 512) := [w2496,w3644,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4673 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4673 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4673 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3644,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4674 : List (BitVec 512) := [w2496,w3686,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4674 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4674 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4674 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3686,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4675 : List (BitVec 512) := [w2496,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_4675 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4675 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4675 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4676 : List (BitVec 512) := [w2496,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4676 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4676 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4676 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4691 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5730,w5956,w6300,w6588]
theorem b5_4691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4691 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5730,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4696 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_4696 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4696 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4698 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6206,w6300,w6588]
theorem b5_4698 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4698 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4698 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6206,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6206 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4702 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_4702 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_4702 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4703 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6573,w6588]
theorem b5_4703 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4703 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4703 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6573,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6573 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4708 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6377,w6478,w6588]
theorem b5_4708 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_4708 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6377,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4709 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5675,w5698,w5956,w6300,w6588]
theorem b5_4709 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4709 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_4709 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2496,v0_3766,v0_4344,v0_4716,v0_5135,v0_5675,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2496 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4713 : List (BitVec 512) := [w2497,w3595,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4713 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4713 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4713 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4714 : List (BitVec 512) := [w2497,w3647,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4714 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4714 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,false),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s5_4714 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3647,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3647 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4715 : List (BitVec 512) := [w2497,w3667,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4715 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4715 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4715 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3667,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3667 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4716 : List (BitVec 512) := [w2497,w3687,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4716 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4716 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4716 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4730 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5810,w5956,w6300,w6588]
theorem b5_4730 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4730 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4730 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4736 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6232,w6300,w6588]
theorem b5_4736 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4736 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,false),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s5_4736 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6232,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6232 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4740 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6496,w6588]
theorem b5_4740 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4740 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_4740 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6496,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6496 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4742 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6575,w6588]
theorem b5_4742 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4742 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,false),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s5_4742 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6575,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6575 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4743 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6576,w6588]
theorem b5_4743 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4743 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_4743 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2497,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6576,v0_6588] (PetersenWireProjection.cons pc0_2497 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6576 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4759 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_4759 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4759 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_4759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4760 : List (BitVec 512) := [w3335,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_4760 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4760 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_4760 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4761 : List (BitVec 512) := [w3335,w3766,w4463,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4761 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4761 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,false),(3,true)),(false,(0,true),(3,true))] s5_4761 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4463,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4463 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4762 : List (BitVec 512) := [w3335,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6888]
theorem b5_4762 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4762 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true))] s5_4762 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6888] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6888 rfl)))))))))) (by decide +kernel)
def s5_4763 : List (BitVec 512) := [w3336,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4763 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4763 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4763 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3336,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3336 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4764 : List (BitVec 512) := [w3337,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4764 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3337,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3337 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4765 : List (BitVec 512) := [w3340,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4765 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3340,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3340 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4766 : List (BitVec 512) := [w3340,w4344,w4348,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4766 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true)),(false,(0,true),(3,true))] s5_4766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3340,v0_4344,v0_4348,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3340 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4348 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4767 : List (BitVec 512) := [w3340,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4767 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3340,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3340 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4768 : List (BitVec 512) := [w3341,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_4768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4768 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(9,true),(3,true))] s5_4768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3341,v0_3935,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_3341 (PetersenWireProjection.cons pc0_3935 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_4769 : List (BitVec 512) := [w3341,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b5_4769 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4769 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true)),(false,(0,false),(1,false))] s5_4769 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3341,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_3341 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl)))))))))) (by decide +kernel)
def s5_4770 : List (BitVec 512) := [w3341,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b5_4770 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4770 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(7,true),(6,true)),(false,(9,true),(3,true))] s5_4770 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3341,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3341 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4771 : List (BitVec 512) := [w3341,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b5_4771 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4771 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(8,true),(7,true))] s5_4771 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3341,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3341 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_4772 : List (BitVec 512) := [w3342,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4772 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4772 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4772 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3342,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3342 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4773 : List (BitVec 512) := [w3345,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4773 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4773 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4773 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3345,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3345 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4774 : List (BitVec 512) := [w3349,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4774 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4774 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4774 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3349,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3349 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4775 : List (BitVec 512) := [w3351,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4775 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4775 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4775 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3351,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3351 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4776 : List (BitVec 512) := [w3353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4776 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4776 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4776 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4777 : List (BitVec 512) := [w3353,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4777 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4777 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4777 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3353,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3353 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4778 : List (BitVec 512) := [w3354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_4778 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4778 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_4778 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3354,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3354 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
