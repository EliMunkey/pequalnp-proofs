import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7669 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7669 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_7670 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7670 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7773 : List (BitVec 512) := [w1312,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7773 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7773 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7773 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7774 : List (BitVec 512) := [w1312,w3766,w4004,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7774 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7774 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7774 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4004,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7775 : List (BitVec 512) := [w1312,w3766,w4010,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7775 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4010,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4010 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7813 : List (BitVec 512) := [w1312,w3766,w4344,w4392,w4716,w5135,w5393,w5861,w5956,w6300,w6588]
theorem b4_7813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7813 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_7813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4392,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7820 : List (BitVec 512) := [w1312,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7820 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7842 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7842 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7843 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7843 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7844 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5012,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7844 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5012,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5012 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7845 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7845 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7846 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5014,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7846 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5014,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5014 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7847 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5020,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7847 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5020,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5020 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7848 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5029,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7848 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5029,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5029 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7849 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7849 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7850 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5034,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7850 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7851 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5044,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7851 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true))] s4_7851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5044,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5044 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7852 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5070,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7852 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5070,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5070 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7853 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7853 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7854 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_7854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7854 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7855 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6813]
theorem b4_7855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7855 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s4_7856 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5105,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7856 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5105,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5105 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7857 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7857 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7858 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7858 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_7859 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7859 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7860 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6720]
theorem b4_7860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7860 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_7861 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_7861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7861 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7862 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6785]
theorem b4_7862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7862 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl)))))))))) (by decide +kernel)
def s4_7863 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6785,w6813]
theorem b4_7863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7863 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7864 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5107,w5393,w5585,w5956,w6300,w6813]
theorem b4_7864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7864 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5107,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s4_7865 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5179,w5393,w5585,w5956,w6300,w6813]
theorem b4_7865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7865 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5179,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5179 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7867 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6813]
theorem b4_7867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7867 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7868 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5209,w5393,w5585,w5956,w6300,w6588]
theorem b4_7868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7868 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_7868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5209,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5209 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7869 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6813]
theorem b4_7869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7869 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7892 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6813]
theorem b4_7892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7892 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7923 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6813]
theorem b4_7923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7923 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7924 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5883,w5956,w6300,w6588]
theorem b4_7924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7924 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_7924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5883,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5883 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7961 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6813]
theorem b4_7961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7961 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7962 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6148,w6300,w6588]
theorem b4_7962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7962 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_7962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6148,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6148 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7963 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6153,w6300,w6588]
theorem b4_7963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7963 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s4_7963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6153,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7979 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6243,w6300,w6588]
theorem b4_7979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7979 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true))] s4_7979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7999 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6813]
theorem b4_7999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_8000 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6446,w6588]
theorem b4_8000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8000 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_8000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8018 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6555,w6588]
theorem b4_8018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8018 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_8018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6555,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8046 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6825]
theorem b4_8046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8046 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_8046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6825] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6825 rfl))))))))))) (by decide +kernel)
def s4_8052 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6763,w6813]
theorem b4_8052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8052 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_8052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6763,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6763 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_8056 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6825]
theorem b4_8056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8056 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_8056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6785,v1_6825] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6825 rfl))))))))))) (by decide +kernel)
def s4_8064 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6823]
theorem b4_8064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_8064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813,v1_6823] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6823 rfl))))))))))) (by decide +kernel)
def s4_8065 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6825]
theorem b4_8065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8065 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_8065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813,v1_6825] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6825 rfl))))))))))) (by decide +kernel)
def s4_8096 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5698,w5873,w5956,w6300,w6588]
theorem b4_8096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_8096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8098 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5769,w5863,w5956,w6300,w6588]
theorem b4_8098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8098 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_8098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5863,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8103 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5848,w5861,w5956,w6300,w6588]
theorem b4_8103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8103 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_8103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5848,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8104 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w5993,w6300,w6588]
theorem b4_8104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8104 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_8104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_5993,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_5993 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8105 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6061,w6300,w6588]
theorem b4_8105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8105 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s4_8105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8106 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6225,w6300,w6588]
theorem b4_8106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8106 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true))] s4_8106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8107 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6389,w6588]
theorem b4_8107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8107 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_8107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8108 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6522,w6588]
theorem b4_8108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8108 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_8108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8109 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6720,w6813]
theorem b4_8109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8109 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_8109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_8110 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6785,w6813]
theorem b4_8110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8110 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_8110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6785,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_8111 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5861,w5956,w6300,w6813]
theorem b4_8111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8111 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_8111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s4_8122 : List (BitVec 512) := [w1312,w3766,w4344,w4982,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8122 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8122 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8122 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4982,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8123 : List (BitVec 512) := [w1312,w3766,w4344,w4987,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8123 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_4987,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8124 : List (BitVec 512) := [w1312,w3766,w4344,w5002,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8124 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8124 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8124 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5002,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8125 : List (BitVec 512) := [w1312,w3766,w4344,w5013,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8125 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5013,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
end NineCert
