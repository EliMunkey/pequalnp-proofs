import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7884 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5370,w5393,w5585,w5956,w6300,w6720]
theorem b4_7884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7884 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_7884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5370,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5370 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_7885 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5370,w5393,w5585,w5956,w6300,w6785]
theorem b4_7885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7885 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_7885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5370,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5370 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_7886 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5370,w5393,w5585,w5956,w6300,w6813]
theorem b4_7886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7886 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5370,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5370 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7887 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5432,w5585,w5956,w6300,w6813]
theorem b4_7887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7887 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5432,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5432 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7889 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6813]
theorem b4_7889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7889 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7890 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5483,w5585,w5956,w6300,w6588]
theorem b4_7890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7890 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_7890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5483,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5483 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7891 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6813]
theorem b4_7891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7891 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7925 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6813]
theorem b4_7925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7925 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7926 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6588]
theorem b4_7926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7926 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(1,false))] s4_7926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7964 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6813]
theorem b4_7964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7964 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_7964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_7965 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6159,w6300,w6588]
theorem b4_7965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7965 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s4_7965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6159,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6159 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7966 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6162,w6300,w6588]
theorem b4_7966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7966 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(4,true))] s4_7966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6162,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6162 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_7980 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6249,w6300,w6588]
theorem b4_7980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7980 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(4,true))] s4_7980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6249,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6249 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8001 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6813]
theorem b4_8001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8001 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_8001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_8002 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6452,w6588]
theorem b4_8002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8002 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(5,true))] s4_8002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6452,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6452 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8019 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6559,w6588]
theorem b4_8019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8019 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_8019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8047 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6829]
theorem b4_8047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8047 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_8047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6829] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6829 rfl))))))))))) (by decide +kernel)
def s4_8053 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6782,w6813]
theorem b4_8053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8053 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_8053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6782,v2_6813] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_8057 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6829]
theorem b4_8057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8057 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_8057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785,v2_6829] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6829 rfl))))))))))) (by decide +kernel)
def s4_8066 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6827]
theorem b4_8066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8066 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_8066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813,v2_6827] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6827 rfl))))))))))) (by decide +kernel)
def s4_8067 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6829]
theorem b4_8067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8067 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_8067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6813,v2_6829] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6829 rfl))))))))))) (by decide +kernel)
def s4_8077 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6451,w6522,w6588]
theorem b4_8077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8077 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_8077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8084 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6300,w6522,w6588]
theorem b4_8084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8084 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true))] s4_8084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8134 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5251,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8134 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8134 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8134 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5251,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8135 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5268,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8135 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8135 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8135 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5268,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5268 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8136 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5283,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8136 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8136 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8136 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5283,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8137 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5299,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8137 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8137 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8137 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5299,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8138 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5337,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8138 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8138 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8138 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5337,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5337 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8139 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5362,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8139 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8139 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8139 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5362,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5362 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8140 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5432,w5585,w5769,w5956,w6300,w6720]
theorem b4_8140 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8140 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8140 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5432,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5432 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8142 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5479,w5585,w5769,w5956,w6300,w6720]
theorem b4_8142 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8142 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8142 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5479,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8162 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5884,w5956,w6300,w6720]
theorem b4_8162 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8162 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8162 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5884,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8163 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5894,w5956,w6300,w6720]
theorem b4_8163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8163 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8171 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6158,w6300,w6720]
theorem b4_8171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8171 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6158,v2_6300,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8182 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6451,w6720]
theorem b4_8182 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8182 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8182 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6451,v2_6720] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_8191 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6782]
theorem b4_8191 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8191 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(8,true),(9,true))] s4_8191 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6720,v2_6782] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6782 rfl))))))))))) (by decide +kernel)
def s4_8213 : List (BitVec 512) := [w1312,w3766,w4716,w5135,w5393,w5479,w5585,w5956,w6061,w6300,w6588]
theorem b4_8213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8213 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(4,true))] s4_8213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8214 : List (BitVec 512) := [w1312,w3766,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6389,w6588]
theorem b4_8214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8214 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(5,true))] s4_8214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8227 : List (BitVec 512) := [w1328,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8227 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8228 : List (BitVec 512) := [w1328,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8228 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8229 : List (BitVec 512) := [w1328,w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8229 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8231 : List (BitVec 512) := [w1328,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8231 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8232 : List (BitVec 512) := [w1328,w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8232 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_8232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8233 : List (BitVec 512) := [w1328,w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8233 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_8233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8234 : List (BitVec 512) := [w1328,w2352,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8234 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8235 : List (BitVec 512) := [w1328,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8235 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8236 : List (BitVec 512) := [w1328,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8236 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8237 : List (BitVec 512) := [w1328,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8237 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8298 : List (BitVec 512) := [w1328,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8298 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8309 : List (BitVec 512) := [w1328,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8309 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8320 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4887,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8320 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_4887,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4887 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8347 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b4_8347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8347 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8348 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5258,w5393,w5585,w5956,w6300,w6588]
theorem b4_8348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8348 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_8348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5258,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5258 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8349 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5268,w5393,w5585,w5956,w6300,w6588]
theorem b4_8349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8349 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_8349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5268,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5268 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8350 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5281,w5393,w5585,w5956,w6300,w6588]
theorem b4_8350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8350 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5281,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5281 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8351 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b4_8351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8351 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8352 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b4_8352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8352 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8353 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b4_8353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8353 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8354 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5336,w5393,w5585,w5956,w6300,w6588]
theorem b4_8354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8354 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5336,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5336 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8355 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5433,w5585,w5956,w6300,w6588]
theorem b4_8355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8355 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5433,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5433 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8357 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_8357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8357 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8358 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b4_8358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8358 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8359 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6588]
theorem b4_8359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8359 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_8404 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_8404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8404 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_8404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
