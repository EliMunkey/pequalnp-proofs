import NinePin40
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11771 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_11771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11771 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_11771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2381,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5956,v40_6300,v40_6389,v40_6588] (PetersenWireProjection.cons pc40_2381 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6389 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s4_11787 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_11787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11787 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_11787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2387,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5956,v40_6300,v40_6588,v40_6873] (PetersenWireProjection.cons pc40_2387 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 (PetersenWireProjection.cons pc40_6873 rfl)))))))))) (by decide +kernel)
def s4_12680 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4801,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12680 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_12680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_4801,v40_5135,v40_5585,v40_5956,v40_6300,v40_6389,v40_6588] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_4801 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6389 (PetersenWireProjection.cons pc40_6588 rfl))))))))))) (by decide +kernel)
def s4_12807 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5653,w5956,w6300,w6389,w6588]
theorem b4_12807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12807 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_12807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5653,v40_5956,v40_6300,v40_6389,v40_6588] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5653 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6389 (PetersenWireProjection.cons pc40_6588 rfl))))))))))) (by decide +kernel)
def s4_12935 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588,w6641]
theorem b4_12935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12935 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_12935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5956,v40_6300,v40_6389,v40_6588,v40_6641] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6389 (PetersenWireProjection.cons pc40_6588 (PetersenWireProjection.cons pc40_6641 rfl))))))))))) (by decide +kernel)
def s4_13095 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_13095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13095 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [] s4_13095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2497,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5956,v40_6300,v40_6422,v40_6588] (PetersenWireProjection.cons pc40_2497 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6422 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s5_3114 : List (BitVec 512) := [w1403,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3114 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3114 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [(false,(3,false),(5,true))] s5_3114 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_1403,v40_2496,v40_3766,v40_4344,v40_4716,v40_5135,v40_5585,v40_5956,v40_6300,v40_6588] (PetersenWireProjection.cons pc40_1403 (PetersenWireProjection.cons pc40_2496 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s5_4411 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5305,w5585,w5956,w6300,w6588]
theorem b5_4411 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4411 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [(false,(2,true),(3,true))] s5_4411 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_5135,v40_5305,v40_5585,v40_5956,v40_6300,v40_6588] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5305 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s5_4412 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5308,w5585,w5956,w6300,w6588]
theorem b5_4412 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4412 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [(false,(4,true),(3,true))] s5_4412 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_5135,v40_5308,v40_5585,v40_5956,v40_6300,v40_6588] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5308 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s5_4419 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5450,w5585,w5956,w6300,w6588]
theorem b5_4419 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4419 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [(false,(3,true),(5,true))] s5_4419 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2488,v40_3766,v40_4344,v40_4716,v40_5135,v40_5450,v40_5585,v40_5956,v40_6300,v40_6588] (PetersenWireProjection.cons pc40_2488 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5135 (PetersenWireProjection.cons pc40_5450 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 rfl)))))))))) (by decide +kernel)
def s6_80 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5187,w5585,w5956,w6300,w6588]
theorem b6_80 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_80 := by
  intro m le c
  apply rejects_sound r40 i7 8 tgt (small40 adj) hot40 [(false,(3,false),(5,true)),(false,(0,true),(2,true))] s6_80 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v40_2496,v40_3766,v40_4344,v40_4716,v40_5187,v40_5585,v40_5956,v40_6300,v40_6588] (PetersenWireProjection.cons pc40_2496 (PetersenWireProjection.cons pc40_3766 (PetersenWireProjection.cons pc40_4344 (PetersenWireProjection.cons pc40_4716 (PetersenWireProjection.cons pc40_5187 (PetersenWireProjection.cons pc40_5585 (PetersenWireProjection.cons pc40_5956 (PetersenWireProjection.cons pc40_6300 (PetersenWireProjection.cons pc40_6588 rfl))))))))) (by decide +kernel)
end NineCert
