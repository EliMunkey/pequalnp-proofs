import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5971 : List (BitVec 512) := [w1151,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5971 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true))] s4_5971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5972 : List (BitVec 512) := [w1151,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_5972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5972 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true))] s4_5972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5973 : List (BitVec 512) := [w1151,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_5973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5973 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true))] s4_5973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1151,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1151 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5974 : List (BitVec 512) := [w1153,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_5974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5974 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_5974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_1312,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_5975 : List (BitVec 512) := [w1153,w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_5975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5975 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_5975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_5976 : List (BitVec 512) := [w1153,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5976 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_5976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4392,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5977 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_5977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5977 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(2,true),(0,false))] s4_5977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5978 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_5978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5978 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_5978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_5993,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_5993 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5979 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_5979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5979 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true))] s4_5979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5980 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_5980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5980 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s4_5980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5981 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_5981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5981 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true))] s4_5981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5982 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_5982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5982 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true))] s4_5982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5983 : List (BitVec 512) := [w1153,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_5983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5983 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(2,true),(6,true))] s4_5983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1153,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1153 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5984 : List (BitVec 512) := [w1155,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5984 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_5984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5985 : List (BitVec 512) := [w1155,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true))] s4_5985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5986 : List (BitVec 512) := [w1155,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_5986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true))] s4_5986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5987 : List (BitVec 512) := [w1155,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5987 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true))] s4_5987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5988 : List (BitVec 512) := [w1155,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_5988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5988 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true))] s4_5988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5989 : List (BitVec 512) := [w1155,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5989 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_5989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1155,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1155 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_5990 : List (BitVec 512) := [w1156,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5990 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true))] s4_5990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1156,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1156 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5991 : List (BitVec 512) := [w1156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_5991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5991 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true))] s4_5991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1156,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1156 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5992 : List (BitVec 512) := [w1156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_5992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5992 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true))] s4_5992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1156,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_1156 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5993 : List (BitVec 512) := [w1158,w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5993 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_5993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1158,v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1158 (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5994 : List (BitVec 512) := [w1158,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5994 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_5994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1158,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1158 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_5995 : List (BitVec 512) := [w1159,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5995 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_5995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_5996 : List (BitVec 512) := [w1159,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_5996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_5996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_5997 : List (BitVec 512) := [w1159,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_5997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5997 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_5997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_5998 : List (BitVec 512) := [w1159,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5998 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_5998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4403,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_5999 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_5999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_4748,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4748 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6000 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6000 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true))] s4_6000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6001 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_6001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6001 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s4_6001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6002 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_6002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6002 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(3,true),(0,false))] s4_6002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6003 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_6003 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6003 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true))] s4_6003 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6004 : List (BitVec 512) := [w1159,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_6004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6004 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(7,true))] s4_6004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1159,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1159 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6005 : List (BitVec 512) := [w1161,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6005 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6006 : List (BitVec 512) := [w1161,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_6006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6006 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true))] s4_6006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6007 : List (BitVec 512) := [w1161,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_6007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6007 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true))] s4_6007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6008 : List (BitVec 512) := [w1161,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_6008 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6008 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true))] s4_6008 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6009 : List (BitVec 512) := [w1161,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_6009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6009 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s4_6009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6010 : List (BitVec 512) := [w1161,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6010 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6010 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_6010 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6011 : List (BitVec 512) := [w1162,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6011 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6011 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_6011 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1162,v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1162 (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6012 : List (BitVec 512) := [w1162,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_6012 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6012 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true))] s4_6012 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1162,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1162 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6013 : List (BitVec 512) := [w1162,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_6013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6013 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true))] s4_6013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1162,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1162 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6014 : List (BitVec 512) := [w1162,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_6014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6014 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s4_6014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1162,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1162 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6015 : List (BitVec 512) := [w1162,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6015 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6015 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_6015 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1162,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1162 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6016 : List (BitVec 512) := [w1164,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_6016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6016 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_6016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_6017 : List (BitVec 512) := [w1164,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_6017 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6017 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_6017 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6018 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_6018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6018 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_6018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5623,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5623 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6019 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_6019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6019 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true))] s4_6019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6020 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_6020 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true))] s4_6020 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6021 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_6021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(0,false))] s4_6021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6022 : List (BitVec 512) := [w1164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_6022 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6022 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s4_6022 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6023 : List (BitVec 512) := [w1166,w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6023 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6023 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_6023 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1166,v1_1411,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1166 (PetersenWireProjection.cons pc1_1411 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6024 : List (BitVec 512) := [w1166,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6024 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6024 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_6024 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1166,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1166 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6025 : List (BitVec 512) := [w1167,w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6025 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6025 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true))] s4_6025 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_1415,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_1415 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6026 : List (BitVec 512) := [w1167,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_6026 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6026 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true))] s4_6026 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6027 : List (BitVec 512) := [w1167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_6027 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6027 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true))] s4_6027 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6028 : List (BitVec 512) := [w1167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_6028 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6028 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true))] s4_6028 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6464,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6029 : List (BitVec 512) := [w1167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_6029 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6029 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true))] s4_6029 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6030 : List (BitVec 512) := [w1167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6030 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6030 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_6030 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6031 : List (BitVec 512) := [w1170,w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_6031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6031 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_6031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6032 : List (BitVec 512) := [w1170,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6032 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6032 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_6032 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6033 : List (BitVec 512) := [w1170,w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6033 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6033 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_6033 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1369,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1369 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6034 : List (BitVec 512) := [w1170,w1374,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b4_6034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6034 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_6034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_1374,v1_3766,v1_4344,v1_4403,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4403 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
end NineCert
