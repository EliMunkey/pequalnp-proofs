import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12185 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12185 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12185 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12185 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12186 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12186 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12186 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12186 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12187 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_12187 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12187 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_12187 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6640] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6640 rfl))))))))))) (by decide +kernel)
def s4_12188 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12188 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12188 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12188 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_12189 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12189 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12189 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12189 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_12190 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12190 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_12191 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12191 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12191 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12191 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_12192 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12192 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12192 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12192 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12193 : List (BitVec 512) := [w2468,w3766,w4179,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12193 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12194 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12194 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12195 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12195 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12196 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12196 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12197 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12197 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12197 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12197 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_12198 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12198 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12198 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12198 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_12199 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12199 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_12200 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12200 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12201 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6389,w6588]
theorem b4_12201 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12201 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12201 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12202 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12202 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12202 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12202 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_12203 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12203 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12204 : List (BitVec 512) := [w2468,w3766,w4276,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12204 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12204 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12204 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12205 : List (BitVec 512) := [w2468,w3766,w4276,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12205 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4276,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12206 : List (BitVec 512) := [w2468,w3766,w4292,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12206 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12206 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12206 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12207 : List (BitVec 512) := [w2468,w3766,w4292,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12207 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12207 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12207 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4292,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4292 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12208 : List (BitVec 512) := [w2468,w3766,w4294,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12208 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12208 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12208 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12209 : List (BitVec 512) := [w2468,w3766,w4294,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12209 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4294,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4294 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12210 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12210 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12210 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12210 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12211 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12211 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12211 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12211 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_4800,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4800 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12212 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12212 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12213 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12213 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12214 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12214 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12215 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6690]
theorem b4_12215 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12215 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12215 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_12216 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12216 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12217 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12217 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12217 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12217 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12218 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_12219 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b4_12219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_12220 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12221 : List (BitVec 512) := [w2468,w3766,w4297,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12221 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12222 : List (BitVec 512) := [w2468,w3766,w4311,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12222 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4311,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4311 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12223 : List (BitVec 512) := [w2468,w3766,w4311,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_12223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12223 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_12223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4311,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6640] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4311 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6640 rfl))))))))))) (by decide +kernel)
def s4_12224 : List (BitVec 512) := [w2468,w3766,w4316,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12225 : List (BitVec 512) := [w2468,w3766,w4316,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12225 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12226 : List (BitVec 512) := [w2468,w3766,w4316,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12226 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4316,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4316 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_12227 : List (BitVec 512) := [w2468,w3766,w4319,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12227 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4319,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12228 : List (BitVec 512) := [w2468,w3766,w4319,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12228 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4319,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12229 : List (BitVec 512) := [w2468,w3766,w4319,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12229 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4319,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4319 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_12230 : List (BitVec 512) := [w2468,w3766,w4327,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_12231 : List (BitVec 512) := [w2468,w3766,w4340,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12231 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4340,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4340 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_12232 : List (BitVec 512) := [w2468,w3766,w4340,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12232 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4340,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4340 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_12241 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12241 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12251 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12258 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12265 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12276 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12276 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_12284 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12284 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12284 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12284 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12332 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12339 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12347 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12347 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12351 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12351 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12406 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6061,w6300,w6588]
theorem b4_12406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12406 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12414 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6543,w6588]
theorem b4_12414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12414 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12419 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6389,w6522,w6588]
theorem b4_12419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12419 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12482 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6543,w6588]
theorem b4_12482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12482 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12486 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6389,w6522,w6588]
theorem b4_12486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12486 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6061,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12532 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6380,w6389,w6522,w6588]
theorem b4_12532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12532 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6380,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6380 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
