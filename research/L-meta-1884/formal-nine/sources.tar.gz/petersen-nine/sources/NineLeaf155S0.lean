import NinePin155
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7109 : List (BitVec 512) := [w1257,w2468,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_7109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7109 := by
  intro m le c
  apply rejects_sound r155 i7 6 tgt (small155 adj) hot155 [] s4_7109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v155_1257,v155_2468,v155_3766,v155_4344,v155_4716,v155_5135,v155_5585,v155_5652,v155_5956,v155_6300,v155_6588] (PetersenWireProjection.cons pc155_1257 (PetersenWireProjection.cons pc155_2468 (PetersenWireProjection.cons pc155_3766 (PetersenWireProjection.cons pc155_4344 (PetersenWireProjection.cons pc155_4716 (PetersenWireProjection.cons pc155_5135 (PetersenWireProjection.cons pc155_5585 (PetersenWireProjection.cons pc155_5652 (PetersenWireProjection.cons pc155_5956 (PetersenWireProjection.cons pc155_6300 (PetersenWireProjection.cons pc155_6588 rfl))))))))))) (by decide +kernel)
def s5_2272 : List (BitVec 512) := [w1257,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6796]
theorem b5_2272 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2272 := by
  intro m le c
  apply rejects_sound r155 i7 6 tgt (small155 adj) hot155 [] s5_2272 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v155_1257,v155_2468,v155_3766,v155_4344,v155_4716,v155_5135,v155_5585,v155_5956,v155_6300,v155_6796] (PetersenWireProjection.cons pc155_1257 (PetersenWireProjection.cons pc155_2468 (PetersenWireProjection.cons pc155_3766 (PetersenWireProjection.cons pc155_4344 (PetersenWireProjection.cons pc155_4716 (PetersenWireProjection.cons pc155_5135 (PetersenWireProjection.cons pc155_5585 (PetersenWireProjection.cons pc155_5956 (PetersenWireProjection.cons pc155_6300 (PetersenWireProjection.cons pc155_6796 rfl)))))))))) (by decide +kernel)
def s5_2275 : List (BitVec 512) := [w1257,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6640]
theorem b5_2275 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2275 := by
  intro m le c
  apply rejects_sound r155 i7 6 tgt (small155 adj) hot155 [] s5_2275 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v155_1257,v155_3766,v155_4344,v155_4716,v155_5135,v155_5585,v155_5652,v155_5956,v155_6300,v155_6640] (PetersenWireProjection.cons pc155_1257 (PetersenWireProjection.cons pc155_3766 (PetersenWireProjection.cons pc155_4344 (PetersenWireProjection.cons pc155_4716 (PetersenWireProjection.cons pc155_5135 (PetersenWireProjection.cons pc155_5585 (PetersenWireProjection.cons pc155_5652 (PetersenWireProjection.cons pc155_5956 (PetersenWireProjection.cons pc155_6300 (PetersenWireProjection.cons pc155_6640 rfl)))))))))) (by decide +kernel)
end NineCert
