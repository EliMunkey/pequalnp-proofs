import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3324 : List (BitVec 512) := [w847,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_3324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3324 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s4_3324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_847,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_847 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3325 : List (BitVec 512) := [w847,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_3325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3325 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_3325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_847,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_847 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3326 : List (BitVec 512) := [w847,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3326 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_3326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_847,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_847 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_3327 : List (BitVec 512) := [w849,w1422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3327 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_3327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_1422,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_1422 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3328 : List (BitVec 512) := [w849,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_3328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3328 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true))] s4_3328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3329 : List (BitVec 512) := [w849,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_3329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3329 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true))] s4_3329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3330 : List (BitVec 512) := [w849,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_3330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3330 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s4_3330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3331 : List (BitVec 512) := [w849,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_3331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3331 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s4_3331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3332 : List (BitVec 512) := [w849,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3332 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_3332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_3333 : List (BitVec 512) := [w852,w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3333 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_3333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1119,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1119 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3334 : List (BitVec 512) := [w852,w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_3334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3334 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(6,true),(7,true))] s4_3334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3335 : List (BitVec 512) := [w852,w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3335 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_3335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1328,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3336 : List (BitVec 512) := [w852,w1369,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3336 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_3336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1369,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1369 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3337 : List (BitVec 512) := [w852,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3337 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_3337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3338 : List (BitVec 512) := [w852,w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3338 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s4_3338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3339 : List (BitVec 512) := [w852,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_3339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3339 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_3339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3340 : List (BitVec 512) := [w852,w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_3340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3340 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_3340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1403,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3341 : List (BitVec 512) := [w852,w1403,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3341 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_3341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1403,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3342 : List (BitVec 512) := [w852,w1410,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3342 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true))] s4_3342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1410,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1410 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3343 : List (BitVec 512) := [w852,w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3343 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s4_3343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3344 : List (BitVec 512) := [w852,w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3344 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_3344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3345 : List (BitVec 512) := [w852,w1416,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3345 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_3345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1416,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1416 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3346 : List (BitVec 512) := [w852,w1418,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_3346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3346 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(7,true),(6,true))] s4_3346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1418,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1418 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3347 : List (BitVec 512) := [w852,w1419,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3347 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_3347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1419,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1419 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3348 : List (BitVec 512) := [w852,w1420,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3348 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_3348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1420,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1420 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3349 : List (BitVec 512) := [w852,w1422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3349 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s4_3349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1422,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1422 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3350 : List (BitVec 512) := [w852,w1618,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_3350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3350 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(6,true),(3,true))] s4_3350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1618,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1618 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3351 : List (BitVec 512) := [w852,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6489,w6588]
theorem b4_3351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3351 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(1,false),(8,true))] s4_3351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3352 : List (BitVec 512) := [w852,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_3352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3352 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(7,true),(8,true))] s4_3352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3353 : List (BitVec 512) := [w852,w1626,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b4_3353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3353 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(6,true),(8,true))] s4_3353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1626,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3354 : List (BitVec 512) := [w852,w1626,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6422,w6588]
theorem b4_3354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3354 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(3,true),(8,true))] s4_3354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1626,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1626 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3355 : List (BitVec 512) := [w852,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3355 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(8,true))] s4_3355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1635,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1635 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3356 : List (BitVec 512) := [w852,w1644,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_3356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(7,true),(3,true))] s4_3356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1644,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1644 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3357 : List (BitVec 512) := [w852,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6549,w6588]
theorem b4_3357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3357 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(1,false),(8,true))] s4_3357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1646,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1646 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3358 : List (BitVec 512) := [w852,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b4_3358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3358 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(7,true),(8,true))] s4_3358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1646,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1646 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3359 : List (BitVec 512) := [w852,w1649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3359 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(8,true))] s4_3359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3360 : List (BitVec 512) := [w852,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6588]
theorem b4_3360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(1,false),(8,true))] s4_3360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1650,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1650 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3361 : List (BitVec 512) := [w852,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b4_3361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3361 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(7,true),(8,true))] s4_3361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1650,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1650 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3362 : List (BitVec 512) := [w852,w1651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3362 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(8,true))] s4_3362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3363 : List (BitVec 512) := [w852,w1652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3363 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,false),(2,true)),(false,(8,true),(0,true))] s4_3363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1652,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1652 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3364 : List (BitVec 512) := [w852,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6890]
theorem b4_3364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3364 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(1,false),(8,true))] s4_3364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_3365 : List (BitVec 512) := [w852,w1664,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_3365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3365 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_3365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3366 : List (BitVec 512) := [w852,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_3366 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3366 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(2,true),(6,true))] s4_3366 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1664,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3367 : List (BitVec 512) := [w852,w1665,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_3367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3367 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(3,true),(6,true))] s4_3367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1665,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1665 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3368 : List (BitVec 512) := [w852,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3368 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true)),(false,(0,true),(8,true))] s4_3368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1666,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1666 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3369 : List (BitVec 512) := [w852,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3369 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(1,true)),(false,(0,true),(8,true))] s4_3369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3370 : List (BitVec 512) := [w852,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3370 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(8,true))] s4_3370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1670,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1670 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3371 : List (BitVec 512) := [w852,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_3371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3371 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(7,true),(6,true))] s4_3371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1672,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1672 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3372 : List (BitVec 512) := [w852,w1673,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3372 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(8,true)),(false,(8,true),(0,true))] s4_3372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1673,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1673 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3373 : List (BitVec 512) := [w852,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3373 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(0,true),(8,true))] s4_3373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1674,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1674 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3374 : List (BitVec 512) := [w852,w1676,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3374 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(8,true))] s4_3374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1676,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1676 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3375 : List (BitVec 512) := [w852,w1867,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_3375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3375 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(2,true),(9,true))] s4_3375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1867,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1867 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_3376 : List (BitVec 512) := [w852,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_3376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3376 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(1,false),(7,true))] s4_3376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1875,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1875 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3377 : List (BitVec 512) := [w852,w1875,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_3377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3377 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(6,true),(2,true))] s4_3377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1875,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1875 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3378 : List (BitVec 512) := [w852,w1875,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_3378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3378 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_3378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1875,v0_3766,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1875 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3379 : List (BitVec 512) := [w852,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3379 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(3,true),(9,true))] s4_3379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1875,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1875 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_3380 : List (BitVec 512) := [w852,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3380 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(7,true))] s4_3380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1883,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1883 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3381 : List (BitVec 512) := [w852,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6543,w6588]
theorem b4_3381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(1,false),(7,true))] s4_3381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1891,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1891 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3382 : List (BitVec 512) := [w852,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6389,w6522,w6588]
theorem b4_3382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3382 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(8,true),(7,true))] s4_3382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1891,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1891 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3383 : List (BitVec 512) := [w852,w1892,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b4_3383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3383 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(8,true),(2,true))] s4_3383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1892,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1892 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3384 : List (BitVec 512) := [w852,w1893,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3384 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(7,true))] s4_3384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1893,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1893 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3385 : List (BitVec 512) := [w852,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_3385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3385 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(8,true),(9,true))] s4_3385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1894,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1894 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_3386 : List (BitVec 512) := [w852,w1895,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3386 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(7,true))] s4_3386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1895,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1895 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_3387 : List (BitVec 512) := [w852,w1896,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3387 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(7,true),(0,true))] s4_3387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_1896,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_1896 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
