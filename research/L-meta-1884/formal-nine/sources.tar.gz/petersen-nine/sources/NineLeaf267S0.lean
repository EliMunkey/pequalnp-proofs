import NinePin267
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4079 : List (BitVec 512) := [w2468,w3766,w4344,w4566,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4079 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4079 := by
  intro m le c
  apply rejects_sound r267 i6 5 tgt (small267 adj) hot267 [] s5_4079 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v267_2468,v267_3766,v267_4344,v267_4566,v267_4716,v267_5135,v267_5585,v267_5956,v267_6300,v267_6588] (PetersenWireProjection.cons pc267_2468 (PetersenWireProjection.cons pc267_3766 (PetersenWireProjection.cons pc267_4344 (PetersenWireProjection.cons pc267_4566 (PetersenWireProjection.cons pc267_4716 (PetersenWireProjection.cons pc267_5135 (PetersenWireProjection.cons pc267_5585 (PetersenWireProjection.cons pc267_5956 (PetersenWireProjection.cons pc267_6300 (PetersenWireProjection.cons pc267_6588 rfl)))))))))) (by decide +kernel)
end NineCert
