import NinePin47
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4224 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6517,w6522,w6873]
theorem b5_4224 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4224 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_4224 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_5585,v47_5956,v47_6517,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6517 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
def s5_5431 : List (BitVec 512) := [w3766,w4283,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5431 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5431 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_5431 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4283,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4283 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_5432 : List (BitVec 512) := [w3766,w4284,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_5432 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5432 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_5432 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4284,v47_4344,v47_4716,v47_5135,v47_5393,v47_6179,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4284 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_5433 : List (BitVec 512) := [w3766,w4285,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_5433 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5433 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_5433 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4285,v47_4344,v47_5135,v47_5393,v47_5585,v47_6101,v47_6300,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4285 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_5434 : List (BitVec 512) := [w3766,w4286,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5434 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5434 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_5434 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4286,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4286 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_5642 : List (BitVec 512) := [w3766,w4344,w4558,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5642 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5642 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_5642 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4558,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6300,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4558 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6300 (PetersenWireProjection.cons pc47_6588 rfl)))))))))) (by decide +kernel)
def s5_6053 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6518,w6522,w6873]
theorem b5_6053 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6053 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6053 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5956,v47_6518,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5956 (PetersenWireProjection.cons pc47_6518 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
def s5_6066 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5968,w6522,w6588]
theorem b5_6066 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6066 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6066 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5968,v47_6522,v47_6588] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5968 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 rfl))))))))) (by decide +kernel)
def s5_6067 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5968,w6522,w6588,w6890]
theorem b5_6067 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6067 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [(false,(3,true),(5,true))] s5_6067 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_5968,v47_6522,v47_6588,v47_6890] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_5968 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6588 (PetersenWireProjection.cons pc47_6890 rfl)))))))))) (by decide +kernel)
def s5_6107 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6517,w6522,w6873]
theorem b5_6107 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6107 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6107 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_6101,v47_6517,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6517 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
def s5_6126 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6516,w6522,w6873]
theorem b5_6126 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6126 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6126 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_5585,v47_6179,v47_6516,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6516 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl)))))))))) (by decide +kernel)
def s5_6164 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6517,w6522,w6873]
theorem b5_6164 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6164 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6164 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_4716,v47_5135,v47_5393,v47_6179,v47_6517,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6517 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl))))))))) (by decide +kernel)
def s5_6253 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6516,w6522,w6873]
theorem b5_6253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6253 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s5_6253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_3766,v47_4344,v47_5135,v47_5393,v47_5585,v47_6101,v47_6516,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5393 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6516 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl))))))))) (by decide +kernel)
def s6_64 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w6179,w6517,w6522,w6873]
theorem b6_64 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_64 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s6_64 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_4716,v47_5135,v47_6179,v47_6517,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_4716 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_6179 (PetersenWireProjection.cons pc47_6517 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl))))))))) (by decide +kernel)
def s6_69 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5585,w6101,w6516,w6522,w6873]
theorem b6_69 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_69 := by
  intro m le c
  apply rejects_sound r47 i6 7 tgt (small47 adj) hot47 [] s6_69 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v47_2468,v47_3766,v47_4344,v47_5135,v47_5585,v47_6101,v47_6516,v47_6522,v47_6873] (PetersenWireProjection.cons pc47_2468 (PetersenWireProjection.cons pc47_3766 (PetersenWireProjection.cons pc47_4344 (PetersenWireProjection.cons pc47_5135 (PetersenWireProjection.cons pc47_5585 (PetersenWireProjection.cons pc47_6101 (PetersenWireProjection.cons pc47_6516 (PetersenWireProjection.cons pc47_6522 (PetersenWireProjection.cons pc47_6873 rfl))))))))) (by decide +kernel)
end NineCert
