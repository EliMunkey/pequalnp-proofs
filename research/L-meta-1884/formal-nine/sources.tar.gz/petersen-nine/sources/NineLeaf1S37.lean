import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_766 : List (BitVec 512) := [w515,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_766 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_515,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_515 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_767 : List (BitVec 512) := [w516,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_767 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_516,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_516 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_768 : List (BitVec 512) := [w517,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_768 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_517,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_517 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_769 : List (BitVec 512) := [w518,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_769 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_769 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_769 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_518,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_518 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_770 : List (BitVec 512) := [w519,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_770 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_770 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_770 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_519,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_519 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_771 : List (BitVec 512) := [w520,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_771 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_771 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_771 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_520,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_520 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_783 : List (BitVec 512) := [w523,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_783 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_783 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_783 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_523,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_523 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_784 : List (BitVec 512) := [w524,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_784 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_784 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_784 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_524,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_524 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_785 : List (BitVec 512) := [w525,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_785 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_785 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_785 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_525,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_525 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_786 : List (BitVec 512) := [w526,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_786 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_786 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(6,true))] s5_786 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_526,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_526 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_787 : List (BitVec 512) := [w527,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_787 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_787 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_787 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_527,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_527 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_788 : List (BitVec 512) := [w528,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_788 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_788 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_788 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_528,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_528 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_789 : List (BitVec 512) := [w529,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_789 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_789 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_789 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_529,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_529 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_790 : List (BitVec 512) := [w530,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_790 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_790 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_790 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_530,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_530 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_791 : List (BitVec 512) := [w531,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_791 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_791 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_791 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_531,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_531 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_792 : List (BitVec 512) := [w532,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_792 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_792 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_792 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_532,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_532 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_793 : List (BitVec 512) := [w533,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_793 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_793 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_793 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_533,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_533 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_794 : List (BitVec 512) := [w534,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_794 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_794 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_794 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_534,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_534 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_795 : List (BitVec 512) := [w535,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_795 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_795 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_795 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_535,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_535 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_796 : List (BitVec 512) := [w536,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_796 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_796 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_796 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_536,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_536 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_797 : List (BitVec 512) := [w537,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_797 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_797 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_797 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_537,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_537 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_798 : List (BitVec 512) := [w538,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_798 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_798 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_798 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_538,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_538 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_799 : List (BitVec 512) := [w539,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_799 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_799 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_799 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_539,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_539 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_800 : List (BitVec 512) := [w540,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_800 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_800 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true)),(false,(7,true),(0,true))] s5_800 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_801 : List (BitVec 512) := [w540,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_801 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_801 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_801 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_3197,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_3197 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_802 : List (BitVec 512) := [w540,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_802 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_802 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false)),(false,(3,true),(0,true))] s5_802 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_803 : List (BitVec 512) := [w540,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_803 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_803 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(4,true),(8,true)),(false,(6,true),(1,true))] s5_803 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_804 : List (BitVec 512) := [w540,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_804 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_804 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true)),(false,(5,true),(6,true))] s5_804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_805 : List (BitVec 512) := [w540,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_805 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_805 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true)),(false,(5,true),(6,true))] s5_805 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_540,v1_3766,v1_4344,v1_5135,v1_5393,v1_5698,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_540 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_806 : List (BitVec 512) := [w541,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_806 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_806 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s5_806 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_541,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_541 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_807 : List (BitVec 512) := [w541,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_807 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_807 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_807 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_541,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_541 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_808 : List (BitVec 512) := [w541,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_808 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_808 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_808 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_541,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_541 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_809 : List (BitVec 512) := [w544,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_809 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_809 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true)),(false,(7,true),(0,true))] s5_809 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_544,v1_2443,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_544 (PetersenWireProjection.cons pc1_2443 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_810 : List (BitVec 512) := [w544,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_810 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_810 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(1,false)),(false,(7,true),(0,true))] s5_810 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_544,v1_2494,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_544 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_811 : List (BitVec 512) := [w544,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_811 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_811 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(5,true),(6,true))] s5_811 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_544,v1_3766,v1_4344,v1_4748,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_544 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4748 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_812 : List (BitVec 512) := [w544,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_812 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_812 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true)),(false,(5,true),(2,false))] s5_812 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_544,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_544 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_813 : List (BitVec 512) := [w545,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_813 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_813 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s5_813 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_545,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_545 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_814 : List (BitVec 512) := [w545,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_814 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_814 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_814 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_545,v1_3293,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_545 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_815 : List (BitVec 512) := [w545,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_815 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_815 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(5,true),(6,true))] s5_815 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_545,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_545 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_816 : List (BitVec 512) := [w546,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_816 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_816 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_816 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_546,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_546 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_817 : List (BitVec 512) := [w546,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_817 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_817 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(6,true))] s5_817 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_546,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_546 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s5_818 : List (BitVec 512) := [w547,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_818 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_818 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(1,false),(0,false)),(false,(0,true),(6,true))] s5_818 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_547,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_547 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_819 : List (BitVec 512) := [w548,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_819 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_819 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(1,false)),(false,(7,true),(0,true))] s5_819 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_548,v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_548 (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_820 : List (BitVec 512) := [w550,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_820 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_820 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s5_820 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_550,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_550 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_821 : List (BitVec 512) := [w550,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_821 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_821 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s5_821 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_550,v1_3303,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_550 (PetersenWireProjection.cons pc1_3303 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_822 : List (BitVec 512) := [w551,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_822 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_822 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(3,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_822 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_551,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_551 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_823 : List (BitVec 512) := [w552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_823 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_823 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_823 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_552,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_552 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_828 : List (BitVec 512) := [w570,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_828 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_828 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s5_828 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_570,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_570 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_846 : List (BitVec 512) := [w583,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_846 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_846 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_846 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_583,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_583 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_847 : List (BitVec 512) := [w584,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_847 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_847 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_847 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_584,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_584 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_848 : List (BitVec 512) := [w585,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_848 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_848 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_848 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_585,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_585 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_900 : List (BitVec 512) := [w608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_900 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_900 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_900 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_901 : List (BitVec 512) := [w609,w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_901 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_901 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s5_901 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_609,v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_609 (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_902 : List (BitVec 512) := [w609,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_902 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_902 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s5_902 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_609,v1_2488,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_609 (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_903 : List (BitVec 512) := [w609,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_903 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_903 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(0,false)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_903 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_609,v1_2529,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_609 (PetersenWireProjection.cons pc1_2529 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_904 : List (BitVec 512) := [w609,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_904 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_904 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_904 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_609,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_609 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_905 : List (BitVec 512) := [w609,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_905 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_905 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_905 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_609,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6464,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_609 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_958 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5099,w5393,w5585,w5956,w6300,w6588]
theorem b5_958 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_958 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(0,false),(5,true))] s5_958 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_637,v1_3766,v1_4344,v1_4716,v1_5099,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_637 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5099 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1118 : List (BitVec 512) := [w884,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1118 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1118 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1118 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_884,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_884 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1119 : List (BitVec 512) := [w885,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1119 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1119 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1119 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_885,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_885 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1120 : List (BitVec 512) := [w887,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1120 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1120 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1120 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_887,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_887 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1121 : List (BitVec 512) := [w890,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1121 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1121 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1121 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_890,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_890 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1122 : List (BitVec 512) := [w891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1122 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1122 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1122 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_891,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_891 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_1123 : List (BitVec 512) := [w892,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1123 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1123 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_1123 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_892,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_892 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
end NineCert
