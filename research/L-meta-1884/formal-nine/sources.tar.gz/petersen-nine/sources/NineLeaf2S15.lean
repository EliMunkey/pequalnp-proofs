import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_2445 : List (BitVec 512) := [w491,w1403,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2445 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_2445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_1403,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2446 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_2446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2446 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_2446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5623,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5623 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2447 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2447 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_2447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2448 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_2448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2448 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_2448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_5995,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_5995 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2449 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_2449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2449 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_2449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2450 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_2450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2450 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true))] s4_2450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2451 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_2451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2451 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(1,false))] s4_2451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2452 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_2452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2452 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(1,false))] s4_2452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2453 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873,w6890]
theorem b4_2453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2453 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_2453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6873,v2_6890] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6873 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_2454 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_2454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2454 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_2454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2455 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_2455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2455 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_2455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2456 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_2456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2456 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_2456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2457 : List (BitVec 512) := [w491,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_2457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2457 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true))] s4_2457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2458 : List (BitVec 512) := [w492,w1410,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2458 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_2458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_1410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_1410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2459 : List (BitVec 512) := [w492,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2459 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(3,true))] s4_2459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2460 : List (BitVec 512) := [w492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_2460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2460 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(4,true),(3,true))] s4_2460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2461 : List (BitVec 512) := [w492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_2461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2461 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true))] s4_2461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2462 : List (BitVec 512) := [w493,w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2462 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_2462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_493,v2_1411,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_493 (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2463 : List (BitVec 512) := [w493,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2463 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_2463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_493,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_493 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2464 : List (BitVec 512) := [w494,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2464 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(3,true))] s4_2464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_494,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2465 : List (BitVec 512) := [w494,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_2465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2465 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(4,true),(3,true))] s4_2465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2466 : List (BitVec 512) := [w494,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_2466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2466 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true))] s4_2466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2467 : List (BitVec 512) := [w495,w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2467 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_2467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2468 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2468 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_2468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2469 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_2469 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2469 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_2469 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2470 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_2470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2470 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_2470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2471 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_2471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2471 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_2471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2472 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2472 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_2472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2473 : List (BitVec 512) := [w496,w1416,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2473 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_2473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_496,v2_1416,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_496 (PetersenWireProjection.cons pc2_1416 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2474 : List (BitVec 512) := [w496,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2474 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true))] s4_2474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2475 : List (BitVec 512) := [w498,w1418,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_2475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2475 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(4,true),(7,true))] s4_2475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_1418,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_1418 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2508 : List (BitVec 512) := [w498,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2508 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(3,true))] s4_2508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2509 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2509 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true))] s4_2509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2510 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2510 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(8,true),(7,true))] s4_2510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2512 : List (BitVec 512) := [w499,w1419,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2512 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_2512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_1419,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_1419 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2517 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_2517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2517 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_2517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2518 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_2518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2518 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(0,true),(9,true))] s4_2518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2519 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_2519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2519 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_2519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2520 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_2520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2520 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_2520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2521 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2521 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s4_2521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2522 : List (BitVec 512) := [w500,w1420,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2522 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_1420,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_1420 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2527 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_2527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2527 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_2527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2528 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_2528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2528 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2529 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_2529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2529 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_2529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2530 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_2530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2530 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2531 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2531 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2532 : List (BitVec 512) := [w502,w1422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2532 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_1422,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_1422 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2537 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_2537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2537 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_2537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2538 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_2538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2538 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2539 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_2539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2539 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_2539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2540 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_2540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2540 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2541 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2541 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_2541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_2873 : List (BitVec 512) := [w628,w2513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_2873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_628,v2_2513,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_628 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2892 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5362,w5393,w5585,w5956,w6300,w6588]
theorem b4_2892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2892 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_2892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_628,v2_3766,v2_4344,v2_4716,v2_5135,v2_5362,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_628 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5362 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2906 : List (BitVec 512) := [w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6782]
theorem b4_2906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2906 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_2906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_628,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6782] (PetersenWireProjection.cons pc2_628 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6782 rfl))))))))))) (by decide +kernel)
def s4_2927 : List (BitVec 512) := [w632,w2513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2927 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_2927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_632,v2_2513,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_632 (PetersenWireProjection.cons pc2_2513 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2982 : List (BitVec 512) := [w635,w1609,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2982 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_2982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_1609,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_1609 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_2994 : List (BitVec 512) := [w635,w1850,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2994 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_2994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_1850,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_1850 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3000 : List (BitVec 512) := [w635,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3000 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3001 : List (BitVec 512) := [w635,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3001 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3003 : List (BitVec 512) := [w635,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3003 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3003 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3003 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3004 : List (BitVec 512) := [w635,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3004 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3005 : List (BitVec 512) := [w635,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3005 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_3006 : List (BitVec 512) := [w635,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3006 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true))] s4_3006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_635,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_635 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
