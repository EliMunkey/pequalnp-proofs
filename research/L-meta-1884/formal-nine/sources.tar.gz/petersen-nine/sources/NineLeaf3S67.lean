import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_15739 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_15739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15739 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_15739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15740 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_15740 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15740 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(7,true),(6,true))] s4_15740 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_15741 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_15741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15741 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(8,true),(7,true))] s4_15741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15742 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_15742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15742 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_15742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15743 : List (BitVec 512) := [w3766,w4327,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_15743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15743 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(8,true),(6,true))] s4_15743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15744 : List (BitVec 512) := [w3766,w4327,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15744 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_15744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15745 : List (BitVec 512) := [w3766,w4327,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_15745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15745 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s4_15745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4519,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4519 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15746 : List (BitVec 512) := [w3766,w4327,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15746 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_15746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4571,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4571 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15747 : List (BitVec 512) := [w3766,w4327,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_15747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15747 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s4_15747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4571,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4571 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15748 : List (BitVec 512) := [w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6890]
theorem b4_15748 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15748 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s4_15748 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15749 : List (BitVec 512) := [w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873,w6890]
theorem b4_15749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15749 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(8,true))] s4_15749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15750 : List (BitVec 512) := [w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873,w6890]
theorem b4_15750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15750 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(5,true))] s4_15750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15751 : List (BitVec 512) := [w3766,w4329,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15751 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4329,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4329 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15752 : List (BitVec 512) := [w3766,w4329,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_15752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15752 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_15752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4329,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4329 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15753 : List (BitVec 512) := [w3766,w4330,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15753 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15753 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15753 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4330,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4330 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15754 : List (BitVec 512) := [w3766,w4330,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_15754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15754 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_15754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4330,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4330 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15755 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_15755 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15755 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15755 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15756 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_15756 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15756 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15756 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15757 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_15757 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15757 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15757 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15758 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_15758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15758 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_15758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15759 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_15759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15759 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(5,true))] s4_15759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15760 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_15760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15760 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s4_15760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15761 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15761 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15761 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15761 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15762 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_15762 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15762 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15762 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_15763 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_15763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15763 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(5,true))] s4_15763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_15764 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_15764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15764 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(6,true))] s4_15764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_15765 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_15765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15765 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_15765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15766 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_15766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15766 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15767 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_15767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15767 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6897 rfl))))))))))) (by decide +kernel)
def s4_15768 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_15768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15768 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s4_15768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
def s4_15769 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_15769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15769 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,false),(6,true))] s4_15769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6906] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6906 rfl))))))))))) (by decide +kernel)
def s4_15770 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_15770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15770 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(6,true))] s4_15770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_15771 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_15771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15771 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,false),(7,true))] s4_15771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6912] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6912 rfl))))))))))) (by decide +kernel)
def s4_15772 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_15772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15772 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15773 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_15773 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15773 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(8,true),(5,true))] s4_15773 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15774 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_15774 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15774 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_15774 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15775 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_15775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15775 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(7,true),(5,true))] s4_15775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15776 : List (BitVec 512) := [w3766,w4336,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_15776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15776 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(7,true),(6,true))] s4_15776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_15777 : List (BitVec 512) := [w3766,w4336,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_15777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15777 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s4_15777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15778 : List (BitVec 512) := [w3766,w4336,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_15778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15778 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(5,true))] s4_15778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15779 : List (BitVec 512) := [w3766,w4336,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_15779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15779 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(3,true),(1,false))] s4_15779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15780 : List (BitVec 512) := [w3766,w4336,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6720]
theorem b4_15780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15780 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(2,true),(6,true))] s4_15780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15781 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_15781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15781 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_15781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15782 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588,w6895]
theorem b4_15782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15782 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15783 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_15783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15783 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s4_15784 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748,w6895]
theorem b4_15784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15784 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(7,true))] s4_15784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15785 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_15785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15785 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_15785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl)))))))))) (by decide +kernel)
def s4_15786 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890,w6895]
theorem b4_15786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15786 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s4_15786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15787 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895,w6897]
theorem b4_15787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15787 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 (PetersenWireProjection.cons pc3_6897 rfl))))))))))) (by decide +kernel)
def s4_15788 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_15788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15788 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6897 rfl)))))))))) (by decide +kernel)
def s4_15789 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_15789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15789 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s4_15790 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6895]
theorem b4_15790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15790 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false))] s4_15790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15791 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_15791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15791 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s4_15791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15792 : List (BitVec 512) := [w3766,w4336,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588,w6895]
theorem b4_15792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15792 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s4_15792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4336,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4336 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15793 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15793 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15794 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_15794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15794 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s4_15794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15795 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_15795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15795 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s4_15795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15796 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_15796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15796 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(2,true))] s4_15796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15797 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_15797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15797 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s4_15797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15798 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_15798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15798 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_15798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_15799 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_15799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15799 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s4_15799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_15800 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_15800 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15800 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s4_15800 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6905] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6905 rfl))))))))))) (by decide +kernel)
def s4_15801 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_15801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15801 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true)),(false,(0,false),(3,true))] s4_15801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6906] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6906 rfl))))))))))) (by decide +kernel)
def s4_15802 : List (BitVec 512) := [w3766,w4338,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_15802 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15802 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(8,true))] s4_15802 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4338,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
end NineCert
