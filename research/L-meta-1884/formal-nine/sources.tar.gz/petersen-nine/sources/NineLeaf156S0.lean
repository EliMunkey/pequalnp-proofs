import NinePin156
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12242 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w4964,w5135,w5585,w5956,w6300,w6588]
theorem b4_12242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12242 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s4_12242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_3766,v156_4344,v156_4583,v156_4716,v156_4964,v156_5135,v156_5585,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4583 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_4964 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl))))))))))) (by decide +kernel)
def s4_12252 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5725,w5956,w6300,w6588]
theorem b4_12252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12252 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s4_12252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_3766,v156_4344,v156_4583,v156_4716,v156_5135,v156_5585,v156_5725,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4583 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5725 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl))))))))))) (by decide +kernel)
def s4_12277 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588,w6708]
theorem b4_12277 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12277 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s4_12277 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_3766,v156_4344,v156_4583,v156_4716,v156_5135,v156_5585,v156_5956,v156_6300,v156_6588,v156_6708] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4583 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 (PetersenWireProjection.cons pc156_6708 rfl))))))))))) (by decide +kernel)
def s5_3838 : List (BitVec 512) := [w2468,w2474,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3838 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3838 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_3838 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_2474,v156_3766,v156_4344,v156_4716,v156_5135,v156_5585,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_2474 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
def s5_3840 : List (BitVec 512) := [w2468,w2476,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3840 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3840 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_3840 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_2476,v156_3766,v156_4344,v156_4716,v156_5135,v156_5585,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_2476 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
def s5_3841 : List (BitVec 512) := [w2468,w2477,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3841 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3841 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_3841 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_2477,v156_3766,v156_4344,v156_4716,v156_5135,v156_5585,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_2477 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
def s5_3892 : List (BitVec 512) := [w2468,w2682,w3766,w4344,w4716,w5585,w5956,w6300,w6588,w6736]
theorem b5_3892 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3892 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_3892 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_2682,v156_3766,v156_4344,v156_4716,v156_5585,v156_5956,v156_6300,v156_6588,v156_6736] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_2682 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 (PetersenWireProjection.cons pc156_6736 rfl)))))))))) (by decide +kernel)
def s5_4110 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5282,w5585,w5956,w6300,w6588]
theorem b5_4110 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4110 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_4110 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_3766,v156_4344,v156_4716,v156_5135,v156_5282,v156_5585,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5282 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
def s5_4146 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5858,w5956,w6300,w6588]
theorem b5_4146 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4146 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_4146 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_2468,v156_3766,v156_4344,v156_4716,v156_5135,v156_5585,v156_5858,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_2468 (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5858 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
def s5_5665 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5585,w5802,w5956,w6300,w6588]
theorem b5_5665 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5665 := by
  intro m le c
  apply rejects_sound r156 i7 6 tgt (small156 adj) hot156 [] s5_5665 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v156_3766,v156_4344,v156_4583,v156_4716,v156_5135,v156_5585,v156_5802,v156_5956,v156_6300,v156_6588] (PetersenWireProjection.cons pc156_3766 (PetersenWireProjection.cons pc156_4344 (PetersenWireProjection.cons pc156_4583 (PetersenWireProjection.cons pc156_4716 (PetersenWireProjection.cons pc156_5135 (PetersenWireProjection.cons pc156_5585 (PetersenWireProjection.cons pc156_5802 (PetersenWireProjection.cons pc156_5956 (PetersenWireProjection.cons pc156_6300 (PetersenWireProjection.cons pc156_6588 rfl)))))))))) (by decide +kernel)
end NineCert
