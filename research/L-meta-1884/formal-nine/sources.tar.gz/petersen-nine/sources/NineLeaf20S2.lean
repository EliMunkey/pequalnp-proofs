import NinePin20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_6185 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5465,w5585,w5956,w6300,w6588]
theorem b5_6185 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6185 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_6185 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5465,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5465 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_6186 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5466,w5585,w5956,w6300,w6588]
theorem b5_6186 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6186 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_6186 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5466,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5466 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_6193 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5899,w5956,w6300,w6588]
theorem b5_6193 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6193 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_6193 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5585,v20_5899,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5899 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_6225 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6248,w6300,w6588]
theorem b5_6225 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6225 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(2,true))] s5_6225 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5769,v20_5956,v20_6248,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5769 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6248 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_6226 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5585,w5891,w5956,w6522,w6588]
theorem b5_6226 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6226 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true))] s5_6226 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5891,v20_5956,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5891 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s6_8 : List (BitVec 512) := [w428,w2468,w3766,w4344,w5135,w5585,w6101,w6522,w6873]
theorem b6_8 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_8 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(7,true)),(false,(6,true),(8,true)),(false,(4,true),(8,true))] s6_8 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_3766,v20_4344,v20_5135,v20_5585,v20_6101,v20_6522,v20_6873] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_6101 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6873 rfl))))))))) (by decide +kernel)
def s6_43 : List (BitVec 512) := [w2299,w2468,w3766,w5135,w5585,w6101,w6389,w6522,w6588]
theorem b6_43 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_43 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true)),(false,(3,true),(7,true)),(false,(5,true),(9,true))] s6_43 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2299,v20_2468,v20_3766,v20_5135,v20_5585,v20_6101,v20_6389,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2299 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_6101 (PetersenWireProjection.cons pc20_6389 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s6_44 : List (BitVec 512) := [w2323,w2468,w3766,w4716,w5135,w6179,w6389,w6522,w6588]
theorem b6_44 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_44 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true)),(false,(5,true),(7,true)),(false,(5,true),(9,true))] s6_44 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3766,v20_4716,v20_5135,v20_6179,v20_6389,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_6179 (PetersenWireProjection.cons pc20_6389 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s6_46 : List (BitVec 512) := [w2381,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b6_46 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_46 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s6_46 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2381,v20_2681,v20_3766,v20_4344,v20_4716,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2381 (PetersenWireProjection.cons pc20_2681 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
end NineCert
