import NinePin43
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7566 : List (BitVec 512) := [w1312,w1668,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7566 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s4_7566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_1312,v43_1668,v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_5585,v43_5956,v43_6300,v43_6813] (PetersenWireProjection.cons pc43_1312 (PetersenWireProjection.cons pc43_1668 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6813 rfl))))))))))) (by decide +kernel)
def s4_7581 : List (BitVec 512) := [w1312,w1911,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7581 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7581 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s4_7581 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_1312,v43_1911,v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_5585,v43_5956,v43_6300,v43_6813] (PetersenWireProjection.cons pc43_1312 (PetersenWireProjection.cons pc43_1911 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6813 rfl))))))))))) (by decide +kernel)
def s4_10104 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6477,w6588]
theorem b4_10104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10104 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(0,true),(2,true))] s4_10104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_1403,v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_5585,v43_5956,v43_6300,v43_6477,v43_6588] (PetersenWireProjection.cons pc43_1403 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6477 (PetersenWireProjection.cons pc43_6588 rfl))))))))))) (by decide +kernel)
def s4_16983 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_16983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16983 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s4_16983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_3766,v43_4344,v43_4716,v43_4921,v43_5135,v43_5393,v43_5585,v43_5956,v43_6300,v43_6785,v43_6873] (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_4921 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6785 (PetersenWireProjection.cons pc43_6873 rfl))))))))))) (by decide +kernel)
def s5_1507 : List (BitVec 512) := [w979,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1507 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1507 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s5_1507 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_979,v43_3766,v43_4716,v43_5135,v43_5393,v43_5585,v43_5698,v43_5956,v43_6300,v43_6588] (PetersenWireProjection.cons pc43_979 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5698 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6588 rfl)))))))))) (by decide +kernel)
def s5_2436 : List (BitVec 512) := [w1312,w1911,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_2436 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2436 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s5_2436 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_1312,v43_1911,v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_6179,v43_6300,v43_6785] (PetersenWireProjection.cons pc43_1312 (PetersenWireProjection.cons pc43_1911 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_6179 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6785 rfl)))))))))) (by decide +kernel)
def s5_3160 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6456,w6873]
theorem b5_3160 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3160 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(2,true),(0,true))] s5_3160 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_1403,v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_5585,v43_5956,v43_6456,v43_6873] (PetersenWireProjection.cons pc43_1403 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6456 (PetersenWireProjection.cons pc43_6873 rfl)))))))))) (by decide +kernel)
def s5_4084 : List (BitVec 512) := [w2468,w3766,w4344,w4582,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4084 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4084 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_4084 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_2468,v43_3766,v43_4344,v43_4582,v43_4716,v43_5135,v43_5585,v43_5956,v43_6300,v43_6588] (PetersenWireProjection.cons pc43_2468 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4582 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6588 rfl)))))))))) (by decide +kernel)
def s5_4225 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6517,w6785,w6873]
theorem b5_4225 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4225 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_4225 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_2468,v43_3766,v43_4344,v43_4716,v43_5135,v43_5585,v43_5956,v43_6517,v43_6785,v43_6873] (PetersenWireProjection.cons pc43_2468 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6517 (PetersenWireProjection.cons pc43_6785 (PetersenWireProjection.cons pc43_6873 rfl)))))))))) (by decide +kernel)
def s5_5595 : List (BitVec 512) := [w3766,w4344,w4498,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5595 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5595 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s5_5595 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_3766,v43_4344,v43_4498,v43_4716,v43_5135,v43_5393,v43_5585,v43_5956,v43_6300,v43_6588] (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4498 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_5585 (PetersenWireProjection.cons pc43_5956 (PetersenWireProjection.cons pc43_6300 (PetersenWireProjection.cons pc43_6588 rfl)))))))))) (by decide +kernel)
def s5_6163 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6517,w6522,w6785,w6873]
theorem b5_6163 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6163 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(4,true),(2,true))] s5_6163 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_6179,v43_6517,v43_6522,v43_6785,v43_6873] (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_6179 (PetersenWireProjection.cons pc43_6517 (PetersenWireProjection.cons pc43_6522 (PetersenWireProjection.cons pc43_6785 (PetersenWireProjection.cons pc43_6873 rfl)))))))))) (by decide +kernel)
def s5_6165 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6517,w6785,w6873]
theorem b5_6165 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6165 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [] s5_6165 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_3766,v43_4344,v43_4716,v43_5135,v43_5393,v43_6179,v43_6517,v43_6785,v43_6873] (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_5393 (PetersenWireProjection.cons pc43_6179 (PetersenWireProjection.cons pc43_6517 (PetersenWireProjection.cons pc43_6785 (PetersenWireProjection.cons pc43_6873 rfl))))))))) (by decide +kernel)
def s6_65 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w6179,w6517,w6785,w6873]
theorem b6_65 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_65 := by
  intro m le c
  apply rejects_sound r43 i7 8 tgt (small43 adj) hot43 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s6_65 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v43_2468,v43_3766,v43_4344,v43_4716,v43_5135,v43_6179,v43_6517,v43_6785,v43_6873] (PetersenWireProjection.cons pc43_2468 (PetersenWireProjection.cons pc43_3766 (PetersenWireProjection.cons pc43_4344 (PetersenWireProjection.cons pc43_4716 (PetersenWireProjection.cons pc43_5135 (PetersenWireProjection.cons pc43_6179 (PetersenWireProjection.cons pc43_6517 (PetersenWireProjection.cons pc43_6785 (PetersenWireProjection.cons pc43_6873 rfl))))))))) (by decide +kernel)
end NineCert
