import NinePin33
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_413 : List (BitVec 512) := [w365,w1410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_413 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_413 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s3_413 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_1410,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_1410 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s3_414 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_414 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_414 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s3_414 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6422,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s3_415 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588,w6832]
theorem b3_415 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_415 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(1,true),(0,true))] s3_415 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6422,v33_6588,v33_6832] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 (PetersenWireProjection.cons pc33_6832 rfl)))))))))))) (by decide +kernel)
def s3_416 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_416 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_416 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s3_416 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s4_2321 : List (BitVec 512) := [w365,w1410,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2321 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_2321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_1410,v33_3766,v33_4344,v33_5135,v33_5393,v33_5585,v33_5769,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_1410 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5769 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_2333 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_2333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2333 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(4,true),(2,true))] s4_2333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5698,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5698 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_2340 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_2340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2340 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_2340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6436,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6436 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_2344 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_2344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2344 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(0,true),(1,true))] s4_2344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588,v33_6832] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 (PetersenWireProjection.cons pc33_6832 rfl))))))))))) (by decide +kernel)
def s4_2349 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_2349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2349 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(1,true),(0,true))] s4_2349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588,v33_6912] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 (PetersenWireProjection.cons pc33_6912 rfl))))))))))) (by decide +kernel)
def s4_2350 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6621]
theorem b4_2350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2350 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_2350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6621] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6621 rfl)))))))))) (by decide +kernel)
def s4_2351 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6621,w6832]
theorem b4_2351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2351 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(0,true),(1,true))] s4_2351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6621,v33_6832] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6621 (PetersenWireProjection.cons pc33_6832 rfl))))))))))) (by decide +kernel)
def s4_2354 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_2354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2354 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_2354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6389,v33_6422,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6389 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_15475 : List (BitVec 512) := [w3766,w4250,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_15475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15475 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_15475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4250,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6422,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4250 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_15476 : List (BitVec 512) := [w3766,w4250,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15476 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_15476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4250,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4250 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s4_15477 : List (BitVec 512) := [w3766,w4251,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_15477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15477 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_15477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4251,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6422,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4251 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_15478 : List (BitVec 512) := [w3766,w4251,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15478 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_15478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4251,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4251 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s4_16229 : List (BitVec 512) := [w3766,w4344,w4440,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16229 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(2,true),(0,true))] s4_16229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4344,v33_4440,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6179,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4440 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6179 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_16230 : List (BitVec 512) := [w3766,w4344,w4440,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16230 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_16230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4344,v33_4440,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6422,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4440 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6422 (PetersenWireProjection.cons pc33_6588 rfl))))))))))) (by decide +kernel)
def s4_16231 : List (BitVec 512) := [w3766,w4344,w4440,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16231 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s4_16231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4344,v33_4440,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4440 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_617 : List (BitVec 512) := [w365,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_617 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_617 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(4,true),(2,true)),(false,(4,true),(0,true))] s5_617 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_365,v33_3258,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_365 (PetersenWireProjection.cons pc33_3258 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_1096 : List (BitVec 512) := [w858,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1096 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1096 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [(false,(2,true),(4,true)),(false,(4,true),(0,true))] s5_1096 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_858,v33_3258,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_858 (PetersenWireProjection.cons pc33_3258 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_1505 : List (BitVec 512) := [w977,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1505 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1505 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s5_1505 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_977,v33_3766,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_977 (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_5396 : List (BitVec 512) := [w3766,w4249,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5396 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5396 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s5_5396 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4249,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4249 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_5397 : List (BitVec 512) := [w3766,w4252,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5397 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5397 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s5_5397 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4252,v33_4344,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4252 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_5587 : List (BitVec 512) := [w3766,w4344,w4488,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5587 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5587 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s5_5587 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4344,v33_4488,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4488 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
def s5_5633 : List (BitVec 512) := [w3766,w4344,w4546,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5633 := by
  intro m le c
  apply rejects_sound r33 i7 8 tgt (small33 adj) hot33 [] s5_5633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v33_3766,v33_4344,v33_4546,v33_4716,v33_5135,v33_5393,v33_5585,v33_5956,v33_6300,v33_6588] (PetersenWireProjection.cons pc33_3766 (PetersenWireProjection.cons pc33_4344 (PetersenWireProjection.cons pc33_4546 (PetersenWireProjection.cons pc33_4716 (PetersenWireProjection.cons pc33_5135 (PetersenWireProjection.cons pc33_5393 (PetersenWireProjection.cons pc33_5585 (PetersenWireProjection.cons pc33_5956 (PetersenWireProjection.cons pc33_6300 (PetersenWireProjection.cons pc33_6588 rfl)))))))))) (by decide +kernel)
end NineCert
