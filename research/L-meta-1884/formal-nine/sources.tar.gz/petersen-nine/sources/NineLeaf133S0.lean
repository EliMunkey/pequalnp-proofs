import NinePin133
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13016 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6389,w6543,w6588]
theorem b4_13016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13016 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s4_13016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_6101,v133_6300,v133_6389,v133_6543,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_6101 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6389 (PetersenWireProjection.cons pc133_6543 (PetersenWireProjection.cons pc133_6588 rfl))))))))))) (by decide +kernel)
def s5_969 : List (BitVec 512) := [w637,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_969 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_969 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_969 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_637,v133_3766,v133_4716,v133_5135,v133_5393,v133_5585,v133_5698,v133_5956,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_637 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5698 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_970 : List (BitVec 512) := [w637,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_970 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_970 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_970 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_637,v133_3766,v133_4716,v133_5135,v133_5393,v133_5585,v133_5956,v133_6061,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_637 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6061 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_971 : List (BitVec 512) := [w637,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_971 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_971 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_971 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_637,v133_3766,v133_4716,v133_5135,v133_5393,v133_5585,v133_5956,v133_6201,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_637 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6201 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_2877 : List (BitVec 512) := [w1384,w2884,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2877 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2877 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_2877 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_1384,v133_2884,v133_3766,v133_4344,v133_4716,v133_5135,v133_5393,v133_5585,v133_5956,v133_6300] (PetersenWireProjection.cons pc133_1384 (PetersenWireProjection.cons pc133_2884 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 rfl)))))))))) (by decide +kernel)
def s5_2980 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b5_2980 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2980 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_2980 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_1384,v133_3766,v133_4716,v133_5135,v133_5393,v133_5585,v133_6061,v133_6101,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_1384 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_6061 (PetersenWireProjection.cons pc133_6101 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_2982 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_2982 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2982 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_2982 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_1384,v133_3766,v133_4716,v133_5135,v133_5393,v133_5698,v133_5769,v133_5956,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_1384 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5698 (PetersenWireProjection.cons pc133_5769 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_3306 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_3306 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3306 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_3306 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_1415,v133_3766,v133_4716,v133_5135,v133_5393,v133_5698,v133_5769,v133_5956,v133_6300,v133_6690] (PetersenWireProjection.cons pc133_1415 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5698 (PetersenWireProjection.cons pc133_5769 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_4439 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5656,w5956,w6300,w6588]
theorem b5_4439 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4439 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4439 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_5656,v133_5956,v133_6300,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5656 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6588 rfl)))))))))) (by decide +kernel)
def s5_4440 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5658,w5956,w6300,w6588]
theorem b5_4440 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4440 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4440 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_5658,v133_5956,v133_6300,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5658 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6588 rfl)))))))))) (by decide +kernel)
def s5_4513 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6647]
theorem b5_4513 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4513 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4513 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_5956,v133_6300,v133_6588,v133_6647] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6588 (PetersenWireProjection.cons pc133_6647 rfl)))))))))) (by decide +kernel)
def s5_4514 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6651]
theorem b5_4514 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4514 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4514 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_5956,v133_6300,v133_6588,v133_6651] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6588 (PetersenWireProjection.cons pc133_6651 rfl)))))))))) (by decide +kernel)
def s5_4548 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6720,w6890]
theorem b5_4548 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4548 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4548 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5585,v133_5956,v133_6300,v133_6720,v133_6890] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6720 (PetersenWireProjection.cons pc133_6890 rfl)))))))))) (by decide +kernel)
def s5_4573 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5769,w5956,w6300,w6478,w6588]
theorem b5_4573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4573 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4344,v133_4716,v133_5135,v133_5769,v133_5956,v133_6300,v133_6478,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5769 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6478 (PetersenWireProjection.cons pc133_6588 rfl)))))))))) (by decide +kernel)
def s5_4610 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6389,w6422,w6588]
theorem b5_4610 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4610 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4610 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4716,v133_5135,v133_5585,v133_5698,v133_5956,v133_6389,v133_6422,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5698 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6389 (PetersenWireProjection.cons pc133_6422 (PetersenWireProjection.cons pc133_6588 rfl)))))))))) (by decide +kernel)
def s5_4621 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5956,w6061,w6300,w6690,w6720]
theorem b5_4621 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4621 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4621 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4716,v133_5135,v133_5585,v133_5956,v133_6061,v133_6300,v133_6690,v133_6720] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6061 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6690 (PetersenWireProjection.cons pc133_6720 rfl)))))))))) (by decide +kernel)
def s5_4626 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w6061,w6101,w6300,w6588,w6690]
theorem b5_4626 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4626 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4626 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4716,v133_5135,v133_5585,v133_6061,v133_6101,v133_6300,v133_6588,v133_6690] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_6061 (PetersenWireProjection.cons pc133_6101 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6588 (PetersenWireProjection.cons pc133_6690 rfl)))))))))) (by decide +kernel)
def s5_4628 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b5_4628 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4628 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_4628 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_2488,v133_3766,v133_4716,v133_5135,v133_5698,v133_5769,v133_5956,v133_6300,v133_6389,v133_6588] (PetersenWireProjection.cons pc133_2488 (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5698 (PetersenWireProjection.cons pc133_5769 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6389 (PetersenWireProjection.cons pc133_6588 rfl)))))))))) (by decide +kernel)
def s5_5555 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5555 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5555 := by
  intro m le c
  apply rejects_sound r133 i7 6 tgt (small133 adj) hot133 [] s5_5555 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v133_3766,v133_4344,v133_4417,v133_4716,v133_5135,v133_5393,v133_5585,v133_5956,v133_6300,v133_6720] (PetersenWireProjection.cons pc133_3766 (PetersenWireProjection.cons pc133_4344 (PetersenWireProjection.cons pc133_4417 (PetersenWireProjection.cons pc133_4716 (PetersenWireProjection.cons pc133_5135 (PetersenWireProjection.cons pc133_5393 (PetersenWireProjection.cons pc133_5585 (PetersenWireProjection.cons pc133_5956 (PetersenWireProjection.cons pc133_6300 (PetersenWireProjection.cons pc133_6720 rfl)))))))))) (by decide +kernel)
end NineCert
