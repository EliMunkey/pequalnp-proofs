import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3333 : List (BitVec 512) := [w1688,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b5_3333 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3333 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true))] s5_3333 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1688,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1688 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3334 : List (BitVec 512) := [w1706,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3334 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3334 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s5_3334 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3335 : List (BitVec 512) := [w1706,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6720]
theorem b5_3335 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3335 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(5,true)),(false,(1,true),(0,true)),(false,(10,true),(4,true))] s5_3335 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6177,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6177 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_3336 : List (BitVec 512) := [w1706,w4344,w4716,w5135,w5393,w5698,w5956,w6177,w6300,w6588]
theorem b5_3336 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3336 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,true)),(false,(7,true),(3,true))] s5_3336 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6177,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6177 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3355 : List (BitVec 512) := [w2197,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3355 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3355 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3355 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3356 : List (BitVec 512) := [w2198,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3356 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3356 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2198,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2198 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3357 : List (BitVec 512) := [w2199,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3357 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3357 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3357 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2199,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2199 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3358 : List (BitVec 512) := [w2200,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3358 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3358 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3358 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2200,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2200 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3359 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_3359 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3359 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_3359 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_3360 : List (BitVec 512) := [w2203,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_3360 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(8,true),(4,true))] s5_3360 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_3361 : List (BitVec 512) := [w2203,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_3361 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3361 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_3361 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_3362 : List (BitVec 512) := [w2203,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_3362 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3362 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(5,true),(1,true)),(false,(9,true),(2,true)),(false,(7,true),(8,true))] s5_3362 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_3363 : List (BitVec 512) := [w2203,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_3363 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3363 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true)),(false,(3,true),(9,true))] s5_3363 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3364 : List (BitVec 512) := [w2203,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6690,w6720]
theorem b5_3364 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3364 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(2,true)),(false,(6,true),(3,true)),(false,(3,true),(10,true))] s5_3364 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_3370 : List (BitVec 512) := [w2211,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3370 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3370 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3370 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2211,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2211 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3639 : List (BitVec 512) := [w2381,w3581,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3639 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3639 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3639 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2381,v0_3581,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3581 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3640 : List (BitVec 512) := [w2381,w3623,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3640 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3640 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3640 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2381,v0_3623,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3623 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3641 : List (BitVec 512) := [w2381,w3766,w3913,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3641 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3641 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3641 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2381,v0_3766,v0_3913,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3913 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3658 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6017,w6300,w6588]
theorem b5_3658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3658 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2381,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6017,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6017 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3659 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6050,w6300,w6588]
theorem b5_3659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3659 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2381,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6050,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2381 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6050 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3674 : List (BitVec 512) := [w2382,w3624,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3674 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3674 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3674 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2382,v0_3624,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2382 (PetersenWireProjection.cons pc0_3624 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3682 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6051,w6300,w6588]
theorem b5_3682 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3682 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3682 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2382,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6051,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2382 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6051 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3695 : List (BitVec 512) := [w2387,w3578,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3695 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3695 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3695 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2387,v0_3578,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3578 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3696 : List (BitVec 512) := [w2387,w3625,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3696 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3696 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2387,v0_3625,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3625 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3697 : List (BitVec 512) := [w2387,w3766,w3923,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3697 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3697 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3697 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2387,v0_3766,v0_3923,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3923 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3715 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6026,w6300,w6588]
theorem b5_3715 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3715 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3715 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2387,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6026,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6026 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3716 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6052,w6300,w6588]
theorem b5_3716 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3716 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true)),(false,(6,true),(0,true))] s5_3716 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2387,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6052,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2387 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6052 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3850 : List (BitVec 512) := [w2468,w2681,w3335,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3850 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3850 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3850 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3335,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3851 : List (BitVec 512) := [w2468,w2681,w3411,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3851 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3851 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3851 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3411,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3852 : List (BitVec 512) := [w2468,w2681,w3568,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3852 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3852 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3852 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3568,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3568 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3853 : List (BitVec 512) := [w2468,w2681,w3669,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3853 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3853 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3853 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3669,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3854 : List (BitVec 512) := [w2468,w2681,w3766,w3929,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3854 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3854 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3854 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3766,v0_3929,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3929 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3861 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4602,w4716,w5585,w5956,w6300,w6588]
theorem b5_3861 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3861 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3861 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3766,v0_4344,v0_4602,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3871 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w4814,w5585,w5956,w6300,w6588]
theorem b5_3871 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3871 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3871 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_4814,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3880 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6522,w6588]
theorem b5_3880 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3880 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true)),(false,(6,true),(0,true))] s5_3880 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3882 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6538,w6588]
theorem b5_3882 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3882 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3882 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3908 : List (BitVec 512) := [w2468,w3338,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3908 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3338,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3338 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3909 : List (BitVec 512) := [w2468,w3348,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3909 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3909 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3909 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3348,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3348 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3910 : List (BitVec 512) := [w2468,w3350,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3910 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3350,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3350 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3911 : List (BitVec 512) := [w2468,w3352,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3911 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3352,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3352 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3912 : List (BitVec 512) := [w2468,w3370,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3912 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3912 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3912 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3370,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3370 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3913 : List (BitVec 512) := [w2468,w3371,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3371,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3371 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3914 : List (BitVec 512) := [w2468,w3397,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3914 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3397,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3397 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3915 : List (BitVec 512) := [w2468,w3399,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3915 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3915 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3915 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3399,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3399 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3916 : List (BitVec 512) := [w2468,w3410,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3916 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3410,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3410 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3917 : List (BitVec 512) := [w2468,w3414,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3917 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3917 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3917 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3414,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3414 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3918 : List (BitVec 512) := [w2468,w3425,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3918 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3918 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3918 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3425,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3425 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3919 : List (BitVec 512) := [w2468,w3427,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3919 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3919 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3919 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3427,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3427 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3920 : List (BitVec 512) := [w2468,w3429,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3920 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3920 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3920 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3429,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3429 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3921 : List (BitVec 512) := [w2468,w3446,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3921 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3921 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3921 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3446,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3446 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3922 : List (BitVec 512) := [w2468,w3447,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3922 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3922 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3922 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3447,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3447 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3923 : List (BitVec 512) := [w2468,w3500,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3923 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3923 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3923 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3500,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3500 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3924 : List (BitVec 512) := [w2468,w3502,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3924 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3502,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3502 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3925 : List (BitVec 512) := [w2468,w3523,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3925 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3925 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3925 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3523,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3523 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3926 : List (BitVec 512) := [w2468,w3544,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3926 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3544,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3544 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3927 : List (BitVec 512) := [w2468,w3566,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3927 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3927 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3927 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3566,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3566 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3928 : List (BitVec 512) := [w2468,w3570,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3928 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3928 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3928 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3570,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3570 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3929 : List (BitVec 512) := [w2468,w3571,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3929 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3929 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3929 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3571,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3571 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3930 : List (BitVec 512) := [w2468,w3574,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3574,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3574 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3931 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b5_3931 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3931 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s5_3931 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3932 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_3932 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3932 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_3932 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3933 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5725,w5956,w6300,w6588]
theorem b5_3933 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3933 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(1,true),(0,false))] s5_3933 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5725,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5725 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3934 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_3934 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3934 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(4,true),(0,false))] s5_3934 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3935 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b5_3935 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3935 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3935 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
