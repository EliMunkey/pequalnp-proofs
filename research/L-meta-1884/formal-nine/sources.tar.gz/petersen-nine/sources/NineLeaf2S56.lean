import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_6162 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6246,w6522,w6785,w6873]
theorem b5_6162 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6162 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_6162 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6246,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6168 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6559,w6785,w6873]
theorem b5_6168 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6168 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_6168 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6559,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6172 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6827,w6873]
theorem b5_6172 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6172 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_6172 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6785,v2_6827,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6827 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6175 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6827,w6873]
theorem b5_6175 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6175 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_6175 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6827,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6827 (PetersenWireProjection.cons pc2_6873 rfl))))))))) (by decide +kernel)
def s5_6187 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5520,w5585,w5956,w6300,w6588]
theorem b5_6187 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6187 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s5_6187 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5470,v2_5520,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5470 (PetersenWireProjection.cons pc2_5520 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6199 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6783]
theorem b5_6199 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6199 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(1,false))] s5_6199 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5470,v2_5585,v2_5956,v2_6300,v2_6588,v2_6783] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5470 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6783 rfl)))))))))) (by decide +kernel)
def s5_6230 : List (BitVec 512) := [w3766,w4344,w4716,w5187,w5393,w5585,w6158,w6389,w6522,w6588]
theorem b5_6230 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6230 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_6230 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_6158,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_6236 : List (BitVec 512) := [w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6522,w6767,w6873]
theorem b5_6236 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6236 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true)),(false,(9,true),(5,true))] s5_6236 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6258 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6559,w6720,w6873]
theorem b5_6258 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6258 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6258 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6559,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_6261 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6782,w6873]
theorem b5_6261 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6261 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6261 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6782,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6873 rfl))))))))) (by decide +kernel)
def s6_40 : List (BitVec 512) := [w2240,w2531,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_40 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_40 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s6_40 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2240,v2_2531,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2240 (PetersenWireProjection.cons pc2_2531 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s6_41 : List (BitVec 512) := [w2240,w2532,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_41 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_41 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s6_41 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2240,v2_2532,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2240 (PetersenWireProjection.cons pc2_2532 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s6_42 : List (BitVec 512) := [w2240,w2534,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b6_42 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_42 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(2,true)),(false,(1,false),(0,true)),(false,(0,true),(2,false))] s6_42 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2240,v2_2534,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2240 (PetersenWireProjection.cons pc2_2534 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s6_45 : List (BitVec 512) := [w2326,w3258,w4716,w5135,w5393,w6179,w6389,w6522,w6588]
theorem b6_45 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_45 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true)),(false,(5,true),(8,true)),(false,(7,true),(5,true))] s6_45 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4716,v2_5135,v2_5393,v2_6179,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))) (by decide +kernel)
def s6_60 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w6179,w6785,w6873]
theorem b6_60 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_60 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(6,true)),(false,(9,true),(5,true)),(false,(8,true),(5,true))] s6_60 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_6179,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))) (by decide +kernel)
def s6_67 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5311,w5585,w6101,w6720,w6873]
theorem b6_67 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_67 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(9,true),(5,true)),(false,(9,true),(5,true))] s6_67 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_5135,v2_5311,v2_5585,v2_6101,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))) (by decide +kernel)
end NineCert
