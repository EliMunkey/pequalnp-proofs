import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9937 : List (BitVec 512) := [w1403,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9937 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_9937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9938 : List (BitVec 512) := [w1403,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9938 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_9938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_9939 : List (BitVec 512) := [w1403,w3766,w4297,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9939 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_9939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4297,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_9940 : List (BitVec 512) := [w1403,w3766,w4297,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b4_9940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9940 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(8,true),(0,true))] s4_9940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4297,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9941 : List (BitVec 512) := [w1403,w3766,w4327,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9941 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true))] s4_9941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4327,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9942 : List (BitVec 512) := [w1403,w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6873,w6890]
theorem b4_9942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9942 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true))] s4_9942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9943 : List (BitVec 512) := [w1403,w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9943 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true))] s4_9943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl)))))))))) (by decide +kernel)
def s4_9944 : List (BitVec 512) := [w1403,w3766,w4344,w4405,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9944 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_9944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9945 : List (BitVec 512) := [w1403,w3766,w4344,w4405,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9945 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_9945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4405,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_9946 : List (BitVec 512) := [w1403,w3766,w4344,w4405,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9946 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_9946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4405,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4405 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_9978 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9978 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_9978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_9979 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9979 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_9979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_9980 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4926,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9980 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_9980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_4926,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10042 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6690]
theorem b4_10042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10042 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_10042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5623,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5623 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10051 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6890]
theorem b4_10051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10051 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_10051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_10052 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6522,w6588]
theorem b4_10052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10052 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10053 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5706,w5956,w6300,w6588]
theorem b4_10053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10053 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_10053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5706,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5706 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10057 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6690]
theorem b4_10057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10057 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(5,true))] s4_10057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10063 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_10063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10063 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(5,true))] s4_10063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10078 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6890]
theorem b4_10078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10078 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_10078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_10079 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6522,w6588]
theorem b4_10079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10079 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10080 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6067,w6300,w6588]
theorem b4_10080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10080 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_10080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6067,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6067 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10082 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_10082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10082 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(6,true))] s4_10082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10089 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6690]
theorem b4_10089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10089 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(5,true),(6,true))] s4_10089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10094 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_10094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10094 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(5,true),(6,true))] s4_10094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10106 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6690]
theorem b4_10106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10106 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(5,true),(7,true))] s4_10106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10144 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6311,w6873,w6890]
theorem b4_10144 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10144 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true))] s4_10144 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6311,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6311 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_10147 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6380,w6389,w6588]
theorem b4_10147 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10147 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s4_10147 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6380,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6380 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10148 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6380,w6522,w6588]
theorem b4_10148 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10148 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10148 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6380,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6380 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10149 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6380,w6588]
theorem b4_10149 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10149 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true))] s4_10149 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6380,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6380 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10154 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6690]
theorem b4_10154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10154 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10171 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6523,w6588]
theorem b4_10171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10171 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6523,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6523 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10173 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6543,w6588]
theorem b4_10173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10173 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(7,true))] s4_10173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10180 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6690]
theorem b4_10180 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10180 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10180 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10189 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6690]
theorem b4_10189 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10189 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true))] s4_10189 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_10198 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_10198 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10198 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(6,true))] s4_10198 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10211 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5213,w5393,w5585,w5956,w6300,w6588]
theorem b4_10211 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10211 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_10211 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5213,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5213 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10220 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_10220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10224 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_10224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10230 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_10230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_10230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10235 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6690]
theorem b4_10235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10235 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_10235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_10241 : List (BitVec 512) := [w1403,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_10241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10241 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(6,true))] s4_10241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10271 : List (BitVec 512) := [w1411,w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10271 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10273 : List (BitVec 512) := [w1411,w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10273 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10274 : List (BitVec 512) := [w1411,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10274 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10275 : List (BitVec 512) := [w1411,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10275 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10276 : List (BitVec 512) := [w1411,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10276 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10277 : List (BitVec 512) := [w1411,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10277 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10277 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10277 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4412,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4412 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10301 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10301 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10301 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10306 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10306 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10309 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10317 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true))] s4_10317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10319 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_10319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10326 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_10326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(0,true))] s4_10326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1411,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1411 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_10407 : List (BitVec 512) := [w1415,w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10407 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10410 : List (BitVec 512) := [w1415,w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10410 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10411 : List (BitVec 512) := [w1415,w3766,w4079,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_10411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10411 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s4_10411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10412 : List (BitVec 512) := [w1415,w3766,w4079,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10412 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s4_10412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4079,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10413 : List (BitVec 512) := [w1415,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10413 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10414 : List (BitVec 512) := [w1415,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10414 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10415 : List (BitVec 512) := [w1415,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b4_10415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10415 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10416 : List (BitVec 512) := [w1415,w3766,w4179,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10416 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4179,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10417 : List (BitVec 512) := [w1415,w3766,w4258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10417 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10418 : List (BitVec 512) := [w1415,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10418 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
