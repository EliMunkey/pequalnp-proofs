import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9035 : List (BitVec 512) := [w1374,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9035 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9036 : List (BitVec 512) := [w1374,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9036 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9036 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9036 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9037 : List (BitVec 512) := [w1374,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9037 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9037 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9037 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9038 : List (BitVec 512) := [w1374,w3766,w4344,w4637,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9038 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9038 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9038 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4637,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4637 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9056 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4748,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b4_9056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9056 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_9056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4748,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4748 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9069 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4876,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9069 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4876,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4876 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9075 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4926,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b4_9075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9075 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true))] s4_9075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4926,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9085 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9085 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9086 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9086 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9087 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9087 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9088 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9088 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9089 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9089 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9090 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5028,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9090 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5028,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5028 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9091 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5029,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9091 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5029,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5029 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9092 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5034,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9092 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9093 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6201,w6300]
theorem b4_9093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9093 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(1,false))] s4_9093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9094 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6225,w6300]
theorem b4_9094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9094 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(1,false))] s4_9094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9095 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6389]
theorem b4_9095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9095 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true))] s4_9095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6389] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 rfl))))))))))) (by decide +kernel)
def s4_9096 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w6179,w6300,w6522]
theorem b4_9096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6522] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 rfl))))))))))) (by decide +kernel)
def s4_9097 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5066,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9097 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5066,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5066 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9098 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5066,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9098 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5066,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5066 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9099 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5066,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9099 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5066,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5066 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9100 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b4_9100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9100 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9101 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6300]
theorem b4_9101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9101 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_9102 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9102 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9103 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6179,w6300]
theorem b4_9103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9103 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_9104 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_9104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9104 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9105 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b4_9105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9105 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s4_9106 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5098,w5393,w5585,w5956,w6300,w6720]
theorem b4_9106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9106 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_9107 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5105,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_9107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9107 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_9107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5105,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5105 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_9108 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5119,w5135,w5393,w5585,w5956,w6300]
theorem b4_9108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9108 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true))] s4_9108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5119,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5119 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_9109 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5119,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9109 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5119,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5119 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9110 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5183,w5393,w5585,w5956,w6300,w6720]
theorem b4_9110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9110 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5183,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5183 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9111 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5183,w5393,w5585,w5956,w6300,w6866]
theorem b4_9111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9111 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5183,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5183 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9112 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5183,w5393,w5585,w6179,w6300,w6832]
theorem b4_9112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9112 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5183,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5183 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9117 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6720]
theorem b4_9117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9117 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9118 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6866]
theorem b4_9118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9118 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9119 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w6179,w6300,w6832]
theorem b4_9119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9119 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9120 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5205,w5393,w5956,w6179,w6300,w6785]
theorem b4_9120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9120 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(7,true),(5,true))] s4_9120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 rfl))))))))))) (by decide +kernel)
def s4_9121 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5211,w5393,w5585,w5956,w6300,w6588]
theorem b4_9121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9121 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_9121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5211,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5211 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9122 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6720]
theorem b4_9122 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9122 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9122 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9123 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6866]
theorem b4_9123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9123 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9124 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w6179,w6300,w6832]
theorem b4_9124 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9124 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9124 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9125 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5240,w5393,w5585,w5956,w6300,w6588]
theorem b4_9125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9125 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true))] s4_9125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5240,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5240 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9126 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5243,w5393,w5585,w5956,w6300,w6588]
theorem b4_9126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9126 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true))] s4_9126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5243,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5243 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9163 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6720]
theorem b4_9163 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9163 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9163 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9164 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6866]
theorem b4_9164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9164 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6866] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_9165 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w6179,w6300,w6832]
theorem b4_9165 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9165 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9165 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_6179,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9200 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6241,w6300,w6720]
theorem b4_9200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9200 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6241,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9201 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6242,w6300,w6588]
theorem b4_9201 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9201 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(1,false))] s4_9201 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6242,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6242 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9202 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6243,w6300,w6588]
theorem b4_9202 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9202 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(1,false))] s4_9202 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9213 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6446,w6588]
theorem b4_9213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9213 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true))] s4_9213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6446,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6446 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9229 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6763]
theorem b4_9229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9229 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6763] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6763 rfl))))))))))) (by decide +kernel)
def s4_9239 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866,w6871]
theorem b4_9239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9239 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6866,v1_6871] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6866 (PetersenWireProjection.cons pc1_6871 rfl))))))))))) (by decide +kernel)
def s4_9245 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6422,w6444,w6588]
theorem b4_9245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9245 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(4,true))] s4_9245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6422,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9260 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6241,w6300,w6832]
theorem b4_9260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9260 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_9275 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6860]
theorem b4_9275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9275 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6832,v1_6860] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6860 rfl))))))))))) (by decide +kernel)
def s4_9283 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6241,w6300,w6522,w6588]
theorem b4_9283 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9283 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9283 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6241,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9284 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6241,w6300,w6832]
theorem b4_9284 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9284 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s4_9284 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6241,v1_6300,v1_6832] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s4_9298 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5239,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_9298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9298 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_9299 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5239,w5393,w5585,w5956,w6300,w6720]
theorem b4_9299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9299 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(4,true),(5,true))] s4_9299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_9309 : List (BitVec 512) := [w1384,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9309 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9320 : List (BitVec 512) := [w1384,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9320 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9321 : List (BitVec 512) := [w1384,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9321 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
