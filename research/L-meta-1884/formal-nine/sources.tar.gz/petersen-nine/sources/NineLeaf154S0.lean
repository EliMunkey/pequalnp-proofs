import NinePin154
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_11 : List (BitVec 512) := [w507,w2536,w3766,w4344,w4716,w5135,w5585,w5956,w6300]
theorem b6_11 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_11 := by
  intro m le c
  apply rejects_sound r154 i7 6 tgt (small154 adj) hot154 [] s6_11 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v154_507,v154_2536,v154_3766,v154_4344,v154_4716,v154_5135,v154_5585,v154_5956,v154_6300] (PetersenWireProjection.cons pc154_507 (PetersenWireProjection.cons pc154_2536 (PetersenWireProjection.cons pc154_3766 (PetersenWireProjection.cons pc154_4344 (PetersenWireProjection.cons pc154_4716 (PetersenWireProjection.cons pc154_5135 (PetersenWireProjection.cons pc154_5585 (PetersenWireProjection.cons pc154_5956 (PetersenWireProjection.cons pc154_6300 rfl))))))))) (by decide +kernel)
end NineCert
