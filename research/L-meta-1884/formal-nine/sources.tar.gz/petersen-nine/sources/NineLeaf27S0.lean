import NinePin27
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s2_74 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_74 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_74 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s2_74 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_216 : List (BitVec 512) := [w160,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_216 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_216 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_216 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_217 : List (BitVec 512) := [w160,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_217 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_217 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_217 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_1599,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_1599 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_218 : List (BitVec 512) := [w160,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_218 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_218 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_218 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_219 : List (BitVec 512) := [w160,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_219 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_219 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s3_219 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl)))))))))))) (by decide +kernel)
def s3_220 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_220 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_220 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_220 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_372 : List (BitVec 512) := [w332,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_372 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_372 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_372 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_373 : List (BitVec 512) := [w332,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_373 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_373 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_373 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_1832,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_1832 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_374 : List (BitVec 512) := [w332,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_374 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_374 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_374 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_375 : List (BitVec 512) := [w332,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_375 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_375 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s3_375 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl)))))))))))) (by decide +kernel)
def s3_376 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_376 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_376 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_376 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_332,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_332 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_1372 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1372 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1372 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1372 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1373 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_1373 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1373 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1373 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1374 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_1374 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1374 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s3_1374 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1375 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_1375 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1375 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1375 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1376 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_1376 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1376 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s3_1376 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1377 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_1377 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1377 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true))] s3_1377 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_1383 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b3_1383 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1383 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1383 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s3_1408 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5618,w5956,w6300,w6588]
theorem b3_1408 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1408 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1408 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5618,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5618 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1412 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_1412 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1412 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1412 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1418 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b3_1418 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1418 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1418 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_5981,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_5981 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1422 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_1422 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1422 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1422 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1428 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6321,w6588]
theorem b3_1428 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1428 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1428 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6321,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6321 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1432 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_1432 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1432 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1432 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1450 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6748]
theorem b3_1450 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1450 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1450 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6690,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6690 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s3_1452 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6748]
theorem b3_1452 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1452 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1452 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 (PetersenWireProjection.cons pc27_6748 rfl))))))))))) (by decide +kernel)
def s3_1453 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b3_1453 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1453 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1453 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6748] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6748 rfl)))))))))) (by decide +kernel)
def s3_1454 : List (BitVec 512) := [w1119,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_1454 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1454 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1454 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4344,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_1456 : List (BitVec 512) := [w1119,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_1456 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1456 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_1456 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_1119,v27_3766,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6389,v27_6588] (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6389 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_4567 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_4567 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4567 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(2,true))] s3_4567 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6179,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6179 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_4568 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4568 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4568 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4568 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_4570 : List (BitVec 512) := [w3766,w4344,w4716,w4910,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4570 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4570 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4570 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4910,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4910 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_4571 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_4571 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4571 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s3_4571 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4916,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4916 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_4572 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4572 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4572 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4572 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4916,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4916 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_4573 : List (BitVec 512) := [w3766,w4344,w4716,w4916,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4573 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4573 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4573 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4916,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4916 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_4574 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_4574 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4574 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(2,true),(4,true))] s3_4574 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4917,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_4575 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4575 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4575 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4575 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4917,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_4577 : List (BitVec 512) := [w3766,w4344,w4716,w4917,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4577 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4577 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4577 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4917,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4917 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_4578 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4578 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4578 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4578 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s3_4579 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_4579 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4579 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(1,true))] s3_4579 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6785] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6785 rfl)))))))))))) (by decide +kernel)
def s3_4580 : List (BitVec 512) := [w3766,w4344,w4716,w4921,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4580 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4580 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4580 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4921,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4921 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s3_4649 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6136,w6300,w6588]
theorem b3_4649 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4649 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4649 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6136,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_4654 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6436,w6588]
theorem b3_4654 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4654 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4654 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s3_4659 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6748]
theorem b3_4659 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4659 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4659 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5848,v27_5956,v27_6300,v27_6588,v27_6748] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5848 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6748 rfl)))))))))))) (by decide +kernel)
def s3_4688 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6436,w6588]
theorem b3_4688 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4688 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s3_4688 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6136,v27_6300,v27_6436,v27_6588] (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6136 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6436 (PetersenWireProjection.cons pc27_6588 rfl)))))))))))) (by decide +kernel)
def s4_312 : List (BitVec 512) := [w24,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_312 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_313 : List (BitVec 512) := [w24,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_313 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_1599,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_1599 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_314 : List (BitVec 512) := [w24,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_314 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_1832,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_1832 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_315 : List (BitVec 512) := [w24,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_315 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_316 : List (BitVec 512) := [w24,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_316 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(4,true),(2,true))] s4_316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6522,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6522 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_317 : List (BitVec 512) := [w24,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_317 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_318 : List (BitVec 512) := [w24,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_318 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(2,true))] s4_318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6832] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6832 rfl))))))))))) (by decide +kernel)
def s4_319 : List (BitVec 512) := [w24,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_319 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_24,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_24 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_527 : List (BitVec 512) := [w37,w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_527 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_1119,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_528 : List (BitVec 512) := [w37,w1599,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_528 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_1599,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_1599 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_529 : List (BitVec 512) := [w37,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_529 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_2104,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_2104 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_530 : List (BitVec 512) := [w37,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_530 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_3766,v27_4344,v27_4716,v27_4926,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_4926 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_531 : List (BitVec 512) := [w37,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_531 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(0,true),(4,true))] s4_531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6464,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6464 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_532 : List (BitVec 512) := [w37,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_532 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl)))))))))) (by decide +kernel)
def s4_533 : List (BitVec 512) := [w37,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_533 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(0,true))] s4_533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6785] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6785 rfl))))))))))) (by decide +kernel)
def s4_534 : List (BitVec 512) := [w37,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_534 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_37,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588,v27_6873] (PetersenWireProjection.cons pc27_37 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 (PetersenWireProjection.cons pc27_6873 rfl))))))))))) (by decide +kernel)
def s4_970 : List (BitVec 512) := [w160,w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_970 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [] s4_970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_1119,v27_3766,v27_4344,v27_5135,v27_5393,v27_5585,v27_5956,v27_6101,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_1119 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6101 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
def s4_977 : List (BitVec 512) := [w160,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_977 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,false),(4,true))] s4_977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_1666,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6720] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_1666 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6720 rfl))))))))))) (by decide +kernel)
def s4_987 : List (BitVec 512) := [w160,w2759,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_987 := by
  intro m le c
  apply rejects_sound r27 i7 8 tgt (small27 adj) hot27 [(false,(1,true),(4,true))] s4_987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v27_160,v27_2759,v27_3766,v27_4344,v27_4716,v27_5135,v27_5393,v27_5585,v27_5956,v27_6300,v27_6588] (PetersenWireProjection.cons pc27_160 (PetersenWireProjection.cons pc27_2759 (PetersenWireProjection.cons pc27_3766 (PetersenWireProjection.cons pc27_4344 (PetersenWireProjection.cons pc27_4716 (PetersenWireProjection.cons pc27_5135 (PetersenWireProjection.cons pc27_5393 (PetersenWireProjection.cons pc27_5585 (PetersenWireProjection.cons pc27_5956 (PetersenWireProjection.cons pc27_6300 (PetersenWireProjection.cons pc27_6588 rfl))))))))))) (by decide +kernel)
end NineCert
