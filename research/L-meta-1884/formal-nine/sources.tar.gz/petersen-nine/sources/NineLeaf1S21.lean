import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_6227 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_6227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6227 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,true),(0,true))] s4_6227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6173,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6173 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6228 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_6228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6228 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_6228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6237,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6237 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6229 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_6229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6229 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s4_6229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6499,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6499 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6230 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_6230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6230 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false))] s4_6230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6572,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6572 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6231 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6599]
theorem b4_6231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6231 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_6231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6599] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6599 rfl))))))))))) (by decide +kernel)
def s4_6232 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6600]
theorem b4_6232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6232 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_6232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6600] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6600 rfl))))))))))) (by decide +kernel)
def s4_6233 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6601]
theorem b4_6233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6233 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_6233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6601] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6601 rfl))))))))))) (by decide +kernel)
def s4_6234 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6603]
theorem b4_6234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6234 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_6234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6603] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6603 rfl))))))))))) (by decide +kernel)
def s4_6235 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6604]
theorem b4_6235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6235 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_6235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6604] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6604 rfl))))))))))) (by decide +kernel)
def s4_6236 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6606]
theorem b4_6236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6236 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_6236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6606] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6606 rfl))))))))))) (by decide +kernel)
def s4_6237 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6615]
theorem b4_6237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6237 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_6237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6615] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6615 rfl))))))))))) (by decide +kernel)
def s4_6238 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6616]
theorem b4_6238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6238 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true))] s4_6238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6616] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6616 rfl))))))))))) (by decide +kernel)
def s4_6239 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_6239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6239 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_6239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6618] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6618 rfl))))))))))) (by decide +kernel)
def s4_6240 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6620]
theorem b4_6240 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6240 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true))] s4_6240 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6620] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6620 rfl))))))))))) (by decide +kernel)
def s4_6241 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6621]
theorem b4_6241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6241 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_6241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6621] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6621 rfl))))))))))) (by decide +kernel)
def s4_6242 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6623]
theorem b4_6242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6242 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_6242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6623] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6623 rfl))))))))))) (by decide +kernel)
def s4_6243 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6643]
theorem b4_6243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6243 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true))] s4_6243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6643] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6643 rfl))))))))))) (by decide +kernel)
def s4_6244 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6644]
theorem b4_6244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6244 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_6244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6644] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6644 rfl))))))))))) (by decide +kernel)
def s4_6245 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6645]
theorem b4_6245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6245 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_6245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6645] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6645 rfl))))))))))) (by decide +kernel)
def s4_6246 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6647]
theorem b4_6246 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6246 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_6246 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6647] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6647 rfl))))))))))) (by decide +kernel)
def s4_6247 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_6247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6247 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(3,true),(2,true)),(false,(1,false),(0,false))] s4_6247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6821] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6821 rfl))))))))))) (by decide +kernel)
def s4_6248 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_6248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6248 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(3,true),(2,true)),(false,(1,false),(0,false))] s4_6248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6859] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6859 rfl))))))))))) (by decide +kernel)
def s4_6249 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_6249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6249 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false))] s4_6249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6868] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6868 rfl))))))))))) (by decide +kernel)
def s4_6250 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_6250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6250 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s4_6250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6869] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6869 rfl))))))))))) (by decide +kernel)
def s4_6251 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_6251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6251 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false))] s4_6251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6897] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6897 rfl))))))))))) (by decide +kernel)
def s4_6252 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_6252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6252 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,false))] s4_6252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6905] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6905 rfl))))))))))) (by decide +kernel)
def s4_6253 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_6253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6253 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(1,false))] s4_6253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6389,v1_6549,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6549 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6254 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_6254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6254 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(9,true),(0,false))] s4_6254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_6255 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6588,w6873]
theorem b4_6255 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6255 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(9,true),(1,false))] s4_6255 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6567,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6567 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_6256 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_6256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6256 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(3,true)),(false,(8,true),(1,false))] s4_6256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6543,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6543 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6257 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_6257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6257 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s4_6257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6258 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_6258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6258 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(9,true),(8,true))] s4_6258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_6259 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_6259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6259 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(8,true),(1,false))] s4_6259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_6260 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b4_6260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6260 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true))] s4_6260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6261 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_6261 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6261 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true))] s4_6261 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_6262 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_6262 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6262 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(8,true),(0,false))] s4_6262 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6225,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6263 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_6263 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6263 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true))] s4_6263 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_6179,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6264 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_6264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6264 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s4_6264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_6179,v1_6300,v1_6588,v1_6832] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_6265 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_6265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6265 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(7,true),(9,true))] s4_6265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6464,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_6266 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_6266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6266 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_6266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6267 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_6267 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6267 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_6267 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5585,v1_5956,v1_6300,v1_6588,v1_6690] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6690 rfl))))))))))) (by decide +kernel)
def s4_6268 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_6268 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6268 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_6268 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5471,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5471 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6269 : List (BitVec 512) := [w1170,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_6269 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6269 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s4_6269 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5471,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5471 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_6270 : List (BitVec 512) := [w1170,w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_6270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6270 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true))] s4_6270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_4926,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6271 : List (BitVec 512) := [w1170,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_6271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6271 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(4,true),(1,false))] s4_6271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6895] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6895 rfl))))))))))) (by decide +kernel)
def s4_6272 : List (BitVec 512) := [w1170,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b4_6272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6272 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(3,true)),(false,(9,true),(4,true))] s4_6272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6389,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6273 : List (BitVec 512) := [w1170,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_6273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6273 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_6273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_6274 : List (BitVec 512) := [w1170,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_6274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6274 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true))] s4_6274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6061,v1_6101,v1_6300,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_6275 : List (BitVec 512) := [w1170,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6720]
theorem b4_6275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6275 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true))] s4_6275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6522,v1_6588,v1_6720] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_6276 : List (BitVec 512) := [w1170,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_6276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6276 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true))] s4_6276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_6277 : List (BitVec 512) := [w1170,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6389,w6522,w6588]
theorem b4_6277 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6277 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true))] s4_6277 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1170,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7212 : List (BitVec 512) := [w1292,w2313,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7212 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7226 : List (BitVec 512) := [w1292,w2555,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7226 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7227 : List (BitVec 512) := [w1292,w2589,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7227 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7228 : List (BitVec 512) := [w1292,w2608,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7228 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7229 : List (BitVec 512) := [w1292,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_7229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7229 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(8,true))] s4_7229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7230 : List (BitVec 512) := [w1292,w2636,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7230 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7231 : List (BitVec 512) := [w1292,w2642,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7231 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(8,true))] s4_7231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2642,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2642 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7232 : List (BitVec 512) := [w1292,w2644,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7232 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7233 : List (BitVec 512) := [w1292,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6422,w6588]
theorem b4_7233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7233 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(9,true))] s4_7233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7234 : List (BitVec 512) := [w1292,w2650,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7234 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7235 : List (BitVec 512) := [w1292,w2652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7235 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(9,true))] s4_7235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2652,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2652 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7236 : List (BitVec 512) := [w1292,w2659,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7236 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_7236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2659,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2659 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7237 : List (BitVec 512) := [w1292,w2667,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7237 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
