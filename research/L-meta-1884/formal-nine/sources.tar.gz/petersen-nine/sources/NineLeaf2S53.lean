import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3738 : List (BitVec 512) := [w2393,w2691,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3738 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3738 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_3738 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2691,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2691 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3739 : List (BitVec 512) := [w2393,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3739 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3739 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(4,true))] s5_3739 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3740 : List (BitVec 512) := [w2393,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6720]
theorem b5_3740 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3740 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true)),(false,(9,true),(5,true))] s5_3740 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2393,v2_3766,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2393 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3741 : List (BitVec 512) := [w2394,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3741 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3741 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3741 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2394,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2394 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3742 : List (BitVec 512) := [w2395,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3742 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3742 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3742 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2395,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2395 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3743 : List (BitVec 512) := [w2396,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3743 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3743 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3743 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2396,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2396 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3744 : List (BitVec 512) := [w2397,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3744 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3744 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3744 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2397,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2397 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3745 : List (BitVec 512) := [w2398,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3745 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3745 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(0,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3745 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2398,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2398 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3746 : List (BitVec 512) := [w2399,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3746 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3746 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3746 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2399,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2399 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3747 : List (BitVec 512) := [w2400,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3747 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3747 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3747 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2400,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2400 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3750 : List (BitVec 512) := [w2401,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3750 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3750 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3750 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2401,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2401 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3751 : List (BitVec 512) := [w2402,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3751 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3751 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3751 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2402,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2402 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3754 : List (BitVec 512) := [w2403,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3754 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3754 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true)),(false,(0,false),(4,true))] s5_3754 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2403,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2403 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3755 : List (BitVec 512) := [w2404,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3755 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3755 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3755 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2404,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2404 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3758 : List (BitVec 512) := [w2405,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3758 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3758 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3758 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2405,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2405 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3759 : List (BitVec 512) := [w2406,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3759 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3759 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false))] s5_3759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2406,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2406 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3764 : List (BitVec 512) := [w2410,w2690,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588]
theorem b5_3764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3764 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(5,true),(6,true))] s5_3764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3765 : List (BitVec 512) := [w2410,w3258,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3765 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true)),(false,(5,true),(9,true))] s5_3765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3766 : List (BitVec 512) := [w2410,w3296,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3766 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false)),(false,(3,true),(0,true))] s5_3766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3296,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3296 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3767 : List (BitVec 512) := [w2410,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3767 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true)),(false,(9,true),(5,true))] s5_3767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3303,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3768 : List (BitVec 512) := [w2410,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3768 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true)),(false,(5,true),(9,true))] s5_3768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3321,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3321 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3769 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6604]
theorem b5_3769 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3769 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(10,true))] s5_3769 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588,v2_6604] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6604 rfl)))))))))) (by decide +kernel)
def s5_3770 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6890]
theorem b5_3770 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3770 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,false),(9,true)),(false,(6,true),(5,true))] s5_3770 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_3771 : List (BitVec 512) := [w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6785,w6873]
theorem b5_3771 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3771 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(4,true),(5,true)),(false,(10,true),(6,true))] s5_3771 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3772 : List (BitVec 512) := [w2410,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_3772 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3772 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_3772 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3773 : List (BitVec 512) := [w2410,w3766,w4716,w5135,w5393,w5585,w5698,w6389,w6522,w6588]
theorem b5_3773 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3773 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true)),(false,(6,true),(4,true))] s5_3773 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3774 : List (BitVec 512) := [w2410,w3766,w4926,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b5_3774 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3774 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(5,true),(3,true)),(false,(9,true),(4,true))] s5_3774 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3775 : List (BitVec 512) := [w2410,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_3775 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3775 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(3,true),(5,true)),(false,(5,true),(9,true))] s5_3775 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_4926,v2_5135,v2_5393,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3776 : List (BitVec 512) := [w2410,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6690,w6720]
theorem b5_3776 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3776 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(3,true),(9,true)),(false,(9,true),(5,true))] s5_3776 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3766,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3777 : List (BitVec 512) := [w2410,w3901,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b5_3777 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3777 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(4,true),(5,true)),(false,(1,true),(3,true))] s5_3777 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3901,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3778 : List (BitVec 512) := [w2410,w3901,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b5_3778 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3778 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,true),(6,true)),(false,(8,true),(9,true)),(false,(1,true),(3,true))] s5_3778 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3901,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3901 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3779 : List (BitVec 512) := [w2410,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3779 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3779 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(4,true),(8,true)),(false,(1,true),(3,true))] s5_3779 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2410,v2_3935,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3935 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3780 : List (BitVec 512) := [w2411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3780 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3780 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s5_3780 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2411,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2411 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3781 : List (BitVec 512) := [w2412,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3781 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3781 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s5_3781 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2412,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2412 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3782 : List (BitVec 512) := [w2413,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3782 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3782 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s5_3782 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2413,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2413 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3783 : List (BitVec 512) := [w2414,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3783 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3783 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3783 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2414,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2414 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3784 : List (BitVec 512) := [w2415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3784 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3784 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3784 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3785 : List (BitVec 512) := [w2416,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3785 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3785 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3785 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2416,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2416 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3786 : List (BitVec 512) := [w2417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3786 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3786 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3786 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2417,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2417 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3789 : List (BitVec 512) := [w2418,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3789 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3789 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s5_3789 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2418,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2418 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3790 : List (BitVec 512) := [w2419,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3790 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3790 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3790 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2419,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2419 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3793 : List (BitVec 512) := [w2420,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3793 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3793 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(2,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3793 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2420,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2420 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3794 : List (BitVec 512) := [w2421,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3794 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3794 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(2,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s5_3794 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2421,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2421 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3795 : List (BitVec 512) := [w2422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3795 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3795 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s5_3795 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2422,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2422 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3796 : List (BitVec 512) := [w2423,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3796 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3796 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true)),(false,(0,false),(9,true))] s5_3796 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2423,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2423 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3799 : List (BitVec 512) := [w2426,w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3799 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3799 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s5_3799 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3800 : List (BitVec 512) := [w2426,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3800 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3800 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(2,false))] s5_3800 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3801 : List (BitVec 512) := [w2426,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3801 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3801 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(4,true),(2,false))] s5_3801 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3802 : List (BitVec 512) := [w2426,w2691,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3802 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3802 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(0,false),(9,true)),(false,(7,true),(0,true))] s5_3802 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_2691,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_2691 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3803 : List (BitVec 512) := [w2426,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3803 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3803 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(2,false),(5,true))] s5_3803 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3804 : List (BitVec 512) := [w2426,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3804 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3804 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(2,false),(9,true))] s5_3804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3805 : List (BitVec 512) := [w2426,w3296,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3805 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3805 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(7,true),(0,false)),(false,(3,true),(0,true))] s5_3805 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2426,v2_3296,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2426 (PetersenWireProjection.cons pc2_3296 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3808 : List (BitVec 512) := [w2430,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3808 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3808 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s5_3808 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2430,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2430 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3809 : List (BitVec 512) := [w2431,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3809 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3809 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s5_3809 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_2496,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_2496 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3810 : List (BitVec 512) := [w2431,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3810 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3810 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(4,true)),(false,(0,false),(8,true))] s5_3810 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3811 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_3811 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3811 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(3,true),(1,false)),(false,(1,true),(7,true))] s5_3811 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5200,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5200 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3813 : List (BitVec 512) := [w2433,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3813 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3813 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(1,true),(0,true)),(false,(0,true),(5,true))] s5_3813 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2433,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2433 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3815 : List (BitVec 512) := [w2435,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3815 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3815 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,false))] s5_3815 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_2497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_2497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3816 : List (BitVec 512) := [w2435,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3816 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3816 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(2,false),(5,true))] s5_3816 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3817 : List (BitVec 512) := [w2435,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3817 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3817 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(2,false),(8,true))] s5_3817 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3818 : List (BitVec 512) := [w2435,w2693,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3818 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3818 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(9,true),(0,false)),(false,(7,true),(0,true))] s5_3818 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_2693,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_2693 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3819 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w6389,w6522,w6588]
theorem b5_3819 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3819 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(1,false),(7,true)),(false,(5,true),(6,true))] s5_3819 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3820 : List (BitVec 512) := [w2436,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3820 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3820 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true)),(false,(0,false),(2,false))] s5_3820 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3821 : List (BitVec 512) := [w2436,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3821 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3821 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(1,false),(5,true))] s5_3821 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
