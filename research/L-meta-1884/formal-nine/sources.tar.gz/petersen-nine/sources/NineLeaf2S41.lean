import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12612 : List (BitVec 512) := [w2488,w3766,w4041,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12612 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12637 : List (BitVec 512) := [w2488,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12637 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12638 : List (BitVec 512) := [w2488,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12639 : List (BitVec 512) := [w2488,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12639 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12640 : List (BitVec 512) := [w2488,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12640 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12640 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12640 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12741 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6061,w6300,w6588]
theorem b4_12741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12741 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12742 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6389,w6588]
theorem b4_12742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12742 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12743 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6543,w6588]
theorem b4_12743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12743 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12744 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6588]
theorem b4_12744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12744 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12745 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5289,w5585,w5956,w6061,w6300,w6588]
theorem b4_12745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12745 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12746 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5289,w5585,w5956,w6300,w6543,w6588]
theorem b4_12746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12746 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12747 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5289,w5585,w5956,w6300,w6588]
theorem b4_12747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12747 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5289,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5289 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12748 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5299,w5585,w5956,w6061,w6300,w6588]
theorem b4_12748 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12748 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12748 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12749 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5299,w5585,w5956,w6300,w6389,w6588]
theorem b4_12749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12749 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12750 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5299,w5585,w5956,w6300,w6543,w6588]
theorem b4_12750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12750 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12751 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5299,w5585,w5956,w6300,w6588]
theorem b4_12751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12751 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12752 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5301,w5585,w5956,w6300,w6389,w6588]
theorem b4_12752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12752 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5301,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5301 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12753 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5301,w5585,w5956,w6300,w6543,w6588]
theorem b4_12753 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12753 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12753 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5301,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5301 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12754 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5301,w5585,w5956,w6300,w6588]
theorem b4_12754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12754 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5301,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5301 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12755 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5313,w5585,w5956,w6061,w6300,w6588]
theorem b4_12755 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12755 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12755 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12756 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5313,w5585,w5956,w6300,w6389,w6588]
theorem b4_12756 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12756 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12756 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12757 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5313,w5585,w5956,w6300,w6543,w6588]
theorem b4_12757 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12757 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12757 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12758 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5313,w5585,w5956,w6300,w6588]
theorem b4_12758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12758 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12759 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_12759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12759 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(5,true))] s4_12759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12760 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_12760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12760 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(8,true))] s4_12760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12761 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_12761 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12761 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(7,true))] s4_12761 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12762 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_12762 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12762 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(1,false),(8,true))] s4_12762 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12763 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_12763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12763 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(1,false),(7,true))] s4_12763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12764 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_12764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12764 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(1,false),(8,true))] s4_12764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12765 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_12765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12765 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s4_12765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12766 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_12766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12766 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(1,false),(7,true))] s4_12766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12767 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_12767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12767 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(7,true))] s4_12767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12768 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_12768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12768 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(1,false),(5,true))] s4_12768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_12769 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_12769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12769 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(2,true),(4,true)),(false,(0,false),(4,true))] s4_12769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_12770 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_12770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12770 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(9,true))] s4_12770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_12771 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_12771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12771 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(1,false),(9,true))] s4_12771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_12772 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_12772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12772 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(1,false),(9,true))] s4_12772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6908] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_12773 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_12773 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12773 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(9,true))] s4_12773 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6910] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6910 rfl))))))))))) (by decide +kernel)
def s4_12774 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_12774 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12774 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(5,true),(8,true))] s4_12774 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12775 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_12775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12775 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(5,true),(9,true))] s4_12775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_12776 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_12776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12776 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(4,true),(8,true))] s4_12776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12777 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_12777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12777 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(4,true),(8,true))] s4_12777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12778 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_12778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12778 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(1,false))] s4_12778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12779 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_12779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12779 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(4,true),(7,true))] s4_12779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12839 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6030,w6061,w6300,w6588]
theorem b4_12839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12839 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6030,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6030 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12840 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6030,w6300,w6389,w6588]
theorem b4_12840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12840 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6030,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6030 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12841 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6030,w6300,w6543,w6588]
theorem b4_12841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12841 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6030,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6030 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12842 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6030,w6300,w6588]
theorem b4_12842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12842 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6030,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6030 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12855 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6080,w6300,w6588]
theorem b4_12855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12855 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6080,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12864 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6360,w6588]
theorem b4_12864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12864 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6360,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6360 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12888 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6080,w6300,w6543,w6588]
theorem b4_12888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12888 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6080,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12889 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6080,w6300,w6588]
theorem b4_12889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12889 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6080,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12910 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6360,w6389,w6588]
theorem b4_12910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12910 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6360,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6360 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12911 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6360,w6543,w6588]
theorem b4_12911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12911 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6360,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6360 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12912 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6360,w6588]
theorem b4_12912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12912 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6360,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6360 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12919 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6413,w6588]
theorem b4_12919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12919 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6413,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6413 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12945 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6413,w6543,w6588]
theorem b4_12945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12945 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6413,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6413 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12946 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6413,w6588]
theorem b4_12946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12946 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6413,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6413 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_13022 : List (BitVec 512) := [w2488,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_13022 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13022 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(3,true),(8,true))] s4_13022 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_13025 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_13025 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13025 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(3,true),(7,true))] s4_13025 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_13026 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6690]
theorem b4_13026 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13026 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(3,true),(9,true))] s4_13026 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_13031 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13031 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_13031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_13034 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_13034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13034 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s4_13034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_13035 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_13035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13035 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(0,false),(3,true))] s4_13035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
