import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_16897 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5585,w6179,w6300,w6690,w6832]
theorem b4_16897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16897 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(7,true),(9,true))] s4_16897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_16898 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b4_16898 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16898 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(1,true)),(false,(8,true),(7,true))] s4_16898 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16899 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_16899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16899 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(8,true),(7,true))] s4_16899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_6179,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_16900 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_16900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16900 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(7,true),(0,false))] s4_16900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_6225,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16901 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_16901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16901 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true)),(false,(6,true),(0,false))] s4_16901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5698,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16902 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_16902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16902 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s4_16902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16903 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_16903 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16903 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(7,true),(6,true))] s4_16903 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_16904 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_16904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16904 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true)),(false,(6,true),(1,false))] s4_16904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5769,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16905 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_16905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16905 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(8,true),(6,true))] s4_16905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5769,v0_5956,v0_6464,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_16906 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5956,w6179,w6300,w6588,w6807]
theorem b4_16906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16906 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(6,true)),(false,(6,true),(1,false))] s4_16906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6588,v0_6807] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6807 rfl))))))))))) (by decide +kernel)
def s4_16907 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5956,w6179,w6300,w6785,w6873]
theorem b4_16907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16907 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(6,true),(9,true))] s4_16907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_16908 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w6179,w6300,w6522,w6588,w6785]
theorem b4_16908 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16908 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s4_16908 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_6179,v0_6300,v0_6522,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_16909 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_16909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16909 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_16909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16910 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_16910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16910 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_16910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_16911 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_16911 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16911 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_16911 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5471,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16912 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_16912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16912 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_16912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16913 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5187,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_16913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_16913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16914 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_16914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16914 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_16914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16915 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5200,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16915 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_16915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5200,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5200 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16916 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b4_16916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16916 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_16916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5200,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5200 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16917 : List (BitVec 512) := [w3766,w4344,w4716,w4817,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16917 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_16917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4817,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4817 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16918 : List (BitVec 512) := [w3766,w4344,w4716,w4818,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16918 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_16918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4818,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4818 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16919 : List (BitVec 512) := [w3766,w4344,w4716,w4819,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16919 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_16919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4819,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4819 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16920 : List (BitVec 512) := [w3766,w4344,w4716,w4819,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16920 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_16920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4819,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4819 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16921 : List (BitVec 512) := [w3766,w4344,w4716,w4821,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16921 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_16921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4821,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4821 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16922 : List (BitVec 512) := [w3766,w4344,w4716,w4822,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16922 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_16922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4822,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4822 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16923 : List (BitVec 512) := [w3766,w4344,w4716,w4824,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16923 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_16923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4824,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4824 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16924 : List (BitVec 512) := [w3766,w4344,w4716,w4830,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16924 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_16924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4830,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4830 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16925 : List (BitVec 512) := [w3766,w4344,w4716,w4831,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16925 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_16925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4831,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4831 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16926 : List (BitVec 512) := [w3766,w4344,w4716,w4832,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16926 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_16926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4832,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4832 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16927 : List (BitVec 512) := [w3766,w4344,w4716,w4832,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16927 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_16927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4832,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4832 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16928 : List (BitVec 512) := [w3766,w4344,w4716,w4834,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16928 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_16928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4834,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4834 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16929 : List (BitVec 512) := [w3766,w4344,w4716,w4834,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16929 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_16929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4834,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4834 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_16930 : List (BitVec 512) := [w3766,w4344,w4716,w4835,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_16930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4835,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4835 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16931 : List (BitVec 512) := [w3766,w4344,w4716,w4837,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16931 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_16931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4837,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4837 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16932 : List (BitVec 512) := [w3766,w4344,w4716,w4843,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16932 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4843,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4843 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16933 : List (BitVec 512) := [w3766,w4344,w4716,w4844,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16933 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4844,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4844 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16934 : List (BitVec 512) := [w3766,w4344,w4716,w4845,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16934 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4845,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4845 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16935 : List (BitVec 512) := [w3766,w4344,w4716,w4847,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16935 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4847,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4847 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16936 : List (BitVec 512) := [w3766,w4344,w4716,w4847,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16936 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4847,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4847 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_16937 : List (BitVec 512) := [w3766,w4344,w4716,w4848,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_16937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4848,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4848 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16938 : List (BitVec 512) := [w3766,w4344,w4716,w4850,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16938 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4850,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4850 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16939 : List (BitVec 512) := [w3766,w4344,w4716,w4850,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16939 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_16939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4850,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4850 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_16940 : List (BitVec 512) := [w3766,w4344,w4716,w4854,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16940 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_16940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4854,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4854 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16941 : List (BitVec 512) := [w3766,w4344,w4716,w4855,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16941 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_16941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4855,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4855 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16942 : List (BitVec 512) := [w3766,w4344,w4716,w4856,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16942 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_16942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4856,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4856 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16943 : List (BitVec 512) := [w3766,w4344,w4716,w4858,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16943 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_16943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4858,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4858 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16944 : List (BitVec 512) := [w3766,w4344,w4716,w4858,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_16944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16944 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_16944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4858,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4858 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_16945 : List (BitVec 512) := [w3766,w4344,w4716,w4859,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16945 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_16945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4859,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4859 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16946 : List (BitVec 512) := [w3766,w4344,w4716,w4861,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16946 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_16946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4861,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4861 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16947 : List (BitVec 512) := [w3766,w4344,w4716,w4861,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16947 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_16947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4861,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4861 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_16948 : List (BitVec 512) := [w3766,w4344,w4716,w4865,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_16948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4865,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4865 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_16949 : List (BitVec 512) := [w3766,w4344,w4716,w4865,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16949 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_16949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4865,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4865 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16950 : List (BitVec 512) := [w3766,w4344,w4716,w4866,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16950 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_16950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4866,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4866 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16951 : List (BitVec 512) := [w3766,w4344,w4716,w4867,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16951 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_16951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4867,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4867 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16952 : List (BitVec 512) := [w3766,w4344,w4716,w4869,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16952 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_16952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4869,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4869 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16953 : List (BitVec 512) := [w3766,w4344,w4716,w4870,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16953 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_16953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4870,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4870 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16954 : List (BitVec 512) := [w3766,w4344,w4716,w4872,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_16954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4872,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4872 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_16955 : List (BitVec 512) := [w3766,w4344,w4716,w4872,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16955 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_16955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4872,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4872 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_17004 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_17004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17004 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s4_17004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_17010 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6238,w6300,w6588]
theorem b4_17010 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17010 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,false),(7,true))] s4_17010 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6238,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6238 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_17014 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6500,w6588]
theorem b4_17014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17014 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true))] s4_17014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6500,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6500 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_17018 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6554,w6588]
theorem b4_17018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17018 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s4_17018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6554,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6554 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_17021 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6569,w6588]
theorem b4_17021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17021 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true)),(false,(0,false),(8,true))] s4_17021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6569,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6569 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
