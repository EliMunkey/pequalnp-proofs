import NinePin112
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13045 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6136,w6300,w6553,w6588]
theorem b4_13045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13045 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6136,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13049 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6553,w6588]
theorem b4_13049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13049 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13062 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6572,w6588]
theorem b4_13062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13062 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5698,v112_5956,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13065 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6572,w6588]
theorem b4_13065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13065 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6061,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6061 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13070 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6572,w6588]
theorem b4_13070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13070 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6201,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_13074 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6572,w6588]
theorem b4_13074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13074 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_13074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6543,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_15900 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6066,w6300,w6588]
theorem b4_15900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15900 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_15900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4392,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6066,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4392 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6066 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_15909 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6394,w6588]
theorem b4_15909 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15909 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_15909 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4392,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6394,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4392 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6394 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_15999 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w4932,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15999 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_15999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4403,v112_4716,v112_4932,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4403 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4932 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16034 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6397,w6588]
theorem b4_16034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16034 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4403,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6397,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4403 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6397 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16126 : List (BitVec 512) := [w3766,w4344,w4413,w4716,w4934,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16126 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4413,v112_4716,v112_4934,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4413 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4934 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16144 : List (BitVec 512) := [w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6069,w6300,w6588]
theorem b4_16144 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16144 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16144 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4413,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6069,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4413 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6069 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16173 : List (BitVec 512) := [w3766,w4344,w4415,w4716,w4935,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16173 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4415,v112_4716,v112_4935,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4415 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4935 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16185 : List (BitVec 512) := [w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5708,w5956,w6300,w6588]
theorem b4_16185 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16185 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16185 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4415,v112_4716,v112_5135,v112_5393,v112_5585,v112_5708,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4415 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5708 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16306 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6403,w6588]
theorem b4_16306 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16306 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16306 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4483,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6403,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4483 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6403 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16317 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6698]
theorem b4_16317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16317 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4483,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6698] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4483 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6698 rfl))))))))))) (by decide +kernel)
def s4_16390 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w4950,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16390 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4502,v112_4716,v112_4950,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4502 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4950 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16425 : List (BitVec 512) := [w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6701]
theorem b4_16425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16425 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4502,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6701] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4502 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6701 rfl))))))))))) (by decide +kernel)
def s4_16457 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5719,w5956,w6300,w6588]
theorem b4_16457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16457 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4515,v112_4716,v112_5135,v112_5393,v112_5585,v112_5719,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4515 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5719 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16469 : List (BitVec 512) := [w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6405,w6588]
theorem b4_16469 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16469 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16469 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4515,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6405,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4515 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6405 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16492 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w4952,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16492 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4516,v112_4716,v112_4952,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4516 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4952 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16516 : List (BitVec 512) := [w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6406,w6588]
theorem b4_16516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16516 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4516,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6406,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4516 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6406 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16546 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w4953,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16546 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4519,v112_4716,v112_4953,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4519 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4953 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16558 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5720,w5956,w6300,w6588]
theorem b4_16558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16558 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4519,v112_4716,v112_5135,v112_5393,v112_5585,v112_5720,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4519 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5720 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16698 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w4957,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16698 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4561,v112_4716,v112_4957,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4561 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4957 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16733 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6706]
theorem b4_16733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16733 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4561,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6706] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4561 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6706 rfl))))))))))) (by decide +kernel)
def s4_16753 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w4959,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16753 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16753 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16753 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4571,v112_4716,v112_4959,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4571 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4959 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16991 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4932,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16991 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4932,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4932 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16992 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4934,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16992 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4934,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4934 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16993 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4935,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16993 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4935,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4935 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16995 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4941,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16995 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4941,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4941 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16997 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4944,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16997 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4944,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4944 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_16998 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w4945,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16998 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_16998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_4945,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_4945 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17024 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6578,w6588]
theorem b4_17024 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17024 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17024 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17035 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6870]
theorem b4_17035 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17035 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17035 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4926,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6870] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6870 rfl))))))))))) (by decide +kernel)
def s4_17184 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5705,w5956,w6300,w6588]
theorem b4_17184 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17184 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17184 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5705,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5705 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17186 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5707,w5956,w6300,w6588]
theorem b4_17186 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17186 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17186 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5707,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5707 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17187 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5708,w5956,w6300,w6588]
theorem b4_17187 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17187 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17187 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5708,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5708 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17207 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6578,w6588]
theorem b4_17207 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17207 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17207 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5698,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17483 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6553,w6588]
theorem b4_17483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17483 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17486 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6572,w6588]
theorem b4_17486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17486 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17488 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6578,w6588]
theorem b4_17488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17488 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17505 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6859]
theorem b4_17505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17505 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6859] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6859 rfl))))))))))) (by decide +kernel)
def s4_17507 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6868]
theorem b4_17507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17507 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6868] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6868 rfl))))))))))) (by decide +kernel)
def s4_17509 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6870]
theorem b4_17509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17509 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6870] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6870 rfl))))))))))) (by decide +kernel)
def s4_17512 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6897]
theorem b4_17512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17512 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6897] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6897 rfl))))))))))) (by decide +kernel)
def s4_17514 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6905]
theorem b4_17514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17514 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6905] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6905 rfl))))))))))) (by decide +kernel)
def s4_17516 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6907]
theorem b4_17516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17516 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588,v112_6907] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6907 rfl))))))))))) (by decide +kernel)
def s4_17601 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6499,w6588]
theorem b4_17601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17601 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6136,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17606 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6572,w6588]
theorem b4_17606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17606 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6136,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17608 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6578,w6588]
theorem b4_17608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17608 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6136,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17611 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588,w6897]
theorem b4_17611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17611 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6136,v112_6300,v112_6588,v112_6897] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6897 rfl))))))))))) (by decide +kernel)
def s4_17614 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588,w6913]
theorem b4_17614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17614 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6136,v112_6300,v112_6588,v112_6913] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6136 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6913 rfl))))))))))) (by decide +kernel)
def s4_17643 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6499,w6588]
theorem b4_17643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17643 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6237,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17644 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6553,w6588]
theorem b4_17644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17644 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6237,v112_6300,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17645 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6572,w6588]
theorem b4_17645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17645 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6237,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17647 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6578,w6588]
theorem b4_17647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17647 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6237,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17656 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6553,w6588]
theorem b4_17656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17656 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6499,v112_6553,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6553 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17657 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6572,w6588]
theorem b4_17657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17657 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6499,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17658 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6578,w6588]
theorem b4_17658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17658 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6499,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s4_17663 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6578,w6588]
theorem b4_17663 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17663 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s4_17663 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6572,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl))))))))))) (by decide +kernel)
def s5_182 : List (BitVec 512) := [w79,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_182 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_182 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_182 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_79,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_79 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_1486 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6691]
theorem b5_1486 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1486 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1486 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_972,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6691] (PetersenWireProjection.cons pc112_972 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6691 rfl)))))))))) (by decide +kernel)
def s5_1498 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6693]
theorem b5_1498 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1498 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_1498 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_975,v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6693] (PetersenWireProjection.cons pc112_975 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6693 rfl)))))))))) (by decide +kernel)
end NineCert
