import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17400 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5776,w5956,w6300,w6588]
theorem b4_17400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17400 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true)),(false,(0,true),(7,true))] s4_17400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5776,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5776 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_17408 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5792,w5956,w6300,w6588]
theorem b4_17408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17408 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(0,true),(7,true))] s4_17408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5792,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5792 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_17432 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5828,w5848,w5956,w6300,w6588]
theorem b4_17432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17432 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_17432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5828,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5828 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17433 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5828,w5956,w6300,w6588]
theorem b4_17433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17433 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_17433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5828,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5828 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_17440 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5833,w5848,w5956,w6300,w6588]
theorem b4_17440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17440 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s4_17440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5833,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5833 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17441 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5833,w5956,w6300,w6588]
theorem b4_17441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17441 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_17441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5833,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5833 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_17447 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5840,w5848,w5956,w6300,w6588]
theorem b4_17447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17447 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true))] s4_17447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5840,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5840 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17448 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5840,w5956,w6300,w6588]
theorem b4_17448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17448 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_17448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5840,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5840 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_17482 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6549,w6588]
theorem b4_17482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17482 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(8,true))] s4_17482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17520 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6720,w6873]
theorem b4_17520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17520 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(4,true))] s4_17520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17532 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w6101,w6300,w6522,w6588]
theorem b4_17532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17532 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(7,true))] s4_17532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5848,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17582 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6464,w6720,w6873]
theorem b4_17582 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17582 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s4_17582 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6464,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17584 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6522,w6720,w6873]
theorem b4_17584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17584 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(4,true))] s4_17584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17600 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6489,w6588]
theorem b4_17600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17600 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(7,true),(4,true))] s4_17600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17602 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6553,w6588]
theorem b4_17602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17602 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true))] s4_17602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6300,v4_6553,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6553 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_17617 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6720,w6873]
theorem b4_17617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17617 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(5,true))] s4_17617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17636 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6690,w6720]
theorem b4_17636 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17636 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(8,true),(7,true))] s4_17636 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6690,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_17653 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6720,w6890]
theorem b4_17653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17653 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_17653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6436,v4_6720,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_17678 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610]
theorem b4_17678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17678 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_17678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl))))))))) (by decide +kernel)
def s4_17679 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610,w6720]
theorem b4_17679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17679 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_17679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_17778 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6716]
theorem b4_17778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17778 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s4_17778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6716] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6716 rfl)))))))))) (by decide +kernel)
def s4_17779 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6716,w6720]
theorem b4_17779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17779 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s4_17779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6716,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6716 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_17780 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6716,w6807]
theorem b4_17780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17780 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(7,true),(0,false))] s4_17780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6716,v4_6807] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6716 (PetersenWireProjection.cons pc4_6807 rfl))))))))))) (by decide +kernel)
def s4_17781 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6717]
theorem b4_17781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17781 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_17781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6717] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6717 rfl)))))))))) (by decide +kernel)
def s4_17782 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6717,w6720]
theorem b4_17782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17782 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_17782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6717,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6717 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_17783 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6717,w6852]
theorem b4_17783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17783 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(8,true))] s4_17783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6717,v4_6852] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6717 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
def s4_17784 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6719]
theorem b4_17784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17784 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_17784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6719] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6719 rfl)))))))))) (by decide +kernel)
def s4_17785 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6719,w6720]
theorem b4_17785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17785 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_17785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6719,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6719 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_17786 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6719,w6890]
theorem b4_17786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17786 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true))] s4_17786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6719,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6719 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_17880 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_17880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17880 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(5,true),(3,true))] s4_17880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6857] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6857 rfl)))))))))) (by decide +kernel)
def s4_17899 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6719]
theorem b4_17899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17899 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_17899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6719] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6719 rfl))))))))) (by decide +kernel)
def s4_17900 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6719,w6720]
theorem b4_17900 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17900 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_17900 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6719,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6719 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_17901 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6719,w6720,w6890]
theorem b4_17901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17901 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_17901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6719,v4_6720,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6719 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_17902 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6719,w6890]
theorem b4_17902 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17902 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_17902 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6719,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6719 (PetersenWireProjection.cons pc4_6890 rfl)))))))))) (by decide +kernel)
def s4_17923 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890,w6897]
theorem b4_17923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17923 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_17923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6890,v4_6897] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 (PetersenWireProjection.cons pc4_6897 rfl))))))))))) (by decide +kernel)
def s4_17941 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6720,w6890]
theorem b4_17941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17941 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_17941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6422,v4_6720,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_17968 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6489,w6720,w6873]
theorem b4_17968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17968 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s4_17968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6489,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17974 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6718,w6720,w6873]
theorem b4_17974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17974 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s4_17974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6718,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6718 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_17975 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6718,w6873]
theorem b4_17975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17975 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s4_17975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6718,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6718 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s4_17984 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6895]
theorem b4_17984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17984 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s4_17984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6720,v4_6873,v4_6895] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_18001 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6549,w6720,w6873]
theorem b4_18001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18001 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_18001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6549,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_18007 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6895]
theorem b4_18007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18007 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(8,true))] s4_18007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6720,v4_6873,v4_6895] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_18022 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6720,w6873]
theorem b4_18022 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18022 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(5,true))] s4_18022 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_18029 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6101,w6389,w6522,w6588]
theorem b4_18029 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18029 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(4,true))] s4_18029 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_18030 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6101,w6522,w6588,w6873]
theorem b4_18030 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18030 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(4,true))] s4_18030 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6101,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_18031 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6389,w6522,w6588]
theorem b4_18031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18031 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(4,true))] s4_18031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_18032 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6522,w6588,w6873]
theorem b4_18032 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18032 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(4,true))] s4_18032 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s4_18048 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6690,w6720]
theorem b4_18048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18048 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(3,true))] s4_18048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6690,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_18065 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6549,w6588,w6873]
theorem b4_18065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18065 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_18065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6549,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_18072 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b4_18072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18072 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_18072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_27 : List (BitVec 512) := [w8,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_27 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_27 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_27 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_8,v4_2690,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_8 (PetersenWireProjection.cons pc4_2690 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_28 : List (BitVec 512) := [w8,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_28 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_28 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_28 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_8,v4_2696,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_8 (PetersenWireProjection.cons pc4_2696 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_29 : List (BitVec 512) := [w8,w2701,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_29 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_29 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(2,true),(0,true))] s5_29 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_8,v4_2701,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_8 (PetersenWireProjection.cons pc4_2701 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_49 : List (BitVec 512) := [w15,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_49 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_49 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_49 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_15,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_15 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_50 : List (BitVec 512) := [w15,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_50 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_50 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_50 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_15,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_15 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_51 : List (BitVec 512) := [w15,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_51 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_51 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s5_51 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_15,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_15 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_52 : List (BitVec 512) := [w15,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_52 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_52 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(4,true),(3,true)),(false,(1,false),(0,false)),(false,(8,true),(0,true))] s5_52 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_15,v4_2528,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_15 (PetersenWireProjection.cons pc4_2528 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_53 : List (BitVec 512) := [w15,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_53 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_53 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_53 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_15,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_15 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_70 : List (BitVec 512) := [w23,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_70 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_70 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_70 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_71 : List (BitVec 512) := [w23,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_71 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_71 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(1,true),(0,true))] s5_71 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_2690,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_2690 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_72 : List (BitVec 512) := [w23,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_72 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_72 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_72 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_2696,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_2696 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_73 : List (BitVec 512) := [w23,w2701,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_73 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_73 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(2,true),(0,true))] s5_73 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_2701,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_2701 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_74 : List (BitVec 512) := [w23,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_74 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_74 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_74 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_75 : List (BitVec 512) := [w23,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_75 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_75 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_75 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_23,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_23 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
