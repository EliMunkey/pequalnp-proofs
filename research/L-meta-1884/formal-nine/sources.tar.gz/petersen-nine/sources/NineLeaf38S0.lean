import NinePin38
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5735 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5453,w5585,w5956,w6300,w6588]
theorem b5_5735 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5735 := by
  intro m le c
  apply rejects_sound r38 i7 8 tgt (small38 adj) hot38 [(false,(0,true),(1,true))] s5_5735 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v38_3766,v38_4344,v38_4716,v38_4926,v38_5135,v38_5453,v38_5585,v38_5956,v38_6300,v38_6588] (PetersenWireProjection.cons pc38_3766 (PetersenWireProjection.cons pc38_4344 (PetersenWireProjection.cons pc38_4716 (PetersenWireProjection.cons pc38_4926 (PetersenWireProjection.cons pc38_5135 (PetersenWireProjection.cons pc38_5453 (PetersenWireProjection.cons pc38_5585 (PetersenWireProjection.cons pc38_5956 (PetersenWireProjection.cons pc38_6300 (PetersenWireProjection.cons pc38_6588 rfl)))))))))) (by decide +kernel)
end NineCert
