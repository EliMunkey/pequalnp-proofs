import NinePin293
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4910 : List (BitVec 512) := [w1002,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4910 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4910 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s4_4910 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_1002,v293_3766,v293_4344,v293_4561,v293_4716,v293_5135,v293_5393,v293_5585,v293_5956,v293_6300,v293_6588] (PetersenWireProjection.cons pc293_1002 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4561 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5135 (PetersenWireProjection.cons pc293_5393 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6300 (PetersenWireProjection.cons pc293_6588 rfl))))))))))) (by decide +kernel)
def s4_9811 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_9811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9811 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s4_9811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_1403,v293_2468,v293_3766,v293_4344,v293_4716,v293_5135,v293_5585,v293_5956,v293_6389,v293_6522,v293_6588] (PetersenWireProjection.cons pc293_1403 (PetersenWireProjection.cons pc293_2468 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5135 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6389 (PetersenWireProjection.cons pc293_6522 (PetersenWireProjection.cons pc293_6588 rfl))))))))))) (by decide +kernel)
def s4_9815 : List (BitVec 512) := [w1403,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_9815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9815 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s4_9815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_1403,v293_2488,v293_3766,v293_4344,v293_4716,v293_5135,v293_5585,v293_5956,v293_6300,v293_6543,v293_6588] (PetersenWireProjection.cons pc293_1403 (PetersenWireProjection.cons pc293_2488 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5135 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6300 (PetersenWireProjection.cons pc293_6543 (PetersenWireProjection.cons pc293_6588 rfl))))))))))) (by decide +kernel)
def s5_3104 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5187,w5585,w5956,w6522,w6588]
theorem b5_3104 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3104 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s5_3104 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_1403,v293_2468,v293_3766,v293_4344,v293_4716,v293_5187,v293_5585,v293_5956,v293_6522,v293_6588] (PetersenWireProjection.cons pc293_1403 (PetersenWireProjection.cons pc293_2468 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5187 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6522 (PetersenWireProjection.cons pc293_6588 rfl)))))))))) (by decide +kernel)
def s5_4253 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5187,w5585,w5956,w6389,w6522,w6588]
theorem b5_4253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4253 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s5_4253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_2468,v293_3766,v293_4344,v293_4716,v293_5187,v293_5585,v293_5956,v293_6389,v293_6522,v293_6588] (PetersenWireProjection.cons pc293_2468 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5187 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6389 (PetersenWireProjection.cons pc293_6522 (PetersenWireProjection.cons pc293_6588 rfl)))))))))) (by decide +kernel)
def s5_4498 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6541,w6588]
theorem b5_4498 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4498 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s5_4498 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_2488,v293_3766,v293_4344,v293_4716,v293_5135,v293_5585,v293_5956,v293_6300,v293_6541,v293_6588] (PetersenWireProjection.cons pc293_2488 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5135 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6300 (PetersenWireProjection.cons pc293_6541 (PetersenWireProjection.cons pc293_6588 rfl)))))))))) (by decide +kernel)
def s5_4577 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5187,w5585,w5956,w6300,w6543,w6588]
theorem b5_4577 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4577 := by
  intro m le c
  apply rejects_sound r293 i5 4 tgt (small293 adj) hot293 [] s5_4577 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v293_2488,v293_3766,v293_4344,v293_4716,v293_5187,v293_5585,v293_5956,v293_6300,v293_6543,v293_6588] (PetersenWireProjection.cons pc293_2488 (PetersenWireProjection.cons pc293_3766 (PetersenWireProjection.cons pc293_4344 (PetersenWireProjection.cons pc293_4716 (PetersenWireProjection.cons pc293_5187 (PetersenWireProjection.cons pc293_5585 (PetersenWireProjection.cons pc293_5956 (PetersenWireProjection.cons pc293_6300 (PetersenWireProjection.cons pc293_6543 (PetersenWireProjection.cons pc293_6588 rfl)))))))))) (by decide +kernel)
end NineCert
