import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5568 : List (BitVec 512) := [w3766,w4344,w4467,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5568 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5568 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_5568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4467,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4467 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5570 : List (BitVec 512) := [w3766,w4344,w4469,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5570 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5570 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s5_5570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4469,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4469 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5572 : List (BitVec 512) := [w3766,w4344,w4472,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5572 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5572 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5572 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4472,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4472 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5573 : List (BitVec 512) := [w3766,w4344,w4473,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5573 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5573 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5573 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4473,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4473 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5574 : List (BitVec 512) := [w3766,w4344,w4474,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5574 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5574 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5574 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4474,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4474 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5575 : List (BitVec 512) := [w3766,w4344,w4475,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5575 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5575 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5575 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4475,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4475 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5577 : List (BitVec 512) := [w3766,w4344,w4477,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5577 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5577 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5577 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4477,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4477 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5578 : List (BitVec 512) := [w3766,w4344,w4478,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5578 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5578 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_5578 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4478,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4478 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5580 : List (BitVec 512) := [w3766,w4344,w4481,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5580 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5580 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true))] s5_5580 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4481,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4481 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5584 : List (BitVec 512) := [w3766,w4344,w4483,w4926,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_5584 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5584 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(5,true)),(false,(7,true),(0,true))] s5_5584 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4483,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4483 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5590 : List (BitVec 512) := [w3766,w4344,w4492,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5590 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5590 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s5_5590 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4492,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4492 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5591 : List (BitVec 512) := [w3766,w4344,w4493,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5591 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5591 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,false)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s5_5591 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4493,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4493 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5593 : List (BitVec 512) := [w3766,w4344,w4495,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5593 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5593 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s5_5593 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4495,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4495 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5594 : List (BitVec 512) := [w3766,w4344,w4496,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5594 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5594 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s5_5594 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4496,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4496 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5599 : List (BitVec 512) := [w3766,w4344,w4504,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5599 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5599 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(2,true),(0,false)),(false,(7,true),(0,true))] s5_5599 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4504,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4504 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5601 : List (BitVec 512) := [w3766,w4344,w4507,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5601 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5601 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5601 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4507,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4507 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5602 : List (BitVec 512) := [w3766,w4344,w4508,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5602 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5602 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,false)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5602 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4508,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4508 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5604 : List (BitVec 512) := [w3766,w4344,w4510,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5604 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5604 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5604 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4510,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4510 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5605 : List (BitVec 512) := [w3766,w4344,w4511,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5605 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5605 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5605 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4511,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4511 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5607 : List (BitVec 512) := [w3766,w4344,w4513,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5607 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5607 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5607 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4513,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4513 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5608 : List (BitVec 512) := [w3766,w4344,w4514,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5608 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s5_5608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4514,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4514 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5610 : List (BitVec 512) := [w3766,w4344,w4515,w4926,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_5610 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5610 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true)),(false,(3,true),(7,true))] s5_5610 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5611 : List (BitVec 512) := [w3766,w4344,w4515,w5135,w5393,w5585,w6101,w6300,w6588,w6720]
theorem b5_5611 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5611 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true)),(false,(3,true),(7,true))] s5_5611 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5612 : List (BitVec 512) := [w3766,w4344,w4515,w5135,w5393,w5585,w6101,w6300,w6588,w6748]
theorem b5_5612 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5612 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(6,true)),(false,(3,true),(7,true))] s5_5612 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4515,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4515 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_5614 : List (BitVec 512) := [w3766,w4344,w4517,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5614 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5614 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(7,true))] s5_5614 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4517,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4517 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5618 : List (BitVec 512) := [w3766,w4344,w4520,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5618 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5618 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(7,true))] s5_5618 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4520,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4520 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5621 : List (BitVec 512) := [w3766,w4344,w4521,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5621 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5621 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(7,true))] s5_5621 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4521,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4521 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5624 : List (BitVec 512) := [w3766,w4344,w4530,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5624 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5624 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s5_5624 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4530,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4530 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5626 : List (BitVec 512) := [w3766,w4344,w4532,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5626 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5626 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s5_5626 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4532,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4532 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5634 : List (BitVec 512) := [w3766,w4344,w4548,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5634 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5634 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_5634 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4548,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4548 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5636 : List (BitVec 512) := [w3766,w4344,w4550,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5636 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_5636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4550,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4550 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5638 : List (BitVec 512) := [w3766,w4344,w4552,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5638 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_5638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4552,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4552 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5639 : List (BitVec 512) := [w3766,w4344,w4553,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5639 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5639 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s5_5639 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4553,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4553 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5644 : List (BitVec 512) := [w3766,w4344,w4561,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_5644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5644 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(5,true)),(false,(7,true),(6,true))] s5_5644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4561,v3_4716,v3_5135,v3_5393,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4561 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5645 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5645 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(0,true),(6,true))] s5_5645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4563,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4563 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5652 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5652 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5652 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(6,true))] s5_5652 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4572,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4572 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5658 : List (BitVec 512) := [w3766,w4344,w4577,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5658 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_5658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4577,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4577 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5659 : List (BitVec 512) := [w3766,w4344,w4577,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_5659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5659 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_5659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4577,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4577 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_5661 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w4892,w5135,w5585,w5956,w6300,w6588]
theorem b5_5661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5661 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(3,false))] s5_5661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4583,v3_4716,v3_4892,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4892 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5662 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5263,w5585,w5956,w6300,w6588]
theorem b5_5662 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5662 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(6,false))] s5_5662 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5263,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5263 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5663 : List (BitVec 512) := [w3766,w4344,w4583,w4716,w5135,w5460,w5585,w5956,w6300,w6588]
theorem b5_5663 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5663 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,false))] s5_5663 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5460,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5460 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5745 : List (BitVec 512) := [w3766,w4344,w4716,w4941,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5745 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5745 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s5_5745 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4941,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4941 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5746 : List (BitVec 512) := [w3766,w4344,w4716,w4943,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_5746 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5746 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(2,true)),(false,(1,true),(5,true))] s5_5746 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4943,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4943 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5747 : List (BitVec 512) := [w3766,w4344,w4716,w4944,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5747 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5747 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s5_5747 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4944,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4944 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5748 : List (BitVec 512) := [w3766,w4344,w4716,w4945,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5748 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5748 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s5_5748 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_4945,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4945 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5796 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5705,w5956,w6300,w6588]
theorem b5_5796 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5796 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_5796 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5705,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5705 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5798 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5708,w5956,w6300,w6588]
theorem b5_5798 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5798 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_5798 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5708,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5708 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5803 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5748,w5956,w6522,w6588]
theorem b5_5803 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5803 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(7,false),(0,true)),(false,(8,true),(7,true))] s5_5803 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5748,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5748 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5849 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5831,w5956,w6522,w6588]
theorem b5_5849 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5849 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(7,false),(0,true)),(false,(8,true),(7,true))] s5_5849 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5831,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5831 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5927 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6595,w6690]
theorem b5_5927 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5927 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true))] s5_5927 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6595,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6595 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_5930 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6598]
theorem b5_5930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5930 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6598] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6598 rfl))))))))) (by decide +kernel)
def s5_5931 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6598,w6604]
theorem b5_5931 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5931 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s5_5931 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6598,v3_6604] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6598 (PetersenWireProjection.cons pc3_6604 rfl)))))))))) (by decide +kernel)
def s5_5932 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6598,w6690]
theorem b5_5932 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5932 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5932 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6598,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6598 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_5988 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6738]
theorem b5_5988 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5988 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_5988 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6738] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6738 rfl)))))))))) (by decide +kernel)
def s5_5989 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6739]
theorem b5_5989 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5989 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_5989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6739] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6739 rfl)))))))))) (by decide +kernel)
def s5_5990 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6740]
theorem b5_5990 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5990 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(2,true),(8,true)),(false,(1,false),(0,false))] s5_5990 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6740] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6740 rfl)))))))))) (by decide +kernel)
def s5_5991 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6741]
theorem b5_5991 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5991 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_5991 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6741] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6741 rfl)))))))))) (by decide +kernel)
def s5_5992 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6742]
theorem b5_5992 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5992 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(2,true),(8,true)),(false,(1,false),(0,false))] s5_5992 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6742] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6742 rfl)))))))))) (by decide +kernel)
def s5_5993 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6743]
theorem b5_5993 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5993 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,false),(0,false))] s5_5993 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6743] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6743 rfl)))))))))) (by decide +kernel)
def s5_5997 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6844]
theorem b5_5997 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5997 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_5997 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6844] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6844 rfl)))))))))) (by decide +kernel)
def s5_5998 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6845]
theorem b5_5998 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5998 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_5998 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6845] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6845 rfl)))))))))) (by decide +kernel)
def s5_5999 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6846]
theorem b5_5999 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5999 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false))] s5_5999 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6846] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6846 rfl)))))))))) (by decide +kernel)
def s5_6000 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6847]
theorem b5_6000 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6000 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_6000 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6847] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6847 rfl)))))))))) (by decide +kernel)
def s5_6001 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6848]
theorem b5_6001 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6001 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(6,true),(8,true)),(false,(1,false),(0,false))] s5_6001 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6848] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6848 rfl)))))))))) (by decide +kernel)
end NineCert
