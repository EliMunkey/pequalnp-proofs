import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_14930 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5135,w5393,w5585,w5620,w5956,w6300,w6588]
theorem b4_14930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14930 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(7,true)),(false,(0,true),(5,true))] s4_14930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5620,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5620 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14931 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_14931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14931 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_14931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5623,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5623 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14932 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14932 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_14932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14933 : List (BitVec 512) := [w3766,w4100,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14933 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_14933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4100,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4100 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_14948 : List (BitVec 512) := [w3766,w4120,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_14948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14948 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(1,true),(0,true))] s4_14948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4120,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5767,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4120 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5767 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14949 : List (BitVec 512) := [w3766,w4120,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14949 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_14949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4120,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4120 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_14950 : List (BitVec 512) := [w3766,w4121,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14950 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_14950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14951 : List (BitVec 512) := [w3766,w4121,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14951 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true))] s4_14951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4426,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14952 : List (BitVec 512) := [w3766,w4121,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14952 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true))] s4_14952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4483,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4483 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14953 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_14953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14953 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,false))] s4_14953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5750,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5750 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14954 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_14954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14954 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,false))] s4_14954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5760,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5760 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14955 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14955 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_14955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14956 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_14956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14956 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_14956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5993,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5993 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14957 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_14957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14957 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_14957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6004,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6004 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14958 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6038,w6300,w6588]
theorem b4_14958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14958 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s4_14958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6038,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6038 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14959 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_14959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14959 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(6,true),(0,false))] s4_14959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6237,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6237 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14960 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_14960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14960 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s4_14960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6499,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6499 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14961 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_14961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14961 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s4_14961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14962 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_14962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14962 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false))] s4_14962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6575,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6575 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14963 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14963 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_14963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_14964 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6601]
theorem b4_14964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14964 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true))] s4_14964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6601] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6601 rfl))))))))))) (by decide +kernel)
def s4_14965 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_14965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14965 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_14965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6618] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6618 rfl))))))))))) (by decide +kernel)
def s4_14966 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6653]
theorem b4_14966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14966 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true))] s4_14966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6653] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6653 rfl))))))))))) (by decide +kernel)
def s4_14967 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_14967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14967 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true))] s4_14967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6821] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6821 rfl))))))))))) (by decide +kernel)
def s4_14968 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14968 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_14968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_14969 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_14969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14969 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true))] s4_14969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_14970 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_14970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14970 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,false))] s4_14970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6869] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6869 rfl))))))))))) (by decide +kernel)
def s4_14971 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_14971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14971 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_14971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_14972 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_14972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14972 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false)),(false,(0,false),(8,true))] s4_14972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6906] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6906 rfl))))))))))) (by decide +kernel)
def s4_14973 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_14973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14973 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(7,true))] s4_14973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_14974 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_14974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14974 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_14974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_14975 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_14975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14975 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false)),(false,(9,true),(8,true))] s4_14975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_14976 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_14976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14976 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s4_14976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14977 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_14977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14977 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(7,true),(8,true))] s4_14977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_14978 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_14978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14978 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(7,true),(0,false))] s4_14978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6225,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14979 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6201,w6300,w6588]
theorem b4_14979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14979 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_14979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14980 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_14980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14980 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s4_14980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14981 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6478,w6588]
theorem b4_14981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14981 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true))] s4_14981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14982 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6489,w6588]
theorem b4_14982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14982 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s4_14982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14983 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6522,w6588]
theorem b4_14983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14983 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s4_14983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14984 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6807]
theorem b4_14984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14984 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s4_14984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_14985 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6813]
theorem b4_14985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14985 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s4_14985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_14986 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6832]
theorem b4_14986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14986 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_14986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_14987 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588,w6873]
theorem b4_14987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14987 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s4_14987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_14988 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_14988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14988 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(5,true),(7,true))] s4_14988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14989 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_14989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14989 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(8,true),(6,true))] s4_14989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_14990 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5848,w5956,w6300,w6464,w6588]
theorem b4_14990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14990 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(5,true),(7,true))] s4_14990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5848,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14991 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_14991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14991 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_14991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14992 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_14992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14992 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_14992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_14993 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_14993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14993 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(8,true),(2,true))] s4_14993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_14994 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_14994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14994 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(3,true),(1,false))] s4_14994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s4_14995 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6690,w6720]
theorem b4_14995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14995 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(2,true))] s4_14995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_14996 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_14996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14996 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(3,true))] s4_14996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_14997 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b4_14997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14997 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(7,true))] s4_14997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14998 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5848,w5956,w6300,w6422,w6588]
theorem b4_14998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14998 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(7,true))] s4_14998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_14999 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6720]
theorem b4_14999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14999 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(8,true))] s4_14999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15000 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_15000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15000 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(3,true))] s4_15000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15001 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_15001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15001 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s4_15001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15002 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_15002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15002 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(2,true))] s4_15002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15003 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5769,w5956,w6300,w6464,w6588,w6720]
theorem b4_15003 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15003 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(8,true),(2,true)),(false,(6,true),(3,true))] s4_15003 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5769,v3_5956,v3_6300,v3_6464,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15004 : List (BitVec 512) := [w3766,w4121,w4392,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15004 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_15004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15005 : List (BitVec 512) := [w3766,w4121,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15005 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true))] s4_15005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4392,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15006 : List (BitVec 512) := [w3766,w4121,w4426,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15006 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true))] s4_15006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4426,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15007 : List (BitVec 512) := [w3766,w4121,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15007 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true))] s4_15007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4426,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
