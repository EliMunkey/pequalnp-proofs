import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1810 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b4_1810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1810 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_1810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6807] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_1811 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_1811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1811 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s4_1811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6857] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_1812 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6866]
theorem b4_1812 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1812 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(5,true))] s4_1812 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6866] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_1813 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b4_1813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1813 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s4_1813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s4_1814 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6908]
theorem b4_1814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1814 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s4_1814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6908] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_1815 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_1815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1815 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s4_1815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1816 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_1816 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1816 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_1816 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1817 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6852]
theorem b4_1817 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1817 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_1817 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_1818 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_1818 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1818 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(7,true),(6,true))] s4_1818 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_1819 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832]
theorem b4_1819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1819 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(6,true),(8,true))] s4_1819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1820 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_1820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1820 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_1820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1821 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_1821 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1821 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_1821 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1822 : List (BitVec 512) := [w291,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_1822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1822 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(5,true),(7,true))] s4_1822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1823 : List (BitVec 512) := [w291,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_1823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1823 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(2,true),(7,true))] s4_1823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1824 : List (BitVec 512) := [w291,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6690]
theorem b4_1824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1824 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_1824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_1825 : List (BitVec 512) := [w291,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_1825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1825 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_1825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_1826 : List (BitVec 512) := [w291,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6832]
theorem b4_1826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1826 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s4_1826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_291,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_291 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1832 : List (BitVec 512) := [w316,w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1832 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_316,v3_332,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_316 (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1885 : List (BitVec 512) := [w316,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_1885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1885 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_316,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_316 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1925 : List (BitVec 512) := [w332,w3156,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6832]
theorem b4_1925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1925 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_332,v3_3156,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3156 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_1926 : List (BitVec 512) := [w332,w3178,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1926 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_332,v3_3178,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3178 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1929 : List (BitVec 512) := [w332,w3766,w4322,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1929 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_332,v3_3766,v3_4322,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4322 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_1952 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_1952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1952 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_332,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_1964 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_1964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1964 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,false),(0,false))] s4_1964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_332,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_332 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_2049 : List (BitVec 512) := [w357,w3766,w4322,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2049 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,false))] s4_2049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_357,v3_3766,v3_4322,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_357 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4322 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2065 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_2065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2065 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,false))] s4_2065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_357,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_357 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_2073 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_2073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2073 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,false))] s4_2073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_357,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_357 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_2079 : List (BitVec 512) := [w360,w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2079 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2094 : List (BitVec 512) := [w360,w1565,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2094 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_1565,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_1565 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2104 : List (BitVec 512) := [w360,w1795,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2104 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_1795,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_1795 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2120 : List (BitVec 512) := [w360,w2063,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2120 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_2063,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_2063 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2151 : List (BitVec 512) := [w360,w2770,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2151 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2151 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2151 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_2770,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_2770 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2190 : List (BitVec 512) := [w360,w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2190 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2193 : List (BitVec 512) := [w360,w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2193 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2194 : List (BitVec 512) := [w360,w3766,w4146,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2194 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2195 : List (BitVec 512) := [w360,w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2195 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2196 : List (BitVec 512) := [w360,w3766,w4297,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2196 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2197 : List (BitVec 512) := [w360,w3766,w4322,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2197 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2197 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true))] s4_2197 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4322,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4322 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2198 : List (BitVec 512) := [w360,w3766,w4324,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2198 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2198 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_2198 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_360,v3_3766,v3_4324,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_360 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4324 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2330 : List (BitVec 512) := [w365,w3766,w4322,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2330 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false))] s4_2330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_365,v3_3766,v3_4322,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_365 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4322 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2695 : List (BitVec 512) := [w590,w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2695 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2695 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s4_2695 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_590,v3_635,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_590 (PetersenWireProjection.cons pc3_635 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2696 : List (BitVec 512) := [w590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2696 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_2696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_590,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_590 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_2697 : List (BitVec 512) := [w590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2697 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_2697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_590,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_590 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2698 : List (BitVec 512) := [w593,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2698 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_2698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_593,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_593 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2699 : List (BitVec 512) := [w594,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2699 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s4_2699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_594,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_594 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2700 : List (BitVec 512) := [w596,w628,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2700 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(5,false),(0,false))] s4_2700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_628,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_628 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2701 : List (BitVec 512) := [w596,w632,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2701 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,false),(0,false))] s4_2701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_632,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_632 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2702 : List (BitVec 512) := [w596,w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2702 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(6,true)),(false,(1,false),(0,true))] s4_2702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_635,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_635 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2703 : List (BitVec 512) := [w596,w639,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2703 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,false),(8,true))] s4_2703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_639,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_639 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2704 : List (BitVec 512) := [w596,w640,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2704 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(8,true),(2,true)),(false,(1,true),(0,false))] s4_2704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_640,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_640 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2705 : List (BitVec 512) := [w596,w642,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2705 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(2,true)),(false,(1,true),(0,false))] s4_2705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_642,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_642 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2706 : List (BitVec 512) := [w596,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_2706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2706 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(9,true),(0,true))] s4_2706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1312,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6813] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_2707 : List (BitVec 512) := [w596,w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_2707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2707 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_2707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1312,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1312 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2708 : List (BitVec 512) := [w596,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b4_2708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2708 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,false)),(false,(9,true),(0,true))] s4_2708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1366,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6857] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1366 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_2709 : List (BitVec 512) := [w596,w1366,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b4_2709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2709 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s4_2709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1366,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1366 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2710 : List (BitVec 512) := [w596,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2710 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_2710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1374,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1374 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2711 : List (BitVec 512) := [w596,w1618,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2711 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,false))] s4_2711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1618,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1618 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2712 : List (BitVec 512) := [w596,w1644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2712 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(6,true))] s4_2712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1644,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1644 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2713 : List (BitVec 512) := [w596,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2713 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true))] s4_2713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1650,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1650 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2714 : List (BitVec 512) := [w596,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_2714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2714 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true))] s4_2714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1664,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1664 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_2715 : List (BitVec 512) := [w596,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_2715 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2715 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(8,true),(2,true))] s4_2715 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1664,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1664 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_2716 : List (BitVec 512) := [w596,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2716 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(7,true))] s4_2716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1666,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1666 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2717 : List (BitVec 512) := [w596,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2717 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2717 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(0,true),(8,true))] s4_2717 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1670,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1670 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_2718 : List (BitVec 512) := [w596,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2718 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,false)),(false,(0,true),(8,true))] s4_2718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_596,v3_1674,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_596 (PetersenWireProjection.cons pc3_1674 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
