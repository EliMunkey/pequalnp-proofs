import NinePin101
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17280 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5766,w5956,w6300,w6588,w6690]
theorem b4_17280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17280 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_17280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5393,v101_5585,v101_5766,v101_5956,v101_6300,v101_6588,v101_6690] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5393 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5766 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6690 rfl))))))))))) (by decide +kernel)
def s4_17281 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5766,w5956,w6300,w6588,w6852]
theorem b4_17281 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17281 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_17281 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5393,v101_5585,v101_5766,v101_5956,v101_6300,v101_6588,v101_6852] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5393 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5766 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6852 rfl))))))))))) (by decide +kernel)
def s4_18088 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6173,w6179,w6300,w6690,w6832]
theorem b4_18088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18088 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_18088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5393,v101_5585,v101_6173,v101_6179,v101_6300,v101_6690,v101_6832] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5393 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_6173 (PetersenWireProjection.cons pc101_6179 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6690 (PetersenWireProjection.cons pc101_6832 rfl))))))))))) (by decide +kernel)
def s4_18130 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6101,w6300,w6588,w6690]
theorem b4_18130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18130 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_18130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6101,v101_6300,v101_6588,v101_6690] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6101 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6690 rfl))))))))))) (by decide +kernel)
def s4_18147 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6852]
theorem b4_18147 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18147 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_18147 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6588,v101_6852] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6852 rfl)))))))))) (by decide +kernel)
def s4_18152 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6690,w6832]
theorem b4_18152 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18152 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s4_18152 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6690,v101_6832] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6690 (PetersenWireProjection.cons pc101_6832 rfl)))))))))) (by decide +kernel)
def s5_3153 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6873]
theorem b5_3153 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3153 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_3153 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_1403,v101_3766,v101_4344,v101_4716,v101_5135,v101_5393,v101_5585,v101_5956,v101_6006,v101_6873] (PetersenWireProjection.cons pc101_1403 (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5393 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6006 (PetersenWireProjection.cons pc101_6873 rfl)))))))))) (by decide +kernel)
def s5_3154 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6890]
theorem b5_3154 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3154 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_3154 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_1403,v101_3766,v101_4344,v101_4716,v101_5135,v101_5393,v101_5585,v101_5956,v101_6006,v101_6890] (PetersenWireProjection.cons pc101_1403 (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5393 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6006 (PetersenWireProjection.cons pc101_6890 rfl)))))))))) (by decide +kernel)
def s5_4136 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5760,w5956,w6300,w6588]
theorem b5_4136 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4136 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [(false,(5,true),(1,false))] s5_4136 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_2468,v101_3766,v101_4344,v101_4716,v101_5135,v101_5585,v101_5760,v101_5956,v101_6300,v101_6588] (PetersenWireProjection.cons pc101_2468 (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5760 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 rfl)))))))))) (by decide +kernel)
def s5_6194 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6111,w6300,w6588]
theorem b5_6194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6194 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6111,v101_6300,v101_6588] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6111 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 rfl)))))))))) (by decide +kernel)
def s5_6201 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6859]
theorem b5_6201 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6201 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6201 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6588,v101_6859] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6859 rfl)))))))))) (by decide +kernel)
def s5_6209 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6690,w6857]
theorem b5_6209 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6209 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6209 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6690,v101_6857] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6690 (PetersenWireProjection.cons pc101_6857 rfl)))))))))) (by decide +kernel)
def s5_6212 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6720,w6852]
theorem b5_6212 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6212 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6212 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6720,v101_6852] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6720 (PetersenWireProjection.cons pc101_6852 rfl)))))))))) (by decide +kernel)
def s5_6214 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6748,w6832]
theorem b5_6214 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6214 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6214 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6748,v101_6832] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6748 (PetersenWireProjection.cons pc101_6832 rfl)))))))))) (by decide +kernel)
def s5_6215 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6807,w6832]
theorem b5_6215 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6215 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6215 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5585,v101_5956,v101_6300,v101_6807,v101_6832] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5585 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6807 (PetersenWireProjection.cons pc101_6832 rfl)))))))))) (by decide +kernel)
def s5_6217 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5638,w5956,w6179,w6300,w6588]
theorem b5_6217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6217 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5638,v101_5956,v101_6179,v101_6300,v101_6588] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5638 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6179 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 rfl)))))))))) (by decide +kernel)
def s5_6222 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5956,w6179,w6300,w6588,w6807]
theorem b5_6222 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6222 := by
  intro m le c
  apply rejects_sound r101 i6 6 tgt (small101 adj) hot101 [] s5_6222 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v101_3766,v101_4344,v101_4716,v101_5135,v101_5470,v101_5956,v101_6179,v101_6300,v101_6588,v101_6807] (PetersenWireProjection.cons pc101_3766 (PetersenWireProjection.cons pc101_4344 (PetersenWireProjection.cons pc101_4716 (PetersenWireProjection.cons pc101_5135 (PetersenWireProjection.cons pc101_5470 (PetersenWireProjection.cons pc101_5956 (PetersenWireProjection.cons pc101_6179 (PetersenWireProjection.cons pc101_6300 (PetersenWireProjection.cons pc101_6588 (PetersenWireProjection.cons pc101_6807 rfl)))))))))) (by decide +kernel)
end NineCert
