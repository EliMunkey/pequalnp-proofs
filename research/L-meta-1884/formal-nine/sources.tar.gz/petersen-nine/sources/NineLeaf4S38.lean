import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5895 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6213,w6300,w6588]
theorem b5_5895 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5895 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s5_5895 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6213,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6213 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_5915 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6589]
theorem b5_5915 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5915 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5915 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6589] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6589 rfl))))))))) (by decide +kernel)
def s5_5916 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6589,w6720]
theorem b5_5916 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5916 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5916 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6589,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6589 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5939 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610]
theorem b5_5939 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5939 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5939 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl))))))))) (by decide +kernel)
def s5_5940 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610,w6869]
theorem b5_5940 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5940 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(6,true))] s5_5940 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610,v4_6869] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 (PetersenWireProjection.cons pc4_6869 rfl)))))))))) (by decide +kernel)
def s5_5943 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6612,w6720]
theorem b5_5943 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5943 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_5943 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6612,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6612 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5945 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6614]
theorem b5_5945 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5945 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5945 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6614] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6614 rfl))))))))) (by decide +kernel)
def s5_5946 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6614,w6620]
theorem b5_5946 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5946 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_5946 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6614,v4_6620] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6614 (PetersenWireProjection.cons pc4_6620 rfl)))))))))) (by decide +kernel)
def s5_5947 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6614,w6720]
theorem b5_5947 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5947 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6614,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6614 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5963 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6646,w6720]
theorem b5_5963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5963 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(6,true))] s5_5963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6646,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6646 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5964 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6649,w6720]
theorem b5_5964 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5964 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,false),(6,true))] s5_5964 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6649,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6649 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5982 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6682]
theorem b5_5982 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5982 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5982 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6682] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6682 rfl))))))))) (by decide +kernel)
def s5_5983 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6682,w6720]
theorem b5_5983 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5983 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_5983 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6682,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6682 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_5986 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6724]
theorem b5_5986 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5986 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(5,true),(3,true)),(false,(1,true),(6,true))] s5_5986 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6724] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6724 rfl)))))))))) (by decide +kernel)
def s5_5987 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6733]
theorem b5_5987 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5987 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true)),(false,(3,true),(5,true)),(false,(1,true),(6,true))] s5_5987 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6733] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6733 rfl)))))))))) (by decide +kernel)
def s5_6015 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6711,w6720]
theorem b5_6015 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6015 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(3,true)),(false,(1,false),(0,false))] s5_6015 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6711,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6711 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_6017 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6713,w6720]
theorem b5_6017 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6017 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(5,true),(3,true)),(false,(1,false),(0,false))] s5_6017 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6713,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6713 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_6018 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6714,w6720]
theorem b5_6018 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6018 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(5,true),(3,true)),(false,(1,false),(0,false))] s5_6018 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6714,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6714 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_6024 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6812]
theorem b5_6024 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6024 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(7,false)),(false,(0,true),(6,true))] s5_6024 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6812] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6812 rfl)))))))))) (by decide +kernel)
def s5_6027 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6720,w6873]
theorem b5_6027 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6027 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(3,false),(0,false)),(false,(0,true),(5,true))] s5_6027 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6321,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6321 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6033 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6331,w6720,w6873]
theorem b5_6033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6033 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(7,false),(0,false)),(false,(0,true),(5,true))] s5_6033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6331,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6331 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6039 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6334,w6389,w6720]
theorem b5_6039 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6039 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(4,true),(3,true)),(false,(1,true),(5,true))] s5_6039 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6334,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6334 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_6040 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6334,w6720,w6873]
theorem b5_6040 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6040 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,false),(0,false)),(false,(0,true),(5,true))] s5_6040 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6334,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6334 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6046 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6365,w6720,w6873]
theorem b5_6046 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6046 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,true),(4,true)),(false,(1,false),(5,true))] s5_6046 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6365,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6365 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6062 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6813,w6873]
theorem b5_6062 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6062 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(4,true),(8,true)),(false,(6,true),(5,true))] s5_6062 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6813,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6813 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6099 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6522,w6588,w6890]
theorem b5_6099 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6099 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,false),(5,true)),(false,(5,true),(9,true))] s5_6099 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6522,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl)))))))))) (by decide +kernel)
def s5_6100 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6088,w6522,w6785,w6873]
theorem b5_6100 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6100 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_6100 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6088,v4_6522,v4_6785,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6102 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6097,w6300,w6522,w6720]
theorem b5_6102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6102 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(8,false),(0,true)),(false,(9,true),(5,true))] s5_6102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6097,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6097 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_6112 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6720,w6890]
theorem b5_6112 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6112 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(4,true),(8,true)),(false,(6,true),(1,false))] s5_6112 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6720,v4_6890] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 rfl)))))))))) (by decide +kernel)
def s5_6114 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6813,w6873]
theorem b5_6114 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6114 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(8,true),(4,true)),(false,(5,true),(6,true))] s5_6114 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6813,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6813 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6127 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6718,w6873]
theorem b5_6127 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6127 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(4,true)),(false,(5,true),(6,true))] s5_6127 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6522,v4_6718,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6718 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6132 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6522,w6720,w6873]
theorem b5_6132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6132 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_6132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6139 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5753,w5956,w6464,w6813,w6873]
theorem b5_6139 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(5,true),(4,true)),(false,(8,true),(5,true))] s5_6139 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5753,v4_5956,v4_6464,v4_6813,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5753 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6813 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6245 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6088,w6101,w6522,w6720,w6873]
theorem b5_6245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6245 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(4,true))] s5_6245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6088,v4_6101,v4_6522,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6088 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s5_6256 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6549,w6720,w6873]
theorem b5_6256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6256 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(4,true))] s5_6256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6549,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s6_16 : List (BitVec 512) := [w1076,w3766,w5135,w5393,w5698,w6225,w6389,w6522,w6588]
theorem b6_16 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_16 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(3,true)),(false,(9,true),(8,true)),(false,(5,true),(6,true))] s6_16 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_5135,v4_5393,v4_5698,v4_6225,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))) (by decide +kernel)
def s6_33 : List (BitVec 512) := [w1716,w1734,w3766,w4344,w5135,w5393,w5585,w5956,w6300]
theorem b6_33 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_33 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(5,false),(0,false)),(false,(6,true),(1,true)),(false,(1,true),(0,true))] s6_33 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1716,v4_1734,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300] (PetersenWireProjection.cons pc4_1716 (PetersenWireProjection.cons pc4_1734 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 rfl))))))))) (by decide +kernel)
def s6_61 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6589]
theorem b6_61 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_61 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s6_61 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6589] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6589 rfl))))))))) (by decide +kernel)
def s6_62 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6628]
theorem b6_62 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_62 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s6_62 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6628] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6628 rfl))))))))) (by decide +kernel)
end NineCert
