import NinePin232
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7135 : List (BitVec 512) := [w1275,w3123,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7135 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7135 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_7135 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1275,v232_3123,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6300,v232_6588] (PetersenWireProjection.cons pc232_1275 (PetersenWireProjection.cons pc232_3123 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_7137 : List (BitVec 512) := [w1275,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_7137 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7137 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_7137 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1275,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6101,v232_6300,v232_6588] (PetersenWireProjection.cons pc232_1275 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6101 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_9279 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b4_9279 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9279 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_9279 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1374,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_6179,v232_6389,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1374 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6389 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_9287 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_9287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9287 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_9287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1374,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5698,v232_6179,v232_6300,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1374 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5698 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_9735 : List (BitVec 512) := [w1388,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_9735 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9735 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_9735 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1388,v232_3766,v232_4344,v232_4926,v232_5135,v232_5393,v232_5585,v232_5956,v232_6101,v232_6300,v232_6588] (PetersenWireProjection.cons pc232_1388 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4926 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6101 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_10174 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6549,w6588]
theorem b4_10174 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10174 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_10174 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6522,v232_6549,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6549 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_10177 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6567,w6588]
theorem b4_10177 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10177 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_10177 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6522,v232_6567,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6567 (PetersenWireProjection.cons pc232_6588 rfl))))))))))) (by decide +kernel)
def s4_16314 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_16314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16314 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s4_16314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_3766,v232_4344,v232_4483,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6300,v232_6588,v232_6618] (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4483 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6588 (PetersenWireProjection.cons pc232_6618 rfl))))))))))) (by decide +kernel)
def s5_1910 : List (BitVec 512) := [w1119,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b5_1910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1910 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_1910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1119,v232_2468,v232_3766,v232_4344,v232_5135,v232_5585,v232_6101,v232_6300,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1119 (PetersenWireProjection.cons pc232_2468 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6101 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_2354 : List (BitVec 512) := [w1292,w2468,w3766,w4344,w4716,w5135,w6179,w6300,w6522,w6588]
theorem b5_2354 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2354 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_2354 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1292,v232_2468,v232_3766,v232_4344,v232_4716,v232_5135,v232_6179,v232_6300,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1292 (PetersenWireProjection.cons pc232_2468 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6300 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_2840 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w6179,w6389,w6522,w6785]
theorem b5_2840 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2840 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_2840 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1374,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_6179,v232_6389,v232_6522,v232_6785] (PetersenWireProjection.cons pc232_1374 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6389 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6785 rfl)))))))))) (by decide +kernel)
def s5_2852 : List (BitVec 512) := [w1374,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_2852 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2852 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_2852 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1374,v232_3766,v232_4716,v232_5135,v232_5393,v232_5698,v232_6179,v232_6389,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1374 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5698 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6389 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_3102 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6522,w6588]
theorem b5_3102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3102 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_3102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_2468,v232_3766,v232_4344,v232_4716,v232_5135,v232_5585,v232_6101,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_2468 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6101 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_3103 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6522,w6588]
theorem b5_3103 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3103 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_3103 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_2468,v232_3766,v232_4344,v232_4716,v232_5135,v232_5585,v232_6179,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_2468 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_3159 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6372,w6588]
theorem b5_3159 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3159 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_3159 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_5956,v232_6372,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_5956 (PetersenWireProjection.cons pc232_6372 (PetersenWireProjection.cons pc232_6588 rfl)))))))))) (by decide +kernel)
def s5_6131 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6522,w6588,w6890]
theorem b5_6131 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6131 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s5_6131 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_6225,v232_6522,v232_6588,v232_6890] (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6225 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 (PetersenWireProjection.cons pc232_6890 rfl)))))))))) (by decide +kernel)
def s6_24 : List (BitVec 512) := [w1403,w2468,w3766,w4716,w5135,w5698,w6179,w6522,w6588]
theorem b6_24 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_24 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s6_24 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_1403,v232_2468,v232_3766,v232_4716,v232_5135,v232_5698,v232_6179,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_1403 (PetersenWireProjection.cons pc232_2468 (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5698 (PetersenWireProjection.cons pc232_6179 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl))))))))) (by decide +kernel)
def s6_90 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6223,w6522,w6588]
theorem b6_90 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_90 := by
  intro m le c
  apply rejects_sound r232 i6 5 tgt (small232 adj) hot232 [] s6_90 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v232_3766,v232_4344,v232_4716,v232_5135,v232_5393,v232_5585,v232_6223,v232_6522,v232_6588] (PetersenWireProjection.cons pc232_3766 (PetersenWireProjection.cons pc232_4344 (PetersenWireProjection.cons pc232_4716 (PetersenWireProjection.cons pc232_5135 (PetersenWireProjection.cons pc232_5393 (PetersenWireProjection.cons pc232_5585 (PetersenWireProjection.cons pc232_6223 (PetersenWireProjection.cons pc232_6522 (PetersenWireProjection.cons pc232_6588 rfl))))))))) (by decide +kernel)
end NineCert
