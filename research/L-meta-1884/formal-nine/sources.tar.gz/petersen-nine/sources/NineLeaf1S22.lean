import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7310 : List (BitVec 512) := [w1292,w3766,w4004,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7310 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7310 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7310 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7321 : List (BitVec 512) := [w1292,w3766,w4344,w4635,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7321 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7321 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7321 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7336 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w4982,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7336 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7337 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5013,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7337 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7338 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5022,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7338 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true))] s4_7338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5022,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5022 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7339 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5024,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7339 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7340 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5031,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7340 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7341 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5037,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7341 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true))] s4_7341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5037,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5037 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7342 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5044,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7342 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true))] s4_7342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5044,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5044 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7343 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5053,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7343 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7344 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5071,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7344 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5071,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5071 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7345 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5178,w5393,w5956,w6179,w6300,w6588]
theorem b4_7345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7345 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5178,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5178 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7347 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5205,w5393,w5956,w6179,w6300,w6588]
theorem b4_7347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7347 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7348 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5239,w5393,w5956,w6179,w6300,w6588]
theorem b4_7348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7348 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7363 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5530,w5956,w6179,w6300,w6588]
theorem b4_7363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7363 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7383 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6154,w6300,w6588]
theorem b4_7383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7383 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(8,true))] s4_7383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6154,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6154 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7398 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6447,w6588]
theorem b4_7398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7398 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(9,true))] s4_7398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6447,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6447 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7414 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6555,w6588]
theorem b4_7414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7414 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_7414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6555,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7442 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6422,w6444,w6588]
theorem b4_7442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7442 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(9,true))] s4_7442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6422,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7446 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6147,w6300,w6588]
theorem b4_7446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7446 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(4,true),(8,true))] s4_7446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7467 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6147,w6179,w6300,w6588]
theorem b4_7467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7467 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6147,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7476 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6241,w6300,w6588]
theorem b4_7476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7476 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7484 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6444,w6588]
theorem b4_7484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7484 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7493 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6756]
theorem b4_7493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7493 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(7,true),(8,true))] s4_7493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1292,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1292 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_7597 : List (BitVec 512) := [w1312,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7597 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7598 : List (BitVec 512) := [w1312,w2313,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7598 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7598 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7598 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2313,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7625 : List (BitVec 512) := [w1312,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7625 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7625 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7625 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7626 : List (BitVec 512) := [w1312,w2555,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7626 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2555,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7627 : List (BitVec 512) := [w1312,w2559,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7627 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7627 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_7627 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2559,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2559 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7628 : List (BitVec 512) := [w1312,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7628 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7628 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7628 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7629 : List (BitVec 512) := [w1312,w2589,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_7629 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7629 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7629 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2589,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7630 : List (BitVec 512) := [w1312,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7630 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7630 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7630 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7631 : List (BitVec 512) := [w1312,w2608,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7631 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7631 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7631 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2608,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7632 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4392,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b4_7632 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7632 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_7632 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4392,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4392 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7633 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7633 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7633 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7633 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7634 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5848,w5956,w6300,w6588]
theorem b4_7634 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7634 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_7634 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7635 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w5993,w6300,w6588]
theorem b4_7635 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7635 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_7635 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_5993,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_5993 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7636 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6061,w6300,w6588]
theorem b4_7636 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7636 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s4_7636 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6061,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7637 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6225,w6300,w6588]
theorem b4_7637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7637 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true))] s4_7637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7638 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6389,w6588]
theorem b4_7638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7638 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_7638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6389,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7639 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6522,w6588]
theorem b4_7639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7639 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_7639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7640 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6720,w6813]
theorem b4_7640 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7640 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7640 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7641 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785,w6813]
theorem b4_7641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7641 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6785,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7642 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b4_7642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7642 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl)))))))))) (by decide +kernel)
def s4_7643 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7643 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7644 : List (BitVec 512) := [w1312,w2613,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b4_7644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7644 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2613,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_7645 : List (BitVec 512) := [w1312,w2615,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_7645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7645 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_7645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2615,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7646 : List (BitVec 512) := [w1312,w2623,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_7646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7646 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_7646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2623,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7647 : List (BitVec 512) := [w1312,w2623,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7647 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2623,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7648 : List (BitVec 512) := [w1312,w2623,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7648 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2623,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_7649 : List (BitVec 512) := [w1312,w2633,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7649 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_7649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2633,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2633 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7650 : List (BitVec 512) := [w1312,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7650 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7651 : List (BitVec 512) := [w1312,w2636,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7651 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2636,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7652 : List (BitVec 512) := [w1312,w2637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7652 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_7652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2637,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2637 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7653 : List (BitVec 512) := [w1312,w2641,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7653 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(8,true))] s4_7653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2641,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2641 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7654 : List (BitVec 512) := [w1312,w2646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7654 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(8,true))] s4_7654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7655 : List (BitVec 512) := [w1312,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7655 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(1,false),(5,true))] s4_7655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7656 : List (BitVec 512) := [w1312,w2650,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7656 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2650,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7657 : List (BitVec 512) := [w1312,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7657 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_7657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7658 : List (BitVec 512) := [w1312,w2659,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7658 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(8,true),(9,true))] s4_7658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2659,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2659 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_7659 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7659 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2681,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7664 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_7664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7664 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_7664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2681,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2681 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_7667 : List (BitVec 512) := [w1312,w2684,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7667 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_7667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2684,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2684 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_7668 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7668 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_7668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_2686,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_2686 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
end NineCert
