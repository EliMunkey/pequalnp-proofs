import NinePin113
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_909 : List (BitVec 512) := [w628,w2173,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_909 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_909 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_909 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_628,v113_2173,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_628 (PetersenWireProjection.cons pc113_2173 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_954 : List (BitVec 512) := [w637,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_954 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_2681,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_960 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6646]
theorem b5_960 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_960 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_960 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6646] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6646 rfl)))))))))) (by decide +kernel)
def s5_962 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5151,w5393,w5585,w5956,w6300,w6588]
theorem b5_962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_962 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_3766,v113_4344,v113_4716,v113_5151,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5151 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_963 : List (BitVec 512) := [w637,w3766,w4344,w4749,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_963 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_3766,v113_4344,v113_4749,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4749 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_966 : List (BitVec 512) := [w637,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b5_966 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_966 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_966 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_637,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_637 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_972 : List (BitVec 512) := [w645,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_972 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_972 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_972 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_645,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_645 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_1843 : List (BitVec 512) := [w1082,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6723]
theorem b5_1843 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1843 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_1843 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1082,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6723] (PetersenWireProjection.cons pc113_1082 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6723 rfl)))))))))) (by decide +kernel)
def s5_1850 : List (BitVec 512) := [w1085,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6726]
theorem b5_1850 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1850 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_1850 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1085,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6726] (PetersenWireProjection.cons pc113_1085 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6726 rfl)))))))))) (by decide +kernel)
def s5_1852 : List (BitVec 512) := [w1085,w3766,w4344,w4766,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1852 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1852 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_1852 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1085,v113_3766,v113_4344,v113_4766,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1085 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4766 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_1864 : List (BitVec 512) := [w1092,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6729]
theorem b5_1864 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1864 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_1864 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1092,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6729] (PetersenWireProjection.cons pc113_1092 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6729 rfl)))))))))) (by decide +kernel)
def s5_2439 : List (BitVec 512) := [w1312,w2125,w3766,w4344,w5135,w5393,w5956,w6225,w6300,w6720]
theorem b5_2439 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2439 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2439 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2125,v113_3766,v113_4344,v113_5135,v113_5393,v113_5956,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2125 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2441 : List (BitVec 512) := [w1312,w2166,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b5_2441 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2441 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2441 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2166,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2166 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2442 : List (BitVec 512) := [w1312,w2166,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2442 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2442 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2442 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2166,v113_3766,v113_4344,v113_5135,v113_5393,v113_5769,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2166 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2444 : List (BitVec 512) := [w1312,w2169,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b5_2444 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2444 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2444 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2169,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2169 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2445 : List (BitVec 512) := [w1312,w2169,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2445 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2445 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2445 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2169,v113_3766,v113_4344,v113_5135,v113_5393,v113_5769,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2169 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2481 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_2481 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2481 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2481 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2681,v113_3766,v113_4344,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2494 : List (BitVec 512) := [w1312,w2880,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_2494 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2494 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2494 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_2880,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_2880 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2512 : List (BitVec 512) := [w1312,w3323,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_2512 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2512 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2512 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1312,v113_3323,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1312 (PetersenWireProjection.cons pc113_3323 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2591 : List (BitVec 512) := [w1328,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6821]
theorem b5_2591 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2591 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2591 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_2681,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6821] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6821 rfl)))))))))) (by decide +kernel)
def s5_2592 : List (BitVec 512) := [w1328,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_2592 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2592 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2592 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_2681,v113_3766,v113_4344,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2597 : List (BitVec 512) := [w1328,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6813]
theorem b5_2597 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2597 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2597 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_2686,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_2686 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2598 : List (BitVec 512) := [w1328,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6821]
theorem b5_2598 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2598 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2598 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_2686,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6821] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_2686 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6821 rfl)))))))))) (by decide +kernel)
def s5_2655 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6748]
theorem b5_2655 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2655 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2655 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5956,v113_6101,v113_6300,v113_6748] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6101 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6748 rfl)))))))))) (by decide +kernel)
def s5_2656 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_2656 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2656 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2656 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1328,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1328 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2987 : List (BitVec 512) := [w1388,w1875,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6720]
theorem b5_2987 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2987 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2987 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_1875,v113_3766,v113_4344,v113_5135,v113_5393,v113_5585,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_1875 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_2989 : List (BitVec 512) := [w1388,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300]
theorem b5_2989 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2989 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2989 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_1913,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_6225,v113_6300] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_1913 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 rfl)))))))))) (by decide +kernel)
def s5_2991 : List (BitVec 512) := [w1388,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6813]
theorem b5_2991 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2991 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2991 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_1913,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_1913 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_2992 : List (BitVec 512) := [w1388,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6869]
theorem b5_2992 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2992 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_2992 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_1913,v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_1913 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl)))))))))) (by decide +kernel)
def s5_3003 : List (BitVec 512) := [w1388,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6869]
theorem b5_3003 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3003 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3003 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2681,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl)))))))))) (by decide +kernel)
def s5_3004 : List (BitVec 512) := [w1388,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_3004 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3004 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3004 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2681,v113_3766,v113_4344,v113_5393,v113_5585,v113_5769,v113_5956,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5769 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_3005 : List (BitVec 512) := [w1388,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_3005 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3005 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3005 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2681,v113_3766,v113_4344,v113_5393,v113_5585,v113_5956,v113_6225,v113_6300,v113_6720] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2681 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6225 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6720 rfl)))))))))) (by decide +kernel)
def s5_3007 : List (BitVec 512) := [w1388,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6813]
theorem b5_3007 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3007 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3007 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2686,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6813] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2686 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6813 rfl)))))))))) (by decide +kernel)
def s5_3008 : List (BitVec 512) := [w1388,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6869]
theorem b5_3008 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3008 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3008 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2686,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2686 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl)))))))))) (by decide +kernel)
def s5_3010 : List (BitVec 512) := [w1388,w2693,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6869]
theorem b5_3010 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3010 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3010 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_1388,v113_2693,v113_3766,v113_4344,v113_4716,v113_5393,v113_5585,v113_5956,v113_6300,v113_6869] (PetersenWireProjection.cons pc113_1388 (PetersenWireProjection.cons pc113_2693 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6869 rfl)))))))))) (by decide +kernel)
def s5_3787 : List (BitVec 512) := [w2417,w3766,w4344,w4716,w5135,w5585,w5956,w6114,w6300,w6588]
theorem b5_3787 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3787 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3787 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2417,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6114,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_2417 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6114 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_3791 : List (BitVec 512) := [w2419,w3766,w4344,w4716,w5135,w5585,w5956,w6116,w6300,w6588]
theorem b5_3791 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3791 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_3791 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2419,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6116,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_2419 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6116 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_4731 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_4731 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4731 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_4731 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5848,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5848 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_4737 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6237,w6300,w6588]
theorem b5_4737 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4737 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_4737 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6237,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6237 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_4741 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6499,w6588]
theorem b5_4741 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4741 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_4741 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6300,v113_6499,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6499 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_4744 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4744 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4744 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_4744 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_2497,v113_3766,v113_4344,v113_4716,v113_5135,v113_5585,v113_5956,v113_6300,v113_6578,v113_6588] (PetersenWireProjection.cons pc113_2497 (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6578 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5826 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5779,w5956,w6300,w6588]
theorem b5_5826 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5826 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5826 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5779,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5779 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5827 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5780,w5956,w6300,w6588]
theorem b5_5827 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5827 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5827 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5780,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5780 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5830 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5788,w5956,w6300,w6588]
theorem b5_5830 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5830 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5830 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5788,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5788 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5836 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5798,w5956,w6300,w6588]
theorem b5_5836 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5836 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5836 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5798,v113_5956,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5798 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5899 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6228,w6300,w6588]
theorem b5_5899 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5899 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5899 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6228,v113_6300,v113_6588] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6228 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6588 rfl)))))))))) (by decide +kernel)
def s5_5924 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6592,w6895]
theorem b5_5924 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5924 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5924 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6592,v113_6895] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6592 (PetersenWireProjection.cons pc113_6895 rfl)))))))))) (by decide +kernel)
def s5_5925 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6593,w6895]
theorem b5_5925 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5925 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5925 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6593,v113_6895] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6593 (PetersenWireProjection.cons pc113_6895 rfl)))))))))) (by decide +kernel)
def s5_5926 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6594,w6895]
theorem b5_5926 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5926 := by
  intro m le c
  apply rejects_sound r113 i8 7 tgt (small113 adj) hot113 [] s5_5926 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v113_3766,v113_4344,v113_4716,v113_5135,v113_5393,v113_5585,v113_5956,v113_6300,v113_6594,v113_6895] (PetersenWireProjection.cons pc113_3766 (PetersenWireProjection.cons pc113_4344 (PetersenWireProjection.cons pc113_4716 (PetersenWireProjection.cons pc113_5135 (PetersenWireProjection.cons pc113_5393 (PetersenWireProjection.cons pc113_5585 (PetersenWireProjection.cons pc113_5956 (PetersenWireProjection.cons pc113_6300 (PetersenWireProjection.cons pc113_6594 (PetersenWireProjection.cons pc113_6895 rfl)))))))))) (by decide +kernel)
end NineCert
