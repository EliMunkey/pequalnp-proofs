import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10671 : List (BitVec 512) := [w2202,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10671 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2202,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2202 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10672 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10672 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(2,true))] s4_10672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4584,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4584 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10673 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10673 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10673 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(6,true))] s4_10673 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10674 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6031,w6300,w6588]
theorem b4_10674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10674 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(0,true),(7,true))] s4_10674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6031,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6031 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10675 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10675 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10675 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(7,true))] s4_10675 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10676 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_10676 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10676 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(6,true),(7,true))] s4_10676 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10677 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_10677 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10677 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(8,true))] s4_10677 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10678 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_10678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10678 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(1,false))] s4_10678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl))))))))))) (by decide +kernel)
def s4_10679 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_10679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10679 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(1,false))] s4_10679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6857] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6857 rfl))))))))))) (by decide +kernel)
def s4_10680 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_10680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10680 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(9,true))] s4_10680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_10681 : List (BitVec 512) := [w2203,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_10681 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10681 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(8,true),(9,true))] s4_10681 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_10682 : List (BitVec 512) := [w2203,w2683,w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6300,w6588]
theorem b4_10682 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10682 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s4_10682 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2683,v0_3766,v0_4344,v0_4716,v0_4926,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10683 : List (BitVec 512) := [w2203,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10683 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10683 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s4_10683 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2683,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10684 : List (BitVec 512) := [w2203,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_10684 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10684 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,false)),(false,(4,true),(0,true))] s4_10684 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2683,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_10685 : List (BitVec 512) := [w2203,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_10685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10685 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s4_10685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2683,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6748] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6748 rfl))))))))))) (by decide +kernel)
def s4_10686 : List (BitVec 512) := [w2203,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_10686 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10686 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,false)),(false,(4,true),(0,true))] s4_10686 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2690,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2690 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10687 : List (BitVec 512) := [w2203,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_10687 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10687 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s4_10687 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2690,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2690 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10688 : List (BitVec 512) := [w2203,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_10688 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10688 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s4_10688 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2690,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2690 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_10689 : List (BitVec 512) := [w2203,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_10689 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10689 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s4_10689 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_2690,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6857] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_2690 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6857 rfl))))))))))) (by decide +kernel)
def s4_10690 : List (BitVec 512) := [w2203,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10690 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_10690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4392,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4392 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10691 : List (BitVec 512) := [w2203,w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10691 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_10691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4402,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4402 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10692 : List (BitVec 512) := [w2203,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10692 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_10692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10693 : List (BitVec 512) := [w2203,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10693 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10693 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_10693 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4412,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4412 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10694 : List (BitVec 512) := [w2203,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10694 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10694 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_10694 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4413,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4413 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10695 : List (BitVec 512) := [w2203,w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10695 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10695 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_10695 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4415,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4415 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10696 : List (BitVec 512) := [w2203,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10696 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10696 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_10696 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4426,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4426 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10697 : List (BitVec 512) := [w2203,w3766,w4344,w4427,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10697 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_10697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4427,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4427 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10698 : List (BitVec 512) := [w2203,w3766,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10698 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10698 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_10698 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4428,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4428 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10699 : List (BitVec 512) := [w2203,w3766,w4344,w4430,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10699 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(2,true))] s4_10699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4430,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4430 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10700 : List (BitVec 512) := [w2203,w3766,w4344,w4431,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10700 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_10700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4431,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4431 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10701 : List (BitVec 512) := [w2203,w3766,w4344,w4433,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10701 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10701 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(2,true))] s4_10701 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4433,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4433 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10702 : List (BitVec 512) := [w2203,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10702 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4483,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4483 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10703 : List (BitVec 512) := [w2203,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10703 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4499,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4499 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10704 : List (BitVec 512) := [w2203,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10704 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4502,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4502 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10705 : List (BitVec 512) := [w2203,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10705 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_10705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4515,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4515 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10706 : List (BitVec 512) := [w2203,w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10706 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s4_10706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4516,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4516 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10707 : List (BitVec 512) := [w2203,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10707 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(2,true))] s4_10707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4519,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4519 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10708 : List (BitVec 512) := [w2203,w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10708 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_10708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4544,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4544 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10709 : List (BitVec 512) := [w2203,w3766,w4344,w4557,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10709 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_10709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4557,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4557 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10710 : List (BitVec 512) := [w2203,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10710 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_10710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4561,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4561 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10711 : List (BitVec 512) := [w2203,w3766,w4344,w4567,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10711 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(2,true))] s4_10711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4567,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4567 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10712 : List (BitVec 512) := [w2203,w3766,w4344,w4568,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10712 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_10712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4568,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4568 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10713 : List (BitVec 512) := [w2203,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10713 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10713 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_10713 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4571,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4571 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10714 : List (BitVec 512) := [w2203,w3766,w4344,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10714 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_10714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4589,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4589 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10715 : List (BitVec 512) := [w2203,w3766,w4344,w4591,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10715 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10715 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_10715 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4591,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4591 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10716 : List (BitVec 512) := [w2203,w3766,w4344,w4592,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10716 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_10716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4592,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4592 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10717 : List (BitVec 512) := [w2203,w3766,w4344,w4596,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10717 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10717 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_10717 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4596,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4596 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10718 : List (BitVec 512) := [w2203,w3766,w4344,w4597,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10718 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10718 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_10718 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4597,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4597 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10719 : List (BitVec 512) := [w2203,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10719 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_10719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4599,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4599 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10720 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10720 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10720 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_10720 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4746,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4746 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10721 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10721 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10721 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_10721 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4747,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4747 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10722 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10722 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10722 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_10722 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4748,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4748 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10723 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10723 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10723 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_10723 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4750,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4750 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10724 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4751,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10724 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10724 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_10724 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4751,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4751 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10725 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4753,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10725 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_10725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4753,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4753 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10726 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4764,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10726 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_10726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4764,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4764 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10727 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4765,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10727 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_10727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4765,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4765 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10728 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10728 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_10728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4766,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10729 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4768,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10729 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_10729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4768,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4768 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10730 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4769,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10730 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_10730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4769,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4769 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10731 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4771,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10731 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10731 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_10731 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4771,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4771 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10732 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4778,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10732 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10732 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_10732 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4778,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4778 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10733 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4779,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10733 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_10733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4779,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4779 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10734 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4780,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10734 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10734 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_10734 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4780,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4780 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
