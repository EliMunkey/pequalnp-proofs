import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2026 : List (BitVec 512) := [w1312,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2026 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2026 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2026 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2027 : List (BitVec 512) := [w1312,w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2027 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2027 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2027 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2028 : List (BitVec 512) := [w1312,w2341,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2028 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2028 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2028 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2341,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2341 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2029 : List (BitVec 512) := [w1312,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2029 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2029 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2029 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2030 : List (BitVec 512) := [w1312,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2030 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2030 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2030 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2031 : List (BitVec 512) := [w1312,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2031 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2031 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2031 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2032 : List (BitVec 512) := [w1312,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2032 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2032 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2032 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2033 : List (BitVec 512) := [w1312,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2033 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2033 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2033 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2034 : List (BitVec 512) := [w1312,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2034 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2034 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2034 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2102 : List (BitVec 512) := [w1312,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2102 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2102 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2102 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2103 : List (BitVec 512) := [w1312,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2103 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2103 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2103 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2122 : List (BitVec 512) := [w1312,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2122 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2122 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2122 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2123 : List (BitVec 512) := [w1312,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2123 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2123 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2123 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2162 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2162 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2162 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2162 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2163 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b3_2163 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2163 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2163 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2164 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5268,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2164 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2164 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2164 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5268,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5268 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2165 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5268,w5393,w5585,w5956,w6300,w6588]
theorem b3_2165 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2165 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2165 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5268,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5268 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2166 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2166 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2166 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2166 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2167 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b3_2167 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2167 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2167 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2168 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2168 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2168 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2168 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2169 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b3_2169 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2169 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2169 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2170 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2170 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2170 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2170 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2171 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b3_2171 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2171 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2171 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2172 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5337,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2172 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2172 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2172 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5337,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5337 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2173 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5337,w5393,w5585,w5956,w6300,w6588]
theorem b3_2173 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2173 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2173 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5337,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5337 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2174 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5432,w5585,w5769,w5956,w6300,w6588]
theorem b3_2174 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2174 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2174 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5432,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5432 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2175 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5432,w5585,w5956,w6300,w6588]
theorem b3_2175 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2175 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2175 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5432,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5432 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2178 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5769,w5956,w6300,w6588]
theorem b3_2178 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2178 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2178 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2179 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b3_2179 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2179 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2179 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2180 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5769,w5956,w6300,w6588]
theorem b3_2180 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2180 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2180 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2181 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b3_2181 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2181 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2181 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2206 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5884,w5956,w6300,w6588]
theorem b3_2206 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2206 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2206 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2207 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5894,w5956,w6300,w6588]
theorem b3_2207 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2207 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2207 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2216 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6158,w6300,w6588]
theorem b3_2216 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2216 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2216 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2226 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6451,w6588]
theorem b3_2226 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2226 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2226 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2235 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6767]
theorem b3_2235 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2235 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2235 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl)))))))))))) (by decide +kernel)
def s3_2247 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b3_2247 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2247 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2247 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2248 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6588]
theorem b3_2248 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2248 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2248 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2257 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b3_2257 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2257 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2257 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2267 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b3_2267 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2267 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2267 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2277 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b3_2277 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2277 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2277 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s3_2305 : List (BitVec 512) := [w1353,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2305 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2305 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2305 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2306 : List (BitVec 512) := [w1353,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2306 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2306 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2306 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2308 : List (BitVec 512) := [w1353,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2308 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2308 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2308 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2309 : List (BitVec 512) := [w1353,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2309 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2309 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2309 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2310 : List (BitVec 512) := [w1353,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2310 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2310 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2310 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2311 : List (BitVec 512) := [w1353,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2311 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2311 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2311 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2340 : List (BitVec 512) := [w1353,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2340 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2340 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2340 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2348 : List (BitVec 512) := [w1353,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2348 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2348 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2348 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2367 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b3_2367 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2367 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2367 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2368 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b3_2368 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2368 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2368 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2369 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b3_2369 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2369 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2369 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2370 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b3_2370 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2370 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2370 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2371 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5335,w5393,w5585,w5956,w6300,w6588]
theorem b3_2371 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2371 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2371 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5335,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5335 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2372 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5434,w5585,w5956,w6300,w6588]
theorem b3_2372 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2372 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2372 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5434,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5434 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2374 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b3_2374 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2374 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2374 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2375 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b3_2375 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2375 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2375 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2387 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b3_2387 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2387 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2387 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2406 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b3_2406 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2406 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2406 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2416 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b3_2416 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2416 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2416 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2426 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b3_2426 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2426 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true))] s3_2426 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1353,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1353 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s3_2450 : List (BitVec 512) := [w1374,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2450 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2450 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_2450 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2451 : List (BitVec 512) := [w1374,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2451 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2451 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_2451 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2452 : List (BitVec 512) := [w1374,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2452 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2452 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_2452 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
