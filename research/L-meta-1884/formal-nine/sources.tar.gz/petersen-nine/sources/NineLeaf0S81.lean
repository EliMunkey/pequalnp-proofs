import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_14341 : List (BitVec 512) := [w3687,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_14341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14341 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s4_14341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14342 : List (BitVec 512) := [w3687,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_14342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14342 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false))] s4_14342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6575,v0_6588] (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6575 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14343 : List (BitVec 512) := [w3687,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14343 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_14343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3687,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3687 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14344 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14344 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true))] s4_14344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14345 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14345 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s4_14345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14346 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14346 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s4_14346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14347 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_14347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14347 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_14347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14348 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14348 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_14348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14349 : List (BitVec 512) := [w3764,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_14349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14349 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false))] s4_14349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3764,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_3764 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl))))))))))) (by decide +kernel)
def s4_14350 : List (BitVec 512) := [w3766,w3767,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_14350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14350 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_14350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3767,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3767 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14351 : List (BitVec 512) := [w3766,w3768,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_14351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14351 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_14351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3768,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3768 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14352 : List (BitVec 512) := [w3766,w3769,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14352 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_14352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3769,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3769 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14353 : List (BitVec 512) := [w3766,w3769,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_14353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14353 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false))] s4_14353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3769,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3769 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14354 : List (BitVec 512) := [w3766,w3771,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14354 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14354 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(8,true))] s4_14354 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3771,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3771 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14355 : List (BitVec 512) := [w3766,w3771,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_14355 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14355 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(8,true)),(false,(1,true),(0,false))] s4_14355 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3771,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3771 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_14356 : List (BitVec 512) := [w3766,w3773,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14356 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14356 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false))] s4_14356 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3773,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3773 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_14357 : List (BitVec 512) := [w3766,w3774,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14357 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14357 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(1,false),(0,true))] s4_14357 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3774,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3774 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_14358 : List (BitVec 512) := [w3766,w3775,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14358 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,false),(7,true))] s4_14358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3775,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3775 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14359 : List (BitVec 512) := [w3766,w3775,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14359 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14359 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true))] s4_14359 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3775,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3775 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_14360 : List (BitVec 512) := [w3766,w3777,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14360 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false))] s4_14360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3777,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3777 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_14361 : List (BitVec 512) := [w3766,w3778,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14361 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true)),(false,(1,true),(0,false))] s4_14361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3778,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3778 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14362 : List (BitVec 512) := [w3766,w3779,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14362 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14362 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(8,true)),(false,(1,true),(0,false))] s4_14362 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3779,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3779 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14363 : List (BitVec 512) := [w3766,w3780,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14363 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14363 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(6,true))] s4_14363 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3780,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3780 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14364 : List (BitVec 512) := [w3766,w3780,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14364 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(2,true),(6,true)),(false,(1,false),(0,true))] s4_14364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3780,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3780 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14365 : List (BitVec 512) := [w3766,w3781,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14365 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14365 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,false),(9,true))] s4_14365 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3781,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3781 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14366 : List (BitVec 512) := [w3766,w3781,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14366 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14366 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(1,true),(7,true)),(false,(1,false),(0,true))] s4_14366 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3781,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3781 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14367 : List (BitVec 512) := [w3766,w3782,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14367 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(5,true)),(false,(1,true),(0,false))] s4_14367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3782,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3782 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14368 : List (BitVec 512) := [w3766,w3783,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_14368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14368 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true))] s4_14368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3783,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3783 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_14369 : List (BitVec 512) := [w3766,w3786,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_14369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14369 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(8,true)),(false,(1,true),(0,false))] s4_14369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3786,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3786 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14370 : List (BitVec 512) := [w3766,w3787,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_14370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14370 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(2,true),(8,true)),(false,(1,true),(0,false))] s4_14370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3787,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3787 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14371 : List (BitVec 512) := [w3766,w3788,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14371 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,false),(3,true))] s4_14371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3788,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3788 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14372 : List (BitVec 512) := [w3766,w3788,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_14372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14372 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(6,true)),(false,(1,false),(0,true))] s4_14372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3788,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3788 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14373 : List (BitVec 512) := [w3766,w3790,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_14373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14373 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(2,true)),(false,(1,true),(0,false))] s4_14373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3790,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3790 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_14374 : List (BitVec 512) := [w3766,w3792,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14374 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true)),(false,(0,false),(9,true))] s4_14374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3792,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3792 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14375 : List (BitVec 512) := [w3766,w3792,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14375 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false))] s4_14375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3792,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3792 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14376 : List (BitVec 512) := [w3766,w3793,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14376 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(2,true))] s4_14376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3793,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3793 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14377 : List (BitVec 512) := [w3766,w3793,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14377 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false))] s4_14377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3793,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3793 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14378 : List (BitVec 512) := [w3766,w3794,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14378 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,false),(9,true))] s4_14378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3794,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3794 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14379 : List (BitVec 512) := [w3766,w3794,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14379 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(1,true),(0,false))] s4_14379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3794,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3794 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14380 : List (BitVec 512) := [w3766,w3796,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14380 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false))] s4_14380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3796,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3796 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14381 : List (BitVec 512) := [w3766,w3797,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(8,true)),(false,(1,true),(0,false))] s4_14381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3797,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3797 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14382 : List (BitVec 512) := [w3766,w3798,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_14382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14382 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(1,true)),(false,(1,true),(0,false))] s4_14382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3798,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3798 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_14383 : List (BitVec 512) := [w3766,w3817,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14383 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(6,true),(7,true))] s4_14383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3817,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3817 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14384 : List (BitVec 512) := [w3766,w3817,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_14384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14384 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(6,true),(8,true))] s4_14384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3817,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3817 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14385 : List (BitVec 512) := [w3766,w3817,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14385 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(8,true))] s4_14385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3817,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3817 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14386 : List (BitVec 512) := [w3766,w3829,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14386 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(7,true))] s4_14386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3829,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3829 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14387 : List (BitVec 512) := [w3766,w3829,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14387 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(3,true),(8,true))] s4_14387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3829,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3829 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14388 : List (BitVec 512) := [w3766,w3829,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14388 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true))] s4_14388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3829,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3829 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14389 : List (BitVec 512) := [w3766,w3830,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14389 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s4_14389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4392,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4392 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14390 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_14390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14390 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(1,false))] s4_14390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14391 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_14391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14391 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_14391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5993,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5993 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14392 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_14392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14392 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(7,true))] s4_14392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14393 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_14393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14393 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(7,true))] s4_14393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14394 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_14394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14394 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(8,true))] s4_14394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14395 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14395 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true))] s4_14395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14396 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6813]
theorem b4_14396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14396 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_14396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6785,v0_6813] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6813 rfl))))))))))) (by decide +kernel)
def s4_14397 : List (BitVec 512) := [w3766,w3830,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_14397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true))] s4_14397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3830,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3830 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14398 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14398 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14399 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_14399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14399 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true))] s4_14399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14400 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14400 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s4_14400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14401 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_14401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14401 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14402 : List (BitVec 512) := [w3766,w3831,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14402 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s4_14402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3831,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3831 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_14403 : List (BitVec 512) := [w3766,w3842,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14403 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true))] s4_14403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3842,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3842 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_14404 : List (BitVec 512) := [w3766,w3842,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_14404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14404 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true)),(false,(3,true),(8,true))] s4_14404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_3842,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3842 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
