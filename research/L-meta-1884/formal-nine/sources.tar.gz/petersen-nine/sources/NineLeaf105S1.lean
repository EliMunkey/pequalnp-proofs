import NinePin105
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12364 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5274,w5585,w5769,w5956,w6300,w6588]
theorem b4_12364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12364 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s4_12364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_2468,v105_3766,v105_4344,v105_4716,v105_5135,v105_5274,v105_5585,v105_5769,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_2468 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5274 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_15906 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b4_15906 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15906 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_15906 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4392,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6331,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6331 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_15914 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_15914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15914 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_15914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4392,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6489,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_15931 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_15931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15931 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_15931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4392,v105_4716,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_15933 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_15933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15933 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_15933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4392,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_16303 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6342,w6588]
theorem b4_16303 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16303 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_16303 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4483,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6342,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4483 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6342 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_16311 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_16311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16311 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_16311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4483,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6489,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4483 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_16329 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_16329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16329 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_16329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4483,v105_4716,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4483 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_16332 : List (BitVec 512) := [w3766,w4344,w4483,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_16332 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16332 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_16332 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4483,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4483 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_17287 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6813,w6873]
theorem b4_17287 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17287 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17287 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5767,v105_5956,v105_6300,v105_6813,v105_6873] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5767 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_17313 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6394,w6588]
theorem b4_17313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17313 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6394,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6394 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_17314 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6403,w6588]
theorem b4_17314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17314 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6403,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6403 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_17315 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6499,w6588]
theorem b4_17315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17315 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6499,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6499 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_17325 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6575,w6588]
theorem b4_17325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17325 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6575,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6575 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_17349 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6618,w6873]
theorem b4_17349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17349 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6618,v105_6873] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6618 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_17351 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6653,w6873]
theorem b4_17351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17351 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6653,v105_6873] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6653 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_17381 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5993,w6300,w6522,w6588]
theorem b4_17381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17381 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_17381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5993,v105_6300,v105_6522,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5993 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s5_109 : List (BitVec 512) := [w29,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_109 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_109 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s5_109 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_29,v105_2468,v105_3766,v105_4344,v105_4716,v105_5135,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_29 (PetersenWireProjection.cons pc105_2468 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_403 : List (BitVec 512) := [w195,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588,w6895]
theorem b5_403 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_403 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_403 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_5135,v105_5393,v105_5769,v105_5956,v105_6464,v105_6588,v105_6895] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6895 rfl)))))))))) (by decide +kernel)
def s5_405 : List (BitVec 512) := [w195,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_405 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_405 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_405 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_5135,v105_5393,v105_5769,v105_5956,v105_6464,v105_6720,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6720 (PetersenWireProjection.cons pc105_6873 rfl)))))))))) (by decide +kernel)
def s5_556 : List (BitVec 512) := [w326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_556 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_556 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_556 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_326,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_326 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_1873 : List (BitVec 512) := [w1095,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6731]
theorem b5_1873 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1873 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_1873 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1095,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6731] (PetersenWireProjection.cons pc105_1095 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6731 rfl)))))))))) (by decide +kernel)
def s5_1874 : List (BitVec 512) := [w1095,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b5_1874 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1874 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_1874 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1095,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5956,v105_6101,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1095 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6101 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_2263 : List (BitVec 512) := [w1253,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6795]
theorem b5_2263 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2263 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2263 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1253,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6795] (PetersenWireProjection.cons pc105_1253 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6795 rfl)))))))))) (by decide +kernel)
def s5_2264 : List (BitVec 512) := [w1253,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b5_2264 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2264 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2264 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1253,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5956,v105_6179,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1253 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6179 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_2302 : List (BitVec 512) := [w1278,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6803]
theorem b5_2302 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2302 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2302 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1278,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6803] (PetersenWireProjection.cons pc105_1278 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6803 rfl)))))))))) (by decide +kernel)
def s5_2447 : List (BitVec 512) := [w1312,w2173,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6813]
theorem b5_2447 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2447 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2447 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2173,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5956,v105_6300,v105_6813] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2173 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 rfl)))))))))) (by decide +kernel)
def s5_2448 : List (BitVec 512) := [w1312,w2173,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_2448 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2448 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2448 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2173,v105_3766,v105_4344,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2173 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2453 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6813]
theorem b5_2453 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2453 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s5_2453 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2468,v105_3766,v105_4344,v105_4716,v105_5135,v105_5585,v105_5956,v105_6300,v105_6813] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2468 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 rfl)))))))))) (by decide +kernel)
def s5_2455 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6300,w6720]
theorem b5_2455 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2455 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s5_2455 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2468,v105_3766,v105_4344,v105_5135,v105_5585,v105_5769,v105_5956,v105_6300,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2468 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2457 : List (BitVec 512) := [w1312,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2457 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2457 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s5_2457 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2497,v105_3766,v105_4344,v105_4716,v105_5135,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2497 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_2483 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5393,w5769,w5956,w6300,w6464,w6720]
theorem b5_2483 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2483 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(3,true),(2,false))] s5_2483 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2681,v105_3766,v105_4344,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2681 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2527 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6785]
theorem b5_2527 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2527 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2527 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_6179,v105_6300,v105_6522,v105_6785] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_6179 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6785 rfl)))))))))) (by decide +kernel)
def s5_2550 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b5_2550 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2550 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2550 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_6101,v105_6300,v105_6522,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_6101 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2551 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6720]
theorem b5_2551 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2551 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2551 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_6225,v105_6300,v105_6522,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2559 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6478,w6720]
theorem b5_2559 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2559 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2559 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6478,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6478 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2562 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5956,w6225,w6300,w6464,w6720]
theorem b5_2562 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2562 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2562 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5956,v105_6225,v105_6300,v105_6464,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2566 : List (BitVec 512) := [w1312,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6720]
theorem b5_2566 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2566 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_5135,v105_5393,v105_5698,v105_5769,v105_5956,v105_6300,v105_6389,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5698 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_2567 : List (BitVec 512) := [w1312,w3766,w5135,w5393,w5698,w5769,w5956,w6389,w6422,w6588]
theorem b5_2567 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2567 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_2567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_5135,v105_5393,v105_5698,v105_5769,v105_5956,v105_6389,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5698 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_5413 : List (BitVec 512) := [w3766,w4274,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5413 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5413 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_5413 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4274,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4274 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s5_5499 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5769,w5956,w6300,w6464,w6720]
theorem b5_5499 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5499 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_5499 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4392,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6720] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s5_6141 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5767,w5956,w6464,w6813,w6873]
theorem b5_6141 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6141 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s5_6141 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5767,v105_5956,v105_6464,v105_6813,v105_6873] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5767 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6873 rfl)))))))))) (by decide +kernel)
end NineCert
