import PetersenComponentLifts
import PetersenBareBases
import Cost3
import Cost7
import M189Closing
import ThetaClosing
import higher.EightUnconditional
import PetersenPackedPin
import PetersenLayerCheck
open PetersenWordCost
namespace NineExtra
abbrev Hard8 := NoAtMost (inputs 8) (graphTarget 8 [(0,1),(1,2),(0,5),(1,6),(2,7),(3,5),(5,7),(7,4),(4,6),(6,3)]) 12
set_option maxRecDepth 200000
set_option maxHeartbeats 0
theorem b15_0 : NoAtMost ([0xaaaa,0xcccc,0xf0f0,0xff00] : List (BitVec 16)) 0xf8c8 3 := by
  exact PetersenGraphCosts.mask15_lower
theorem b15_1 : NoAtMost ([0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] : List (BitVec 32)) 0xfffff8c8 4 := by
  apply lift_pin (insertRow 4 4 false) (insertRow 4 4 true) b15_0 <;> decide +kernel
theorem b15_2 : NoAtMost ([0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] : List (BitVec 64)) 0xfffffffffffff8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) b15_1 <;> decide +kernel
theorem b15_3 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xfffffffffffffffffffffffffffff8c8 6 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) b15_2 <;> decide +kernel
theorem b47_0 : NoAtMost ([0xaaaaaaaa,0xcccccccc,0xf0f0f0f0,0xff00ff00,0xffff0000] : List (BitVec 32)) 0xfaeaf8c8 4 := by
  exact PetersenGraphCosts.mask47_lower
theorem b47_1 : NoAtMost ([0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] : List (BitVec 64)) 0xfffffffffaeaf8c8 5 := by
  apply lift_pin (insertRow 5 5 false) (insertRow 5 5 true) b47_0 <;> decide +kernel
theorem b47_2 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xfffffffffffffffffffffffffaeaf8c8 6 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) b47_1 <;> decide +kernel
theorem b47_3 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] : List (BitVec 256)) 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffffffaeaf8c8 7 := by
  apply lift_pin (insertRow 7 7 false) (insertRow 7 7 true) b47_2 <;> decide +kernel
theorem b63_0 : NoAtMost ([0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] : List (BitVec 64)) 0xffeafaeaffeaf8c8 7 := by
  exact PetersenGraphCosts.mask63_exact_lower
theorem b111_0 : NoAtMost ([0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] : List (BitVec 64)) 0xfeeefcccfaeaf8c8 6 := by
  exact PetersenGraphCosts.M111.bound
theorem b127_0 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xffeefeeeffeefcccffeafaeaffeaf8c8 8 := by
  exact PetersenGraphCosts.mask127_exact_lower
theorem b189_0 : NoAtMost ([0xaaaaaaaaaaaaaaaa,0xcccccccccccccccc,0xf0f0f0f0f0f0f0f0,0xff00ff00ff00ff00,0xffff0000ffff0000,0xffffffff00000000] : List (BitVec 64)) 0xfffffeccfaeafac0 7 := by
  exact M189Certificate.lower
theorem b189_1 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xfffffffffffffffffffffeccfaeafac0 8 := by
  apply lift_pin (insertRow 6 6 false) (insertRow 6 6 true) b189_0 <;> decide +kernel
theorem b189_2 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] : List (BitVec 256)) 0xfffffffffffffffffffffffffffffffffffffffffffffffffffffeccfaeafac0 9 := by
  apply lift_pin (insertRow 7 7 false) (insertRow 7 7 true) b189_1 <;> decide +kernel
theorem b191_0 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xfffffffffffaf8f8ffeafaeaffeaf8c8 10 := by
  exact ThetaCert.bound
theorem b251_0 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000] : List (BitVec 128)) 0xfffffeccfffffa88feeefeccfaaafa88 7 := by
  exact PetersenGraphCosts.mask251_exact_lower
theorem b1018_0 : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] : List (BitVec 256)) 0xfffffffffffffffcfffffffffffff0f0ffffffccffffffccffeaffc0eaeac0c0 11 := by
  exact EightVertexLifts.mask1018_ge12
theorem b1020_0 (adj : Hard8) : NoAtMost ([0xaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa,0xcccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc,0xf0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0f0,0xff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00ff00,0xffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000ffff0000,0xffffffff00000000ffffffff00000000ffffffff00000000ffffffff00000000,0xffffffffffffffff0000000000000000ffffffffffffffff0000000000000000,0xffffffffffffffffffffffffffffffff00000000000000000000000000000000] : List (BitVec 256)) 0xfffffffffffffffcfffffffffffff8f8ffffffeeffffffccffeaffeac8c8c8c8 12 := by
  exact adj
end NineExtra
