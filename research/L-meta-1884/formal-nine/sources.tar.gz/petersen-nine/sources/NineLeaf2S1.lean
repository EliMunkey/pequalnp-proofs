import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_429 : List (BitVec 512) := [w475,w1366,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_429 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_429 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true))] s3_429 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_1366,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_1366 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_430 : List (BitVec 512) := [w475,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_430 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_430 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true))] s3_430 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_431 : List (BitVec 512) := [w475,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_431 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_431 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true))] s3_431 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_432 : List (BitVec 512) := [w477,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_432 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_432 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_432 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_433 : List (BitVec 512) := [w477,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_433 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_433 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_433 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_434 : List (BitVec 512) := [w477,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_434 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_434 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_434 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_435 : List (BitVec 512) := [w477,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_435 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_435 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true))] s3_435 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_436 : List (BitVec 512) := [w491,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_436 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_436 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_436 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_437 : List (BitVec 512) := [w491,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_437 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_437 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_437 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_438 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_438 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_438 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_438 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_439 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_439 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_439 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true))] s3_439 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_440 : List (BitVec 512) := [w492,w1410,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_440 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_440 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true))] s3_440 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_1410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_1410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_441 : List (BitVec 512) := [w492,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_441 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_441 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true))] s3_441 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_442 : List (BitVec 512) := [w494,w1413,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_442 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_442 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true))] s3_442 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_494,v2_1413,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_494 (PetersenWireProjection.cons pc2_1413 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_443 : List (BitVec 512) := [w494,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_443 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_443 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true))] s3_443 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_444 : List (BitVec 512) := [w498,w1418,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_444 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_444 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true))] s3_444 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_1418,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_1418 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_447 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_447 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_447 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true))] s3_447 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_1306 : List (BitVec 512) := [w1119,w1609,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1306 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1306 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1306 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_1609,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_1609 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1309 : List (BitVec 512) := [w1119,w1850,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1309 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1309 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1309 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_1850,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_1850 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1315 : List (BitVec 512) := [w1119,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1315 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1315 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1315 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1316 : List (BitVec 512) := [w1119,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1316 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1316 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1316 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1318 : List (BitVec 512) := [w1119,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1318 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1318 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1318 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1319 : List (BitVec 512) := [w1119,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1319 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1319 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1319 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1320 : List (BitVec 512) := [w1119,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1320 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1320 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1320 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1321 : List (BitVec 512) := [w1119,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1321 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1321 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1321 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1357 : List (BitVec 512) := [w1119,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1357 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1357 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1357 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1365 : List (BitVec 512) := [w1119,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1365 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1365 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1365 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1394 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b3_1394 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1394 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1394 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1395 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b3_1395 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1395 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1395 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1396 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b3_1396 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1396 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1396 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1397 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b3_1397 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1397 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1397 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1398 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5349,w5393,w5585,w5956,w6300,w6588]
theorem b3_1398 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1398 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1398 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5349,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5349 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1399 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5420,w5585,w5956,w6300,w6588]
theorem b3_1399 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1399 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1399 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5420,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5420 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1401 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b3_1401 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1401 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1401 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1402 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b3_1402 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1402 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1402 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1414 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b3_1414 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1414 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1414 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1424 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b3_1424 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1424 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1424 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1434 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b3_1434 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1434 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1434 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1445 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b3_1445 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1445 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s3_1445 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s3_1873 : List (BitVec 512) := [w1292,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1873 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1873 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1874 : List (BitVec 512) := [w1292,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1874 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1874 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1874 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1876 : List (BitVec 512) := [w1292,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1876 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1876 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1876 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1877 : List (BitVec 512) := [w1292,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1877 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1877 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1877 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1878 : List (BitVec 512) := [w1292,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1878 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1878 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1878 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1879 : List (BitVec 512) := [w1292,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1879 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1879 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1879 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1910 : List (BitVec 512) := [w1292,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1910 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1910 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1910 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1918 : List (BitVec 512) := [w1292,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1918 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1918 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1918 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1937 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b3_1937 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1937 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1937 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1938 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b3_1938 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1938 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1938 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1939 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b3_1939 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1939 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1939 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1940 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b3_1940 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1940 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1940 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1941 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5338,w5393,w5585,w5956,w6300,w6588]
theorem b3_1941 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1941 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1941 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5338,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5338 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1942 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5431,w5585,w5956,w6300,w6588]
theorem b3_1942 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1942 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1942 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5431,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5431 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1944 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b3_1944 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1944 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1944 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1945 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b3_1945 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1945 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1945 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1967 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b3_1967 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1967 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1967 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1976 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b3_1976 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1976 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1976 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1986 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b3_1986 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1986 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1986 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_1996 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b3_1996 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1996 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s3_1996 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s3_2019 : List (BitVec 512) := [w1312,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2019 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2019 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2019 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2020 : List (BitVec 512) := [w1312,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2020 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2020 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2020 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2021 : List (BitVec 512) := [w1312,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2021 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2021 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2021 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_2022 : List (BitVec 512) := [w1312,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2022 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2022 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2022 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_2025 : List (BitVec 512) := [w1312,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2025 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2025 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true))] s3_2025 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1312,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1312 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
