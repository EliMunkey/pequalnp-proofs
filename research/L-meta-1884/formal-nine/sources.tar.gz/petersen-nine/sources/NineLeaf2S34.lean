import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11580 : List (BitVec 512) := [w2354,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_11580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11580 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11581 : List (BitVec 512) := [w2354,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_11581 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11581 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11581 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11582 : List (BitVec 512) := [w2354,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11582 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11582 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11582 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11583 : List (BitVec 512) := [w2354,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_11583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11583 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_11583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11584 : List (BitVec 512) := [w2354,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_11584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11584 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2696,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_11585 : List (BitVec 512) := [w2354,w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11585 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_11585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4392,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4392 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11586 : List (BitVec 512) := [w2354,w3766,w4344,w4402,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11586 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_11586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4402,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4402 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11587 : List (BitVec 512) := [w2354,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11587 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11587 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_11587 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4403,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4403 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11588 : List (BitVec 512) := [w2354,w3766,w4344,w4412,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11588 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_11588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4412,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4412 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11589 : List (BitVec 512) := [w2354,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11589 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_11589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4413,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4413 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11590 : List (BitVec 512) := [w2354,w3766,w4344,w4415,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11590 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true))] s4_11590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4415,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4415 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11591 : List (BitVec 512) := [w2354,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11591 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11591 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_11591 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4426,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4426 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11592 : List (BitVec 512) := [w2354,w3766,w4344,w4427,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11592 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11592 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_11592 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4427,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4427 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11593 : List (BitVec 512) := [w2354,w3766,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11593 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11593 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_11593 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4428,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4428 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11594 : List (BitVec 512) := [w2354,w3766,w4344,w4430,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11594 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11594 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_11594 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4430,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4430 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11595 : List (BitVec 512) := [w2354,w3766,w4344,w4431,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11595 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11595 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_11595 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4431,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4431 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11596 : List (BitVec 512) := [w2354,w3766,w4344,w4433,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11596 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11596 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true))] s4_11596 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4433,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4433 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11597 : List (BitVec 512) := [w2354,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11597 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s4_11597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4483,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4483 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11598 : List (BitVec 512) := [w2354,w3766,w4344,w4499,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11598 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11598 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s4_11598 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4499,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4499 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11599 : List (BitVec 512) := [w2354,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11599 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s4_11599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4502,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4502 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11600 : List (BitVec 512) := [w2354,w3766,w4344,w4515,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11600 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(3,true))] s4_11600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4515,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4515 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11601 : List (BitVec 512) := [w2354,w3766,w4344,w4516,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11601 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true))] s4_11601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4516,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4516 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11602 : List (BitVec 512) := [w2354,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11602 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(3,true))] s4_11602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4519,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4519 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11603 : List (BitVec 512) := [w2354,w3766,w4344,w4544,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11603 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_11603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4544,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4544 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11604 : List (BitVec 512) := [w2354,w3766,w4344,w4557,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11604 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_11604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4557,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4557 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11605 : List (BitVec 512) := [w2354,w3766,w4344,w4561,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11605 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_11605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4561,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4561 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11606 : List (BitVec 512) := [w2354,w3766,w4344,w4567,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11606 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_11606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4567,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4567 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11607 : List (BitVec 512) := [w2354,w3766,w4344,w4568,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11607 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_11607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4568,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4568 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11608 : List (BitVec 512) := [w2354,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11608 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_11608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4571,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4571 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11609 : List (BitVec 512) := [w2354,w3766,w4344,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11609 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_11609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4589,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4589 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11610 : List (BitVec 512) := [w2354,w3766,w4344,w4591,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11610 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_11610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4591,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4591 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11611 : List (BitVec 512) := [w2354,w3766,w4344,w4592,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11611 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_11611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4592,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4592 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11612 : List (BitVec 512) := [w2354,w3766,w4344,w4596,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11612 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11612 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_11612 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4596,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4596 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11613 : List (BitVec 512) := [w2354,w3766,w4344,w4597,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11613 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true))] s4_11613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4597,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4597 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11614 : List (BitVec 512) := [w2354,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11614 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_11614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4599,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4599 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11615 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11615 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_11615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4746,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4746 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11616 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11616 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11616 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_11616 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4747,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4747 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11617 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11617 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_11617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4748,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4748 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11618 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11618 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_11618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4750,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4750 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11619 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4751,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11619 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s4_11619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4751,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4751 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11620 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4753,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11620 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11620 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s4_11620 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4753,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4753 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11621 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4764,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11621 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11621 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_11621 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4764,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4764 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11622 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4765,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11622 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s4_11622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4765,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4765 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11623 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11623 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11623 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true))] s4_11623 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4766,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11624 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4768,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11624 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11624 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s4_11624 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4768,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4768 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11625 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4769,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11625 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11625 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s4_11625 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4769,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4769 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11626 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4771,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11626 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(8,true))] s4_11626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4771,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4771 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11627 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4778,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11627 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11627 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true))] s4_11627 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4778,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4778 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11628 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4779,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11628 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11628 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true))] s4_11628 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4779,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4779 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11629 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4780,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11629 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11629 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(8,true))] s4_11629 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4780,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4780 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11630 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4782,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11630 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11630 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(3,true)),(false,(0,true),(8,true))] s4_11630 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4782,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4782 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11631 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4783,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11631 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11631 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(8,true))] s4_11631 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4783,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4783 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11632 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11632 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11632 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true))] s4_11632 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4785,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4785 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11633 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4789,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11633 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11633 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_11633 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4789,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4789 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11634 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4790,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11634 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11634 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_11634 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4790,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4790 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11635 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4791,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11635 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11635 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_11635 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4791,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4791 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11636 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4793,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11636 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11636 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s4_11636 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4793,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4793 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11637 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4794,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11637 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_11637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4794,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4794 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11638 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4796,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_11638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4796,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4796 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11639 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_11639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11639 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(7,true))] s4_11639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4800,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4800 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11640 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4803,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11640 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11640 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true))] s4_11640 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4803,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4803 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11641 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4804,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11641 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_11641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4804,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4804 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11642 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4805,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11642 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true))] s4_11642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4805,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4805 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11643 : List (BitVec 512) := [w2354,w3766,w4344,w4716,w4807,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11643 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_11643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_3766,v2_4344,v2_4716,v2_4807,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4807 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
