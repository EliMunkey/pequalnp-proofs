import NinePin37
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_6279 : List (BitVec 512) := [w1174,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_6279 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6279 := by
  intro m le c
  apply rejects_sound r37 i7 8 tgt (small37 adj) hot37 [(false,(4,true),(2,true))] s4_6279 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v37_1174,v37_3766,v37_4344,v37_4716,v37_5200,v37_5393,v37_5585,v37_5956,v37_6179,v37_6300,v37_6588] (PetersenWireProjection.cons pc37_1174 (PetersenWireProjection.cons pc37_3766 (PetersenWireProjection.cons pc37_4344 (PetersenWireProjection.cons pc37_4716 (PetersenWireProjection.cons pc37_5200 (PetersenWireProjection.cons pc37_5393 (PetersenWireProjection.cons pc37_5585 (PetersenWireProjection.cons pc37_5956 (PetersenWireProjection.cons pc37_6179 (PetersenWireProjection.cons pc37_6300 (PetersenWireProjection.cons pc37_6588 rfl))))))))))) (by decide +kernel)
def s4_10212 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5241,w5393,w5585,w5956,w6300,w6588]
theorem b4_10212 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10212 := by
  intro m le c
  apply rejects_sound r37 i7 8 tgt (small37 adj) hot37 [(false,(3,true),(5,true))] s4_10212 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v37_1403,v37_3766,v37_4344,v37_4716,v37_5187,v37_5241,v37_5393,v37_5585,v37_5956,v37_6300,v37_6588] (PetersenWireProjection.cons pc37_1403 (PetersenWireProjection.cons pc37_3766 (PetersenWireProjection.cons pc37_4344 (PetersenWireProjection.cons pc37_4716 (PetersenWireProjection.cons pc37_5187 (PetersenWireProjection.cons pc37_5241 (PetersenWireProjection.cons pc37_5393 (PetersenWireProjection.cons pc37_5585 (PetersenWireProjection.cons pc37_5956 (PetersenWireProjection.cons pc37_6300 (PetersenWireProjection.cons pc37_6588 rfl))))))))))) (by decide +kernel)
def s4_10222 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5862,w5956,w6300,w6588]
theorem b4_10222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10222 := by
  intro m le c
  apply rejects_sound r37 i7 8 tgt (small37 adj) hot37 [(false,(3,true),(5,true))] s4_10222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v37_1403,v37_3766,v37_4344,v37_4716,v37_5187,v37_5393,v37_5585,v37_5862,v37_5956,v37_6300,v37_6588] (PetersenWireProjection.cons pc37_1403 (PetersenWireProjection.cons pc37_3766 (PetersenWireProjection.cons pc37_4344 (PetersenWireProjection.cons pc37_4716 (PetersenWireProjection.cons pc37_5187 (PetersenWireProjection.cons pc37_5393 (PetersenWireProjection.cons pc37_5585 (PetersenWireProjection.cons pc37_5862 (PetersenWireProjection.cons pc37_5956 (PetersenWireProjection.cons pc37_6300 (PetersenWireProjection.cons pc37_6588 rfl))))))))))) (by decide +kernel)
def s5_3201 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_3201 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3201 := by
  intro m le c
  apply rejects_sound r37 i7 8 tgt (small37 adj) hot37 [(false,(3,true),(5,true))] s5_3201 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v37_1403,v37_3766,v37_4344,v37_4716,v37_5200,v37_5393,v37_5585,v37_5956,v37_6300,v37_6588] (PetersenWireProjection.cons pc37_1403 (PetersenWireProjection.cons pc37_3766 (PetersenWireProjection.cons pc37_4344 (PetersenWireProjection.cons pc37_4716 (PetersenWireProjection.cons pc37_5200 (PetersenWireProjection.cons pc37_5393 (PetersenWireProjection.cons pc37_5585 (PetersenWireProjection.cons pc37_5956 (PetersenWireProjection.cons pc37_6300 (PetersenWireProjection.cons pc37_6588 rfl)))))))))) (by decide +kernel)
end NineCert
