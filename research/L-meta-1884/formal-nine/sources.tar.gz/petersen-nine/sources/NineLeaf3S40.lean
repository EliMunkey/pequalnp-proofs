import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4790 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6225,w6300,w6588]
theorem b4_4790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4790 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(2,true))] s4_4790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4791 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6237,w6300,w6588]
theorem b4_4791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4791 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(2,true))] s4_4791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6237,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6237 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4792 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6422,w6588]
theorem b4_4792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4792 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(6,true),(5,true))] s4_4792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4793 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6478,w6588]
theorem b4_4793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4793 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(5,true),(7,true))] s4_4793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4794 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6543,w6588]
theorem b4_4794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4794 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(6,true),(7,true))] s4_4794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4795 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6567,w6588]
theorem b4_4795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4795 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(7,true))] s4_4795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4796 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6572,w6588]
theorem b4_4796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4796 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(7,true))] s4_4796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6572,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6572 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4797 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_4797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4797 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_4797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4798 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6690]
theorem b4_4798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4798 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4799 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6720]
theorem b4_4799 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4799 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(6,true),(5,true))] s4_4799 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_4800 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6807]
theorem b4_4800 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4800 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(5,true),(8,true))] s4_4800 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4801 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6852]
theorem b4_4801 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4801 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(6,true),(8,true))] s4_4801 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_4802 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6866]
theorem b4_4802 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4802 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(8,true))] s4_4802 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_4803 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6868]
theorem b4_4803 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4803 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(8,true))] s4_4803 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6868] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6868 rfl))))))))))) (by decide +kernel)
def s4_4804 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6873]
theorem b4_4804 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4804 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(5,true))] s4_4804 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4805 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b4_4805 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4805 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4805 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4806 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6201,w6300,w6588]
theorem b4_4806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4806 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(6,true),(2,true))] s4_4806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4807 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6225,w6300,w6588]
theorem b4_4807 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4807 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(5,true))] s4_4807 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4808 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6464,w6588]
theorem b4_4808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4808 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(6,true),(2,true))] s4_4808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4809 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6543,w6588]
theorem b4_4809 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4809 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s4_4809 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4810 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6549,w6588]
theorem b4_4810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4810 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s4_4810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4811 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_4811 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4811 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_4811 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4812 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6690]
theorem b4_4812 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4812 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_4812 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4813 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6785]
theorem b4_4813 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4813 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(2,true),(6,true))] s4_4813 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_4814 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6852]
theorem b4_4814 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4814 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(2,true))] s4_4814 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s4_4815 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6857]
theorem b4_4815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4815 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,false))] s4_4815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s4_4816 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6873]
theorem b4_4816 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4816 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(2,true))] s4_4816 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4817 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6690]
theorem b4_4817 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4817 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s4_4817 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4818 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6179,w6201,w6300,w6522,w6588]
theorem b4_4818 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4818 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(6,true),(7,true))] s4_4818 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6201,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4819 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5585,w6179,w6201,w6300,w6588,w6832]
theorem b4_4819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4819 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(6,true),(8,true))] s4_4819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6201,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_4820 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6201,w6300,w6588]
theorem b4_4820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4820 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(5,true),(2,true))] s4_4820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4821 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6225,w6300,w6588]
theorem b4_4821 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4821 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s4_4821 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4822 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6478,w6588]
theorem b4_4822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4822 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(5,true),(2,true))] s4_4822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4823 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6489,w6588]
theorem b4_4823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4823 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s4_4823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4824 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6522,w6588]
theorem b4_4824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4824 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true))] s4_4824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4825 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_4825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4825 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4826 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6690]
theorem b4_4826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4826 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4827 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6807]
theorem b4_4827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4827 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(5,true),(2,true))] s4_4827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4828 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6813]
theorem b4_4828 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4828 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false))] s4_4828 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s4_4829 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6832]
theorem b4_4829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4829 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(5,true))] s4_4829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_4830 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6873]
theorem b4_4830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4830 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(5,true),(2,true))] s4_4830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4831 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b4_4831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4831 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_4831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4832 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5848,w5956,w6179,w6300,w6588]
theorem b4_4832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4832 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(5,true),(6,true))] s4_4832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5848,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4833 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6101,w6225,w6300,w6588]
theorem b4_4833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4833 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(5,true),(0,false))] s4_4833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6101,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4834 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6225,w6300,w6588]
theorem b4_4834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4834 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(2,true))] s4_4834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4835 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6422,w6588]
theorem b4_4835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4835 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(6,true),(5,true))] s4_4835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4836 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6478,w6588]
theorem b4_4836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4836 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(5,true),(6,true))] s4_4836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4837 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6567,w6588]
theorem b4_4837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4837 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false))] s4_4837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4838 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_4838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4838 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4839 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588,w6690]
theorem b4_4839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4839 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_4840 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588,w6720]
theorem b4_4840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4840 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(6,true))] s4_4840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_4841 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588,w6807]
theorem b4_4841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4841 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(5,true),(6,true))] s4_4841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_4842 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588,w6866]
theorem b4_4842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4842 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(8,true))] s4_4842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s4_4843 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588,w6873]
theorem b4_4843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4843 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(5,true),(6,true))] s4_4843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_4844 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b4_4844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4844 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_4844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_4845 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_4845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4845 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(5,true),(0,false))] s4_4845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4846 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_4846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4846 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(6,true))] s4_4846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4847 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_4847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4847 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(6,true),(5,true))] s4_4847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s4_4848 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5769,w5956,w6061,w6300,w6464,w6588]
theorem b4_4848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4848 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(5,true),(7,true))] s4_4848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5769,v3_5956,v3_6061,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4849 : List (BitVec 512) := [w967,w3766,w4716,w5135,w5393,w5956,w6179,w6201,w6300,w6588,w6785]
theorem b4_4849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4849 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(5,true),(8,true))] s4_4849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6201,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_4850 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588,w6720]
theorem b4_4850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4850 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(2,true),(8,true))] s4_4850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_4851 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6422,w6588]
theorem b4_4851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4851 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(7,true))] s4_4851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4852 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588,w6720]
theorem b4_4852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4852 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(2,true),(8,true))] s4_4852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6061,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_4853 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_4853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4853 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(2,true))] s4_4853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
end NineCert
