import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_628 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_628 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_628 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_628 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_629 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_629 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_629 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_629 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_630 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_630 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_630 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_630 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_631 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6720]
theorem b4_631 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_631 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s4_631 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_632 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_632 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_632 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_632 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_633 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_633 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_633 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,false))] s4_633 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6478,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6478 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_634 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_634 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_634 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_634 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_635 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_635 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_635 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_635 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_636 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_636 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_636 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_636 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6748] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s4_637 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_637 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_637 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(7,true),(0,false))] s4_637 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6807] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6807 rfl))))))))))) (by decide +kernel)
def s4_638 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_638 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(8,true))] s4_638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6852] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
def s4_639 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b4_639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_639 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true))] s4_639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_640 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_640 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_640 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true))] s4_640 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6897] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6897 rfl))))))))))) (by decide +kernel)
def s4_641 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_641 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,false),(5,true)),(false,(8,true),(0,false))] s4_641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6905] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6905 rfl))))))))))) (by decide +kernel)
def s4_642 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_642 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s4_642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_643 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b4_643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_643 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(5,true),(8,true))] s4_643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690,v4_6832] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_644 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_644 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_645 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_645 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_645 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,false))] s4_645 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6890] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_646 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_646 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s4_646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_647 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_647 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(4,true))] s4_647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_648 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_648 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s4_648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_649 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_649 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(4,true))] s4_649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_650 : List (BitVec 512) := [w71,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_650 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(3,true)),(false,(5,true),(0,false))] s4_650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_71,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_71 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_823 : List (BitVec 512) := [w137,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_823 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_137,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_137 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_824 : List (BitVec 512) := [w140,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_824 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_140,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_140 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_825 : List (BitVec 512) := [w141,w202,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_825 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_825 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s4_825 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_141,v4_202,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_141 (PetersenWireProjection.cons pc4_202 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_826 : List (BitVec 512) := [w141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_826 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_826 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_826 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_141,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_141 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_827 : List (BitVec 512) := [w141,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_827 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_827 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_827 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_141,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_141 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_829 : List (BitVec 512) := [w143,w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_829 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s4_829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_192,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_192 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_830 : List (BitVec 512) := [w143,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_830 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false)),(false,(0,false),(4,true))] s4_830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_195,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_195 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_831 : List (BitVec 512) := [w143,w199,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_831 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s4_831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_199,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_199 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_832 : List (BitVec 512) := [w143,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_832 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,false),(4,true))] s4_832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_200,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_200 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_833 : List (BitVec 512) := [w143,w202,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_833 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(5,true)),(false,(1,true),(0,false))] s4_833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_202,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_202 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_834 : List (BitVec 512) := [w143,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_834 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,false),(3,true)),(false,(6,true),(0,true))] s4_834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1403,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6890] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_835 : List (BitVec 512) := [w143,w1410,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_835 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(4,true))] s4_835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1410,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1410 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_836 : List (BitVec 512) := [w143,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6890]
theorem b4_836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_836 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1664,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1664 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_837 : List (BitVec 512) := [w143,w1665,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_837 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,false))] s4_837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1665,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1665 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_838 : List (BitVec 512) := [w143,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_838 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(7,true))] s4_838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1832,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1832 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_839 : List (BitVec 512) := [w143,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_839 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true))] s4_839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_840 : List (BitVec 512) := [w143,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_840 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_841 : List (BitVec 512) := [w143,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_841 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true)),(false,(5,true),(6,true))] s4_841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1894,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1894 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_842 : List (BitVec 512) := [w143,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_842 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true))] s4_842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_843 : List (BitVec 512) := [w143,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_843 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true)),(false,(5,true),(9,true))] s4_843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_844 : List (BitVec 512) := [w143,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_844 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,false),(3,true)),(false,(9,true),(0,true))] s4_844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1916,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1916 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_845 : List (BitVec 512) := [w143,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_845 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(8,true))] s4_845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_1917,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_1917 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_846 : List (BitVec 512) := [w143,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_846 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(6,true))] s4_846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2104,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2104 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_847 : List (BitVec 512) := [w143,w2124,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_847 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(7,true))] s4_847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2124,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2124 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_848 : List (BitVec 512) := [w143,w2125,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_848 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true))] s4_848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2125,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2125 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_849 : List (BitVec 512) := [w143,w2143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_849 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(0,true)),(false,(5,true),(6,true))] s4_849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2143,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2143 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_850 : List (BitVec 512) := [w143,w2165,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873]
theorem b4_850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_850 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,false)),(false,(5,true),(4,true))] s4_850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2165,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2165 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_851 : List (BitVec 512) := [w143,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_851 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,true))] s4_851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2171,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2171 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_852 : List (BitVec 512) := [w143,w2171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_852 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,true)),(false,(4,true),(8,true))] s4_852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2171,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2171 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_853 : List (BitVec 512) := [w143,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785,w6873]
theorem b4_853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_853 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,true)),(false,(6,true),(8,true))] s4_853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2171,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5956,v4_6300,v4_6785,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2171 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_854 : List (BitVec 512) := [w143,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6588,w6873]
theorem b4_854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_854 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(7,true)),(false,(5,true),(8,true))] s4_854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2171,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2171 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_855 : List (BitVec 512) := [w143,w2172,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_855 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(8,true))] s4_855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2172,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2172 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_856 : List (BitVec 512) := [w143,w2173,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_856 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,true))] s4_856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2173,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2173 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_857 : List (BitVec 512) := [w143,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_857 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(0,true),(8,true))] s4_857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2175,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2175 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_858 : List (BitVec 512) := [w143,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_858 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true)),(false,(6,true),(5,true))] s4_858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_859 : List (BitVec 512) := [w143,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_859 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_860 : List (BitVec 512) := [w143,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_860 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_861 : List (BitVec 512) := [w143,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_861 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2527,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2527 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_862 : List (BitVec 512) := [w143,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b4_862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_862 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s4_862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_863 : List (BitVec 512) := [w143,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_863 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false)),(false,(4,true),(5,true))] s4_863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6873] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_864 : List (BitVec 512) := [w143,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_864 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s4_864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_143,v4_2696,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_143 (PetersenWireProjection.cons pc4_2696 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
