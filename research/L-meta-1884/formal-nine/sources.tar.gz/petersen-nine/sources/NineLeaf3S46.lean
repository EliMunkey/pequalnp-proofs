import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10419 : List (BitVec 512) := [w1415,w3766,w4344,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10419 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4413,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4413 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10434 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10434 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10474 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10474 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10475 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b4_10475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10475 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s4_10475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10496 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10496 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10506 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10506 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10507 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6690]
theorem b4_10507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10507 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10522 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6690]
theorem b4_10522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10522 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10527 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6465,w6588]
theorem b4_10527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10527 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6465,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6465 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10531 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6690]
theorem b4_10531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10531 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10549 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10549 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10551 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_10551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10551 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10562 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_10562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10562 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_10562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_10624 : List (BitVec 512) := [w1710,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6588]
theorem b4_10624 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10624 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(5,true)),(false,(1,true),(0,true))] s4_10624 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6177,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6177 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10625 : List (BitVec 512) := [w1710,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10625 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10625 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_10625 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10829 : List (BitVec 512) := [w2212,w3766,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_10829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10829 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_10829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2212,v3_3766,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2212 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10830 : List (BitVec 512) := [w2212,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_10830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10830 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_10830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2212,v3_3766,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2212 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10831 : List (BitVec 512) := [w2213,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_10831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10831 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s4_10831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2213,v3_3766,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2213 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10832 : List (BitVec 512) := [w2213,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_10832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10832 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s4_10832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2213,v3_3766,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2213 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10833 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10833 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10834 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_10834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10834 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_10834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_4800,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4800 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10835 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_10835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10835 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10836 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_10836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10836 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s4_10836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5652,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5652 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10837 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_10837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10837 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10838 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_10838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10838 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_10838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10839 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10839 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10840 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_10840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10840 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_10840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10841 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_10841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10841 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_10841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10842 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_10842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10842 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_10842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6640] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6640 rfl))))))))))) (by decide +kernel)
def s4_10843 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_10843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10843 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_10844 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_10844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10844 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_10844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_10845 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_10845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10845 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_10845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_10846 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_10846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10846 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_10846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_10847 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_10847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10847 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10848 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_10848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10848 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_10848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_10849 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_10849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10849 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_10849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10850 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_10850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10850 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_10850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_6179,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10851 : List (BitVec 512) := [w2214,w2468,w3766,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10851 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10852 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10852 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10853 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_10853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10853 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10854 : List (BitVec 512) := [w2214,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10854 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_10854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_3766,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10855 : List (BitVec 512) := [w2220,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_10855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10855 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s4_10855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10856 : List (BitVec 512) := [w2220,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_10856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10856 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10857 : List (BitVec 512) := [w2220,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_10857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10857 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10858 : List (BitVec 512) := [w2220,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10858 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10859 : List (BitVec 512) := [w2221,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6588]
theorem b4_10859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10859 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s4_10859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2221,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2221 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10860 : List (BitVec 512) := [w2221,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6464,w6588]
theorem b4_10860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10860 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2221,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_2221 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10861 : List (BitVec 512) := [w2221,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_10861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10861 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2221,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_2221 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_10862 : List (BitVec 512) := [w2221,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10862 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2221,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2221 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10863 : List (BitVec 512) := [w2222,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10863 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2222,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2222 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_10864 : List (BitVec 512) := [w2222,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6832]
theorem b4_10864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10864 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2222,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_2222 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s4_10865 : List (BitVec 512) := [w2222,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_10865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10865 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_10865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2222,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_2222 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_10866 : List (BitVec 512) := [w2222,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_10866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10866 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2222,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_2222 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s4_12110 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12110 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4583,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4583 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12111 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12111 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12112 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_12112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12112 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s4_12112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5652,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5652 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12113 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12113 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12114 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12114 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12115 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12115 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12116 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12116 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12117 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12117 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_12118 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12118 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_12119 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12119 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_12120 : List (BitVec 512) := [w2468,w3766,w3936,w4344,w4926,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12120 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2468,v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
