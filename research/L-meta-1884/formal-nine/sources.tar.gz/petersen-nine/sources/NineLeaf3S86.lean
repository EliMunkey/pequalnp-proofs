import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5282 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5282 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5282 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5282 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5283 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_5283 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5283 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(6,true)),(false,(0,true),(4,true))] s5_5283 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5470,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5470 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5284 : List (BitVec 512) := [w3766,w4121,w4344,w4716,w5135,w5471,w5698,w5956,w6300,w6588]
theorem b5_5284 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5284 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_5284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_4716,v3_5135,v3_5471,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5285 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_5285 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5285 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_5285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5393,v3_5769,v3_5956,v3_6464,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5286 : List (BitVec 512) := [w3766,w4121,w4344,w5135,w5471,w5585,w5956,w6300,w6588,w6720]
theorem b5_5286 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5286 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(3,true),(9,true)),(false,(1,true),(6,true))] s5_5286 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4344,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5287 : List (BitVec 512) := [w3766,w4121,w4392,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_5287 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5287 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s5_5287 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4392,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4392 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5288 : List (BitVec 512) := [w3766,w4121,w4426,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_5288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5288 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(7,true),(8,true))] s5_5288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4426,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5289 : List (BitVec 512) := [w3766,w4121,w4426,w5135,w5393,w5585,w5769,w5956,w6422,w6588]
theorem b5_5289 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5289 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(3,true),(8,true))] s5_5289 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4426,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5290 : List (BitVec 512) := [w3766,w4121,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_5290 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5290 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s5_5290 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4716,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5291 : List (BitVec 512) := [w3766,w4121,w4716,w5135,w5471,w5698,w5769,w5956,w6300,w6588]
theorem b5_5291 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5291 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_5291 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_4716,v3_5135,v3_5471,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5292 : List (BitVec 512) := [w3766,w4121,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b5_5292 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5292 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(8,true),(2,true))] s5_5292 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5293 : List (BitVec 512) := [w3766,w4121,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6895]
theorem b5_5293 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5293 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(6,true),(3,true))] s5_5293 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl)))))))))) (by decide +kernel)
def s5_5294 : List (BitVec 512) := [w3766,w4121,w5135,w5393,w5698,w5769,w5956,w6300,w6720,w6873]
theorem b5_5294 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5294 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(8,true),(2,true)),(false,(3,true),(6,true))] s5_5294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4121,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4121 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5295 : List (BitVec 512) := [w3766,w4122,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5295 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4122,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4122 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5297 : List (BitVec 512) := [w3766,w4124,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_5297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5297 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4124,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4124 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5300 : List (BitVec 512) := [w3766,w4128,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5300 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5300 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5300 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4128,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4128 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5301 : List (BitVec 512) := [w3766,w4129,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5301 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5301 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4129,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4129 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5303 : List (BitVec 512) := [w3766,w4131,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_5303 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5303 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(3,true),(9,true))] s5_5303 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4131,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4131 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5304 : List (BitVec 512) := [w3766,w4134,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5304 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5304 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5304 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4134,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4134 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5305 : List (BitVec 512) := [w3766,w4135,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5305 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4135,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4135 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5308 : List (BitVec 512) := [w3766,w4138,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_5308 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5308 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(7,true),(8,true))] s5_5308 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4138,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4138 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5309 : List (BitVec 512) := [w3766,w4138,w4344,w5135,w5393,w5585,w5769,w5956,w6422,w6588]
theorem b5_5309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(3,true),(8,true))] s5_5309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4138,v3_4344,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4138 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5310 : List (BitVec 512) := [w3766,w4139,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5310 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5310 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5310 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4139,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4139 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5311 : List (BitVec 512) := [w3766,w4140,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4140,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4140 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5316 : List (BitVec 512) := [w3766,w4144,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b5_5316 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(3,true),(9,true))] s5_5316 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4144,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4144 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5317 : List (BitVec 512) := [w3766,w4162,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5317 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5317 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4162,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4162 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5318 : List (BitVec 512) := [w3766,w4163,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5318 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5319 : List (BitVec 512) := [w3766,w4163,w4344,w4716,w5135,w5393,w5585,w5995,w6300,w6588]
theorem b5_5319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s5_5319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5995,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5995 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5320 : List (BitVec 512) := [w3766,w4163,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_5320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5320 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_5320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5321 : List (BitVec 512) := [w3766,w4163,w4716,w5135,w5393,w5585,w6032,w6101,w6300,w6588]
theorem b5_5321 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5321 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(5,false),(0,false)),(false,(0,true),(7,true))] s5_5321 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4716,v3_5135,v3_5393,v3_5585,v3_6032,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6032 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5322 : List (BitVec 512) := [w3766,w4163,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_5322 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5322 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s5_5322 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5323 : List (BitVec 512) := [w3766,w4163,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_5323 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5323 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(6,true))] s5_5323 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5324 : List (BitVec 512) := [w3766,w4163,w4926,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b5_5324 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(7,true),(6,true)),(false,(3,true),(7,true))] s5_5324 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4163,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5326 : List (BitVec 512) := [w3766,w4167,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5326 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5326 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4167,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4167 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5327 : List (BitVec 512) := [w3766,w4168,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5327 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5327 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5327 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4168,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4168 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5329 : List (BitVec 512) := [w3766,w4171,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5329 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5329 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4171,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4171 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5330 : List (BitVec 512) := [w3766,w4172,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5330 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5330 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4172,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4172 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5331 : List (BitVec 512) := [w3766,w4172,w4716,w5135,w5393,w5585,w5956,w6114,w6300,w6588]
theorem b5_5331 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5331 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(6,true),(2,true)),(false,(1,true),(0,false))] s5_5331 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4172,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6114,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4172 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6114 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5332 : List (BitVec 512) := [w3766,w4172,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5332 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5332 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4172,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4172 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_5334 : List (BitVec 512) := [w3766,w4177,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5334 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5334 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5334 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4177,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4177 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5335 : List (BitVec 512) := [w3766,w4178,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5335 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5335 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4178,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4178 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5336 : List (BitVec 512) := [w3766,w4178,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b5_5336 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5336 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s5_5336 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4178,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4178 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5337 : List (BitVec 512) := [w3766,w4178,w4716,w5135,w5393,w5698,w6225,w6300,w6522,w6588]
theorem b5_5337 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(2,true)),(false,(7,true),(0,false))] s5_5337 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4178,v3_4716,v3_5135,v3_5393,v3_5698,v3_6225,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4178 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5338 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5338 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5338 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5339 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5339 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5339 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5340 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6566,w6588]
theorem b5_5340 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5340 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(8,false),(0,true)),(false,(0,true),(8,true))] s5_5340 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6566,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6566 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5341 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5200,w5393,w5585,w5956,w6389,w6588]
theorem b5_5341 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5341 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_5341 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5342 : List (BitVec 512) := [w3766,w4179,w4426,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5342 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5342 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,true))] s5_5342 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4426,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4426 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5343 : List (BitVec 512) := [w3766,w4179,w4427,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5343 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5343 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(7,true))] s5_5343 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4427,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4427 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5344 : List (BitVec 512) := [w3766,w4179,w4428,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5344 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5344 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(7,true))] s5_5344 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4428,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4428 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5345 : List (BitVec 512) := [w3766,w4179,w4430,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5345 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5345 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,true),(7,true))] s5_5345 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4430,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4430 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5346 : List (BitVec 512) := [w3766,w4179,w4431,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5346 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5346 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,true),(7,true))] s5_5346 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4431,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4431 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5347 : List (BitVec 512) := [w3766,w4179,w4433,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5347 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5347 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,true),(7,true))] s5_5347 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4433,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4433 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5348 : List (BitVec 512) := [w3766,w4180,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5348 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5348 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5348 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4180,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4180 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5349 : List (BitVec 512) := [w3766,w4185,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5349 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5349 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5349 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4185,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4185 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5350 : List (BitVec 512) := [w3766,w4187,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5350 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5350 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5350 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4187,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4187 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5351 : List (BitVec 512) := [w3766,w4189,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5351 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5351 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5351 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4189,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4189 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5352 : List (BitVec 512) := [w3766,w4190,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5352 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5352 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5352 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4190,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4190 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5353 : List (BitVec 512) := [w3766,w4191,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5353 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5353 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5353 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4191,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4191 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5354 : List (BitVec 512) := [w3766,w4193,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5354 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5354 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5354 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4193,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4193 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5355 : List (BitVec 512) := [w3766,w4194,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5355 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5355 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5355 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4194,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4194 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5356 : List (BitVec 512) := [w3766,w4195,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5356 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5356 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5356 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4195,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4195 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5357 : List (BitVec 512) := [w3766,w4195,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_5357 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5357 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5357 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4195,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4195 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5358 : List (BitVec 512) := [w3766,w4195,w4716,w5135,w5393,w5585,w5956,w6334,w6389,w6588]
theorem b5_5358 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5358 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s5_5358 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4195,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6334,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4195 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6334 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
