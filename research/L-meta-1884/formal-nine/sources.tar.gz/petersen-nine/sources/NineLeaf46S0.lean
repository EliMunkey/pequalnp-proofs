import NinePin46
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_2870 : List (BitVec 512) := [w628,w1665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2870 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(4,true),(3,true))] s4_2870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_628,v46_1665,v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_628 (PetersenWireProjection.cons pc46_1665 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl))))))))))) (by decide +kernel)
def s4_2878 : List (BitVec 512) := [w628,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2878 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(3,true),(4,true))] s4_2878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_628,v46_2681,v46_3766,v46_4344,v46_4716,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588,v46_6720] (PetersenWireProjection.cons pc46_628 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 (PetersenWireProjection.cons pc46_6720 rfl))))))))))) (by decide +kernel)
def s4_2924 : List (BitVec 512) := [w632,w1665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2924 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(3,true))] s4_2924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_632,v46_1665,v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_632 (PetersenWireProjection.cons pc46_1665 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl))))))))))) (by decide +kernel)
def s4_2932 : List (BitVec 512) := [w632,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_2932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2932 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(3,true),(2,true))] s4_2932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_632,v46_2681,v46_3766,v46_4344,v46_4716,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588,v46_6720] (PetersenWireProjection.cons pc46_632 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 (PetersenWireProjection.cons pc46_6720 rfl))))))))))) (by decide +kernel)
def s4_2987 : List (BitVec 512) := [w635,w1665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2987 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(4,true))] s4_2987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_635,v46_1665,v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_635 (PetersenWireProjection.cons pc46_1665 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl))))))))))) (by decide +kernel)
def s4_3018 : List (BitVec 512) := [w635,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3018 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(4,true),(2,true))] s4_3018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_635,v46_2681,v46_3766,v46_4344,v46_4716,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588,v46_6720] (PetersenWireProjection.cons pc46_635 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 (PetersenWireProjection.cons pc46_6720 rfl))))))))))) (by decide +kernel)
def s4_7662 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_7662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7662 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s4_7662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1312,v46_2681,v46_3766,v46_4344,v46_4716,v46_5393,v46_5585,v46_5956,v46_6300,v46_6720,v46_6813] (PetersenWireProjection.cons pc46_1312 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6813 rfl))))))))))) (by decide +kernel)
def s4_9175 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6174,w6300,w6720]
theorem b4_9175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9175 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(4,true),(2,true))] s4_9175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1374,v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6174,v46_6300,v46_6720] (PetersenWireProjection.cons pc46_1374 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6174 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6720 rfl))))))))))) (by decide +kernel)
def s4_9192 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6215,w6300,w6588]
theorem b4_9192 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9192 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(4,true),(2,true))] s4_9192 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1374,v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6215,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_1374 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6215 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl))))))))))) (by decide +kernel)
def s4_16238 : List (BitVec 512) := [w3766,w4344,w4446,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16238 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s4_16238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_4446,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4446 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl)))))))))) (by decide +kernel)
def s4_16239 : List (BitVec 512) := [w3766,w4344,w4446,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_16239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16239 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s4_16239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_4446,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588,v46_6720] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4446 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 (PetersenWireProjection.cons pc46_6720 rfl))))))))))) (by decide +kernel)
def s4_17962 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6460,w6720,w6873]
theorem b4_17962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17962 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s4_17962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6460,v46_6720,v46_6873] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6460 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6873 rfl)))))))))) (by decide +kernel)
def s4_17995 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6516,w6522,w6720,w6873]
theorem b4_17995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17995 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(5,true))] s4_17995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6516,v46_6522,v46_6720,v46_6873] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6522 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6873 rfl))))))))))) (by decide +kernel)
def s5_2480 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_2480 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2480 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s5_2480 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1312,v46_2681,v46_3766,v46_4344,v46_5393,v46_5585,v46_5956,v46_6101,v46_6300,v46_6720] (PetersenWireProjection.cons pc46_1312 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6101 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6720 rfl)))))))))) (by decide +kernel)
def s5_2553 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5694,w5769,w5956,w6300,w6720]
theorem b5_2553 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2553 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s5_2553 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1312,v46_3766,v46_4344,v46_5135,v46_5393,v46_5694,v46_5769,v46_5956,v46_6300,v46_6720] (PetersenWireProjection.cons pc46_1312 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5694 (PetersenWireProjection.cons pc46_5769 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6720 rfl)))))))))) (by decide +kernel)
def s5_2848 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5393,w5585,w5956,w6215,w6300,w6720]
theorem b5_2848 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2848 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(4,true),(2,true))] s5_2848 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_1374,v46_3766,v46_4344,v46_5135,v46_5393,v46_5585,v46_5956,v46_6215,v46_6300,v46_6720] (PetersenWireProjection.cons pc46_1374 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6215 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6720 rfl)))))))))) (by decide +kernel)
def s5_3879 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6516,w6588]
theorem b5_3879 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3879 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s5_3879 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_2681,v46_3766,v46_4344,v46_4716,v46_5585,v46_5956,v46_6300,v46_6516,v46_6588] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6588 rfl)))))))))) (by decide +kernel)
def s5_4083 : List (BitVec 512) := [w2468,w3766,w4344,w4581,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4083 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4083 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(5,true)),(false,(2,true),(0,true))] s5_4083 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_3766,v46_4344,v46_4581,v46_4716,v46_5135,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4581 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl)))))))))) (by decide +kernel)
def s5_4223 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6516,w6720,w6873]
theorem b5_4223 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4223 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(5,true)),(false,(2,true),(0,true))] s5_4223 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_3766,v46_4344,v46_4716,v46_5135,v46_5585,v46_5956,v46_6516,v46_6720,v46_6873] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6873 rfl)))))))))) (by decide +kernel)
def s5_5597 : List (BitVec 512) := [w3766,w4344,w4501,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5597 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5597 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [] s5_5597 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_4501,v46_4716,v46_5135,v46_5393,v46_5585,v46_5956,v46_6300,v46_6588] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4501 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6300 (PetersenWireProjection.cons pc46_6588 rfl)))))))))) (by decide +kernel)
def s5_6252 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6516,w6522,w6720,w6873]
theorem b5_6252 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6252 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(5,true))] s5_6252 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_3766,v46_4344,v46_5135,v46_5393,v46_5585,v46_6101,v46_6516,v46_6522,v46_6720,v46_6873] (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5393 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_6101 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6522 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6873 rfl)))))))))) (by decide +kernel)
def s6_51 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6516,w6873]
theorem b6_51 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_51 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s6_51 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_2681,v46_3766,v46_4344,v46_4716,v46_5585,v46_5956,v46_6516,v46_6873] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_4716 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_5956 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6873 rfl))))))))) (by decide +kernel)
def s6_70 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5585,w6101,w6516,w6720,w6873]
theorem b6_70 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_70 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(2,true),(5,true)),(false,(2,true),(0,true))] s6_70 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_3766,v46_4344,v46_5135,v46_5585,v46_6101,v46_6516,v46_6720,v46_6873] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5135 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_6101 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6720 (PetersenWireProjection.cons pc46_6873 rfl))))))))) (by decide +kernel)
def s7_0 : List (BitVec 512) := [w2468,w2681,w3766,w4344,w5585,w6101,w6516,w6873]
theorem b7_0 (adj : NineExtra.Hard8) : Blocked tgt 7 s7_0 := by
  intro m le c
  apply rejects_sound r46 i6 7 tgt (small46 adj) hot46 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s7_0 7 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v46_2468,v46_2681,v46_3766,v46_4344,v46_5585,v46_6101,v46_6516,v46_6873] (PetersenWireProjection.cons pc46_2468 (PetersenWireProjection.cons pc46_2681 (PetersenWireProjection.cons pc46_3766 (PetersenWireProjection.cons pc46_4344 (PetersenWireProjection.cons pc46_5585 (PetersenWireProjection.cons pc46_6101 (PetersenWireProjection.cons pc46_6516 (PetersenWireProjection.cons pc46_6873 rfl)))))))) (by decide +kernel)
end NineCert
