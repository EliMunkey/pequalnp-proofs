import NinePin141
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5563 : List (BitVec 512) := [w1101,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_5563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5563 := by
  intro m le c
  apply rejects_sound r141 i7 6 tgt (small141 adj) hot141 [] s4_5563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v141_1101,v141_2468,v141_3766,v141_4344,v141_4716,v141_4800,v141_5135,v141_5585,v141_5956,v141_6300,v141_6588] (PetersenWireProjection.cons pc141_1101 (PetersenWireProjection.cons pc141_2468 (PetersenWireProjection.cons pc141_3766 (PetersenWireProjection.cons pc141_4344 (PetersenWireProjection.cons pc141_4716 (PetersenWireProjection.cons pc141_4800 (PetersenWireProjection.cons pc141_5135 (PetersenWireProjection.cons pc141_5585 (PetersenWireProjection.cons pc141_5956 (PetersenWireProjection.cons pc141_6300 (PetersenWireProjection.cons pc141_6588 rfl))))))))))) (by decide +kernel)
def s5_1884 : List (BitVec 512) := [w1101,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6736]
theorem b5_1884 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1884 := by
  intro m le c
  apply rejects_sound r141 i7 6 tgt (small141 adj) hot141 [] s5_1884 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v141_1101,v141_2468,v141_3766,v141_4344,v141_4716,v141_5135,v141_5585,v141_5956,v141_6300,v141_6736] (PetersenWireProjection.cons pc141_1101 (PetersenWireProjection.cons pc141_2468 (PetersenWireProjection.cons pc141_3766 (PetersenWireProjection.cons pc141_4344 (PetersenWireProjection.cons pc141_4716 (PetersenWireProjection.cons pc141_5135 (PetersenWireProjection.cons pc141_5585 (PetersenWireProjection.cons pc141_5956 (PetersenWireProjection.cons pc141_6300 (PetersenWireProjection.cons pc141_6736 rfl)))))))))) (by decide +kernel)
def s5_1887 : List (BitVec 512) := [w1101,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6640]
theorem b5_1887 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1887 := by
  intro m le c
  apply rejects_sound r141 i7 6 tgt (small141 adj) hot141 [] s5_1887 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v141_1101,v141_3766,v141_4344,v141_4716,v141_4800,v141_5135,v141_5585,v141_5956,v141_6300,v141_6640] (PetersenWireProjection.cons pc141_1101 (PetersenWireProjection.cons pc141_3766 (PetersenWireProjection.cons pc141_4344 (PetersenWireProjection.cons pc141_4716 (PetersenWireProjection.cons pc141_4800 (PetersenWireProjection.cons pc141_5135 (PetersenWireProjection.cons pc141_5585 (PetersenWireProjection.cons pc141_5956 (PetersenWireProjection.cons pc141_6300 (PetersenWireProjection.cons pc141_6640 rfl)))))))))) (by decide +kernel)
end NineCert
