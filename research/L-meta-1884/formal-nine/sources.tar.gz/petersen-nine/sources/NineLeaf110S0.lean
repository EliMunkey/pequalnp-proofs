import NinePin110
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_543 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6720]
theorem b3_543 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_543 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s3_543 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6588,v110_6720] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6720 rfl)))))))))))) (by decide +kernel)
def s3_2612 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6866]
theorem b3_2612 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2612 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s3_2612 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6785,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6785 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_2976 : List (BitVec 512) := [w635,w1388,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_2976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2976 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_2976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_1388,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5769,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5769 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_2977 : List (BitVec 512) := [w635,w1388,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_2977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2977 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_2977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_1388,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6225,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6225 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_3016 : List (BitVec 512) := [w635,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_3016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3016 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s4_3016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_2681,v110_3766,v110_4344,v110_4716,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_2681 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_3099 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_3099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3099 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_3099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588,v110_6869] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6869 rfl))))))))))) (by decide +kernel)
def s4_3101 : List (BitVec 512) := [w635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6645,w6720]
theorem b4_3101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3101 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_3101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6645,v110_6720] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6645 (PetersenWireProjection.cons pc110_6720 rfl))))))))))) (by decide +kernel)
def s4_3110 : List (BitVec 512) := [w635,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_3110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3110 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_3110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_3766,v110_4344,v110_4748,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588,v110_6720] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4748 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6720 rfl))))))))))) (by decide +kernel)
def s4_3117 : List (BitVec 512) := [w635,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_3117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3117 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_3117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6225,v110_6300,v110_6588,v110_6720] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6225 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6720 rfl))))))))))) (by decide +kernel)
def s4_4872 : List (BitVec 512) := [w975,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4872 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_4872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_975,v110_1650,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_975 (PetersenWireProjection.cons pc110_1650 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_4874 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_4874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4874 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_4874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_975,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_975 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_4920 : List (BitVec 512) := [w1022,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4920 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_4920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1022,v110_2837,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1022 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_4922 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_4922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4922 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_4922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1022,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1022 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_5541 : List (BitVec 512) := [w1085,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5541 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_5541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1085,v110_1650,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1085 (PetersenWireProjection.cons pc110_1650 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_5543 : List (BitVec 512) := [w1085,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5543 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_5543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1085,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1085 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_7170 : List (BitVec 512) := [w1292,w1650,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7170 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_7170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1292,v110_1650,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1292 (PetersenWireProjection.cons pc110_1650 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_7242 : List (BitVec 512) := [w1292,w2837,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7242 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_7242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1292,v110_2837,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1292 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_7683 : List (BitVec 512) := [w1312,w2837,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_7683 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7683 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_7683 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1312,v110_2837,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6225,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1312 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6225 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_8920 : List (BitVec 512) := [w1374,w2883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b4_8920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8920 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_8920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2883,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 rfl)))))))))) (by decide +kernel)
def s4_8921 : List (BitVec 512) := [w1374,w2883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8921 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_8921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2883,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_9232 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6866]
theorem b4_9232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9232 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6807,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6807 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_9234 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6866]
theorem b4_9234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9234 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6813,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6813 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_9235 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6852,w6866]
theorem b4_9235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9235 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6852,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6852 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_9237 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866,w6868]
theorem b4_9237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9237 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866,v110_6868] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 (PetersenWireProjection.cons pc110_6868 rfl))))))))))) (by decide +kernel)
def s4_9238 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866,w6869]
theorem b4_9238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9238 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866,v110_6869] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 (PetersenWireProjection.cons pc110_6869 rfl))))))))))) (by decide +kernel)
def s4_9273 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6852]
theorem b4_9273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9273 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6179,v110_6300,v110_6832,v110_6852] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6832 (PetersenWireProjection.cons pc110_6852 rfl))))))))))) (by decide +kernel)
def s4_9274 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6857]
theorem b4_9274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9274 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6179,v110_6300,v110_6832,v110_6857] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6832 (PetersenWireProjection.cons pc110_6857 rfl))))))))))) (by decide +kernel)
def s4_9278 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832,w6908]
theorem b4_9278 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9278 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9278 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6179,v110_6300,v110_6832,v110_6908] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6832 (PetersenWireProjection.cons pc110_6908 rfl))))))))))) (by decide +kernel)
def s4_9331 : List (BitVec 512) := [w1384,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9331 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1384,v110_2837,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1384 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_9490 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6866]
theorem b4_9490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9490 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1384,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1384 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_9609 : List (BitVec 512) := [w1388,w2837,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9609 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1388,v110_2837,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5769,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5769 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_9610 : List (BitVec 512) := [w1388,w2837,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_9610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9610 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1388,v110_2837,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6225,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_2837 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6225 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl))))))))))) (by decide +kernel)
def s4_9690 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6866]
theorem b4_9690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9690 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_9690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1388,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6179,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s4_16989 : List (BitVec 512) := [w3766,w4344,w4716,w4923,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_16989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16989 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s4_16989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_3766,v110_4344,v110_4716,v110_4923,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588,v110_6866] (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_4923 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6866 rfl))))))))))) (by decide +kernel)
def s5_941 : List (BitVec 512) := [w635,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6645]
theorem b5_941 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_941 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_941 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_2681,v110_3766,v110_4344,v110_4716,v110_5393,v110_5585,v110_5956,v110_6300,v110_6645] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_2681 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6645 rfl)))))))))) (by decide +kernel)
def s5_942 : List (BitVec 512) := [w635,w2681,w3766,w4344,w4748,w5393,w5585,w5956,w6300,w6588]
theorem b5_942 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_942 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_942 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_2681,v110_3766,v110_4344,v110_4748,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_2681 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4748 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_944 : List (BitVec 512) := [w635,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b5_944 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_944 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_944 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_2681,v110_3766,v110_4344,v110_5393,v110_5585,v110_5956,v110_6225,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_2681 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6225 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_945 : List (BitVec 512) := [w635,w2704,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_945 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_945 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_945 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_635,v110_2704,v110_3766,v110_4344,v110_4716,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_635 (PetersenWireProjection.cons pc110_2704 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_1478 : List (BitVec 512) := [w969,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1478 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1478 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_1478 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_969,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_969 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_1502 : List (BitVec 512) := [w975,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b5_1502 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1502 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_1502 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_975,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6179,v110_6522,v110_6588] (PetersenWireProjection.cons pc110_975 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6522 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_1583 : List (BitVec 512) := [w1022,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_1583 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1583 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_1583 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1022,v110_3766,v110_4344,v110_4716,v110_5200,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1022 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5200 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_1837 : List (BitVec 512) := [w1079,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1837 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1837 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_1837 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1079,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1079 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_2323 : List (BitVec 512) := [w1292,w1650,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6588]
theorem b5_2323 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2323 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2323 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1292,v110_1650,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_6179,v110_6522,v110_6588] (PetersenWireProjection.cons pc110_1292 (PetersenWireProjection.cons pc110_1650 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6522 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_2404 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5200,w5393,w5956,w6179,w6300,w6588]
theorem b5_2404 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2404 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2404 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1292,v110_3766,v110_4344,v110_4716,v110_5200,v110_5393,v110_5956,v110_6179,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1292 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5200 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_2759 : List (BitVec 512) := [w1374,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6866]
theorem b5_2759 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2759 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_1912,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_1912 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2760 : List (BitVec 512) := [w1374,w1912,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_2760 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2760 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2760 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_1912,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_6179,v110_6300,v110_6785] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_1912 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6785 rfl)))))))))) (by decide +kernel)
def s5_2763 : List (BitVec 512) := [w1374,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6866]
theorem b5_2763 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2763 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2763 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_1913,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_1913 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2765 : List (BitVec 512) := [w1374,w1913,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_2765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2765 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_1913,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_6179,v110_6300,v110_6785] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_1913 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6785 rfl)))))))))) (by decide +kernel)
def s5_2783 : List (BitVec 512) := [w1374,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6866]
theorem b5_2783 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2783 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(3,true),(2,false))] s5_2783 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2527,v110_3766,v110_4344,v110_4716,v110_5135,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2527 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2784 : List (BitVec 512) := [w1374,w2527,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6832]
theorem b5_2784 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2784 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(3,true),(2,false))] s5_2784 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2527,v110_3766,v110_4344,v110_4716,v110_5135,v110_5585,v110_6179,v110_6300,v110_6832] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2527 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6832 rfl)))))))))) (by decide +kernel)
def s5_2786 : List (BitVec 512) := [w1374,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6866]
theorem b5_2786 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2786 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(3,true),(2,false))] s5_2786 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2530,v110_3766,v110_4344,v110_4716,v110_5135,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2530 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2801 : List (BitVec 512) := [w1374,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6866]
theorem b5_2801 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2801 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_2801 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2686,v110_3766,v110_4344,v110_4716,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2686 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2802 : List (BitVec 512) := [w1374,w2686,w3766,w4344,w4716,w5393,w5956,w6179,w6300,w6785]
theorem b5_2802 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2802 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_2802 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2686,v110_3766,v110_4344,v110_4716,v110_5393,v110_5956,v110_6179,v110_6300,v110_6785] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2686 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6785 rfl)))))))))) (by decide +kernel)
def s5_2804 : List (BitVec 512) := [w1374,w2693,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6866]
theorem b5_2804 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2804 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_2804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2693,v110_3766,v110_4344,v110_4716,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2693 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_2808 : List (BitVec 512) := [w1374,w2883,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6869]
theorem b5_2808 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2808 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2808 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1374,v110_2883,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6869] (PetersenWireProjection.cons pc110_1374 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6869 rfl)))))))))) (by decide +kernel)
def s5_2876 : List (BitVec 512) := [w1384,w2883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_2876 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2876 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2876 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1384,v110_2883,v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300] (PetersenWireProjection.cons pc110_1384 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 rfl)))))))))) (by decide +kernel)
def s5_2956 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_2956 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2956 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_2956 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1384,v110_3766,v110_4344,v110_4716,v110_5200,v110_5393,v110_5585,v110_5956,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_1384 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5200 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_3012 : List (BitVec 512) := [w1388,w2883,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b5_3012 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3012 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_3012 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1388,v110_2883,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6866] (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6866 rfl)))))))))) (by decide +kernel)
def s5_3013 : List (BitVec 512) := [w1388,w2883,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6869]
theorem b5_3013 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3013 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_3013 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_1388,v110_2883,v110_3766,v110_4344,v110_5135,v110_5393,v110_5585,v110_5956,v110_6300,v110_6869] (PetersenWireProjection.cons pc110_1388 (PetersenWireProjection.cons pc110_2883 (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6869 rfl)))))))))) (by decide +kernel)
def s5_5763 : List (BitVec 512) := [w3766,w4344,w4716,w5026,w5393,w5585,w5956,w6189,w6300,w6588]
theorem b5_5763 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5763 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [(false,(5,true),(1,false))] s5_5763 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_3766,v110_4344,v110_4716,v110_5026,v110_5393,v110_5585,v110_5956,v110_6189,v110_6300,v110_6588] (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5026 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5585 (PetersenWireProjection.cons pc110_5956 (PetersenWireProjection.cons pc110_6189 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 rfl)))))))))) (by decide +kernel)
def s5_6157 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6177,w6179,w6522,w6785,w6873]
theorem b5_6157 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6157 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_6157 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_3766,v110_4344,v110_4716,v110_5135,v110_5393,v110_6177,v110_6179,v110_6522,v110_6785,v110_6873] (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5135 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_6177 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6522 (PetersenWireProjection.cons pc110_6785 (PetersenWireProjection.cons pc110_6873 rfl)))))))))) (by decide +kernel)
def s5_6234 : List (BitVec 512) := [w3766,w4344,w4716,w5200,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b5_6234 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6234 := by
  intro m le c
  apply rejects_sound r110 i6 6 tgt (small110 adj) hot110 [] s5_6234 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v110_3766,v110_4344,v110_4716,v110_5200,v110_5393,v110_5698,v110_6179,v110_6300,v110_6588,v110_6832] (PetersenWireProjection.cons pc110_3766 (PetersenWireProjection.cons pc110_4344 (PetersenWireProjection.cons pc110_4716 (PetersenWireProjection.cons pc110_5200 (PetersenWireProjection.cons pc110_5393 (PetersenWireProjection.cons pc110_5698 (PetersenWireProjection.cons pc110_6179 (PetersenWireProjection.cons pc110_6300 (PetersenWireProjection.cons pc110_6588 (PetersenWireProjection.cons pc110_6832 rfl)))))))))) (by decide +kernel)
end NineCert
