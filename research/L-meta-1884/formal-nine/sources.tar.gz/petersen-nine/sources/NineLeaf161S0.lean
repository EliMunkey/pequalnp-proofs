import NinePin161
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17095 : List (BitVec 512) := [w3766,w4344,w4716,w4941,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_17095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17095 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s4_17095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_3766,v161_4344,v161_4716,v161_4941,v161_5135,v161_5393,v161_5585,v161_5956,v161_6179,v161_6300,v161_6588] (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_4941 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_5585 (PetersenWireProjection.cons pc161_5956 (PetersenWireProjection.cons pc161_6179 (PetersenWireProjection.cons pc161_6300 (PetersenWireProjection.cons pc161_6588 rfl))))))))))) (by decide +kernel)
def s5_2955 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6785]
theorem b5_2955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2955 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s5_2955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_1384,v161_3766,v161_4344,v161_4716,v161_5135,v161_5393,v161_6179,v161_6300,v161_6522,v161_6785] (PetersenWireProjection.cons pc161_1384 (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_6179 (PetersenWireProjection.cons pc161_6300 (PetersenWireProjection.cons pc161_6522 (PetersenWireProjection.cons pc161_6785 rfl)))))))))) (by decide +kernel)
def s5_3331 : List (BitVec 512) := [w1622,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3331 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3331 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s5_3331 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_1622,v161_3766,v161_4344,v161_4716,v161_5135,v161_5393,v161_5585,v161_5956,v161_6300,v161_6588] (PetersenWireProjection.cons pc161_1622 (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_5585 (PetersenWireProjection.cons pc161_5956 (PetersenWireProjection.cons pc161_6300 (PetersenWireProjection.cons pc161_6588 rfl)))))))))) (by decide +kernel)
def s5_6159 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6201,w6522,w6785,w6873]
theorem b5_6159 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6159 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s5_6159 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_3766,v161_4344,v161_4716,v161_5135,v161_5393,v161_6179,v161_6201,v161_6522,v161_6785,v161_6873] (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_6179 (PetersenWireProjection.cons pc161_6201 (PetersenWireProjection.cons pc161_6522 (PetersenWireProjection.cons pc161_6785 (PetersenWireProjection.cons pc161_6873 rfl)))))))))) (by decide +kernel)
def s5_6160 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6225,w6522,w6785,w6873]
theorem b5_6160 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6160 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s5_6160 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_3766,v161_4344,v161_4716,v161_5135,v161_5393,v161_6179,v161_6225,v161_6522,v161_6785,v161_6873] (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_6179 (PetersenWireProjection.cons pc161_6225 (PetersenWireProjection.cons pc161_6522 (PetersenWireProjection.cons pc161_6785 (PetersenWireProjection.cons pc161_6873 rfl)))))))))) (by decide +kernel)
def s5_6171 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6807,w6873]
theorem b5_6171 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6171 := by
  intro m le c
  apply rejects_sound r161 i7 6 tgt (small161 adj) hot161 [] s5_6171 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v161_3766,v161_4344,v161_4716,v161_5135,v161_5393,v161_6179,v161_6522,v161_6785,v161_6807,v161_6873] (PetersenWireProjection.cons pc161_3766 (PetersenWireProjection.cons pc161_4344 (PetersenWireProjection.cons pc161_4716 (PetersenWireProjection.cons pc161_5135 (PetersenWireProjection.cons pc161_5393 (PetersenWireProjection.cons pc161_6179 (PetersenWireProjection.cons pc161_6522 (PetersenWireProjection.cons pc161_6785 (PetersenWireProjection.cons pc161_6807 (PetersenWireProjection.cons pc161_6873 rfl)))))))))) (by decide +kernel)
end NineCert
