import NinePin19
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_6280 : List (BitVec 512) := [w1174,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b4_6280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6280 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [] s4_6280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_1174,v19_3766,v19_4344,v19_4716,v19_5200,v19_5393,v19_5585,v19_5956,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_1174 (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_5200 (PetersenWireProjection.cons pc19_5393 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl)))))))))) (by decide +kernel)
def s5_3352 : List (BitVec 512) := [w2179,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3352 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3352 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s5_3352 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_2179,v19_2468,v19_2681,v19_3766,v19_4344,v19_4716,v19_5585,v19_5956,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_2179 (PetersenWireProjection.cons pc19_2468 (PetersenWireProjection.cons pc19_2681 (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl)))))))))) (by decide +kernel)
def s5_5736 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6240,w6300,w6588]
theorem b5_5736 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5736 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [(false,(6,true),(3,true))] s5_5736 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_3766,v19_4344,v19_4716,v19_4926,v19_5393,v19_5585,v19_5956,v19_6240,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_4926 (PetersenWireProjection.cons pc19_5393 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6240 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl)))))))))) (by decide +kernel)
def s5_5764 : List (BitVec 512) := [w3766,w4344,w4716,w5027,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5764 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [(false,(4,true),(2,true))] s5_5764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_3766,v19_4344,v19_4716,v19_5027,v19_5187,v19_5393,v19_5585,v19_5956,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_5027 (PetersenWireProjection.cons pc19_5187 (PetersenWireProjection.cons pc19_5393 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl)))))))))) (by decide +kernel)
def s6_37 : List (BitVec 512) := [w2179,w2706,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b6_37 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_37 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s6_37 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_2179,v19_2706,v19_3766,v19_4344,v19_4716,v19_5585,v19_5956,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_2179 (PetersenWireProjection.cons pc19_2706 (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl))))))))) (by decide +kernel)
def s6_53 : List (BitVec 512) := [w2468,w2687,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b6_53 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_53 := by
  intro m le c
  apply rejects_sound r19 i8 9 tgt (small19 adj) hot19 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s6_53 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v19_2468,v19_2687,v19_3766,v19_4344,v19_4716,v19_5585,v19_5956,v19_6300,v19_6588] (PetersenWireProjection.cons pc19_2468 (PetersenWireProjection.cons pc19_2687 (PetersenWireProjection.cons pc19_3766 (PetersenWireProjection.cons pc19_4344 (PetersenWireProjection.cons pc19_4716 (PetersenWireProjection.cons pc19_5585 (PetersenWireProjection.cons pc19_5956 (PetersenWireProjection.cons pc19_6300 (PetersenWireProjection.cons pc19_6588 rfl))))))))) (by decide +kernel)
end NineCert
