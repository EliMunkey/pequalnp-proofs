import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1022 : List (BitVec 512) := [w782,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1022 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_782,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_782 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1023 : List (BitVec 512) := [w783,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1023 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1023 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1023 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_783,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_783 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1024 : List (BitVec 512) := [w783,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1024 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1024 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(2,true))] s5_1024 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_783,v0_3197,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_783 (PetersenWireProjection.cons pc0_3197 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1025 : List (BitVec 512) := [w783,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1025 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(1,true),(0,false))] s5_1025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_783,v0_3280,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_783 (PetersenWireProjection.cons pc0_3280 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1026 : List (BitVec 512) := [w784,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1026 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1026 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1026 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_784,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_784 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1027 : List (BitVec 512) := [w785,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1027 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1027 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s5_1027 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_785,v0_3280,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_785 (PetersenWireProjection.cons pc0_3280 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1028 : List (BitVec 512) := [w786,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1028 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1028 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1028 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_786,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_786 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1029 : List (BitVec 512) := [w787,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1029 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1029 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1029 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_787,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_787 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1030 : List (BitVec 512) := [w789,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1030 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1030 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1030 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_789,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_789 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1031 : List (BitVec 512) := [w792,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1031 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1031 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1031 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_792,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_792 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1032 : List (BitVec 512) := [w793,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1032 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1032 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1032 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_793,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_793 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1033 : List (BitVec 512) := [w794,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1033 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1033 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1033 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_794,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_794 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1034 : List (BitVec 512) := [w795,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_1034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1034 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_1034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_795,v0_3766,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_795 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1035 : List (BitVec 512) := [w797,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1035 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1035 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1035 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_797,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_797 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1036 : List (BitVec 512) := [w798,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1036 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1036 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1036 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_798,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_798 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1037 : List (BitVec 512) := [w800,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1037 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1037 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1037 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_800,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_800 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1038 : List (BitVec 512) := [w801,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1038 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1038 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1038 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_801,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_801 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1039 : List (BitVec 512) := [w802,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1039 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1039 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1039 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_802,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_802 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1040 : List (BitVec 512) := [w803,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1040 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1040 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1040 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_803,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_803 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1041 : List (BitVec 512) := [w804,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1041 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1041 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1041 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_804,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_804 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1042 : List (BitVec 512) := [w805,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1042 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1042 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1042 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_805,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_805 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1043 : List (BitVec 512) := [w807,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1043 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1043 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1043 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_807,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_807 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1044 : List (BitVec 512) := [w808,w2442,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1044 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1044 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true)),(false,(6,true),(0,true))] s5_1044 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_808,v0_2442,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_808 (PetersenWireProjection.cons pc0_2442 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1045 : List (BitVec 512) := [w808,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1045 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1045 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1045 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_808,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_808 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1046 : List (BitVec 512) := [w809,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1046 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1046 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1046 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_809,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_809 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1047 : List (BitVec 512) := [w811,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1047 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1047 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true)),(false,(6,true),(0,true))] s5_1047 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_811,v0_2443,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_811 (PetersenWireProjection.cons pc0_2443 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1048 : List (BitVec 512) := [w811,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1048 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1048 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1048 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_811,v0_2494,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_811 (PetersenWireProjection.cons pc0_2494 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1049 : List (BitVec 512) := [w811,w3199,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1049 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1049 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s5_1049 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_811,v0_3199,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_811 (PetersenWireProjection.cons pc0_3199 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1050 : List (BitVec 512) := [w811,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1050 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1050 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false))] s5_1050 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_811,v0_3293,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_811 (PetersenWireProjection.cons pc0_3293 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1051 : List (BitVec 512) := [w812,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1051 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1051 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1051 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_812,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_812 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1052 : List (BitVec 512) := [w813,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1052 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1052 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true))] s5_1052 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_813,v0_3293,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_813 (PetersenWireProjection.cons pc0_3293 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1053 : List (BitVec 512) := [w815,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1053 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1053 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1053 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_815,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_815 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1054 : List (BitVec 512) := [w816,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1054 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1054 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1054 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_816,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_816 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1055 : List (BitVec 512) := [w817,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1055 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1055 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1055 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_817,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_817 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1056 : List (BitVec 512) := [w819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1056 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1056 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1056 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_819,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_819 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1057 : List (BitVec 512) := [w820,w2670,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1057 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1057 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true)),(false,(5,true),(0,true))] s5_1057 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_820,v0_2670,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_820 (PetersenWireProjection.cons pc0_2670 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1058 : List (BitVec 512) := [w822,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1058 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1058 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1058 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_822,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_822 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1059 : List (BitVec 512) := [w823,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1059 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1059 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1059 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_823,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_823 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1060 : List (BitVec 512) := [w824,w2669,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1060 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1060 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true)),(false,(5,true),(0,true))] s5_1060 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_824,v0_2669,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_824 (PetersenWireProjection.cons pc0_2669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1061 : List (BitVec 512) := [w826,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1061 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1061 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1061 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_826,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_826 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1062 : List (BitVec 512) := [w827,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1062 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1062 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1062 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_827,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_827 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1063 : List (BitVec 512) := [w828,w2668,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1063 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1063 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true)),(false,(5,true),(0,true))] s5_1063 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_828,v0_2668,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_828 (PetersenWireProjection.cons pc0_2668 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1064 : List (BitVec 512) := [w829,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1064 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1064 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1064 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_829,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_829 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1065 : List (BitVec 512) := [w830,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1065 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1065 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1065 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_830,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_830 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1066 : List (BitVec 512) := [w831,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1066 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1066 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1066 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_831,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_831 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1067 : List (BitVec 512) := [w832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1067 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1067 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1067 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_832,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_832 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1068 : List (BitVec 512) := [w833,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1068 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1068 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1068 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_833,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_833 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1069 : List (BitVec 512) := [w834,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1069 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1069 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_1069 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_834,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_834 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1070 : List (BitVec 512) := [w834,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1070 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1070 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false))] s5_1070 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_834,v0_3303,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_834 (PetersenWireProjection.cons pc0_3303 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1071 : List (BitVec 512) := [w835,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1071 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1071 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1071 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_835,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_835 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1072 : List (BitVec 512) := [w836,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1072 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1072 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1072 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_836,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_836 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1073 : List (BitVec 512) := [w840,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1073 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1073 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1073 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_840,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_840 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1074 : List (BitVec 512) := [w841,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1074 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1074 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true))] s5_1074 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_841,v0_3303,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_841 (PetersenWireProjection.cons pc0_3303 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1075 : List (BitVec 512) := [w843,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1075 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1075 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1075 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_843,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_843 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1076 : List (BitVec 512) := [w845,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1076 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1076 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1076 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_845,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_845 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1077 : List (BitVec 512) := [w846,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1077 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1077 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_1077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_846,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_846 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1078 : List (BitVec 512) := [w846,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1078 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1078 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_1078 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_846,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_846 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1079 : List (BitVec 512) := [w847,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1079 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1079 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_1079 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_847,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_847 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1080 : List (BitVec 512) := [w847,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1080 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1080 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1080 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_847,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_847 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1081 : List (BitVec 512) := [w848,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1081 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1081 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1081 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_848,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_848 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1082 : List (BitVec 512) := [w849,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1082 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1082 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_1082 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1083 : List (BitVec 512) := [w849,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1083 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1083 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1083 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_849,v0_2494,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_849 (PetersenWireProjection.cons pc0_2494 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1084 : List (BitVec 512) := [w850,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1084 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1084 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1084 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_850,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_850 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1085 : List (BitVec 512) := [w851,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1085 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1085 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_1085 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_851,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_851 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
