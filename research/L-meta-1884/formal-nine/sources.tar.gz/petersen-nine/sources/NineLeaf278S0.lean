import NinePin278
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3122 : List (BitVec 512) := [w637,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_3122 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3122 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_3122 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_637,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_637 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_5611 : List (BitVec 512) := [w1119,w1650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5611 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_5611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1119,v278_1650,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_1119 (PetersenWireProjection.cons pc278_1650 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_8907 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_8907 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8907 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_8907 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1374,v278_2681,v278_3766,v278_4344,v278_4716,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6720] (PetersenWireProjection.cons pc278_1374 (PetersenWireProjection.cons pc278_2681 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6720 rfl))))))))))) (by decide +kernel)
def s4_9487 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_9487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9487 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_9487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1384,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6720] (PetersenWireProjection.cons pc278_1384 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6720 rfl))))))))))) (by decide +kernel)
def s4_10045 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5623,w5956,w6522,w6588]
theorem b4_10045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10045 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5623,v278_5956,v278_6522,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5623 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6522 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_10087 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6169,w6300,w6588]
theorem b4_10087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10087 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6169,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6169 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_10090 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6890]
theorem b4_10090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10090 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6890] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6890 rfl))))))))))) (by decide +kernel)
def s4_10092 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6183,w6300,w6588]
theorem b4_10092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10092 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6183,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6183 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_10225 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_10225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10225 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5187,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5187 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s4_10308 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_10308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10308 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s4_10308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1411,v278_3766,v278_4344,v278_4716,v278_5135,v278_5393,v278_5585,v278_5956,v278_6179,v278_6300,v278_6588] (PetersenWireProjection.cons pc278_1411 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6588 rfl))))))))))) (by decide +kernel)
def s5_2580 : List (BitVec 512) := [w1328,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2580 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2580 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s5_2580 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1328,v278_1875,v278_3766,v278_4344,v278_5135,v278_5393,v278_5585,v278_5956,v278_6300,v278_6720] (PetersenWireProjection.cons pc278_1328 (PetersenWireProjection.cons pc278_1875 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_5135 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6720 rfl)))))))))) (by decide +kernel)
def s5_2798 : List (BitVec 512) := [w1374,w2681,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_2798 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2798 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s5_2798 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1374,v278_2681,v278_3766,v278_4344,v278_5393,v278_5585,v278_5956,v278_6225,v278_6300,v278_6720] (PetersenWireProjection.cons pc278_1374 (PetersenWireProjection.cons pc278_2681 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6225 (PetersenWireProjection.cons pc278_6300 (PetersenWireProjection.cons pc278_6720 rfl)))))))))) (by decide +kernel)
def s5_3200 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w6179,w6522,w6588]
theorem b5_3200 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3200 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s5_3200 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4344,v278_4716,v278_5187,v278_5393,v278_5585,v278_6179,v278_6522,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4344 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5187 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6522 (PetersenWireProjection.cons pc278_6588 rfl)))))))))) (by decide +kernel)
def s5_3217 : List (BitVec 512) := [w1403,w3766,w4716,w5187,w5393,w5585,w5698,w5956,w6522,w6588]
theorem b5_3217 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3217 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s5_3217 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4716,v278_5187,v278_5393,v278_5585,v278_5698,v278_5956,v278_6522,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5187 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5585 (PetersenWireProjection.cons pc278_5698 (PetersenWireProjection.cons pc278_5956 (PetersenWireProjection.cons pc278_6522 (PetersenWireProjection.cons pc278_6588 rfl)))))))))) (by decide +kernel)
def s6_31 : List (BitVec 512) := [w1403,w3766,w4716,w5187,w5393,w5698,w6179,w6522,w6588]
theorem b6_31 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_31 := by
  intro m le c
  apply rejects_sound r278 i6 5 tgt (small278 adj) hot278 [] s6_31 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v278_1403,v278_3766,v278_4716,v278_5187,v278_5393,v278_5698,v278_6179,v278_6522,v278_6588] (PetersenWireProjection.cons pc278_1403 (PetersenWireProjection.cons pc278_3766 (PetersenWireProjection.cons pc278_4716 (PetersenWireProjection.cons pc278_5187 (PetersenWireProjection.cons pc278_5393 (PetersenWireProjection.cons pc278_5698 (PetersenWireProjection.cons pc278_6179 (PetersenWireProjection.cons pc278_6522 (PetersenWireProjection.cons pc278_6588 rfl))))))))) (by decide +kernel)
end NineCert
