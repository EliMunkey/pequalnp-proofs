import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_698 : List (BitVec 512) := [w484,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_698 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_698 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_698 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_484,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_484 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_699 : List (BitVec 512) := [w485,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_699 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_699 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_699 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_485,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_485 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_700 : List (BitVec 512) := [w486,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_700 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_700 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_700 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_486,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_486 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_701 : List (BitVec 512) := [w487,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_701 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_701 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_701 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_487,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_487 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_702 : List (BitVec 512) := [w488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_702 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_702 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_702 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_703 : List (BitVec 512) := [w489,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_703 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_703 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_703 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_489,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_489 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_705 : List (BitVec 512) := [w491,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6873]
theorem b5_705 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_705 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true)),(false,(6,true),(1,true))] s5_705 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_1664,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6873] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_1664 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_706 : List (BitVec 512) := [w491,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_706 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_706 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(1,false))] s5_706 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_707 : List (BitVec 512) := [w491,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_707 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_707 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(1,false)),(false,(3,true),(0,true))] s5_707 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3303,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_708 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6873]
theorem b5_708 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_708 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(7,true)),(false,(10,true),(1,true))] s5_708 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_709 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6873]
theorem b5_709 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_709 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(5,true)),(false,(10,true),(1,true))] s5_709 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_710 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_710 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_710 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_710 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_711 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b5_711 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_711 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(6,true),(5,true))] s5_711 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_712 : List (BitVec 512) := [w491,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6522,w6588]
theorem b5_712 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_712 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_712 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_713 : List (BitVec 512) := [w491,w3766,w4716,w5187,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_713 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_713 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(1,true),(7,true))] s5_713 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_491,v2_3766,v2_4716,v2_5187,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_714 : List (BitVec 512) := [w492,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_714 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_714 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(3,true)),(false,(3,true),(0,true))] s5_714 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_492,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_492 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_715 : List (BitVec 512) := [w495,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_715 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_715 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(2,true))] s5_715 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_716 : List (BitVec 512) := [w495,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_716 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_716 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(3,true),(1,true))] s5_716 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3303,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_717 : List (BitVec 512) := [w495,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6873]
theorem b5_717 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_717 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_717 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_495,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_495 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_718 : List (BitVec 512) := [w497,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_718 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_718 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_718 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_497,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_497 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_735 : List (BitVec 512) := [w498,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_735 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_735 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(3,true),(0,true))] s5_735 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_498,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_498 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_744 : List (BitVec 512) := [w499,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_744 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_744 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(9,true))] s5_744 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_745 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6908]
theorem b5_745 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_745 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_745 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6908] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6908 rfl)))))))))) (by decide +kernel)
def s5_746 : List (BitVec 512) := [w499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6873]
theorem b5_746 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_746 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_746 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_747 : List (BitVec 512) := [w500,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_747 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_747 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s5_747 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_748 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6908]
theorem b5_748 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_748 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_748 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6908] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6908 rfl)))))))))) (by decide +kernel)
def s5_749 : List (BitVec 512) := [w500,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6873]
theorem b5_749 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_749 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_749 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_500,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_500 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_750 : List (BitVec 512) := [w501,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_750 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_750 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_750 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_501,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_501 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_751 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_751 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_751 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s5_751 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_2494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_2494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_755 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6908]
theorem b5_755 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_755 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_755 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6908] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6908 rfl)))))))))) (by decide +kernel)
def s5_756 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6873]
theorem b5_756 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_756 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_756 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_757 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6873]
theorem b5_757 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_757 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_757 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_758 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6873]
theorem b5_758 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_758 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_758 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6567,v2_6873] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_759 : List (BitVec 512) := [w502,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_759 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_759 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_502,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_502 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_760 : List (BitVec 512) := [w503,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_760 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_760 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(6,true)),(false,(1,false),(0,false)),(false,(10,true),(0,true))] s5_760 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_503,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_503 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_761 : List (BitVec 512) := [w504,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_761 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_761 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false)),(false,(0,true),(10,true))] s5_761 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_504,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_504 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1557 : List (BitVec 512) := [w1007,w2441,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1557 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s5_1557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1007,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1007 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1566 : List (BitVec 512) := [w1007,w3766,w4344,w4716,w5135,w5299,w5585,w5956,w6300,w6588]
theorem b5_1566 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1566 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s5_1566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1007,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1007 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1568 : List (BitVec 512) := [w1007,w3766,w4344,w4716,w5135,w5585,w5956,w6029,w6300,w6588]
theorem b5_1568 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1568 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s5_1568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1007,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1007 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1903 : List (BitVec 512) := [w1119,w2441,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1903 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1903 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_1903 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_2441,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1948 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5320,w5585,w5956,w6300,w6588]
theorem b5_1948 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1948 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true))] s5_1948 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_4716,v2_5135,v2_5320,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5320 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1955 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5311,w5585,w6101,w6300,w6522,w6588]
theorem b5_1955 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1955 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_1955 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5311,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_1965 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6101,w6451,w6522,w6588]
theorem b5_1965 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1965 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_1965 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1119,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1119 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2347 : List (BitVec 512) := [w1292,w2441,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6588]
theorem b5_2347 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2347 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(8,true),(5,true))] s5_2347 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2384 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b5_2384 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2384 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s5_2384 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2385 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5311,w6179,w6300,w6522,w6588]
theorem b5_2385 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2385 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(8,true),(5,true))] s5_2385 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2386 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5315,w5585,w5956,w6300,w6588]
theorem b5_2386 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2386 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true))] s5_2386 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5315,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5315 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2400 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6451,w6522,w6588]
theorem b5_2400 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2400 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(8,true),(5,true))] s5_2400 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1292,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1292 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2638 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b5_2638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s5_2638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1328,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1328 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_2766 : List (BitVec 512) := [w1374,w2326,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6832]
theorem b5_2766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2766 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(5,true),(10,true))] s5_2766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_2767 : List (BitVec 512) := [w1374,w2441,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785]
theorem b5_2767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2767 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(8,true),(10,true))] s5_2767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 rfl)))))))))) (by decide +kernel)
def s5_2839 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5887,w6179,w6300,w6832]
theorem b5_2839 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2839 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(5,true),(10,true))] s5_2839 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5887,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5887 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_2841 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w6179,w6451,w6522,w6785]
theorem b5_2841 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2841 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(8,true),(10,true))] s5_2841 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1374,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6451,v2_6522,v2_6785] (PetersenWireProjection.cons pc2_1374 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 rfl)))))))))) (by decide +kernel)
def s5_2864 : List (BitVec 512) := [w1384,w2320,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6832]
theorem b5_2864 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2864 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_2864 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_2947 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5884,w6179,w6300,w6832]
theorem b5_2947 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2947 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_2947 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1384,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1384 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_2993 : List (BitVec 512) := [w1388,w2320,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6832]
theorem b5_2993 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2993 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_2993 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1388,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1388 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_3035 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5884,w6179,w6300,w6832]
theorem b5_3035 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3035 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_3035 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1388,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_1388 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_3086 : List (BitVec 512) := [w1403,w2295,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_3086 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3086 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_3086 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2295,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3087 : List (BitVec 512) := [w1403,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6873]
theorem b5_3087 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3087 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(7,true)),(false,(10,true),(1,true))] s5_3087 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3088 : List (BitVec 512) := [w1403,w2320,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6588]
theorem b5_3088 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3088 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(6,true),(5,true))] s5_3088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3089 : List (BitVec 512) := [w1403,w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6522,w6588]
theorem b5_3089 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3089 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s5_3089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3090 : List (BitVec 512) := [w1403,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6873]
theorem b5_3090 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3090 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(5,true)),(false,(10,true),(1,true))] s5_3090 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3091 : List (BitVec 512) := [w1403,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6890]
theorem b5_3091 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3091 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true)),(false,(6,true),(5,true))] s5_3091 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_3092 : List (BitVec 512) := [w1403,w2354,w3766,w4344,w4716,w5187,w5393,w5585,w6522,w6588]
theorem b5_3092 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3092 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_3092 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2354,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
