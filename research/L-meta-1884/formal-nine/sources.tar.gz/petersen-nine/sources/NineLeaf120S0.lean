import NinePin120
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_296 : List (BitVec 512) := [w154,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_296 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_296 := by
  intro m le c
  apply rejects_sound r120 i7 6 tgt (small120 adj) hot120 [] s5_296 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v120_154,v120_3258,v120_4344,v120_4716,v120_5135,v120_5393,v120_5585,v120_5956,v120_6300,v120_6588] (PetersenWireProjection.cons pc120_154 (PetersenWireProjection.cons pc120_3258 (PetersenWireProjection.cons pc120_4344 (PetersenWireProjection.cons pc120_4716 (PetersenWireProjection.cons pc120_5135 (PetersenWireProjection.cons pc120_5393 (PetersenWireProjection.cons pc120_5585 (PetersenWireProjection.cons pc120_5956 (PetersenWireProjection.cons pc120_6300 (PetersenWireProjection.cons pc120_6588 rfl)))))))))) (by decide +kernel)
def s5_557 : List (BitVec 512) := [w327,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_557 := by
  intro m le c
  apply rejects_sound r120 i7 6 tgt (small120 adj) hot120 [] s5_557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v120_327,v120_3258,v120_4344,v120_4716,v120_5135,v120_5393,v120_5585,v120_5956,v120_6300,v120_6588] (PetersenWireProjection.cons pc120_327 (PetersenWireProjection.cons pc120_3258 (PetersenWireProjection.cons pc120_4344 (PetersenWireProjection.cons pc120_4716 (PetersenWireProjection.cons pc120_5135 (PetersenWireProjection.cons pc120_5393 (PetersenWireProjection.cons pc120_5585 (PetersenWireProjection.cons pc120_5956 (PetersenWireProjection.cons pc120_6300 (PetersenWireProjection.cons pc120_6588 rfl)))))))))) (by decide +kernel)
end NineCert
