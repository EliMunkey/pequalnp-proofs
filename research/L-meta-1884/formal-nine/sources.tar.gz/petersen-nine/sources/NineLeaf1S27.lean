import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9322 : List (BitVec 512) := [w1384,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9322 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9322 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9322 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9323 : List (BitVec 512) := [w1384,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9323 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9323 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9323 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9324 : List (BitVec 512) := [w1384,w2615,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9324 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9324 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s4_9324 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2615,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9325 : List (BitVec 512) := [w1384,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9325 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9326 : List (BitVec 512) := [w1384,w2641,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9326 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9326 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9326 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2641,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2641 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9327 : List (BitVec 512) := [w1384,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9327 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9327 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_9327 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9328 : List (BitVec 512) := [w1384,w2645,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9328 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2645,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2645 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9329 : List (BitVec 512) := [w1384,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9329 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9329 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9329 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9330 : List (BitVec 512) := [w1384,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9330 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9376 : List (BitVec 512) := [w1384,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9376 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9389 : List (BitVec 512) := [w1384,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9389 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9403 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9403 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9404 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9404 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9405 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w4994,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9405 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s4_9405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_4994,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4994 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9406 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9406 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9407 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5020,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9407 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5020,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5020 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9408 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9408 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_9408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9409 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5028,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9409 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5028,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5028 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9410 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9410 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9411 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5698,w5956,w6300]
theorem b4_9411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9411 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s4_9411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9412 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6061,w6300]
theorem b4_9412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9412 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6061,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9413 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b4_9413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9413 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_9413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9414 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6201,w6300]
theorem b4_9414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9414 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9415 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b4_9415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9415 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_9416 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9416 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9417 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5065,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9417 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5065,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5065 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9418 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5184,w5393,w5585,w5956,w6300,w6588]
theorem b4_9418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9418 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5184,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5184 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9420 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_9420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9420 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9421 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_9421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9421 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9435 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_9435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9435 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9458 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_9458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9458 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9459 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6588]
theorem b4_9459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9459 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true))] s4_9459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9479 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b4_9479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9479 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9480 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6153,w6300,w6588]
theorem b4_9480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9480 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6153,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6153 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9508 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6241,w6300,w6588]
theorem b4_9508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9508 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_9508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9509 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6242,w6300,w6588]
theorem b4_9509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9509 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6242,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6242 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9518 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b4_9518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9518 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9530 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_9530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9530 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_9530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_9589 : List (BitVec 512) := [w1388,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9589 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_9589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9600 : List (BitVec 512) := [w1388,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9600 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9601 : List (BitVec 512) := [w1388,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9601 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9602 : List (BitVec 512) := [w1388,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9602 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9603 : List (BitVec 512) := [w1388,w2613,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_9603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9603 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9604 : List (BitVec 512) := [w1388,w2623,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9604 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2623,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9605 : List (BitVec 512) := [w1388,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9605 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_9605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9606 : List (BitVec 512) := [w1388,w2646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9606 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2646,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2646 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9607 : List (BitVec 512) := [w1388,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9607 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9607 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9607 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9626 : List (BitVec 512) := [w1388,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9626 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9638 : List (BitVec 512) := [w1388,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9638 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9647 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9647 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9647 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9647 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9648 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5002,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9648 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9648 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9648 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5002,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9649 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9649 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_9649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9650 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5029,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9650 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5029,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5029 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9651 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5769,w5956,w6300]
theorem b4_9651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9651 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9652 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6179,w6300]
theorem b4_9652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9652 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_9652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9653 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6225,w6300]
theorem b4_9653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9653 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 rfl))))))))))) (by decide +kernel)
def s4_9654 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300]
theorem b4_9654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9654 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s4_9655 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9655 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9656 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5064,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9656 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5064,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5064 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9657 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5185,w5393,w5585,w5956,w6300,w6588]
theorem b4_9657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9657 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5185,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5185 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9659 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_9659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9659 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9660 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_9660 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9660 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9660 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9680 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_9680 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9680 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9680 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9681 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5873,w5956,w6300,w6588]
theorem b4_9681 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9681 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9681 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
