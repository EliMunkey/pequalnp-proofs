import NinePin20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_446 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_446 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_446 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s3_446 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2368 : List (BitVec 512) := [w428,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_2368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2368 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true))] s4_2368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2369 : List (BitVec 512) := [w428,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_2369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2369 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2370 : List (BitVec 512) := [w428,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_2370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2370 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(5,true))] s4_2370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6720] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6720 rfl))))))))))) (by decide +kernel)
def s4_2476 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_2476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2476 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4583,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4583 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2477 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_2477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2477 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_4800,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4800 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2478 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_2478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2478 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(3,true))] s4_2478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_4926,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4926 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2479 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_2479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2479 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5652,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5652 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2480 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_2480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2480 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(3,true))] s4_2480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5698,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5698 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2481 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_2481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2481 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(4,true))] s4_2481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5769,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5769 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2491 : List (BitVec 512) := [w498,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6640]
theorem b4_2491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2491 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s4_2502 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6832]
theorem b4_2502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2502 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(5,true))] s4_2502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2527,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6832] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2527 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6832 rfl)))))))))) (by decide +kernel)
def s4_2504 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6873]
theorem b4_2504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2504 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(5,true))] s4_2504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2527,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6873] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2527 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6873 rfl)))))))))) (by decide +kernel)
def s4_2507 : List (BitVec 512) := [w498,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_2507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2507 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_3766,v20_4344,v20_4716,v20_4800,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4800 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2511 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_2511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2511 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5652,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5652 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2513 : List (BitVec 512) := [w499,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_2513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2513 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(3,true))] s4_2513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_499,v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6061,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_499 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6061 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2514 : List (BitVec 512) := [w499,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_2514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2514 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(3,true))] s4_2514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_499,v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6389,v20_6588] (PetersenWireProjection.cons pc20_499 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6389 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2516 : List (BitVec 512) := [w499,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_2516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2516 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_499,v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_499 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2523 : List (BitVec 512) := [w500,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_2523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2523 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(2,true))] s4_2523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_500,v20_2491,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6101,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_500 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6101 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2524 : List (BitVec 512) := [w500,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_2524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2524 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(2,true))] s4_2524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_500,v20_2491,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6422,v20_6588] (PetersenWireProjection.cons pc20_500 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6422 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2526 : List (BitVec 512) := [w500,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_2526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2526 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_500,v20_2491,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_500 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_2533 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6588]
theorem b4_2533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2533 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(4,true))] s4_2533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_502,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6179,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_502 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6179 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2534 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6464,w6588]
theorem b4_2534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2534 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(4,true))] s4_2534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_502,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6464,v20_6588] (PetersenWireProjection.cons pc20_502 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6464 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_2536 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_2536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2536 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_2536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_502,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_502 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_11375 : List (BitVec 512) := [w2299,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_11375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11375 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(2,true))] s4_11375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2299,v20_2468,v20_3766,v20_4344,v20_4716,v20_4926,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2299 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4926 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11376 : List (BitVec 512) := [w2299,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_11376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11376 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(7,true))] s4_11376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2299,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2299 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11377 : List (BitVec 512) := [w2299,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11377 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2299,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2299 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_11403 : List (BitVec 512) := [w2323,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_11403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11403 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(4,true))] s4_11403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5698,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5698 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11404 : List (BitVec 512) := [w2323,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_11404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11404 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(7,true))] s4_11404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11405 : List (BitVec 512) := [w2323,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11405 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_11450 : List (BitVec 512) := [w2337,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_11450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11450 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(2,true))] s4_11450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2337,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5769,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2337 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5769 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11451 : List (BitVec 512) := [w2337,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_11451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11451 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true))] s4_11451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2337,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2337 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_11452 : List (BitVec 512) := [w2337,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11452 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2337,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2337 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_11772 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11772 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2381,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2381 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_11776 : List (BitVec 512) := [w2382,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11776 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2382,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2382 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_11786 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11786 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_11786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2387,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2387 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_12239 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12239 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4583,v20_4716,v20_4800,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4583 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4800 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_12249 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_12249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12249 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4583,v20_4716,v20_5135,v20_5585,v20_5652,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4583 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5652 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))))) (by decide +kernel)
def s4_12274 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_12274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12274 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4583,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6640] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4583 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6640 rfl))))))))))) (by decide +kernel)
def s4_12682 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4801,w5135,w5585,w5956,w6300,w6588]
theorem b4_12682 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12682 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12682 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_4801,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4801 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_12809 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5653,w5956,w6300,w6588]
theorem b4_12809 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12809 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12809 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5653,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5653 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_12992 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6641]
theorem b4_12992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12992 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_12992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6641] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6641 rfl)))))))))) (by decide +kernel)
def s4_13052 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_13052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13052 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_13052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2492,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2492 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_13077 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_13077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13077 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_13077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2496,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2496 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_13103 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_13103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13103 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_13103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2497,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2497 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_18114 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5402,w5585,w5956,w6300,w6588]
theorem b4_18114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18114 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5402,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5402 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_18118 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5457,w5585,w5956,w6300,w6588]
theorem b4_18118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18118 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5457,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5457 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_18123 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5520,w5585,w5956,w6300,w6588]
theorem b4_18123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18123 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5520,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5520 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_18124 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5520,w5585,w5956,w6300,w6588,w6690]
theorem b4_18124 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18124 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(5,true))] s4_18124 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5520,v20_5585,v20_5956,v20_6300,v20_6588,v20_6690] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5520 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6690 rfl))))))))))) (by decide +kernel)
def s4_18131 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6161,w6300,w6588]
theorem b4_18131 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18131 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18131 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5585,v20_5956,v20_6161,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6161 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s4_18132 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6161,w6300,w6588,w6690]
theorem b4_18132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18132 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(5,true))] s4_18132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5585,v20_5956,v20_6161,v20_6300,v20_6588,v20_6690] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6161 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6690 rfl))))))))))) (by decide +kernel)
def s4_18156 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5585,w5891,w5956,w6300,w6588]
theorem b4_18156 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18156 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18156 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5891,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5891 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s4_18157 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5585,w5892,w5956,w6300,w6588]
theorem b4_18157 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18157 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s4_18157 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5892,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5892 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_627 : List (BitVec 512) := [w428,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_627 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s5_627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_2681,v20_3766,v20_4344,v20_4716,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_2681 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_629 : List (BitVec 512) := [w428,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6873]
theorem b5_629 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_629 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(7,true)),(false,(6,true),(8,true))] s5_629 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6522,v20_6873] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6873 rfl)))))))))) (by decide +kernel)
def s5_630 : List (BitVec 512) := [w428,w2491,w3766,w4344,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b5_630 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_630 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(2,true))] s5_630 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2491,v20_3766,v20_4344,v20_5135,v20_5585,v20_5956,v20_6101,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6101 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_631 : List (BitVec 512) := [w428,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_631 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_631 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_631 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_428,v20_2529,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_428 (PetersenWireProjection.cons pc20_2529 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_633 : List (BitVec 512) := [w429,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_633 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_429,v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_429 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_650 : List (BitVec 512) := [w446,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_650 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_650 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_650 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_446,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_446 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_662 : List (BitVec 512) := [w458,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_662 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_662 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_662 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_458,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_458 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_664 : List (BitVec 512) := [w460,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_664 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_664 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_664 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_460,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_460 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_704 : List (BitVec 512) := [w490,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_704 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_704 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true))] s5_704 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_490,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_490 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_723 : List (BitVec 512) := [w498,w2098,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_723 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_723 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,false),(4,true))] s5_723 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2098,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2098 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_725 : List (BitVec 512) := [w498,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_725 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_725 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_725 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2468,v20_3258,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3258 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
end NineCert
