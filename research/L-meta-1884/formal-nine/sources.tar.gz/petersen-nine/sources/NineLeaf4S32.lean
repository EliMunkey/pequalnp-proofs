import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1619 : List (BitVec 512) := [w1058,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1619 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1619 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1619 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1058,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1058 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1620 : List (BitVec 512) := [w1059,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1620 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1620 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1620 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1059,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1059 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1621 : List (BitVec 512) := [w1060,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1621 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1621 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(6,true),(0,true))] s5_1621 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1060,v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1060 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1622 : List (BitVec 512) := [w1060,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1622 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1622 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1622 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1060,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1060 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1626 : List (BitVec 512) := [w1066,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1626 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1626 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1626 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1066,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1066 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1628 : List (BitVec 512) := [w1068,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1628 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1628 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(8,true),(0,true))] s5_1628 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1068,v4_2443,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1068 (PetersenWireProjection.cons pc4_2443 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1629 : List (BitVec 512) := [w1068,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1629 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1629 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,false)),(false,(7,true),(0,true))] s5_1629 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1068,v4_2494,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1068 (PetersenWireProjection.cons pc4_2494 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1630 : List (BitVec 512) := [w1068,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720]
theorem b5_1630 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1630 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(0,true),(4,false))] s5_1630 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1068,v4_2681,v4_3766,v4_4344,v4_4716,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1068 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1631 : List (BitVec 512) := [w1068,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1631 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1631 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s5_1631 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1068,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1068 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1632 : List (BitVec 512) := [w1068,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_1632 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1632 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s5_1632 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1068,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1068 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1633 : List (BitVec 512) := [w1069,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1633 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1633 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1633 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1069,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1069 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1635 : List (BitVec 512) := [w1071,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1635 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s5_1635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1071,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1071 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1636 : List (BitVec 512) := [w1071,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1636 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(3,true),(0,true))] s5_1636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1071,v4_3293,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1071 (PetersenWireProjection.cons pc4_3293 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1637 : List (BitVec 512) := [w1071,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1637 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1071,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1071 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1638 : List (BitVec 512) := [w1073,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1638 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s5_1638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1073,v4_2488,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1073 (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1639 : List (BitVec 512) := [w1073,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1639 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1639 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1639 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1073,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1073 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1640 : List (BitVec 512) := [w1074,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1640 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1640 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(2,true),(0,true))] s5_1640 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1074,v4_3258,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1074 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1641 : List (BitVec 512) := [w1074,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1641 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1641 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))] s5_1641 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1074,v4_3303,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1074 (PetersenWireProjection.cons pc4_3303 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1642 : List (BitVec 512) := [w1075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1642 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1642 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1642 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1075,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1075 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1643 : List (BitVec 512) := [w1076,w1403,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1643 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1643 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s5_1643 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1403,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1644 : List (BitVec 512) := [w1076,w1618,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b5_1644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1644 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true))] s5_1644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1618,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1618 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1645 : List (BitVec 512) := [w1076,w1618,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6720]
theorem b5_1645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1645 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true))] s5_1645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1618,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1618 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1646 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_1646 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1646 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(8,true),(4,true)),(false,(9,true),(8,true))] s5_1646 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1647 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_1647 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1647 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(7,true),(4,true))] s5_1647 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1648 : List (BitVec 512) := [w1076,w1626,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720]
theorem b5_1648 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1648 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(7,true),(4,true))] s5_1648 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1626,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1626 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1649 : List (BitVec 512) := [w1076,w1635,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_1649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1649 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s5_1649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1635,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1635 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1650 : List (BitVec 512) := [w1076,w1644,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1650 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1650 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(4,true))] s5_1650 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1644,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1644 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1651 : List (BitVec 512) := [w1076,w1644,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_1651 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1651 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(4,true))] s5_1651 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1644,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1644 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1652 : List (BitVec 512) := [w1076,w1646,w2468,w3766,w4344,w5135,w5585,w6101,w6522,w6588]
theorem b5_1652 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1652 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(8,true),(4,true)),(false,(7,true),(0,true))] s5_1652 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_2468,v4_3766,v4_4344,v4_5135,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1653 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1653 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1653 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(8,true),(4,true))] s5_1653 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1654 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720]
theorem b5_1654 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1654 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(8,true),(4,true))] s5_1654 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1655 : List (BitVec 512) := [w1076,w1646,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_1655 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1655 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(8,true),(7,true)),(false,(9,true),(5,true))] s5_1655 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1646,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1646 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1656 : List (BitVec 512) := [w1076,w1650,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1656 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1656 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1656 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1650,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1650 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1657 : List (BitVec 512) := [w1076,w1650,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_1657 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1657 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(5,true))] s5_1657 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1650,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1650 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1658 : List (BitVec 512) := [w1076,w1650,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_1658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1658 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s5_1658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1650,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1650 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1659 : List (BitVec 512) := [w1076,w1652,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1659 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(5,true))] s5_1659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1652,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1652 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1660 : List (BitVec 512) := [w1076,w1652,w3766,w4344,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_1660 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1660 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(5,true))] s5_1660 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1652,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1652 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1661 : List (BitVec 512) := [w1076,w1652,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_1661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1661 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s5_1661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1652,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1652 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1662 : List (BitVec 512) := [w1076,w1664,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1662 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1662 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true))] s5_1662 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1664,v4_3766,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1664 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1663 : List (BitVec 512) := [w1076,w1670,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_1663 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1663 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(4,true)),(false,(8,true),(5,true))] s5_1663 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1670,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1670 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1664 : List (BitVec 512) := [w1076,w1674,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_1664 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1664 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,true),(4,true)),(false,(9,true),(5,true))] s5_1664 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1674,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1674 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1665 : List (BitVec 512) := [w1076,w1875,w2125,w3766,w4344,w5135,w5393,w6179,w6300,w6588]
theorem b5_1665 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1665 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(7,true),(0,true)),(false,(9,true),(1,true))] s5_1665 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_2125,v4_3766,v4_4344,v4_5135,v4_5393,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2125 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1666 : List (BitVec 512) := [w1076,w1875,w2125,w3766,w4344,w5135,w5393,w6225,w6300,w6588]
theorem b5_1666 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1666 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(7,true),(0,true)),(false,(9,true),(8,false))] s5_1666 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_2125,v4_3766,v4_4344,v4_5135,v4_5393,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2125 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1667 : List (BitVec 512) := [w1076,w1875,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_1667 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1667 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(1,true),(5,false))] s5_1667 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1668 : List (BitVec 512) := [w1076,w1875,w2681,w3766,w4344,w5393,w5585,w5956,w6300,w6720]
theorem b5_1668 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1668 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(1,true),(5,false))] s5_1668 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_2681,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2681 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1669 : List (BitVec 512) := [w1076,w1875,w2686,w3766,w4344,w5393,w5585,w5956,w6300,w6588]
theorem b5_1669 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1669 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(5,true),(7,true)),(false,(2,true),(0,true))] s5_1669 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_2686,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1670 : List (BitVec 512) := [w1076,w1875,w3258,w4344,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1670 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1670 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true)),(false,(3,true),(0,true))] s5_1670 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3258,v4_4344,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3258 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1671 : List (BitVec 512) := [w1076,w1875,w3280,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1671 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1671 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_1671 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3280,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3280 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1672 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1672 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1672 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(0,true))] s5_1672 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1673 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6720]
theorem b5_1673 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1673 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(0,true))] s5_1673 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1674 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b5_1674 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1674 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s5_1674 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1675 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6720]
theorem b5_1675 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1675 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s5_1675 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1676 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1676 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1676 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true))] s5_1676 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1677 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w5956,w6300,w6720]
theorem b5_1677 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1677 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true))] s5_1677 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1678 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_1678 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1678 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(7,true)),(false,(9,true),(1,true))] s5_1678 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1679 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w6225,w6300,w6588]
theorem b5_1679 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1679 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(8,true)),(false,(8,true),(4,true))] s5_1679 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1680 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w6179,w6300,w6588,w6785]
theorem b5_1680 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1680 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(7,true),(5,true)),(false,(9,true),(1,true))] s5_1680 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_6179,v4_6300,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl)))))))))) (by decide +kernel)
def s5_1681 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_1681 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1681 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s5_1681 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1682 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5471,w5585,w5956,w6300,w6720]
theorem b5_1682 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1682 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s5_1682 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1683 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5471,w5698,w5956,w6300,w6588]
theorem b5_1683 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1683 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true)),(false,(1,true),(7,true))] s5_1683 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5471,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1684 : List (BitVec 512) := [w1076,w1875,w3766,w5135,w5393,w5698,w5956,w6300,w6389,w6588]
theorem b5_1684 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1684 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true))] s5_1684 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1685 : List (BitVec 512) := [w1076,w1875,w3766,w5135,w5393,w5698,w5956,w6300,w6588,w6690]
theorem b5_1685 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1685 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(3,true),(5,true)),(false,(8,true),(4,true))] s5_1685 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl)))))))))) (by decide +kernel)
def s5_1686 : List (BitVec 512) := [w1076,w1883,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b5_1686 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1686 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s5_1686 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1883,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1883 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1687 : List (BitVec 512) := [w1076,w1910,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b5_1687 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1687 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true))] s5_1687 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1910,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1910 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
