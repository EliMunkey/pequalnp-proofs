import NinePin297
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17180 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5690,w5956,w6300,w6549,w6588]
theorem b4_17180 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17180 := by
  intro m le c
  apply rejects_sound r297 i5 4 tgt (small297 adj) hot297 [] s4_17180 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v297_3766,v297_4344,v297_4716,v297_5135,v297_5393,v297_5585,v297_5690,v297_5956,v297_6300,v297_6549,v297_6588] (PetersenWireProjection.cons pc297_3766 (PetersenWireProjection.cons pc297_4344 (PetersenWireProjection.cons pc297_4716 (PetersenWireProjection.cons pc297_5135 (PetersenWireProjection.cons pc297_5393 (PetersenWireProjection.cons pc297_5585 (PetersenWireProjection.cons pc297_5690 (PetersenWireProjection.cons pc297_5956 (PetersenWireProjection.cons pc297_6300 (PetersenWireProjection.cons pc297_6549 (PetersenWireProjection.cons pc297_6588 rfl))))))))))) (by decide +kernel)
def s5_5442 : List (BitVec 512) := [w3766,w4293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5442 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5442 := by
  intro m le c
  apply rejects_sound r297 i5 4 tgt (small297 adj) hot297 [] s5_5442 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v297_3766,v297_4293,v297_4344,v297_4716,v297_5135,v297_5393,v297_5585,v297_5956,v297_6300,v297_6588] (PetersenWireProjection.cons pc297_3766 (PetersenWireProjection.cons pc297_4293 (PetersenWireProjection.cons pc297_4344 (PetersenWireProjection.cons pc297_4716 (PetersenWireProjection.cons pc297_5135 (PetersenWireProjection.cons pc297_5393 (PetersenWireProjection.cons pc297_5585 (PetersenWireProjection.cons pc297_5956 (PetersenWireProjection.cons pc297_6300 (PetersenWireProjection.cons pc297_6588 rfl)))))))))) (by decide +kernel)
end NineCert
