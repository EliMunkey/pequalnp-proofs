import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2134 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4737,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2134 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2134 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2134 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4737,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4737 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2135 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4737,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2135 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2135 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2135 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4737,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4737 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2138 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2138 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2138 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2138 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2139 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2139 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2139 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2190 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5613,w5769,w5956,w6300,w6588]
theorem b3_2190 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2190 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2190 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5613,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2191 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5613,w5956,w6300,w6588]
theorem b3_2191 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2191 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2191 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5613,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5613 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2214 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6101,w6300,w6588]
theorem b3_2214 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2214 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2214 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2224 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b3_2224 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2224 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2224 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2233 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b3_2233 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2233 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2233 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl)))))))))))) (by decide +kernel)
def s3_2240 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b3_2240 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2240 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2240 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s3_2255 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_2255 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2255 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2255 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2265 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_2265 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2265 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2265 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2274 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_2274 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2274 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2274 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s3_2283 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b3_2283 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2283 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2283 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s3_2349 : List (BitVec 512) := [w1353,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2349 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2349 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_2349 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2350 : List (BitVec 512) := [w1353,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2350 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2350 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_2350 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2351 : List (BitVec 512) := [w1353,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2351 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2351 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_2351 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2352 : List (BitVec 512) := [w1353,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2352 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2352 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_2352 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2353 : List (BitVec 512) := [w1353,w3766,w4344,w4685,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2353 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2353 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s3_2353 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1353,v4_3766,v4_4344,v4_4685,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1353 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4685 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2525 : List (BitVec 512) := [w1374,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2525 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2525 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2525 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2526 : List (BitVec 512) := [w1374,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2526 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2526 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2526 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2527 : List (BitVec 512) := [w1374,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2527 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2527 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2527 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2528 : List (BitVec 512) := [w1374,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2528 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2528 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2528 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2529 : List (BitVec 512) := [w1374,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2529 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2529 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2529 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2530 : List (BitVec 512) := [w1374,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2530 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2530 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2530 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2531 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2531 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2531 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2531 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2532 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2532 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2532 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s3_2532 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2704 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2704 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2704 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2704 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2705 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2705 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2705 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2705 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2706 : List (BitVec 512) := [w1403,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2706 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2706 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2706 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2707 : List (BitVec 512) := [w1403,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2707 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2707 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2707 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2708 : List (BitVec 512) := [w1403,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2708 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2708 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2708 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2709 : List (BitVec 512) := [w1403,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2709 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2709 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2709 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2710 : List (BitVec 512) := [w1403,w3766,w4344,w4682,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2710 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2710 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2710 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4682,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2711 : List (BitVec 512) := [w1403,w3766,w4344,w4682,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2711 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2711 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s3_2711 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4682,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_3953 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3953 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3953 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s3_3953 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_3954 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_3954 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3954 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s3_3954 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s3_3956 : List (BitVec 512) := [w3766,w3947,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3956 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3956 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s3_3956 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3947,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3947 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_4630 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6136,w6300,w6588]
theorem b3_4630 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4630 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s3_4630 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6136,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4631 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6179,w6300,w6588]
theorem b3_4631 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4631 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_4631 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4632 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_4632 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4632 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_4632 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4634 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6436,w6588]
theorem b3_4634 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4634 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_4634 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4635 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6464,w6588]
theorem b3_4635 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4635 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s3_4635 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4636 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_4636 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4636 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s3_4636 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4637 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_4637 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4637 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s3_4637 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4639 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6748]
theorem b3_4639 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4639 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s3_4639 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6748] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6748 rfl)))))))))))) (by decide +kernel)
def s3_4640 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6785]
theorem b3_4640 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4640 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true))] s3_4640 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl)))))))))))) (by decide +kernel)
def s3_4641 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_4641 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4641 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_4641 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl)))))))))))) (by decide +kernel)
def s3_4642 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_4642 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4642 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true))] s3_4642 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl)))))))))))) (by decide +kernel)
def s3_4643 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_4643 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4643 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s3_4643 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))))) (by decide +kernel)
def s3_4648 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6101,w6300,w6588]
theorem b3_4648 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4648 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_4648 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4653 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6422,w6588]
theorem b3_4653 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4653 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_4653 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4673 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6179,w6300,w6588]
theorem b3_4673 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4673 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_4673 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4674 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b3_4674 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4674 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true))] s3_4674 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4676 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6436,w6588]
theorem b3_4676 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4676 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_4676 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6436,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6436 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4677 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6464,w6588]
theorem b3_4677 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4677 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true))] s3_4677 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4678 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6522,w6588]
theorem b3_4678 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4678 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s3_4678 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4679 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_4679 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4679 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s3_4679 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4680 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6785]
theorem b3_4680 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4680 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_4680 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl)))))))))))) (by decide +kernel)
def s3_4681 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6857]
theorem b3_4681 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4681 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true))] s3_4681 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl)))))))))))) (by decide +kernel)
def s3_4682 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_4682 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4682 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s3_4682 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))))) (by decide +kernel)
def s3_4702 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_4702 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4702 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_4702 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_4712 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_4712 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4712 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_4712 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_4720 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_4720 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4720 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s3_4720 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
