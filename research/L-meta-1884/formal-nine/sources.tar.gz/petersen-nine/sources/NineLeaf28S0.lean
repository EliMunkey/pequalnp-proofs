import NinePin28
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17119 : List (BitVec 512) := [w3766,w4344,w4716,w5104,w5393,w5585,w5956,w6300,w6588]
theorem b4_17119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17119 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [] s4_17119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_3766,v28_4344,v28_4716,v28_5104,v28_5393,v28_5585,v28_5956,v28_6300,v28_6588] (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5104 (PetersenWireProjection.cons pc28_5393 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6588 rfl))))))))) (by decide +kernel)
def s5_5767 : List (BitVec 512) := [w3766,w4344,w4716,w5104,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b5_5767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5767 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [(false,(3,true),(1,true))] s5_5767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_3766,v28_4344,v28_4716,v28_5104,v28_5393,v28_5585,v28_5956,v28_6300,v28_6522,v28_6588] (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5104 (PetersenWireProjection.cons pc28_5393 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6522 (PetersenWireProjection.cons pc28_6588 rfl)))))))))) (by decide +kernel)
def s5_5768 : List (BitVec 512) := [w3766,w4344,w4716,w5109,w5393,w5585,w5956,w6300,w6588]
theorem b5_5768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5768 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [] s5_5768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_3766,v28_4344,v28_4716,v28_5109,v28_5393,v28_5585,v28_5956,v28_6300,v28_6588] (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5109 (PetersenWireProjection.cons pc28_5393 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6588 rfl))))))))) (by decide +kernel)
def s5_5770 : List (BitVec 512) := [w3766,w4344,w4716,w5118,w5393,w5585,w5956,w6300,w6588]
theorem b5_5770 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5770 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [] s5_5770 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_3766,v28_4344,v28_4716,v28_5118,v28_5393,v28_5585,v28_5956,v28_6300,v28_6588] (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5118 (PetersenWireProjection.cons pc28_5393 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6588 rfl))))))))) (by decide +kernel)
def s5_5772 : List (BitVec 512) := [w3766,w4344,w4716,w5131,w5393,w5585,w5956,w6300,w6588]
theorem b5_5772 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5772 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [] s5_5772 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_3766,v28_4344,v28_4716,v28_5131,v28_5393,v28_5585,v28_5956,v28_6300,v28_6588] (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5131 (PetersenWireProjection.cons pc28_5393 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6588 rfl))))))))) (by decide +kernel)
def s6_59 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5104,w5585,w5956,w6300,w6588]
theorem b6_59 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_59 := by
  intro m le c
  apply rejects_sound r28 i7 8 tgt (small28 adj) hot28 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s6_59 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v28_2468,v28_3766,v28_4344,v28_4716,v28_5104,v28_5585,v28_5956,v28_6300,v28_6588] (PetersenWireProjection.cons pc28_2468 (PetersenWireProjection.cons pc28_3766 (PetersenWireProjection.cons pc28_4344 (PetersenWireProjection.cons pc28_4716 (PetersenWireProjection.cons pc28_5104 (PetersenWireProjection.cons pc28_5585 (PetersenWireProjection.cons pc28_5956 (PetersenWireProjection.cons pc28_6300 (PetersenWireProjection.cons pc28_6588 rfl))))))))) (by decide +kernel)
end NineCert
