import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_8126 : List (BitVec 512) := [w1312,w3766,w4344,w5031,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8126 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5031,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8127 : List (BitVec 512) := [w1312,w3766,w4344,w5070,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8127 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8127 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8127 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5070,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5070 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8128 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8128 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8128 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8128 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8129 : List (BitVec 512) := [w1312,w3766,w4344,w5098,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8129 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8129 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8129 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_8130 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5179,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8130 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5179,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5179 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8132 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5205,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_8132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8132 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5205,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8133 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5239,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_8133 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8133 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_8133 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6813] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6813 rfl))))))))))) (by decide +kernel)
def s4_8143 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5530,w5585,w5769,w5956,w6300,w6720]
theorem b4_8143 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8143 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8143 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5530,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8160 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5861,w5956,w6300,w6720]
theorem b4_8160 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8160 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8160 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5861,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8161 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5873,w5956,w6300,w6720]
theorem b4_8161 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8161 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8161 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8170 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6147,w6300,w6720]
theorem b4_8170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8170 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6147,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8181 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6444,w6720]
theorem b4_8181 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8181 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8181 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6444,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_8190 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6763]
theorem b4_8190 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8190 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8190 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720,v1_6763] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6763 rfl))))))))))) (by decide +kernel)
def s4_8196 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5873,w5956,w6300,w6720]
theorem b4_8196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8196 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_8206 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5769,w5861,w5956,w6300,w6720]
theorem b4_8206 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8206 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(4,true),(5,true))] s4_8206 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1312,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5861,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_1312 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl)))))))))) (by decide +kernel)
def s4_8230 : List (BitVec 512) := [w1328,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8230 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8239 : List (BitVec 512) := [w1328,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8239 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8240 : List (BitVec 512) := [w1328,w2555,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8240 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8240 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8240 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2555,v1_3766,v1_4716,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8241 : List (BitVec 512) := [w1328,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8241 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8242 : List (BitVec 512) := [w1328,w2597,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8242 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2597,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2597 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8243 : List (BitVec 512) := [w1328,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8243 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8244 : List (BitVec 512) := [w1328,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8244 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8245 : List (BitVec 512) := [w1328,w2613,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_8245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8245 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_8245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8246 : List (BitVec 512) := [w1328,w2615,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8246 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8246 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true))] s4_8246 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2615,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8247 : List (BitVec 512) := [w1328,w2623,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8247 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_8247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2623,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8248 : List (BitVec 512) := [w1328,w2633,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8248 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2633,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2633 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8249 : List (BitVec 512) := [w1328,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8249 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8250 : List (BitVec 512) := [w1328,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8250 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8251 : List (BitVec 512) := [w1328,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8251 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8297 : List (BitVec 512) := [w1328,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8297 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8297 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8297 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8308 : List (BitVec 512) := [w1328,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8308 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8308 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8308 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8319 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4876,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8319 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_4876,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4876 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8333 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8333 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8334 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8334 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8334 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8334 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8335 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w4994,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8335 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true))] s4_8335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_4994,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4994 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8336 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5002,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8336 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_8336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5002,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8337 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5012,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8337 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5012,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5012 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8338 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8338 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8339 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8339 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8340 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8340 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8341 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5069,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8341 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5069,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5069 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8342 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5180,w5393,w5585,w5956,w6300,w6588]
theorem b4_8342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8342 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5180,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5180 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8344 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_8344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8344 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8345 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6588]
theorem b4_8345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8345 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8346 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5243,w5393,w5585,w5956,w6300,w6588]
theorem b4_8346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8346 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5243,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5243 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8360 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5530,w5585,w5956,w6300,w6588]
theorem b4_8360 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8360 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8360 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5530,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8400 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5861,w5956,w6300,w6588]
theorem b4_8400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8400 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8401 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5863,w5956,w6300,w6588]
theorem b4_8401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8401 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(5,true))] s4_8401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5863,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5863 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8402 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5873,w5956,w6300,w6588]
theorem b4_8402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8402 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_8402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8403 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5883,w5956,w6300,w6588]
theorem b4_8403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8403 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5883,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5883 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8416 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6147,w6300,w6588]
theorem b4_8416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8416 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8429 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6444,w6588]
theorem b4_8429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8429 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6444,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8441 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_8441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8441 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_8465 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5769,w5861,w5956,w6300,w6588]
theorem b4_8465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8465 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(5,true))] s4_8465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8476 : List (BitVec 512) := [w1328,w3766,w4716,w4926,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_8476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8476 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true))] s4_8476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1328,v1_3766,v1_4716,v1_4926,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1328 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8507 : List (BitVec 512) := [w1353,w2613,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_8507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8507 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_8507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8508 : List (BitVec 512) := [w1353,w2623,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8508 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_8508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_2623,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8509 : List (BitVec 512) := [w1353,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6422,w6588]
theorem b4_8509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8509 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(9,true))] s4_8509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6422,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6422 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8510 : List (BitVec 512) := [w1353,w2652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8510 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(9,true))] s4_8510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_2652,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_2652 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8511 : List (BitVec 512) := [w1353,w2654,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8511 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(7,true),(9,true))] s4_8511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_2654,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_2654 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8538 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5002,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8538 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s4_8538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5002,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8539 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5037,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8539 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s4_8539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5037,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5037 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8540 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5039,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8540 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true))] s4_8540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5039,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5039 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_8558 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5873,w5956,w6300,w6588]
theorem b4_8558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8558 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_8558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1353,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5873,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1353 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
