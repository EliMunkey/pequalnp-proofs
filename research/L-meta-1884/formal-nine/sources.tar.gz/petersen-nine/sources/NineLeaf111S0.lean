import NinePin111
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1220 : List (BitVec 512) := [w192,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1220 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_1220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_192,v111_1915,v111_3766,v111_4344,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6588] (PetersenWireProjection.cons pc111_192 (PetersenWireProjection.cons pc111_1915 (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6588 rfl))))))))))) (by decide +kernel)
def s4_1311 : List (BitVec 512) := [w195,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1311 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1311 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_1311 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_195,v111_1915,v111_3766,v111_4344,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6588] (PetersenWireProjection.cons pc111_195 (PetersenWireProjection.cons pc111_1915 (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6588 rfl))))))))))) (by decide +kernel)
def s4_1364 : List (BitVec 512) := [w195,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1364 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1364 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_1364 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_195,v111_3182,v111_3766,v111_4344,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6588] (PetersenWireProjection.cons pc111_195 (PetersenWireProjection.cons pc111_3182 (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6588 rfl))))))))))) (by decide +kernel)
def s4_16592 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_16592 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16592 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_16592 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_3766,v111_4344,v111_4519,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6588,v111_6904] (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4519 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6588 (PetersenWireProjection.cons pc111_6904 rfl))))))))))) (by decide +kernel)
def s4_16597 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_16597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16597 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_16597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_3766,v111_4344,v111_4519,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6785,v111_6873] (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4519 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6785 (PetersenWireProjection.cons pc111_6873 rfl))))))))))) (by decide +kernel)
def s4_16599 : List (BitVec 512) := [w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_16599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16599 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s4_16599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_3766,v111_4344,v111_4519,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6464,v111_6588,v111_6873] (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4519 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6464 (PetersenWireProjection.cons pc111_6588 (PetersenWireProjection.cons pc111_6873 rfl))))))))))) (by decide +kernel)
def s5_5564 : List (BitVec 512) := [w3766,w4344,w4462,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5564 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5564 := by
  intro m le c
  apply rejects_sound r111 i6 6 tgt (small111 adj) hot111 [] s5_5564 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v111_3766,v111_4344,v111_4462,v111_4716,v111_5135,v111_5393,v111_5585,v111_5956,v111_6300,v111_6588] (PetersenWireProjection.cons pc111_3766 (PetersenWireProjection.cons pc111_4344 (PetersenWireProjection.cons pc111_4462 (PetersenWireProjection.cons pc111_4716 (PetersenWireProjection.cons pc111_5135 (PetersenWireProjection.cons pc111_5393 (PetersenWireProjection.cons pc111_5585 (PetersenWireProjection.cons pc111_5956 (PetersenWireProjection.cons pc111_6300 (PetersenWireProjection.cons pc111_6588 rfl)))))))))) (by decide +kernel)
end NineCert
