import NinePin105
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_292 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_292 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_292 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_292 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6588,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6873 rfl)))))))))))) (by decide +kernel)
def s3_2223 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_2223 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2223 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2223 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s3_2229 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6588]
theorem b3_2229 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2229 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2229 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6522,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s3_2262 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b3_2262 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2262 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2262 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6331,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6331 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s3_2269 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_2269 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2269 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2269 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6489,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s3_2290 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b3_2290 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2290 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2290 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s3_2293 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b3_2293 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2293 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_2293 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s3_4899 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6489,w6588]
theorem b3_4899 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4899 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_4899 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5848,v105_5956,v105_6300,v105_6489,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5848 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s3_4923 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6489,w6588]
theorem b3_4923 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4923 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_4923 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6225,v105_6300,v105_6489,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s3_4938 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6499,w6588]
theorem b3_4938 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4938 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_4938 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6489,v105_6499,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6499 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s3_4940 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6575,w6588]
theorem b3_4940 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4940 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s3_4940 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6489,v105_6575,v105_6588] (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6489 (PetersenWireProjection.cons pc105_6575 (PetersenWireProjection.cons pc105_6588 rfl)))))))))))) (by decide +kernel)
def s4_461 : List (BitVec 512) := [w29,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_461 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_29,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6522,v105_6588] (PetersenWireProjection.cons pc105_29 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_464 : List (BitVec 512) := [w29,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_464 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_29,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588,v105_6873] (PetersenWireProjection.cons pc105_29 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_656 : List (BitVec 512) := [w75,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_656 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_75,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_75 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_1298 : List (BitVec 512) := [w195,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_1298 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1298 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1298 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6720] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 rfl))))))))))) (by decide +kernel)
def s4_1299 : List (BitVec 512) := [w195,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_1299 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1299 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1299 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6785] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6785 rfl))))))))))) (by decide +kernel)
def s4_1300 : List (BitVec 512) := [w195,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_1300 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1300 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1300 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 rfl))))))))))) (by decide +kernel)
def s4_1486 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_1486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1486 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588,v105_6906] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6906 rfl))))))))))) (by decide +kernel)
def s4_1489 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6601,w6873]
theorem b4_1489 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1489 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1489 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6601,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6601 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_1498 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_1498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1498 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_1500 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6331,w6588,w6873]
theorem b4_1500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1500 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6331,v105_6588,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6331 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_1509 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_1509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1509 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5769,v105_5956,v105_6464,v105_6588,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_1511 : List (BitVec 512) := [w195,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_1511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1511 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6588,v105_6895] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 (PetersenWireProjection.cons pc105_6895 rfl))))))))))) (by decide +kernel)
def s4_1513 : List (BitVec 512) := [w195,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_1513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1513 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_1513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_195,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6720,v105_6873] (PetersenWireProjection.cons pc105_195 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 (PetersenWireProjection.cons pc105_6873 rfl))))))))))) (by decide +kernel)
def s4_2268 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_2268 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2268 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_2268 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_360,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_360 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_5561 : List (BitVec 512) := [w1095,w3766,w4344,w4716,w4780,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5561 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_5561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1095,v105_3766,v105_4344,v105_4716,v105_4780,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1095 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_4780 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_5562 : List (BitVec 512) := [w1095,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5562 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_5562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1095,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1095 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s4_7107 : List (BitVec 512) := [w1253,w3766,w4344,w4716,w5135,w5393,w5585,w5646,w5956,w6300,w6588]
theorem b4_7107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7107 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1253,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5646,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1253 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5646 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7108 : List (BitVec 512) := [w1253,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7108 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1253,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1253 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s4_7141 : List (BitVec 512) := [w1278,w3766,w4344,w4716,w5135,w5393,w5585,w5666,w5956,w6300,w6588]
theorem b4_7141 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7141 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7141 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1278,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5666,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1278 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5666 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7142 : List (BitVec 512) := [w1278,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7142 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7142 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7142 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1278,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1278 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl)))))))))) (by decide +kernel)
def s4_7563 : List (BitVec 512) := [w1312,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7563 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_1635,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_1635 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7564 : List (BitVec 512) := [w1312,w1652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7564 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_1652,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_1652 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7568 : List (BitVec 512) := [w1312,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7568 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 rfl))))))))))) (by decide +kernel)
def s4_7569 : List (BitVec 512) := [w1312,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785]
theorem b4_7569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7569 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6785] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6785 rfl))))))))))) (by decide +kernel)
def s4_7570 : List (BitVec 512) := [w1312,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7570 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_1670,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_1670 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 rfl))))))))))) (by decide +kernel)
def s4_7614 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_7614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7614 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [(false,(5,true),(1,false))] s4_7614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_2468,v105_3766,v105_4344,v105_4716,v105_5135,v105_5585,v105_5769,v105_5956,v105_6300,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_2468 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7990 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6386,w6588]
theorem b4_7990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7990 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6386,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6386 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_7994 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6813]
theorem b4_7994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7994 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6389,v105_6813] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6813 rfl))))))))))) (by decide +kernel)
def s4_7995 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6394,w6588]
theorem b4_7995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7995 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_7995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6394,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6394 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8007 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_8007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8007 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6499,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6499 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8009 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6513,w6588]
theorem b4_8009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8009 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6513,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6513 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8013 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6813]
theorem b4_8013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8013 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6522,v105_6813] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6813 rfl))))))))))) (by decide +kernel)
def s4_8014 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6527,w6588]
theorem b4_8014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8014 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6527,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6527 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8021 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_8021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8021 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6575,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6575 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8049 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6906]
theorem b4_8049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8049 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6720,v105_6906] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 (PetersenWireProjection.cons pc105_6906 rfl))))))))))) (by decide +kernel)
def s4_8059 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6906]
theorem b4_8059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8059 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6785,v105_6906] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6785 (PetersenWireProjection.cons pc105_6906 rfl))))))))))) (by decide +kernel)
def s4_8071 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6895]
theorem b4_8071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8071 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813,v105_6895] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6895 rfl))))))))))) (by decide +kernel)
def s4_8072 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6904]
theorem b4_8072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8072 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813,v105_6904] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6904 rfl))))))))))) (by decide +kernel)
def s4_8073 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6906]
theorem b4_8073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8073 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6813,v105_6906] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6813 (PetersenWireProjection.cons pc105_6906 rfl))))))))))) (by decide +kernel)
def s4_8079 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6300,w6522,w6588]
theorem b4_8079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8079 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_5993,v105_6300,v105_6522,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5993 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8086 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_8086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8086 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5585,v105_6225,v105_6300,v105_6522,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8101 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_8101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8101 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6478,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6478 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8115 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5956,w6225,w6300,w6464,w6588]
theorem b4_8115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8115 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_4716,v105_5135,v105_5393,v105_5956,v105_6225,v105_6300,v105_6464,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8178 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6720]
theorem b4_8178 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8178 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8178 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6389,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6720 rfl))))))))))) (by decide +kernel)
def s4_8185 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6522,w6720]
theorem b4_8185 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8185 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8185 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6522,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6522 (PetersenWireProjection.cons pc105_6720 rfl))))))))))) (by decide +kernel)
def s4_8194 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6895]
theorem b4_8194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8194 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6300,v105_6720,v105_6895] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6720 (PetersenWireProjection.cons pc105_6895 rfl))))))))))) (by decide +kernel)
def s4_8195 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b4_8195 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8195 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8195 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5769,v105_5956,v105_6389,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8200 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6422,w6588]
theorem b4_8200 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8200 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8200 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5585,v105_5956,v105_6225,v105_6300,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6225 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8203 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_8203 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8203 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8203 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5698,v105_5769,v105_5956,v105_6300,v105_6422,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5698 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6422 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8208 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5769,w5956,w6300,w6464,w6720]
theorem b4_8208 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8208 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8208 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4344,v105_5135,v105_5393,v105_5769,v105_5956,v105_6300,v105_6464,v105_6720] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4344 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6464 (PetersenWireProjection.cons pc105_6720 rfl)))))))))) (by decide +kernel)
def s4_8209 : List (BitVec 512) := [w1312,w3766,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_8209 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8209 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8209 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4392,v105_4716,v105_5135,v105_5393,v105_5585,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4392 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8216 : List (BitVec 512) := [w1312,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b4_8216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8216 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4716,v105_5135,v105_5393,v105_5585,v105_5848,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5585 (PetersenWireProjection.cons pc105_5848 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
def s4_8218 : List (BitVec 512) := [w1312,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b4_8218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8218 := by
  intro m le c
  apply rejects_sound r105 i6 6 tgt (small105 adj) hot105 [] s4_8218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v105_1312,v105_3766,v105_4716,v105_5135,v105_5393,v105_5698,v105_5769,v105_5956,v105_6300,v105_6389,v105_6588] (PetersenWireProjection.cons pc105_1312 (PetersenWireProjection.cons pc105_3766 (PetersenWireProjection.cons pc105_4716 (PetersenWireProjection.cons pc105_5135 (PetersenWireProjection.cons pc105_5393 (PetersenWireProjection.cons pc105_5698 (PetersenWireProjection.cons pc105_5769 (PetersenWireProjection.cons pc105_5956 (PetersenWireProjection.cons pc105_6300 (PetersenWireProjection.cons pc105_6389 (PetersenWireProjection.cons pc105_6588 rfl))))))))))) (by decide +kernel)
end NineCert
