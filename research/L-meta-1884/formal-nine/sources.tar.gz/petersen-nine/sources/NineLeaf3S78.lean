import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1274 : List (BitVec 512) := [w967,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_1274 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1274 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_1274 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1275 : List (BitVec 512) := [w967,w2494,w3766,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_1275 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1275 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1275 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1276 : List (BitVec 512) := [w967,w2494,w3766,w4716,w5135,w5698,w5956,w6179,w6300,w6588]
theorem b5_1276 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1276 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_1276 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2494,v3_3766,v3_4716,v3_5135,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1277 : List (BitVec 512) := [w967,w2496,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_1277 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1277 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_1277 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2496,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2496 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1278 : List (BitVec 512) := [w967,w2496,w3766,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_1278 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1278 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_1278 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2496,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2496 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1279 : List (BitVec 512) := [w967,w2527,w3182,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1279 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1279 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_1279 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3182,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1280 : List (BitVec 512) := [w967,w2527,w3186,w3766,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1280 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1280 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_1280 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3186,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3186 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1281 : List (BitVec 512) := [w967,w2527,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b5_1281 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1281 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_1281 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2527,v3_3766,v3_4716,v3_5135,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1282 : List (BitVec 512) := [w967,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_1282 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1282 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s5_1282 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2528,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2528 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1283 : List (BitVec 512) := [w967,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_1283 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1283 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s5_1283 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2528,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2528 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1284 : List (BitVec 512) := [w967,w2677,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1284 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1284 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2677,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2677 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1285 : List (BitVec 512) := [w967,w2678,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1285 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1285 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2678,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2678 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1286 : List (BitVec 512) := [w967,w2679,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1286 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1286 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1286 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2679,v3_3766,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2679 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1287 : List (BitVec 512) := [w967,w2681,w3067,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1287 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1287 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(0,true),(6,true))] s5_1287 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3067,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3067 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1288 : List (BitVec 512) := [w967,w2681,w3118,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1288 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(0,true),(7,true))] s5_1288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3118,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3118 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1289 : List (BitVec 512) := [w967,w2681,w3145,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1289 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1289 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true))] s5_1289 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3145,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3145 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1290 : List (BitVec 512) := [w967,w2681,w3177,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1290 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1290 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(4,true),(1,true))] s5_1290 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3177,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3177 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1291 : List (BitVec 512) := [w967,w2681,w3179,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1291 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1291 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,false)),(false,(4,true),(1,true))] s5_1291 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3179,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3179 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1292 : List (BitVec 512) := [w967,w2681,w3183,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1292 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1292 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false)),(false,(4,true),(1,true))] s5_1292 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3183,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3183 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1293 : List (BitVec 512) := [w967,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1293 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1293 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(2,true),(6,false))] s5_1293 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3258,v3_4344,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1294 : List (BitVec 512) := [w967,w2681,w3258,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1294 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1294 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(0,true),(4,false)),(false,(8,true),(2,true)),(false,(4,true),(0,true))] s5_1294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3258,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1295 : List (BitVec 512) := [w967,w2681,w3766,w4716,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b5_1295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1295 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true)),(false,(7,true),(6,true))] s5_1295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1296 : List (BitVec 512) := [w967,w2681,w3766,w4716,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b5_1296 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1296 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(6,true),(7,true))] s5_1296 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3766,v3_4716,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1297 : List (BitVec 512) := [w967,w2681,w3766,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b5_1297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1297 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(7,true),(3,true))] s5_1297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3766,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_1298 : List (BitVec 512) := [w967,w2681,w3766,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b5_1298 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1298 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(3,true),(0,true)),(false,(6,true),(3,true))] s5_1298 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2681,v3_3766,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_1299 : List (BitVec 512) := [w967,w2683,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1299 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1299 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_1299 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2683,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1300 : List (BitVec 512) := [w967,w2683,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_1300 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1300 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_1300 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2683,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1301 : List (BitVec 512) := [w967,w2683,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1301 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1301 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_1301 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2683,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1302 : List (BitVec 512) := [w967,w2683,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b5_1302 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1302 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_1302 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2683,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2683 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1303 : List (BitVec 512) := [w967,w2686,w3177,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1303 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1303 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_1303 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2686,v3_3177,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2686 (PetersenWireProjection.cons pc3_3177 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1304 : List (BitVec 512) := [w967,w2686,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1304 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1304 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_1304 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2686,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2686 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1305 : List (BitVec 512) := [w967,w2686,w3766,w4716,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1305 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(8,true),(0,false)),(false,(4,true),(0,true))] s5_1305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2686,v3_3766,v3_4716,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2686 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1306 : List (BitVec 512) := [w967,w2687,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1306 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1306 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1306 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2687,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2687 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1307 : List (BitVec 512) := [w967,w2690,w3179,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1307 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1307 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_1307 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2690,v3_3179,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2690 (PetersenWireProjection.cons pc3_3179 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1308 : List (BitVec 512) := [w967,w2690,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1308 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1308 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_1308 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2690,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2690 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1309 : List (BitVec 512) := [w967,w2690,w3766,w4716,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,false)),(false,(4,true),(0,true))] s5_1309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2690,v3_3766,v3_4716,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2690 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1310 : List (BitVec 512) := [w967,w2691,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1310 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1310 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1310 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2691,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2691 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1311 : List (BitVec 512) := [w967,w2696,w3182,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1311 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(4,true),(0,true))] s5_1311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2696,v3_3182,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2696 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1312 : List (BitVec 512) := [w967,w2696,w3183,w3766,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_1312 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1312 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1312 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2696,v3_3183,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2696 (PetersenWireProjection.cons pc3_3183 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1313 : List (BitVec 512) := [w967,w2696,w3766,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_1313 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1313 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2696,v3_3766,v3_4716,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2696 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1314 : List (BitVec 512) := [w967,w2696,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_1314 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1314 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true)),(false,(4,true),(0,true))] s5_1314 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2696,v3_3766,v3_4716,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2696 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1315 : List (BitVec 512) := [w967,w2837,w3258,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1315 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1315 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(2,true),(6,false))] s5_1315 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3258,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1316 : List (BitVec 512) := [w967,w2837,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_1316 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true))] s5_1316 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1317 : List (BitVec 512) := [w967,w2837,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_1317 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true))] s5_1317 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_1318 : List (BitVec 512) := [w967,w2837,w3766,w4716,w5135,w5393,w5698,w6300,w6522,w6588]
theorem b5_1318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1318 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(7,true),(8,true))] s5_1318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1319 : List (BitVec 512) := [w967,w2837,w3766,w4716,w5200,w5393,w5698,w5956,w6300,w6588]
theorem b5_1319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_1319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_4716,v3_5200,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1320 : List (BitVec 512) := [w967,w2837,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1320 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(0,false),(5,true)),(false,(3,true),(0,true))] s5_1320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1321 : List (BitVec 512) := [w967,w2837,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1321 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1321 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true)),(false,(3,true),(0,true))] s5_1321 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1322 : List (BitVec 512) := [w967,w2837,w3766,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b5_1322 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1322 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(1,false),(3,true))] s5_1322 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2837,v3_3766,v3_5135,v3_5393,v3_5698,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2837 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1323 : List (BitVec 512) := [w967,w2838,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1323 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1323 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(7,true),(3,true))] s5_1323 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2838,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2838 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1324 : List (BitVec 512) := [w967,w2838,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1324 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(6,true),(3,true))] s5_1324 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2838,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2838 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1325 : List (BitVec 512) := [w967,w2857,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1325 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1325 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(6,true),(3,true))] s5_1325 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2857,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2857 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1326 : List (BitVec 512) := [w967,w2861,w3766,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_1326 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1326 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,true),(2,true)),(false,(7,true),(3,true))] s5_1326 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2861,v3_3766,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2861 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1327 : List (BitVec 512) := [w967,w2880,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_1327 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1327 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(6,true),(3,true))] s5_1327 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2880,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2880 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1328 : List (BitVec 512) := [w967,w2952,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1328 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1328 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s5_1328 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2952,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2952 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1329 : List (BitVec 512) := [w967,w2953,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1329 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1329 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s5_1329 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2953,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2953 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1330 : List (BitVec 512) := [w967,w2954,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1330 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1330 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s5_1330 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2954,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2954 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1331 : List (BitVec 512) := [w967,w2955,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1331 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1331 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s5_1331 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_2955,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_2955 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1332 : List (BitVec 512) := [w967,w3065,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1332 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1332 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s5_1332 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3065,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3065 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1333 : List (BitVec 512) := [w967,w3116,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1333 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1333 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s5_1333 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3116,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3116 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1334 : List (BitVec 512) := [w967,w3117,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1334 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1334 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s5_1334 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3117,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3117 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1335 : List (BitVec 512) := [w967,w3141,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1335 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true))] s5_1335 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3141,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3141 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1336 : List (BitVec 512) := [w967,w3143,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1336 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1336 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))] s5_1336 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3143,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3143 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_1337 : List (BitVec 512) := [w967,w3144,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1337 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_1337 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3144,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3144 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
