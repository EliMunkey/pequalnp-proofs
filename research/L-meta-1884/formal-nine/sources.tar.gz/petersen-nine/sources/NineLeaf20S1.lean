import NinePin20
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_731 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6464,w6873]
theorem b5_731 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_731 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(5,true)),(false,(5,true),(8,true))] s5_731 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2527,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6464,v20_6873] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2527 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6464 (PetersenWireProjection.cons pc20_6873 rfl)))))))))) (by decide +kernel)
def s5_732 : List (BitVec 512) := [w498,w2527,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6832]
theorem b5_732 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_732 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(5,true)),(false,(5,true),(7,true))] s5_732 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2527,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_6179,v20_6300,v20_6832] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2527 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_6179 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6832 rfl)))))))))) (by decide +kernel)
def s5_734 : List (BitVec 512) := [w498,w2816,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_734 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_734 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,false),(2,true))] s5_734 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_2816,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_2816 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_737 : List (BitVec 512) := [w498,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6640]
theorem b5_737 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_737 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_737 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_3766,v20_4344,v20_4716,v20_4800,v20_5135,v20_5585,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4800 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s5_742 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6640]
theorem b5_742 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_742 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_742 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5652,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5652 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s5_743 : List (BitVec 512) := [w498,w3766,w4344,w4716,w5135,w5585,w5802,w5956,w6300,w6588]
theorem b5_743 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_743 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(4,true))] s5_743 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_498,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5802,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5802 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_752 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6464,w6873]
theorem b5_752 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_752 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(4,true)),(false,(6,true),(8,true))] s5_752 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_502,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6464,v20_6873] (PetersenWireProjection.cons pc20_502 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6464 (PetersenWireProjection.cons pc20_6873 rfl)))))))))) (by decide +kernel)
def s5_754 : List (BitVec 512) := [w502,w2494,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6832]
theorem b5_754 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_754 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(6,true),(4,true)),(false,(6,true),(7,true))] s5_754 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_502,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_6179,v20_6300,v20_6832] (PetersenWireProjection.cons pc20_502 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_6179 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6832 rfl)))))))))) (by decide +kernel)
def s5_1560 : List (BitVec 512) := [w1007,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6640]
theorem b5_1560 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1560 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,false),(5,true))] s5_1560 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_1007,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_1007 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s5_1882 : List (BitVec 512) := [w1101,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6640]
theorem b5_1882 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1882 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,false),(5,true))] s5_1882 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_1101,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_1101 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s5_2269 : List (BitVec 512) := [w1257,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6640]
theorem b5_2269 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2269 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,false),(5,true))] s5_2269 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_1257,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6640] (PetersenWireProjection.cons pc20_1257 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6640 rfl)))))))))) (by decide +kernel)
def s5_3367 : List (BitVec 512) := [w2207,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3367 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3367 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(4,true)),(false,(1,true),(0,true))] s5_3367 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2207,v20_2468,v20_3258,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2207 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3258 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3379 : List (BitVec 512) := [w2215,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_3379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3379 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true))] s5_3379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2215,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2215 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3380 : List (BitVec 512) := [w2216,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3380 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3380 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3380 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2216,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2216 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3382 : List (BitVec 512) := [w2218,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3382 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3382 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3382 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2218,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2218 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3448 : List (BitVec 512) := [w2225,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3448 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3448 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3448 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2225,v20_2527,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2225 (PetersenWireProjection.cons pc20_2527 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3479 : List (BitVec 512) := [w2253,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3479 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3479 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3479 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2253,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2253 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3482 : List (BitVec 512) := [w2256,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3482 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3482 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3482 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2256,v20_2491,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2256 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3495 : List (BitVec 512) := [w2268,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3495 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3495 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3495 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2268,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2268 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3508 : List (BitVec 512) := [w2299,w2468,w3766,w4344,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b5_3508 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3508 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true)),(false,(3,true),(7,true))] s5_3508 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2299,v20_2468,v20_3766,v20_4344,v20_5135,v20_5585,v20_6101,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2299 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_6101 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3509 : List (BitVec 512) := [w2300,w2488,w3766,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b5_3509 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3509 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(3,true))] s5_3509 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2300,v20_2488,v20_3766,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6389,v20_6588] (PetersenWireProjection.cons pc20_2300 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6389 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3510 : List (BitVec 512) := [w2301,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3510 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3510 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3510 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2301,v20_2494,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2301 (PetersenWireProjection.cons pc20_2494 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3528 : List (BitVec 512) := [w2323,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3528 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3528 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(3,true)),(false,(1,true),(0,true))] s5_3528 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3258,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3258 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3529 : List (BitVec 512) := [w2323,w2468,w3766,w4344,w4716,w5135,w6179,w6300,w6522,w6588]
theorem b5_3529 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3529 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(6,true)),(false,(5,true),(7,true))] s5_3529 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_6179,v20_6300,v20_6522,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_6179 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6522 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3530 : List (BitVec 512) := [w2323,w3766,w4344,w4716,w5135,w5585,w5725,w5956,w6300,w6588]
theorem b5_3530 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3530 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(4,true))] s5_3530 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2323,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5725,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2323 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5725 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3531 : List (BitVec 512) := [w2324,w2488,w3766,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b5_3531 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3531 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(3,true))] s5_3531 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2324,v20_2488,v20_3766,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6389,v20_6588] (PetersenWireProjection.cons pc20_2324 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6389 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3532 : List (BitVec 512) := [w2325,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3532 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3532 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3532 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2325,v20_2491,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2325 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3557 : List (BitVec 512) := [w2335,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b5_3557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3557 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2335,v20_3766,v20_4344,v20_4716,v20_5135,v20_5470,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2335 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5470 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3559 : List (BitVec 512) := [w2338,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3559 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3559 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3559 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2338,v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2338 (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3560 : List (BitVec 512) := [w2339,w2491,w3766,w4344,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b5_3560 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3560 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(7,true),(2,true))] s5_3560 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2339,v20_2491,v20_3766,v20_4344,v20_5135,v20_5585,v20_5956,v20_6300,v20_6422,v20_6588] (PetersenWireProjection.cons pc20_2339 (PetersenWireProjection.cons pc20_2491 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6422 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3578 : List (BitVec 512) := [w2349,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_3578 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3578 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3578 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2349,v20_3766,v20_4344,v20_4716,v20_5135,v20_5471,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2349 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5471 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3579 : List (BitVec 512) := [w2350,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3579 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3579 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3579 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2350,v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2350 (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3637 : List (BitVec 512) := [w2379,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3637 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2379,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2379 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3668 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_3668 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3668 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(5,true),(2,true))] s5_3668 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2381,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6720] (PetersenWireProjection.cons pc20_2381 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6720 rfl)))))))))) (by decide +kernel)
def s5_3692 : List (BitVec 512) := [w2383,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3692 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3692 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3692 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2383,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2383 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3704 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b5_3704 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3704 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(3,true))] s5_3704 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2387,v20_3766,v20_4344,v20_4716,v20_4926,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2387 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4926 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_3732 : List (BitVec 512) := [w2388,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3732 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3732 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3732 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2388,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2388 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3735 : List (BitVec 512) := [w2389,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3735 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3735 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3735 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2389,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2389 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3749 : List (BitVec 512) := [w2400,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3749 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3749 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3749 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2400,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2400 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3753 : List (BitVec 512) := [w2402,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3753 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3753 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3753 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2402,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2402 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3757 : List (BitVec 512) := [w2404,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3757 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3757 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3757 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2404,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2404 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3761 : List (BitVec 512) := [w2406,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3761 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3761 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3761 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2406,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2406 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3788 : List (BitVec 512) := [w2417,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3788 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3788 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3788 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2417,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2417 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_3792 : List (BitVec 512) := [w2419,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3792 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3792 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_3792 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2419,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2419 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4096 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4892,w5135,w5585,w5956,w6300,w6588]
theorem b5_4096 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4096 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(2,true))] s5_4096 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4716,v20_4892,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_4892 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4106 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5263,w5585,w5956,w6300,w6588]
theorem b5_4106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4106 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(3,true),(4,true))] s5_4106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5263,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5263 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4109 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5274,w5585,w5956,w6300,w6588]
theorem b5_4109 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4109 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(2,true))] s5_4109 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2468,v20_3766,v20_4344,v20_4716,v20_5135,v20_5274,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2468 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5274 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4267 : List (BitVec 512) := [w2469,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4267 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4267 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4267 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2469,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2469 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4270 : List (BitVec 512) := [w2470,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4270 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4270 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4270 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2470,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2470 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4273 : List (BitVec 512) := [w2471,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4273 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4273 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4273 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2471,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2471 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4407 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5272,w5585,w5956,w6300,w6588]
theorem b5_4407 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4407 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(4,true))] s5_4407 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5272,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5272 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4416 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5447,w5585,w5956,w6300,w6588]
theorem b5_4416 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4416 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(5,true))] s5_4416 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5447,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5447 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4417 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5448,w5585,w5956,w6300,w6588]
theorem b5_4417 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4417 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(5,true))] s5_4417 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5448,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5448 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4445 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5803,w5956,w6300,w6588]
theorem b5_4445 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4445 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(4,true))] s5_4445 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5803,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5803 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl)))))))))) (by decide +kernel)
def s5_4515 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6737]
theorem b5_4515 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4515 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(5,true))] s5_4515 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6737] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6737 rfl)))))))))) (by decide +kernel)
def s5_4519 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6797]
theorem b5_4519 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4519 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(5,true))] s5_4519 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2488,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6797] (PetersenWireProjection.cons pc20_2488 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6797 rfl)))))))))) (by decide +kernel)
def s5_4660 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4660 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4660 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4660 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2492,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2492 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4661 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b5_4661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4661 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(4,true),(5,true))] s5_4661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2492,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6785] (PetersenWireProjection.cons pc20_2492 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6785 rfl)))))))))) (by decide +kernel)
def s5_4706 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4706 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4706 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4706 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2496,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2496 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4707 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b5_4707 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4707 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [(false,(2,true),(5,true))] s5_4707 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2496,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588,v20_6720] (PetersenWireProjection.cons pc20_2496 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 (PetersenWireProjection.cons pc20_6720 rfl)))))))))) (by decide +kernel)
def s5_4745 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4745 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4745 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4745 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2497,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2497 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_4753 : List (BitVec 512) := [w2498,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4753 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4753 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_4753 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_2498,v20_3766,v20_4344,v20_4716,v20_5135,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_2498 (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_6183 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5458,w5585,w5956,w6300,w6588]
theorem b5_6183 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6183 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_6183 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5458,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5458 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
def s5_6184 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5464,w5585,w5956,w6300,w6588]
theorem b5_6184 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6184 := by
  intro m le c
  apply rejects_sound r20 i8 9 tgt (small20 adj) hot20 [] s5_6184 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v20_3766,v20_4344,v20_4716,v20_5135,v20_5464,v20_5585,v20_5956,v20_6300,v20_6588] (PetersenWireProjection.cons pc20_3766 (PetersenWireProjection.cons pc20_4344 (PetersenWireProjection.cons pc20_4716 (PetersenWireProjection.cons pc20_5135 (PetersenWireProjection.cons pc20_5464 (PetersenWireProjection.cons pc20_5585 (PetersenWireProjection.cons pc20_5956 (PetersenWireProjection.cons pc20_6300 (PetersenWireProjection.cons pc20_6588 rfl))))))))) (by decide +kernel)
end NineCert
