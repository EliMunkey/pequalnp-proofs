import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11976 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11976 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11976 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(3,true))] s4_11976 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11977 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_11977 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11977 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(1,false),(7,true))] s4_11977 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11978 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11978 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(7,true)),(false,(4,true),(0,false))] s4_11978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11979 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_11979 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11979 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(8,true))] s4_11979 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11980 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_11980 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11980 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(3,true))] s4_11980 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11981 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_11981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11981 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true)),(false,(3,true),(7,true))] s4_11981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11982 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11982 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_11982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11983 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_11983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11983 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false))] s4_11983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11984 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_11984 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11984 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(5,true))] s4_11984 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11985 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11985 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_11985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11986 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11986 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true))] s4_11986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11987 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_11987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11987 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(3,true))] s4_11987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11988 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_11988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11988 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(7,true))] s4_11988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11989 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_11989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11989 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(8,true))] s4_11989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11990 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_11990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11990 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,false),(8,true))] s4_11990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11991 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_11991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11991 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(3,true))] s4_11991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11992 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11992 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false))] s4_11992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11993 : List (BitVec 512) := [w2458,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11993 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true)),(false,(1,false),(0,false))] s4_11993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2458,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2458 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12233 : List (BitVec 512) := [w2468,w3766,w4344,w4578,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12233 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4578,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4578 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12234 : List (BitVec 512) := [w2468,w3766,w4344,w4578,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12234 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s4_12234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4578,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4578 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12235 : List (BitVec 512) := [w2468,w3766,w4344,w4579,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12235 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4579,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4579 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12236 : List (BitVec 512) := [w2468,w3766,w4344,w4579,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12236 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true))] s4_12236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4579,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4579 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12247 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5283,w5585,w5956,w6300,w6588]
theorem b4_12247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12247 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12248 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5299,w5585,w5956,w6300,w6588]
theorem b4_12248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12248 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5299,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12256 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6029,w6300,w6588]
theorem b4_12256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12256 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12259 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6080,w6300,w6588]
theorem b4_12259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12259 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6080,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12263 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6359,w6588]
theorem b4_12263 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12263 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12263 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6359,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6359 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12266 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6413,w6588]
theorem b4_12266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12266 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6413,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6413 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12271 : List (BitVec 512) := [w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12271 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s4_12271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12330 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5283,w5585,w5956,w6300,w6588]
theorem b4_12330 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12330 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(7,true))] s4_12330 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12331 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5311,w5585,w5956,w6300,w6588]
theorem b4_12331 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12331 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(7,true))] s4_12331 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5311,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12337 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6029,w6300,w6588]
theorem b4_12337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12337 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(7,true))] s4_12337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12367 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5698,w5956,w6300,w6588]
theorem b4_12367 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12367 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s4_12367 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12368 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5769,w5956,w6300,w6588]
theorem b4_12368 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12368 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_12368 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12369 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6543,w6588]
theorem b4_12369 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12369 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s4_12369 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12370 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6549,w6588]
theorem b4_12370 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12370 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false))] s4_12370 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12371 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6300,w6588,w6690]
theorem b4_12371 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12371 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true))] s4_12371 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_12372 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5283,w5585,w5956,w6389,w6522,w6588]
theorem b4_12372 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12372 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_12372 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12374 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5698,w5956,w6300,w6588]
theorem b4_12374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12374 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s4_12374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12375 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5769,w5956,w6300,w6588]
theorem b4_12375 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12375 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_12375 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12376 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6389,w6522,w6588]
theorem b4_12376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12376 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_12376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12377 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6389,w6588]
theorem b4_12377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12377 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_12377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12380 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_12380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12380 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true))] s4_12380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12381 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_12381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12381 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(0,false))] s4_12381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12382 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_12382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12382 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s4_12382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12383 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_12383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12383 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true))] s4_12383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12384 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_12384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12384 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true))] s4_12384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_12385 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_12385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12385 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(3,true))] s4_12385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12386 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_12386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12386 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(5,true),(0,false))] s4_12386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_12387 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_12387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12387 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_12387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_12388 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6785,w6873]
theorem b4_12388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12388 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_12388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_12389 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_12389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12389 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_12389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12390 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_12390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12390 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_12390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_12404 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6029,w6300,w6588]
theorem b4_12404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12404 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s4_12404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5698,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12442 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6029,w6300,w6588]
theorem b4_12442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12442 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_12442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5769,v2_5956,v2_6029,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12447 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6359,w6588]
theorem b4_12447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12447 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_12447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5769,v2_5956,v2_6300,v2_6359,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6359 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12473 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6029,w6300,w6543,w6588]
theorem b4_12473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12473 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s4_12473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12474 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6029,w6300,w6549,w6588]
theorem b4_12474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12474 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false))] s4_12474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12475 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6029,w6389,w6522,w6588]
theorem b4_12475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12475 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_12475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6029,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6029 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12488 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6080,w6300,w6588]
theorem b4_12488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12488 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_12488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6080,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6080 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12495 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6117,w6300,w6588]
theorem b4_12495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12495 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(7,true))] s4_12495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6117,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6117 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_12609 : List (BitVec 512) := [w2488,w3766,w4041,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12609 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12610 : List (BitVec 512) := [w2488,w3766,w4041,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12610 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_12610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_12611 : List (BitVec 512) := [w2488,w3766,w4041,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12611 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_12611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
