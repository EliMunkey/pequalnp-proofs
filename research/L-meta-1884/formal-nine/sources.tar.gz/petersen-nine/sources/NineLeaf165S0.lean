import NinePin165
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2620 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6201,w6300,w6588]
theorem b3_2620 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2620 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s3_2620 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6061,v165_6201,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6201 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))))) (by decide +kernel)
def s4_8869 : List (BitVec 512) := [w1374,w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_8869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8869 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_8869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1374,v165_2468,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_6179,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1374 (PetersenWireProjection.cons pc165_2468 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6179 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9282 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_9282 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9282 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9282 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1374,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6225,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1374 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6225 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9351 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_9351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9351 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3293,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6061,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3293 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9478 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_9478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9478 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6136,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6136 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9523 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_9523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9523 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6300,v165_6543,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6543 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9556 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_9556 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9556 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9556 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6061,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9558 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_9558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9558 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6179,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6179 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9582 : List (BitVec 512) := [w1388,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_9582 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9582 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9582 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_1875,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_1875 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9685 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_9685 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9685 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9685 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6136,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6136 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9726 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_9726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9726 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6061,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9728 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_9728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9728 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6101,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9730 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_9730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9730 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6179,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6179 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9733 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_9733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9733 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6225,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6225 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9746 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_9746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9746 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1390,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6061,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1390 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9747 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_9747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9747 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1390,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1390 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_9748 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_9748 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9748 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_9748 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1390,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6136,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1390 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6136 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_10609 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_10609 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10609 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_10609 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1423,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6061,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1423 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16055 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_16055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16055 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4403,v165_4716,v165_5135,v165_5393,v165_5585,v165_6179,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4403 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6179 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16062 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16062 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4404,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4404 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16216 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16216 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4416,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6101,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4416 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16218 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16218 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4416,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4416 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16219 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_16219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16219 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4416,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6300,v165_6549,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4416 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6549 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_16223 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16223 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_16223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4417,v165_4716,v165_5135,v165_5393,v165_5585,v165_5956,v165_6300,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4417 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl))))))))))) (by decide +kernel)
def s4_18039 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6136,w6522,w6588,w6873]
theorem b4_18039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18039 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_18039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6101,v165_6136,v165_6522,v165_6588,v165_6873] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6136 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 (PetersenWireProjection.cons pc165_6873 rfl))))))))))) (by decide +kernel)
def s4_18047 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6225,w6522,w6588,w6873]
theorem b4_18047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18047 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s4_18047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6101,v165_6225,v165_6522,v165_6588,v165_6873] (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6225 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 (PetersenWireProjection.cons pc165_6873 rfl))))))))))) (by decide +kernel)
def s5_456 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6522,w6588]
theorem b5_456 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_456 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_456 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_204,v165_3766,v165_4344,v165_4716,v165_5135,v165_5393,v165_5585,v165_6225,v165_6522,v165_6588] (PetersenWireProjection.cons pc165_204 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6225 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_2773 : List (BitVec 512) := [w1374,w2468,w3766,w4344,w4716,w5135,w6179,w6300,w6522,w6785]
theorem b5_2773 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2773 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_2773 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1374,v165_2468,v165_3766,v165_4344,v165_4716,v165_5135,v165_6179,v165_6300,v165_6522,v165_6785] (PetersenWireProjection.cons pc165_1374 (PetersenWireProjection.cons pc165_2468 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_6179 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6785 rfl)))))))))) (by decide +kernel)
def s5_2851 : List (BitVec 512) := [w1374,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6720]
theorem b5_2851 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2851 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_2851 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1374,v165_3766,v165_4344,v165_5135,v165_5393,v165_5585,v165_6225,v165_6300,v165_6522,v165_6720] (PetersenWireProjection.cons pc165_1374 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6225 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6522 (PetersenWireProjection.cons pc165_6720 rfl)))))))))) (by decide +kernel)
def s5_2865 : List (BitVec 512) := [w1384,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2865 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2865 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_2865 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_2488,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_2961 : List (BitVec 512) := [w1384,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_2961 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2961 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_2961 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1384,v165_3766,v165_4344,v165_5135,v165_5393,v165_5585,v165_6061,v165_6101,v165_6300,v165_6720] (PetersenWireProjection.cons pc165_1384 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5393 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6720 rfl)))))))))) (by decide +kernel)
def s5_2994 : List (BitVec 512) := [w1388,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2994 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2994 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_2994 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1388,v165_2491,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1388 (PetersenWireProjection.cons pc165_2491 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_3318 : List (BitVec 512) := [w1423,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3318 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_3318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1423,v165_2468,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1423 (PetersenWireProjection.cons pc165_2468 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_3319 : List (BitVec 512) := [w1423,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3319 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_3319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_1423,v165_2488,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_1423 (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_4057 : List (BitVec 512) := [w2468,w3766,w4344,w4416,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4057 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4057 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4057 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2468,v165_3766,v165_4344,v165_4416,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_2468 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4416 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_4058 : List (BitVec 512) := [w2468,w3766,w4344,w4417,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4058 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4058 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4058 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2468,v165_3766,v165_4344,v165_4417,v165_4716,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_2468 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4417 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_4372 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4754,w5135,w5585,w5956,w6300,w6588]
theorem b5_4372 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4372 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4372 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2488,v165_3766,v165_4344,v165_4716,v165_4754,v165_5135,v165_5585,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_4754 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_4436 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5627,w5956,w6300,w6588]
theorem b5_4436 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4436 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4436 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2488,v165_3766,v165_4344,v165_4716,v165_5135,v165_5585,v165_5627,v165_5956,v165_6300,v165_6588] (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_4716 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_5627 (PetersenWireProjection.cons pc165_5956 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 rfl)))))))))) (by decide +kernel)
def s5_4587 : List (BitVec 512) := [w2488,w3766,w4344,w5135,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b5_4587 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4587 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4587 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2488,v165_3766,v165_4344,v165_5135,v165_5585,v165_6061,v165_6101,v165_6300,v165_6588,v165_6720] (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6061 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6588 (PetersenWireProjection.cons pc165_6720 rfl)))))))))) (by decide +kernel)
def s5_4588 : List (BitVec 512) := [w2488,w3766,w4344,w5135,w5585,w6101,w6300,w6543,w6588,w6720]
theorem b5_4588 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4588 := by
  intro m le c
  apply rejects_sound r165 i7 6 tgt (small165 adj) hot165 [] s5_4588 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v165_2488,v165_3766,v165_4344,v165_5135,v165_5585,v165_6101,v165_6300,v165_6543,v165_6588,v165_6720] (PetersenWireProjection.cons pc165_2488 (PetersenWireProjection.cons pc165_3766 (PetersenWireProjection.cons pc165_4344 (PetersenWireProjection.cons pc165_5135 (PetersenWireProjection.cons pc165_5585 (PetersenWireProjection.cons pc165_6101 (PetersenWireProjection.cons pc165_6300 (PetersenWireProjection.cons pc165_6543 (PetersenWireProjection.cons pc165_6588 (PetersenWireProjection.cons pc165_6720 rfl)))))))))) (by decide +kernel)
end NineCert
