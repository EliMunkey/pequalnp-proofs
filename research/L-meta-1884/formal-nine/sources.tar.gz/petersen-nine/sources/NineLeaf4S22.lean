import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5466 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6857]
theorem b4_5466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5466 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_5466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_5467 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6869]
theorem b4_5467 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5467 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s4_5467 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6869] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6869 rfl))))))))))) (by decide +kernel)
def s4_5468 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6890]
theorem b4_5468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5468 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(3,true))] s4_5468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_5469 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_5469 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5469 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_5469 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6895] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_5470 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6906]
theorem b4_5470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5470 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,false),(4,true))] s4_5470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6906] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6906 rfl))))))))))) (by decide +kernel)
def s4_5471 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6908]
theorem b4_5471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5471 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(4,true))] s4_5471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_5472 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_5472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5472 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_5472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5473 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6748]
theorem b4_5473 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5473 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s4_5473 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720,v4_6748] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s4_5474 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6857]
theorem b4_5474 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5474 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_5474 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720,v4_6857] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_5475 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6895]
theorem b4_5475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5475 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_5475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720,v4_6895] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_5476 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6389,w6522,w6588]
theorem b4_5476 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5476 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(3,true))] s4_5476 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5477 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6522,w6588,w6873]
theorem b4_5477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5477 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(5,true))] s4_5477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5478 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w6225,w6300,w6522,w6588]
theorem b4_5478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5478 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s4_5478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5479 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6225,w6300,w6588]
theorem b4_5479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5479 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(7,true),(8,true))] s4_5479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5480 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6389,w6549,w6588]
theorem b4_5480 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5480 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(3,true))] s4_5480 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6389,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5481 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6464,w6588,w6873]
theorem b4_5481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5481 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s4_5481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5482 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6136,w6225,w6300,w6588]
theorem b4_5482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5482 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(3,true))] s4_5482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6136,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5483 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b4_5483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5483 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5484 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6720]
theorem b4_5484 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5484 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5484 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5485 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6201,w6225,w6300,w6588]
theorem b4_5485 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5485 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(0,false))] s4_5485 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6201,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6201 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5486 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6237,w6300,w6588]
theorem b4_5486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5486 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(0,false))] s4_5486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6237,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6237 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5487 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6389,w6588]
theorem b4_5487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5487 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(8,true))] s4_5487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5488 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_5488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5488 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5489 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6690]
theorem b4_5489 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5489 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(8,true),(7,true))] s4_5489 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5490 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6720]
theorem b4_5490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5490 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5491 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6813]
theorem b4_5491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5491 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(7,true),(8,true))] s4_5491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_5492 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6866]
theorem b4_5492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5492 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s4_5492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588,v4_6866] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6866 rfl))))))))))) (by decide +kernel)
def s4_5493 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588,w6869]
theorem b4_5493 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5493 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,false))] s4_5493 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588,v4_6869] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6869 rfl))))))))))) (by decide +kernel)
def s4_5494 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b4_5494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5494 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5495 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6201,w6300,w6588]
theorem b4_5495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5495 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true))] s4_5495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6201,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6201 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5496 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6225,w6300,w6588]
theorem b4_5496 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5496 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(3,true))] s4_5496 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5497 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6464,w6588]
theorem b4_5497 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5497 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(8,true),(3,true))] s4_5497 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5498 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6543,w6588]
theorem b4_5498 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5498 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true))] s4_5498 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5499 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6549,w6588]
theorem b4_5499 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5499 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(3,true))] s4_5499 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5500 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_5500 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5500 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s4_5500 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5501 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b4_5501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5501 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s4_5501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5502 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6785]
theorem b4_5502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5502 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(8,true),(3,true))] s4_5502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl))))))))))) (by decide +kernel)
def s4_5503 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6852]
theorem b4_5503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5503 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(5,true))] s4_5503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588,v4_6852] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
def s4_5504 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6857]
theorem b4_5504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5504 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(8,true),(3,true))] s4_5504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_5505 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588,w6873]
theorem b4_5505 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5505 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(5,true))] s4_5505 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5506 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b4_5506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5506 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s4_5506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5507 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6136,w6300,w6522,w6588]
theorem b4_5507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5507 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(4,true),(8,true))] s4_5507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6136,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6136 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5508 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6225,w6300,w6522,w6588]
theorem b4_5508 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5508 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(8,true))] s4_5508 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5509 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6389,w6543,w6588]
theorem b4_5509 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5509 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false))] s4_5509 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6389,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5510 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6543,w6588]
theorem b4_5510 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5510 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(0,false))] s4_5510 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5511 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6567,w6588]
theorem b4_5511 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5511 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(0,false))] s4_5511 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6567,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6567 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5512 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_5512 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5512 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s4_5512 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5513 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6690]
theorem b4_5513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5513 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(5,true))] s4_5513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5514 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6720]
theorem b4_5514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5514 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s4_5514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5515 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6785]
theorem b4_5515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5515 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(8,true),(4,true))] s4_5515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588,v4_6785] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 rfl))))))))))) (by decide +kernel)
def s4_5516 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6857]
theorem b4_5516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5516 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(8,true),(4,true))] s4_5516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588,v4_6857] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6857 rfl))))))))))) (by decide +kernel)
def s4_5517 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588,w6908]
theorem b4_5517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5517 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(0,false))] s4_5517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_5518 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6720]
theorem b4_5518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5518 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s4_5518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5519 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_5519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5519 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false))] s4_5519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5520 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_5520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5520 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(4,true),(8,true))] s4_5520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5521 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_5521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5521 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(4,true))] s4_5521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s4_5522 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6179,w6225,w6300,w6522,w6588]
theorem b4_5522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5522 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(8,true))] s4_5522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6179,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5523 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6179,w6225,w6300,w6588,w6832]
theorem b4_5523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5523 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(8,true),(5,true))] s4_5523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6179,v4_6225,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_5524 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_5524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5524 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s4_5524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5525 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_5525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5525 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s4_5525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl)))))))))) (by decide +kernel)
def s4_5526 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_5526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5526 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_5526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5527 : List (BitVec 512) := [w1076,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_5527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5527 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(3,true),(4,true))] s4_5527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5528 : List (BitVec 512) := [w1076,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6389,w6522,w6588]
theorem b4_5528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5528 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(4,true)),(false,(4,true),(5,true))] s4_5528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5687 : List (BitVec 512) := [w1119,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5687 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5687 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true)),(false,(7,true),(8,true))] s4_5687 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
