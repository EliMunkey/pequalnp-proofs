import NinePin160
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_982 : List (BitVec 512) := [w160,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_982 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_160,v160_2171,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_160 (PetersenWireProjection.cons pc160_2171 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_1557 : List (BitVec 512) := [w200,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1557 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_1557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_200,v160_2171,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_200 (PetersenWireProjection.cons pc160_2171 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_4904 : List (BitVec 512) := [w1000,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6873]
theorem b4_4904 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4904 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_4904 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1000,v160_3766,v160_4344,v160_4571,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6873] (PetersenWireProjection.cons pc160_1000 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4571 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6873 rfl))))))))))) (by decide +kernel)
def s4_7081 : List (BitVec 512) := [w1237,w3766,w4344,w4716,w5135,w5393,w5585,w5634,w5956,w6300,w6588]
theorem b4_7081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7081 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_7081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1237,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5634,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_1237 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5634 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_7085 : List (BitVec 512) := [w1239,w3766,w4344,w4716,w5135,w5393,w5585,w5635,w5956,w6300,w6588]
theorem b4_7085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7085 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_7085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1239,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5635,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_1239 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5635 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_7087 : List (BitVec 512) := [w1240,w1646,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7087 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_7087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1240,v160_1646,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_1240 (PetersenWireProjection.cons pc160_1646 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_7088 : List (BitVec 512) := [w1240,w3766,w4344,w4716,w5135,w5393,w5585,w5636,w5956,w6300,w6588]
theorem b4_7088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7088 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_7088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1240,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5636,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_1240 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5636 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_11769 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6017,w6300,w6389,w6588]
theorem b4_11769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11769 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_11769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2381,v160_3766,v160_4344,v160_4716,v160_5135,v160_5585,v160_5956,v160_6017,v160_6300,v160_6389,v160_6588] (PetersenWireProjection.cons pc160_2381 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6017 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6389 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_11785 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5585,w5956,w6026,w6300,w6588,w6873]
theorem b4_11785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11785 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_11785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2387,v160_3766,v160_4344,v160_4716,v160_5135,v160_5585,v160_5956,v160_6026,v160_6300,v160_6588,v160_6873] (PetersenWireProjection.cons pc160_2387 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6026 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6873 rfl))))))))))) (by decide +kernel)
def s4_16742 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16742 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4563,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6422,v160_6588] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4563 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6422 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_16743 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_16743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16743 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4563,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6522,v160_6588] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4563 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_16744 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_16744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16744 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4563,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6549,v160_6588] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4563 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6549 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_16777 : List (BitVec 512) := [w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_16777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16777 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4571,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588,v160_6895] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4571 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6895 rfl))))))))))) (by decide +kernel)
def s4_16784 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_16784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16784 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4572,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6422,v160_6588] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4572 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6422 (PetersenWireProjection.cons pc160_6588 rfl))))))))))) (by decide +kernel)
def s4_16787 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_16787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16787 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4572,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588,v160_6873] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4572 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6873 rfl))))))))))) (by decide +kernel)
def s4_16788 : List (BitVec 512) := [w3766,w4344,w4572,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_16788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16788 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s4_16788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4572,v160_4716,v160_5135,v160_5393,v160_5585,v160_5956,v160_6300,v160_6588,v160_6895] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4572 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6895 rfl))))))))))) (by decide +kernel)
def s5_455 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588]
theorem b5_455 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_455 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_455 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_204,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_6179,v160_6522,v160_6588] (PetersenWireProjection.cons pc160_204 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_3077 : List (BitVec 512) := [w1403,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6873]
theorem b5_3077 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3077 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1403,v160_1664,v160_3766,v160_4716,v160_5135,v160_5393,v160_5585,v160_5698,v160_5956,v160_6873] (PetersenWireProjection.cons pc160_1403 (PetersenWireProjection.cons pc160_1664 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5698 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6873 rfl)))))))))) (by decide +kernel)
def s5_3149 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5638,w5956,w6873]
theorem b5_3149 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3149 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3149 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1403,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_5638,v160_5956,v160_6873] (PetersenWireProjection.cons pc160_1403 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5638 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6873 rfl)))))))))) (by decide +kernel)
def s5_3184 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6873]
theorem b5_3184 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3184 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3184 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1403,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_6179,v160_6522,v160_6873] (PetersenWireProjection.cons pc160_1403 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6873 rfl)))))))))) (by decide +kernel)
def s5_3185 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6890]
theorem b5_3185 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3185 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3185 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_1403,v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_5585,v160_6179,v160_6522,v160_6890] (PetersenWireProjection.cons pc160_1403 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6890 rfl)))))))))) (by decide +kernel)
def s5_3667 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6634]
theorem b5_3667 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3667 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3667 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2381,v160_3766,v160_4344,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588,v160_6634] (PetersenWireProjection.cons pc160_2381 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6634 rfl)))))))))) (by decide +kernel)
def s5_3673 : List (BitVec 512) := [w2381,w3766,w4716,w5135,w5698,w5956,w6017,w6300,w6389,w6588]
theorem b5_3673 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3673 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3673 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2381,v160_3766,v160_4716,v160_5135,v160_5698,v160_5956,v160_6017,v160_6300,v160_6389,v160_6588] (PetersenWireProjection.cons pc160_2381 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5698 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6017 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6389 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_3700 : List (BitVec 512) := [w2387,w3766,w4344,w4571,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3700 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3700 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3700 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2387,v160_3766,v160_4344,v160_4571,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_2387 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4571 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_3703 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w4796,w5135,w5585,w5956,w6300,w6588]
theorem b5_3703 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3703 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3703 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2387,v160_3766,v160_4344,v160_4716,v160_4796,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_2387 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_4796 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_3729 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5956,w6026,w6300,w6785,w6873]
theorem b5_3729 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3729 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_3729 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2387,v160_3766,v160_4344,v160_4716,v160_5135,v160_5956,v160_6026,v160_6300,v160_6785,v160_6873] (PetersenWireProjection.cons pc160_2387 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6026 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6785 (PetersenWireProjection.cons pc160_6873 rfl)))))))))) (by decide +kernel)
def s5_4077 : List (BitVec 512) := [w2468,w3766,w4344,w4563,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4077 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4077 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2468,v160_3766,v160_4344,v160_4563,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_2468 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4563 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_4081 : List (BitVec 512) := [w2468,w3766,w4344,w4573,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4081 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4081 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4081 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2468,v160_3766,v160_4344,v160_4573,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_2468 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4573 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_4378 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w4792,w5135,w5585,w5956,w6300,w6588]
theorem b5_4378 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4378 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4378 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2488,v160_3766,v160_4344,v160_4716,v160_4792,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588] (PetersenWireProjection.cons pc160_2488 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_4792 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_4511 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6634]
theorem b5_4511 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4511 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4511 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2488,v160_3766,v160_4344,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588,v160_6634] (PetersenWireProjection.cons pc160_2488 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6634 rfl)))))))))) (by decide +kernel)
def s5_4512 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6638]
theorem b5_4512 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4512 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4512 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2488,v160_3766,v160_4344,v160_4716,v160_5135,v160_5585,v160_5956,v160_6300,v160_6588,v160_6638] (PetersenWireProjection.cons pc160_2488 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6300 (PetersenWireProjection.cons pc160_6588 (PetersenWireProjection.cons pc160_6638 rfl)))))))))) (by decide +kernel)
def s5_4585 : List (BitVec 512) := [w2488,w3766,w4344,w5135,w5585,w5769,w5956,w6389,w6422,w6588]
theorem b5_4585 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4585 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_4585 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_2488,v160_3766,v160_4344,v160_5135,v160_5585,v160_5769,v160_5956,v160_6389,v160_6422,v160_6588] (PetersenWireProjection.cons pc160_2488 (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5585 (PetersenWireProjection.cons pc160_5769 (PetersenWireProjection.cons pc160_5956 (PetersenWireProjection.cons pc160_6389 (PetersenWireProjection.cons pc160_6422 (PetersenWireProjection.cons pc160_6588 rfl)))))))))) (by decide +kernel)
def s5_6167 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6543,w6785,w6873]
theorem b5_6167 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6167 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_6167 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_6179,v160_6522,v160_6543,v160_6785,v160_6873] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6543 (PetersenWireProjection.cons pc160_6785 (PetersenWireProjection.cons pc160_6873 rfl)))))))))) (by decide +kernel)
def s5_6174 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873,w6917]
theorem b5_6174 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6174 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_6174 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_6179,v160_6522,v160_6785,v160_6873,v160_6917] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6522 (PetersenWireProjection.cons pc160_6785 (PetersenWireProjection.cons pc160_6873 (PetersenWireProjection.cons pc160_6917 rfl)))))))))) (by decide +kernel)
def s5_6176 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6567,w6785,w6873,w6908]
theorem b5_6176 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6176 := by
  intro m le c
  apply rejects_sound r160 i7 6 tgt (small160 adj) hot160 [] s5_6176 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v160_3766,v160_4344,v160_4716,v160_5135,v160_5393,v160_6179,v160_6567,v160_6785,v160_6873,v160_6908] (PetersenWireProjection.cons pc160_3766 (PetersenWireProjection.cons pc160_4344 (PetersenWireProjection.cons pc160_4716 (PetersenWireProjection.cons pc160_5135 (PetersenWireProjection.cons pc160_5393 (PetersenWireProjection.cons pc160_6179 (PetersenWireProjection.cons pc160_6567 (PetersenWireProjection.cons pc160_6785 (PetersenWireProjection.cons pc160_6873 (PetersenWireProjection.cons pc160_6908 rfl)))))))))) (by decide +kernel)
end NineCert
