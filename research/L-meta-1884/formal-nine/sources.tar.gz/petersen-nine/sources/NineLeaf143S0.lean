import NinePin143
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1662 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_1662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1662 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_1662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_200,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6588,v143_6873] (PetersenWireProjection.cons pc143_200 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_5535 : List (BitVec 512) := [w1082,w3766,w4344,w4716,w4764,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5535 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_5535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_1082,v143_3766,v143_4344,v143_4716,v143_4764,v143_5135,v143_5393,v143_5585,v143_5956,v143_6300,v143_6588] (PetersenWireProjection.cons pc143_1082 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_4764 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6300 (PetersenWireProjection.cons pc143_6588 rfl))))))))))) (by decide +kernel)
def s4_5542 : List (BitVec 512) := [w1085,w3766,w4344,w4716,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5542 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5542 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_5542 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_1085,v143_3766,v143_4344,v143_4716,v143_4766,v143_5135,v143_5393,v143_5585,v143_5956,v143_6300,v143_6588] (PetersenWireProjection.cons pc143_1085 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_4766 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6300 (PetersenWireProjection.cons pc143_6588 rfl))))))))))) (by decide +kernel)
def s4_17945 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6720,w6890]
theorem b4_17945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17945 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6389,v143_6522,v143_6720,v143_6890] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6389 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6890 rfl))))))))))) (by decide +kernel)
def s4_17966 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6478,w6720,w6873]
theorem b4_17966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17966 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6464,v143_6478,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6478 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_17972 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6567,w6720,w6873]
theorem b4_17972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17972 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6464,v143_6567,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6567 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_17983 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6890]
theorem b4_17983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17983 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6464,v143_6720,v143_6873,v143_6890] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6890 rfl))))))))))) (by decide +kernel)
def s4_17988 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6906]
theorem b4_17988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17988 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6464,v143_6720,v143_6873,v143_6906] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6906 rfl))))))))))) (by decide +kernel)
def s4_17989 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873,w6908]
theorem b4_17989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17989 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_17989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6464,v143_6720,v143_6873,v143_6908] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6908 rfl))))))))))) (by decide +kernel)
def s4_18000 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6543,w6720,w6873]
theorem b4_18000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18000 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6522,v143_6543,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6543 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_18004 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6567,w6720,w6873]
theorem b4_18004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18004 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6522,v143_6567,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6567 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_18006 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6890]
theorem b4_18006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18006 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6522,v143_6720,v143_6873,v143_6890] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6890 rfl))))))))))) (by decide +kernel)
def s4_18009 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6904]
theorem b4_18009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18009 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6522,v143_6720,v143_6873,v143_6904] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6904 rfl))))))))))) (by decide +kernel)
def s4_18010 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873,w6912]
theorem b4_18010 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18010 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18010 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6522,v143_6720,v143_6873,v143_6912] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6912 rfl))))))))))) (by decide +kernel)
def s4_18051 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6478,w6522,w6588]
theorem b4_18051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18051 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6101,v143_6389,v143_6478,v143_6522,v143_6588] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6389 (PetersenWireProjection.cons pc143_6478 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 rfl))))))))))) (by decide +kernel)
def s4_18064 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6543,w6588,w6873]
theorem b4_18064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18064 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6543,v143_6588,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6543 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6873 rfl))))))))))) (by decide +kernel)
def s4_18069 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873,w6912]
theorem b4_18069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18069 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s4_18069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6588,v143_6873,v143_6912] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6912 rfl))))))))))) (by decide +kernel)
def s5_420 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_420 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_420 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_420 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_197,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5769,v143_5956,v143_6464,v143_6588] (PetersenWireProjection.cons pc143_197 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5769 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_423 : List (BitVec 512) := [w200,w1766,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_423 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_423 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_423 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_200,v143_1766,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6522,v143_6588] (PetersenWireProjection.cons pc143_200 (PetersenWireProjection.cons pc143_1766 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_441 : List (BitVec 512) := [w200,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_441 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_441 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_441 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_200,v143_3766,v143_4344,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_200 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_454 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_454 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_454 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_454 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_204,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6588] (PetersenWireProjection.cons pc143_204 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_457 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588]
theorem b5_457 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_457 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_457 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_204,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5769,v143_5956,v143_6464,v143_6588] (PetersenWireProjection.cons pc143_204 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5769 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_3293 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6873]
theorem b5_3293 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3293 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_3293 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_1415,v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5769,v143_5956,v143_6464,v143_6873] (PetersenWireProjection.cons pc143_1415 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5769 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6464 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_4090 : List (BitVec 512) := [w2468,w3766,w4344,w4593,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4090 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4090 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_4090 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_4593,v143_4716,v143_5135,v143_5585,v143_5956,v143_6300,v143_6588] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4593 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6300 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_4094 : List (BitVec 512) := [w2468,w3766,w4344,w4601,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4094 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4094 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_4094 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_4601,v143_4716,v143_5135,v143_5585,v143_5956,v143_6300,v143_6588] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4601 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6300 (PetersenWireProjection.cons pc143_6588 rfl)))))))))) (by decide +kernel)
def s5_4233 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6720,w6890]
theorem b5_4233 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4233 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_4233 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_4716,v143_5135,v143_5585,v143_5956,v143_6522,v143_6720,v143_6890] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6890 rfl)))))))))) (by decide +kernel)
def s5_4238 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6567,w6720,w6873]
theorem b5_4238 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4238 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_4238 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_4716,v143_5135,v143_5585,v143_5956,v143_6567,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6567 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_4244 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6522,w6588,w6890]
theorem b5_4244 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4244 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_4244 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_4716,v143_5135,v143_5585,v143_6101,v143_6522,v143_6588,v143_6890] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6890 rfl)))))))))) (by decide +kernel)
def s5_6049 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6372,w6720,w6873]
theorem b5_6049 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6049 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_6049 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_5956,v143_6372,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_5956 (PetersenWireProjection.cons pc143_6372 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_6105 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6100,w6522,w6588,w6873]
theorem b5_6105 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6105 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_6105 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6100,v143_6522,v143_6588,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6100 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_6106 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6100,w6522,w6588,w6890]
theorem b5_6106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6106 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_6106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_4716,v143_5135,v143_5393,v143_5585,v143_6100,v143_6522,v143_6588,v143_6890] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_4716 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6100 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6588 (PetersenWireProjection.cons pc143_6890 rfl)))))))))) (by decide +kernel)
def s5_6255 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6543,w6720,w6873]
theorem b5_6255 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6255 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_6255 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6543,v143_6720,v143_6873] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6543 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 rfl)))))))))) (by decide +kernel)
def s5_6259 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873,w6912]
theorem b5_6259 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6259 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s5_6259 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_5135,v143_5393,v143_5585,v143_6101,v143_6522,v143_6720,v143_6873,v143_6912] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6873 (PetersenWireProjection.cons pc143_6912 rfl)))))))))) (by decide +kernel)
def s6_71 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5585,w6101,w6522,w6720,w6890]
theorem b6_71 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_71 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s6_71 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_2468,v143_3766,v143_4344,v143_5135,v143_5585,v143_6101,v143_6522,v143_6720,v143_6890] (PetersenWireProjection.cons pc143_2468 (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6101 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6890 rfl))))))))) (by decide +kernel)
def s6_93 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6100,w6522,w6720,w6890]
theorem b6_93 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_93 := by
  intro m le c
  apply rejects_sound r143 i7 6 tgt (small143 adj) hot143 [] s6_93 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v143_3766,v143_4344,v143_5135,v143_5393,v143_5585,v143_6100,v143_6522,v143_6720,v143_6890] (PetersenWireProjection.cons pc143_3766 (PetersenWireProjection.cons pc143_4344 (PetersenWireProjection.cons pc143_5135 (PetersenWireProjection.cons pc143_5393 (PetersenWireProjection.cons pc143_5585 (PetersenWireProjection.cons pc143_6100 (PetersenWireProjection.cons pc143_6522 (PetersenWireProjection.cons pc143_6720 (PetersenWireProjection.cons pc143_6890 rfl))))))))) (by decide +kernel)
end NineCert
