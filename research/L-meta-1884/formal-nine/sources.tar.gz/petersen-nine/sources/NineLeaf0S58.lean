import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_12036 : List (BitVec 512) := [w2468,w3411,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12036 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12036 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12036 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12037 : List (BitVec 512) := [w2468,w3411,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12037 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12037 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12037 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12038 : List (BitVec 512) := [w2468,w3522,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12038 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12038 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12038 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3522,v0_3766,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3522 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12039 : List (BitVec 512) := [w2468,w3522,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12039 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3522,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3522 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12040 : List (BitVec 512) := [w2468,w3545,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12040 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3545,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12041 : List (BitVec 512) := [w2468,w3545,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12041 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3545,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12042 : List (BitVec 512) := [w2468,w3545,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12042 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3545,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12043 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12043 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12043 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12043 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12044 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12044 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12045 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12045 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12046 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12046 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12047 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12047 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12048 : List (BitVec 512) := [w2468,w3567,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12048 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12049 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12049 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12050 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12050 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12050 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12050 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12051 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12051 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12052 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12052 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12053 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12053 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12054 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12054 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12055 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12055 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12056 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12056 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12057 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12057 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12058 : List (BitVec 512) := [w2468,w3575,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12058 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3575,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3575 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12059 : List (BitVec 512) := [w2468,w3582,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12059 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12060 : List (BitVec 512) := [w2468,w3582,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12060 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12061 : List (BitVec 512) := [w2468,w3582,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12061 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12062 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b4_12062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12062 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12063 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12063 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12064 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12064 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12065 : List (BitVec 512) := [w2468,w3582,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12065 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3582,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s4_12066 : List (BitVec 512) := [w2468,w3595,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12066 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12067 : List (BitVec 512) := [w2468,w3595,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12067 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12068 : List (BitVec 512) := [w2468,w3595,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12068 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12069 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12069 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_12069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12070 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_12070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12070 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_12070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12071 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12071 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12072 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5652,w5956,w6300,w6588]
theorem b4_12072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12072 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s4_12072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5652,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5652 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12073 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12073 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12074 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12074 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12075 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12075 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12076 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12076 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12077 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_12077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12077 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(1,false))] s4_12077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6567,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6567 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12078 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6640]
theorem b4_12078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12078 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_12078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6640] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6640 rfl))))))))))) (by decide +kernel)
def s4_12079 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_12079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12079 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(9,true))] s4_12079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_12080 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12080 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true))] s4_12080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12081 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6785]
theorem b4_12081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12081 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true))] s4_12081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_12082 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_12082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12082 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(1,false))] s4_12082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s4_12083 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12083 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12084 : List (BitVec 512) := [w2468,w3620,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12084 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12085 : List (BitVec 512) := [w2468,w3628,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6522,w6588]
theorem b4_12085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12085 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s4_12085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3628,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6101,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3628 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12086 : List (BitVec 512) := [w2468,w3643,w3766,w4344,w4716,w5135,w5585,w6179,w6300,w6522,w6588]
theorem b4_12086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12086 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s4_12086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12087 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_12087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12087 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_12087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12088 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_12088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12088 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_12088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12089 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12089 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_12089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12090 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12090 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_12091 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_12091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12091 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_12091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12092 : List (BitVec 512) := [w2468,w3669,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_12092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12092 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_12092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3669,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3669 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_12093 : List (BitVec 512) := [w2468,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12093 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_12093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12094 : List (BitVec 512) := [w2468,w3682,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12094 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s4_12094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3682,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3682 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12095 : List (BitVec 512) := [w2468,w3683,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_12095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12095 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_12095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12096 : List (BitVec 512) := [w2468,w3683,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12096 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3683,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3683 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12097 : List (BitVec 512) := [w2468,w3731,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_12097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12097 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3731,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3731 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_12098 : List (BitVec 512) := [w2468,w3731,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12098 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s4_12098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3731,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3731 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_12099 : List (BitVec 512) := [w2468,w3731,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_12099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12099 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_12099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3731,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3731 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
end NineCert
