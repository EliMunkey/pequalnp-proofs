import NinePin288
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_6178 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5454,w5585,w5698,w5956,w6300,w6588]
theorem b5_6178 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6178 := by
  intro m le c
  apply rejects_sound r288 i5 4 tgt (small288 adj) hot288 [] s5_6178 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v288_3766,v288_4344,v288_4716,v288_5135,v288_5454,v288_5585,v288_5698,v288_5956,v288_6300,v288_6588] (PetersenWireProjection.cons pc288_3766 (PetersenWireProjection.cons pc288_4344 (PetersenWireProjection.cons pc288_4716 (PetersenWireProjection.cons pc288_5135 (PetersenWireProjection.cons pc288_5454 (PetersenWireProjection.cons pc288_5585 (PetersenWireProjection.cons pc288_5698 (PetersenWireProjection.cons pc288_5956 (PetersenWireProjection.cons pc288_6300 (PetersenWireProjection.cons pc288_6588 rfl)))))))))) (by decide +kernel)
end NineCert
