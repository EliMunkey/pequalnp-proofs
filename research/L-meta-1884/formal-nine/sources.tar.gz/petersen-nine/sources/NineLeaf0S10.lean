import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2391 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6048,w6300,w6588]
theorem b3_2391 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2391 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true))] s3_2391 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2397 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b3_2397 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true))] s3_2397 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2412 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6377,w6588]
theorem b3_2412 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2412 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true))] s3_2412 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_1353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2421 : List (BitVec 512) := [w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b3_2421 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2421 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true))] s3_2421 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s3_2448 : List (BitVec 512) := [w1374,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2448 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2448 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2448 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2449 : List (BitVec 512) := [w1374,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2449 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2449 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2449 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2467 : List (BitVec 512) := [w1374,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2467 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2467 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2467 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2468 : List (BitVec 512) := [w1374,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2468 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2468 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2468 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2481 : List (BitVec 512) := [w1374,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2481 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2481 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2482 : List (BitVec 512) := [w1374,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2482 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2482 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2482 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2483 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2483 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2483 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2483 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2484 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2484 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2484 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2484 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2485 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2485 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2485 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2485 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2486 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2486 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2486 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2486 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2487 : List (BitVec 512) := [w1374,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2487 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2487 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2487 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2488 : List (BitVec 512) := [w1374,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2488 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2488 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2488 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2489 : List (BitVec 512) := [w1374,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2489 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2489 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2489 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2490 : List (BitVec 512) := [w1374,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2490 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2490 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2490 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2491 : List (BitVec 512) := [w1374,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2491 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2491 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2491 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2492 : List (BitVec 512) := [w1374,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2492 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2492 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2492 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2493 : List (BitVec 512) := [w1374,w3643,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2493 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2493 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2493 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2494 : List (BitVec 512) := [w1374,w3643,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2494 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2494 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2494 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2495 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2495 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2495 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2495 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2496 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2496 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2496 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2496 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2497 : List (BitVec 512) := [w1374,w3689,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2497 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2497 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2497 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2498 : List (BitVec 512) := [w1374,w3689,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2498 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2498 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2498 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2499 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2499 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2499 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2499 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2500 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2500 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2500 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2500 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2501 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2501 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2501 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2501 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2502 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2502 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2502 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2502 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2521 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2521 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2521 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2521 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2522 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2522 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2522 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2522 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2535 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2535 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2535 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2535 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2536 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2536 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2536 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2536 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2551 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2551 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2551 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2551 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2552 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b3_2552 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2552 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2552 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2557 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6179,w6300,w6588]
theorem b3_2557 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2557 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2557 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2558 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6300,w6588]
theorem b3_2558 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2558 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2558 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2568 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6179,w6300,w6588]
theorem b3_2568 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2568 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2569 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6300,w6588]
theorem b3_2569 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2569 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2569 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2582 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6195,w6300,w6588]
theorem b3_2582 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2582 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2582 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2587 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_2587 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2587 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2587 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2588 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6667]
theorem b3_2588 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2588 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2588 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl)))))))))))) (by decide +kernel)
def s3_2597 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6195,w6300,w6588]
theorem b3_2597 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2597 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2597 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6195,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6195 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2603 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b3_2603 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2603 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2603 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s3_2614 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w6048,w6179,w6300,w6588]
theorem b3_2614 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2614 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_2614 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2632 : List (BitVec 512) := [w1403,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2632 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2632 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2632 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2633 : List (BitVec 512) := [w1403,w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2633 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2633 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2633 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2651 : List (BitVec 512) := [w1403,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2651 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2651 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2651 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2652 : List (BitVec 512) := [w1403,w2552,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2652 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2652 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2652 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_2552,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_2552 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2663 : List (BitVec 512) := [w1403,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2663 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2663 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2663 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2664 : List (BitVec 512) := [w1403,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2664 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2664 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2664 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2665 : List (BitVec 512) := [w1403,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2665 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2665 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2665 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2666 : List (BitVec 512) := [w1403,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2666 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2666 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2666 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2667 : List (BitVec 512) := [w1403,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2667 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2667 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2667 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2668 : List (BitVec 512) := [w1403,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2668 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2668 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2669 : List (BitVec 512) := [w1403,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2669 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2669 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2669 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2670 : List (BitVec 512) := [w1403,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2670 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2670 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2670 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2671 : List (BitVec 512) := [w1403,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2671 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2671 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2671 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2672 : List (BitVec 512) := [w1403,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2672 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2672 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2672 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2673 : List (BitVec 512) := [w1403,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2673 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2673 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2673 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2674 : List (BitVec 512) := [w1403,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2674 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2674 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2674 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_2675 : List (BitVec 512) := [w1403,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_2675 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2675 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2675 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_2676 : List (BitVec 512) := [w1403,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2676 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2676 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_2676 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
