import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11055 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_11055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11055 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6014,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6014 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11056 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_11056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11056 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6017,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6017 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11057 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_11057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11057 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6019,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6019 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11058 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_11058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11058 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6023,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6023 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11059 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_11059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11059 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true))] s4_11059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6024,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6024 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11060 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_11060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11060 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_11060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6026,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6026 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11061 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6032,w6300,w6588]
theorem b4_11061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11061 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true))] s4_11061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6032,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6032 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11062 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6033,w6300,w6588]
theorem b4_11062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11062 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s4_11062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6033,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6033 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11063 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6034,w6300,w6588]
theorem b4_11063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11063 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s4_11063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6034,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6034 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11064 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6035,w6300,w6588]
theorem b4_11064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11064 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true))] s4_11064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6035,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6035 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11065 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6036,w6300,w6588]
theorem b4_11065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11065 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s4_11065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6036,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6036 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11066 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6037,w6300,w6588]
theorem b4_11066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11066 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true))] s4_11066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6037,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6037 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11067 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6038,w6300,w6588]
theorem b4_11067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11067 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(4,true))] s4_11067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6038,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6038 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11068 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6039,w6300,w6588]
theorem b4_11068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11068 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_11068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6039,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6039 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11069 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6040,w6300,w6588]
theorem b4_11069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11069 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_11069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6040,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6040 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11070 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6041,w6300,w6588]
theorem b4_11070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11070 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(4,true))] s4_11070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6041,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6041 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11071 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6042,w6300,w6588]
theorem b4_11071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11071 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_11071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6042,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6042 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11072 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_11072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11072 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_11072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6044,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6044 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11073 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_11073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11073 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6087,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6087 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11074 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6097,w6300,w6588]
theorem b4_11074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11074 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(3,true)),(false,(1,true),(0,true))] s4_11074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6097,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6097 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11075 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_11075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11075 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(7,true)),(false,(1,true),(0,true))] s4_11075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6099,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6099 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11076 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_11076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11076 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(6,true)),(false,(1,true),(0,true))] s4_11076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6166,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6166 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11077 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_11077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11077 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_11077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6173,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6173 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11078 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6588]
theorem b4_11078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11078 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(1,true),(0,true))] s4_11078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6177,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6177 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11079 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11079 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11080 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6321,w6588]
theorem b4_11080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11080 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6321,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6321 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11081 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6330,w6588]
theorem b4_11081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11081 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6330,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6330 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11082 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6331,w6588]
theorem b4_11082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11082 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6331,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6331 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11083 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6333,w6588]
theorem b4_11083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11083 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6333,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6333 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11084 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6334,w6588]
theorem b4_11084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11084 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s4_11084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6334,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6334 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11085 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_11085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11085 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s4_11085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6336,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6336 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11086 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6340,w6588]
theorem b4_11086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11086 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6340,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6340 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11087 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6341,w6588]
theorem b4_11087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11087 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true))] s4_11087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6341,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6341 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11088 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6342,w6588]
theorem b4_11088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11088 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6342,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6342 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11089 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6344,w6588]
theorem b4_11089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11089 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6344,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6344 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11090 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6345,w6588]
theorem b4_11090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11090 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true))] s4_11090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6345,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6345 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11091 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6346,w6588]
theorem b4_11091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11091 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(5,true))] s4_11091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6346,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6346 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11092 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6351,w6588]
theorem b4_11092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11092 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6351,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6351 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11093 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6352,w6588]
theorem b4_11093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11093 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6352,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6352 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11094 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6353,w6588]
theorem b4_11094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11094 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6353,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6353 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11095 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6355,w6588]
theorem b4_11095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11095 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(5,true))] s4_11095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6355,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6355 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11096 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6356,w6588]
theorem b4_11096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11096 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(0,true),(5,true))] s4_11096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6356,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6356 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11097 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6357,w6588]
theorem b4_11097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11097 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_11097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6357,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6357 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11098 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6363,w6588]
theorem b4_11098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11098 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true))] s4_11098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6363,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6363 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11099 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6364,w6588]
theorem b4_11099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11099 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_11099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6364,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6364 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11100 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6365,w6588]
theorem b4_11100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11100 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_11100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6365,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6365 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11101 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6366,w6588]
theorem b4_11101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11101 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(5,true))] s4_11101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6366,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6366 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11102 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6367,w6588]
theorem b4_11102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11102 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_11102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6367,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6367 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11103 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6368,w6588]
theorem b4_11103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11103 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_11103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6368,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6368 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11104 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6370,w6588]
theorem b4_11104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11104 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_11104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6370,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6370 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11105 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6371,w6588]
theorem b4_11105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11105 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_11105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6371,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6371 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11106 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6372,w6588]
theorem b4_11106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11106 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_11106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6372,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6372 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11107 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6373,w6588]
theorem b4_11107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11107 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(0,true)),(false,(0,true),(5,true))] s4_11107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6373,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6373 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11108 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6374,w6588]
theorem b4_11108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11108 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_11108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6374,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6374 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11109 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6375,w6588]
theorem b4_11109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11109 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(5,true))] s4_11109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6375,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6375 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11110 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11110 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(4,true)),(false,(1,false),(0,false))] s4_11110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11111 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11111 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(7,true)),(false,(1,false),(0,false))] s4_11111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11112 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_11112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11112 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(6,true)),(false,(1,false),(0,false))] s4_11112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11113 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11113 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(1,false),(0,false))] s4_11113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11114 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6599]
theorem b4_11114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11114 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true))] s4_11114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6599] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6599 rfl))))))))))) (by decide +kernel)
def s4_11115 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6600]
theorem b4_11115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11115 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_11115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6600] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6600 rfl))))))))))) (by decide +kernel)
def s4_11116 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6601]
theorem b4_11116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11116 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true))] s4_11116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6601] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6601 rfl))))))))))) (by decide +kernel)
def s4_11117 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6603]
theorem b4_11117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11117 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true))] s4_11117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6603] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6603 rfl))))))))))) (by decide +kernel)
def s4_11118 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6604]
theorem b4_11118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11118 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(9,true))] s4_11118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6604] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6604 rfl))))))))))) (by decide +kernel)
end NineCert
