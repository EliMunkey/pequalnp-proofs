import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_1012 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6478,w6588]
theorem b3_1012 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1012 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_1012 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1013 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6489,w6588]
theorem b3_1013 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1013 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(2,true))] s3_1013 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1014 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6567,w6588]
theorem b3_1014 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1014 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_1014 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1015 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_1015 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1015 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_1015 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1016 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6690]
theorem b3_1016 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1016 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_1016 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_1017 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6720]
theorem b3_1017 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1017 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(8,true),(2,true))] s3_1017 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_1018 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6832]
theorem b3_1018 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1018 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(7,true),(5,true))] s3_1018 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_1019 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6904]
theorem b3_1019 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1019 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_1019 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_1020 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6690]
theorem b3_1020 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1020 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_1020 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_1021 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b3_1021 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1021 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_1021 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1022 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_1022 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1022 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s3_1022 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1023 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_1023 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1023 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_1023 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1024 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6549,w6588]
theorem b3_1024 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1024 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,false))] s3_1024 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1025 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6567,w6588]
theorem b3_1025 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1025 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,false))] s3_1025 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_1026 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_1026 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1026 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_1026 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1027 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6690]
theorem b3_1027 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1027 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_1027 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl)))))))))))) (by decide +kernel)
def s3_1028 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6720]
theorem b3_1028 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1028 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(7,true))] s3_1028 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))))) (by decide +kernel)
def s3_1029 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6785]
theorem b3_1029 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1029 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(6,true),(7,true))] s3_1029 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_1030 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6908]
theorem b3_1030 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1030 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(8,true),(0,false))] s3_1030 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl)))))))))))) (by decide +kernel)
def s3_1031 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6690]
theorem b3_1031 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1031 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_1031 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s3_1032 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_1032 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1032 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_1032 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1033 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b3_1033 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1033 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s3_1033 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1034 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b3_1034 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1034 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_1034 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1035 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1035 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1035 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_1035 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_1036 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690,w6748]
theorem b3_1036 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1036 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_1036 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6748 rfl)))))))))))) (by decide +kernel)
def s3_1037 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690,w6807]
theorem b3_1037 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1037 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_1037 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6807 rfl)))))))))))) (by decide +kernel)
def s3_1038 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690,w6852]
theorem b3_1038 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1038 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_1038 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6852 rfl)))))))))))) (by decide +kernel)
def s3_1039 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690,w6890]
theorem b3_1039 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1039 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_1039 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl)))))))))))) (by decide +kernel)
def s3_1040 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720,w6748]
theorem b3_1040 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1040 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_1040 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6748 rfl)))))))))))) (by decide +kernel)
def s3_1041 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720,w6813]
theorem b3_1041 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1041 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(0,false))] s3_1041 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720,v3_6813] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6813 rfl)))))))))))) (by decide +kernel)
def s3_1042 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720,w6857]
theorem b3_1042 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1042 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,false))] s3_1042 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720,v3_6857] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6857 rfl)))))))))))) (by decide +kernel)
def s3_1043 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720,w6895]
theorem b3_1043 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1043 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(0,false))] s3_1043 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_1044 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_1044 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1044 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_1044 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s3_1045 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6807]
theorem b3_1045 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1045 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_1045 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6807 rfl)))))))))))) (by decide +kernel)
def s3_1046 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6813]
theorem b3_1046 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1046 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true))] s3_1046 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6813] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6813 rfl)))))))))))) (by decide +kernel)
def s3_1047 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6866]
theorem b3_1047 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1047 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(6,true))] s3_1047 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6866] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6866 rfl)))))))))))) (by decide +kernel)
def s3_1048 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6904]
theorem b3_1048 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1048 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s3_1048 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_1049 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b3_1049 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1049 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_1049 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s3_1050 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b3_1050 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1050 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(2,true))] s3_1050 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6813] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6813 rfl))))))))))) (by decide +kernel)
def s3_1051 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832,w6852]
theorem b3_1051 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1051 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true))] s3_1051 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 (PetersenWireProjection.cons pc3_6852 rfl)))))))))))) (by decide +kernel)
def s3_1052 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832,w6857]
theorem b3_1052 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1052 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s3_1052 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832,v3_6857] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 (PetersenWireProjection.cons pc3_6857 rfl)))))))))))) (by decide +kernel)
def s3_1053 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832,w6866]
theorem b3_1053 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1053 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(5,true))] s3_1053 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832,v3_6866] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 (PetersenWireProjection.cons pc3_6866 rfl)))))))))))) (by decide +kernel)
def s3_1054 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832,w6908]
theorem b3_1054 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1054 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s3_1054 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 (PetersenWireProjection.cons pc3_6908 rfl)))))))))))) (by decide +kernel)
def s3_1055 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b3_1055 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1055 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_1055 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s3_1056 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b3_1056 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1056 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(2,true))] s3_1056 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl))))))))))) (by decide +kernel)
def s3_1057 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b3_1057 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1057 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(5,true))] s3_1057 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s3_1058 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6890]
theorem b3_1058 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1058 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true))] s3_1058 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6890 rfl)))))))))))) (by decide +kernel)
def s3_1059 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6895]
theorem b3_1059 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1059 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s3_1059 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6895 rfl)))))))))))) (by decide +kernel)
def s3_1060 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6904]
theorem b3_1060 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1060 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(5,true))] s3_1060 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_1061 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6908]
theorem b3_1061 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1061 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,false))] s3_1061 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 (PetersenWireProjection.cons pc3_6908 rfl)))))))))))) (by decide +kernel)
def s3_1062 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b3_1062 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1062 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_1062 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s3_1063 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b3_1063 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1063 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,true))] s3_1063 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6895] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6895 rfl))))))))))) (by decide +kernel)
def s3_1064 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b3_1064 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1064 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s3_1064 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl))))))))))) (by decide +kernel)
def s3_1065 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b3_1065 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1065 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s3_1065 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6908] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6908 rfl))))))))))) (by decide +kernel)
def s3_1066 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6748]
theorem b3_1066 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1066 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_1066 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6748] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s3_1067 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6807]
theorem b3_1067 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1067 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_1067 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6807] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s3_1068 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6852]
theorem b3_1068 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1068 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_1068 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6852] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6852 rfl))))))))))) (by decide +kernel)
def s3_1069 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b3_1069 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1069 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_1069 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6890] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6890 rfl))))))))))) (by decide +kernel)
def s3_1070 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b3_1070 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1070 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_1070 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1071 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_1071 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1071 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_1071 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1072 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b3_1072 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1072 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(7,true),(8,true))] s3_1072 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_1073 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b3_1073 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1073 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(7,true),(8,true))] s3_1073 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_1074 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b3_1074 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1074 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true))] s3_1074 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_1075 : List (BitVec 512) := [w967,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b3_1075 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1075 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(6,true),(2,true))] s3_1075 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
