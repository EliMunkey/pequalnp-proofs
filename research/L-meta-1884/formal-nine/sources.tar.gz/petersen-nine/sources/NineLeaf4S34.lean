import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1752 : List (BitVec 512) := [w1076,w2686,w3766,w4344,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b5_1752 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1752 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(1,true),(0,true)),(false,(8,true),(5,true))] s5_1752 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2686,v4_3766,v4_4344,v4_5393,v4_5769,v4_5956,v4_6300,v4_6464,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2686 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1753 : List (BitVec 512) := [w1076,w2693,w3766,w4344,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b5_1753 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1753 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,false)),(false,(2,true),(0,true))] s5_1753 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2693,v4_3766,v4_4344,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2693 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1754 : List (BitVec 512) := [w1076,w2786,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1754 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1754 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_1754 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2786,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2786 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1755 : List (BitVec 512) := [w1076,w2788,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1755 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1755 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_1755 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2788,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2788 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1756 : List (BitVec 512) := [w1076,w2789,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1756 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1756 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(4,true))] s5_1756 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2789,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2789 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1757 : List (BitVec 512) := [w1076,w2793,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1757 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1757 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true))] s5_1757 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2793,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2793 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1758 : List (BitVec 512) := [w1076,w2794,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1758 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1758 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true))] s5_1758 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2794,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2794 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1759 : List (BitVec 512) := [w1076,w2852,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1759 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1759 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s5_1759 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2852,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2852 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1760 : List (BitVec 512) := [w1076,w2857,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1760 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1760 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true))] s5_1760 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2857,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2857 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1761 : List (BitVec 512) := [w1076,w2857,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1761 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1761 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true))] s5_1761 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2857,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2857 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1762 : List (BitVec 512) := [w1076,w2863,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1762 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1762 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(7,true),(4,true)),(false,(1,false),(0,false))] s5_1762 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2863,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2863 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1763 : List (BitVec 512) := [w1076,w2867,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1763 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1763 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,true)),(false,(0,true),(6,true))] s5_1763 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2867,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1764 : List (BitVec 512) := [w1076,w2872,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1764 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_1764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2872,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2872 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1765 : List (BitVec 512) := [w1076,w2873,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1765 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(6,true))] s5_1765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2873,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2873 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1766 : List (BitVec 512) := [w1076,w2884,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1766 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(7,true),(5,true)),(false,(1,false),(0,false))] s5_1766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2884,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2884 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1767 : List (BitVec 512) := [w1076,w2888,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1767 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1767 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(3,true),(5,true)),(false,(1,false),(0,false))] s5_1767 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_2888,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_2888 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1768 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1768 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1768 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1768 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1769 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1769 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1769 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1769 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1770 : List (BitVec 512) := [w1076,w3766,w4344,w4721,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1770 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1770 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(6,true))] s5_1770 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4721,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4721 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1771 : List (BitVec 512) := [w1076,w3766,w4344,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1771 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1771 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s5_1771 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1772 : List (BitVec 512) := [w1076,w3766,w4344,w4746,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1772 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1772 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(5,true))] s5_1772 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1773 : List (BitVec 512) := [w1076,w3766,w4344,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1773 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1773 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s5_1773 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1774 : List (BitVec 512) := [w1076,w3766,w4344,w4747,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1774 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1774 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,true),(5,true))] s5_1774 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1775 : List (BitVec 512) := [w1076,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1775 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1775 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1775 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1776 : List (BitVec 512) := [w1076,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1776 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1776 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_1776 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1777 : List (BitVec 512) := [w1076,w3766,w4344,w4749,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1777 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1777 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s5_1777 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4749,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4749 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1778 : List (BitVec 512) := [w1076,w3766,w4344,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1778 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1778 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s5_1778 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4750,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4750 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1779 : List (BitVec 512) := [w1076,w3766,w4344,w4750,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1779 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1779 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s5_1779 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4750,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4750 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1780 : List (BitVec 512) := [w1076,w3766,w4344,w4752,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1780 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1780 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s5_1780 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4752,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4752 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1781 : List (BitVec 512) := [w1076,w3766,w4344,w4761,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1781 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1781 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(4,true))] s5_1781 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4761,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4761 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1782 : List (BitVec 512) := [w1076,w3766,w4344,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1782 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1782 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s5_1782 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4766,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1783 : List (BitVec 512) := [w1076,w3766,w4344,w4766,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_1783 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1783 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s5_1783 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4766,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1784 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5642,w5956,w6300,w6588]
theorem b5_1784 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1784 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(8,true))] s5_1784 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5642,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5642 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1785 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5643,w5956,w6300,w6588]
theorem b5_1785 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1785 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(8,true))] s5_1785 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5643,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5643 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1786 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b5_1786 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1786 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s5_1786 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5656,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5656 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1787 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5656,w5956,w6300,w6720]
theorem b5_1787 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1787 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s5_1787 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5656,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5656 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1788 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5658,w5956,w6300,w6588]
theorem b5_1788 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1788 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s5_1788 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5658,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5658 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1789 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5661,w5956,w6300,w6588]
theorem b5_1789 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1789 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(5,true)),(false,(0,false),(8,true))] s5_1789 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5661,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5661 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1790 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5663,w5956,w6300,w6588]
theorem b5_1790 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1790 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s5_1790 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5663,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5663 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1791 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5664,w5956,w6300,w6588]
theorem b5_1791 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1791 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true)),(false,(0,false),(8,true))] s5_1791 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5664,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5664 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1792 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b5_1792 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1792 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,false),(0,true))] s5_1792 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5750,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1793 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5750,w5956,w6300,w6720]
theorem b5_1793 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1793 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,false),(0,true))] s5_1793 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5750,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1794 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5750,w5956,w6522,w6588]
theorem b5_1794 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1794 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_1794 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5750,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1795 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5767,w5956,w6522,w6588]
theorem b5_1795 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1795 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false)),(false,(5,true),(9,true))] s5_1795 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5767,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5767 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1796 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_1796 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1796 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s5_1796 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1797 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5775,w5956,w6300,w6588]
theorem b5_1797 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1797 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_1797 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5775,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5775 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1798 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5777,w5956,w6300,w6588]
theorem b5_1798 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1798 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_1798 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5777,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5777 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1799 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5778,w5956,w6300,w6588]
theorem b5_1799 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1799 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(5,true),(0,true)),(false,(0,true),(8,true))] s5_1799 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5778,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5778 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1800 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6190,w6300,w6588]
theorem b5_1800 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1800 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(8,true)),(false,(1,false),(0,false))] s5_1800 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6190,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6190 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1801 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6191,w6300,w6588]
theorem b5_1801 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1801 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(7,true),(8,true)),(false,(1,false),(0,false))] s5_1801 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6191,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6191 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1802 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6209,w6300,w6588]
theorem b5_1802 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1802 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,false),(0,true)),(false,(0,true),(8,true))] s5_1802 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6209,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6209 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1803 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6219,w6300,w6588]
theorem b5_1803 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1803 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(5,true)),(false,(1,true),(0,true))] s5_1803 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6219,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6219 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1804 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6220,w6300,w6588]
theorem b5_1804 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1804 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(8,false),(0,true)),(false,(0,true),(8,true))] s5_1804 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6220,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6220 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1805 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_1805 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1805 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s5_1805 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s5_1806 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5995,w6101,w6300,w6588]
theorem b5_1806 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1806 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(0,true),(9,true))] s5_1806 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5995,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5995 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1807 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6017,w6101,w6300,w6588]
theorem b5_1807 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1807 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s5_1807 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6017,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6017 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1808 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6032,w6101,w6300,w6588]
theorem b5_1808 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1808 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1808 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6032,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6032 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1809 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6033,w6101,w6300,w6588]
theorem b5_1809 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1809 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1809 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6033,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6033 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1810 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6034,w6101,w6300,w6588]
theorem b5_1810 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1810 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1810 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6034,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6034 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1811 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6035,w6101,w6300,w6588]
theorem b5_1811 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1811 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1811 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6035,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6035 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1812 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6036,w6101,w6300,w6588]
theorem b5_1812 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1812 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1812 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6036,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6036 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1813 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6037,w6101,w6300,w6588]
theorem b5_1813 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1813 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(8,true)),(false,(0,true),(9,true))] s5_1813 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6037,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6037 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1814 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6037,w6179,w6300,w6588]
theorem b5_1814 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1814 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(8,true),(7,true)),(false,(1,false),(9,true))] s5_1814 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6037,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6037 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s5_1815 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6097,w6300,w6522,w6588]
theorem b5_1815 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1815 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(8,false),(0,true)),(false,(9,true),(5,true))] s5_1815 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6097,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6097 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
end NineCert
