import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_1261 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6813]
theorem b3_1261 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1261 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_1261 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6785,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6813 rfl)))))))))))) (by decide +kernel)
def s3_1262 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6866]
theorem b3_1262 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1262 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_1262 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6785,v4_6866] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6866 rfl)))))))))))) (by decide +kernel)
def s3_1263 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6904]
theorem b3_1263 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1263 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(4,true))] s3_1263 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6785,v4_6904] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6785 (PetersenWireProjection.cons pc4_6904 rfl)))))))))))) (by decide +kernel)
def s3_1264 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b3_1264 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1264 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(3,true))] s3_1264 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6807] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6807 rfl))))))))))) (by decide +kernel)
def s3_1265 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b3_1265 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1265 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true))] s3_1265 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s3_1266 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b3_1266 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1266 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(3,true))] s3_1266 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6852] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
def s3_1267 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b3_1267 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1267 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_1267 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6866] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6866 rfl))))))))))) (by decide +kernel)
def s3_1268 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b3_1268 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1268 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(4,true))] s3_1268 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6890] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s3_1269 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6748]
theorem b3_1269 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1269 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s3_1269 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6748] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s3_1270 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b3_1270 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1270 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true))] s3_1270 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s3_1271 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b3_1271 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1271 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s3_1271 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1272 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_1272 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1272 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(3,true))] s3_1272 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1273 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b3_1273 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1273 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(4,true),(5,true))] s3_1273 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s3_1274 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b3_1274 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1274 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(4,true),(5,true))] s3_1274 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s3_1275 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b3_1275 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1275 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s3_1275 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1276 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b3_1276 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1276 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true))] s3_1276 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1277 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b3_1277 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1277 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true)),(false,(8,true),(7,true))] s3_1277 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1278 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b3_1278 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1278 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(8,true),(7,true))] s3_1278 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s3_1279 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_1279 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1279 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_1279 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1280 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_1280 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1280 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s3_1280 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1281 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b3_1281 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1281 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s3_1281 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1282 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_1282 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1282 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1282 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1283 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_1283 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1283 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true))] s3_1283 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1284 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_1284 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1284 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s3_1284 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1285 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1285 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1285 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s3_1285 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1286 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_1286 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1286 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true))] s3_1286 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s3_1287 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b3_1287 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1287 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s3_1287 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s3_1288 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6813]
theorem b3_1288 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1288 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true))] s3_1288 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s3_1289 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6832]
theorem b3_1289 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1289 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true))] s3_1289 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s3_1290 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_1290 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1290 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s3_1290 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s3_1291 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b3_1291 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1291 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s3_1291 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s3_1292 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_1292 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1292 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1292 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1293 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_1293 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1293 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s3_1293 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1294 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b3_1294 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1294 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true))] s3_1294 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6061,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1295 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b3_1295 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1295 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true))] s3_1295 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s3_1305 : List (BitVec 512) := [w1119,w1590,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1305 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1305 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1305 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_1590,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_1590 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1333 : List (BitVec 512) := [w1119,w2840,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1333 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1333 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1333 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_2840,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_2840 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1366 : List (BitVec 512) := [w1119,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1366 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1366 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1366 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1367 : List (BitVec 512) := [w1119,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1367 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1367 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1367 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1368 : List (BitVec 512) := [w1119,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1368 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1368 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1368 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1369 : List (BitVec 512) := [w1119,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1369 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1369 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1369 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1411 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1411 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1411 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1411 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1421 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_1421 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1421 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1421 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1431 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b3_1431 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1431 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1431 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1441 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b3_1441 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1441 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1441 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s3_1451 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b3_1451 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1451 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,false),(4,true))] s3_1451 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1119,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1119 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s3_1610 : List (BitVec 512) := [w1231,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1610 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1610 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_1610 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_1611 : List (BitVec 512) := [w1231,w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1611 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1611 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_1611 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_1312,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1726 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_1726 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1726 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_1726 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1231,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1231 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1919 : List (BitVec 512) := [w1292,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1919 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1919 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s3_1919 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1920 : List (BitVec 512) := [w1292,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1920 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1920 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s3_1920 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1921 : List (BitVec 512) := [w1292,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1921 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1921 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s3_1921 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1922 : List (BitVec 512) := [w1292,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1922 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1922 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s3_1922 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_1923 : List (BitVec 512) := [w1292,w3766,w4344,w4687,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_1923 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_1923 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s3_1923 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1292,v4_3766,v4_4344,v4_4687,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1292 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4687 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2124 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2124 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2124 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2124 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2125 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2125 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2125 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2125 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2126 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b3_2126 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2126 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2126 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2127 : List (BitVec 512) := [w1312,w3766,w4344,w4646,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2127 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2127 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2127 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2128 : List (BitVec 512) := [w1312,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2128 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2128 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2128 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2129 : List (BitVec 512) := [w1312,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2129 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2129 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2129 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2130 : List (BitVec 512) := [w1312,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2130 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2130 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2130 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2131 : List (BitVec 512) := [w1312,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2131 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2131 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2131 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s3_2132 : List (BitVec 512) := [w1312,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_2132 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2132 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2132 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))))) (by decide +kernel)
def s3_2133 : List (BitVec 512) := [w1312,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_2133 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2133 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,false))] s3_2133 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1312,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1312 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
