import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9822 : List (BitVec 512) := [w1403,w2525,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_9822 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9822 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(0,true))] s4_9822 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2525,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2525 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_9823 : List (BitVec 512) := [w1403,w2525,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873]
theorem b4_9823 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9823 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_9823 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2525,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6873] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2525 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_9824 : List (BitVec 512) := [w1403,w2525,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9824 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9824 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9824 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2525,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2525 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_10018 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6890]
theorem b4_10018 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10018 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_10018 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_10019 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6522,w6588]
theorem b4_10019 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10019 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10019 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10020 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6522,w6588]
theorem b4_10020 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10020 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10020 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10068 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6890]
theorem b4_10068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10068 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_10068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_10069 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6522,w6588]
theorem b4_10069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10069 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10070 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5885,w5956,w6300,w6588]
theorem b4_10070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10070 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_10070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5885,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5885 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10071 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6588]
theorem b4_10071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10071 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true))] s4_10071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10084 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6522,w6588]
theorem b4_10084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10084 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10112 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6506,w6588]
theorem b4_10112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10112 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(1,false))] s4_10112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6506,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6506 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10131 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6902]
theorem b4_10131 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10131 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(0,true))] s4_10131 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6902] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6902 rfl))))))))))) (by decide +kernel)
def s4_10137 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6890]
theorem b4_10137 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10137 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(0,true))] s4_10137 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_10164 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6452,w6522,w6588]
theorem b4_10164 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10164 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10164 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6452,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6452 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10176 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6559,w6588]
theorem b4_10176 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10176 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10176 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10183 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6767]
theorem b4_10183 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10183 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10183 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
def s4_10204 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6389,w6522,w6588]
theorem b4_10204 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10204 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10204 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10205 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6522,w6588]
theorem b4_10205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10205 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_10214 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_10214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10214 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_10214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10223 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_10223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10223 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(0,true),(6,true))] s4_10223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10245 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5479,w5585,w5956,w6389,w6522,w6588]
theorem b4_10245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10245 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s4_10245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10249 : List (BitVec 512) := [w1411,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10249 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10250 : List (BitVec 512) := [w1411,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10250 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10252 : List (BitVec 512) := [w1411,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10252 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10253 : List (BitVec 512) := [w1411,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10253 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10254 : List (BitVec 512) := [w1411,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10254 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10255 : List (BitVec 512) := [w1411,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10255 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10255 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10255 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10295 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_10295 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10295 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10295 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10305 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_10305 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10305 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_10305 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1411,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1411 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10340 : List (BitVec 512) := [w1415,w2223,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10340 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10341 : List (BitVec 512) := [w1415,w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10341 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_10341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10342 : List (BitVec 512) := [w1415,w2295,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10342 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2295,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2295 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10344 : List (BitVec 512) := [w1415,w2320,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10344 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10345 : List (BitVec 512) := [w1415,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6464,w6588]
theorem b4_10345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10345 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10346 : List (BitVec 512) := [w1415,w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10346 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10346 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_10346 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10347 : List (BitVec 512) := [w1415,w2354,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10347 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2354,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10348 : List (BitVec 512) := [w1415,w2441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10348 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10348 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10348 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10349 : List (BitVec 512) := [w1415,w2449,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10349 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10349 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_10349 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2449,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2449 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10350 : List (BitVec 512) := [w1415,w2453,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10350 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2453,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2453 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10351 : List (BitVec 512) := [w1415,w2455,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10351 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10351 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10351 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2455,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2455 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10352 : List (BitVec 512) := [w1415,w2499,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10352 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2499,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2499 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10409 : List (BitVec 512) := [w1415,w3766,w4041,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10409 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4041,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4041 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10422 : List (BitVec 512) := [w1415,w3766,w4344,w4641,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10422 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4641,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4641 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10449 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5251,w5393,w5585,w5956,w6300,w6588]
theorem b4_10449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10449 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5251,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5251 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10450 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5258,w5393,w5585,w5956,w6300,w6588]
theorem b4_10450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10450 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_10450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5258,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5258 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10451 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5283,w5393,w5585,w5956,w6300,w6588]
theorem b4_10451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10451 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5283,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5283 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10452 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5299,w5393,w5585,w5956,w6300,w6588]
theorem b4_10452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10452 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5299,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5299 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10453 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5301,w5393,w5585,w5956,w6300,w6588]
theorem b4_10453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10453 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_10453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5301,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5301 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10454 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5306,w5393,w5585,w5956,w6300,w6588]
theorem b4_10454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10454 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5306,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5306 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10455 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5307,w5393,w5585,w5956,w6300,w6588]
theorem b4_10455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10455 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5307,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5307 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10456 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5324,w5393,w5585,w5956,w6300,w6588]
theorem b4_10456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10456 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5324,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5324 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10457 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5327,w5393,w5585,w5956,w6300,w6588]
theorem b4_10457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10457 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5327,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5327 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10458 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5442,w5585,w5956,w6300,w6588]
theorem b4_10458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10458 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5442,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5442 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10460 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5479,w5585,w5956,w6300,w6588]
theorem b4_10460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10460 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10461 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5518,w5585,w5956,w6300,w6588]
theorem b4_10461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10461 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5518,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10486 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5884,w5956,w6300,w6588]
theorem b4_10486 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10486 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10486 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5884,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10487 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5887,w5956,w6300,w6588]
theorem b4_10487 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10487 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(0,true),(9,true))] s4_10487 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5887,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5887 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10499 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6158,w6300,w6588]
theorem b4_10499 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10499 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10499 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6158,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10518 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6451,w6588]
theorem b4_10518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10518 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6451,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10519 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6452,w6588]
theorem b4_10519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10519 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s4_10519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6452,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6452 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10543 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6505,w6588]
theorem b4_10543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10543 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6505,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6505 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10544 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6506,w6588]
theorem b4_10544 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10544 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10544 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6506,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6506 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_10554 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6767]
theorem b4_10554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10554 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s4_10554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6767] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6767 rfl))))))))))) (by decide +kernel)
end NineCert
