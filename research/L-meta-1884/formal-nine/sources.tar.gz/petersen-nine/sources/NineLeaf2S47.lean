import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_625 : List (BitVec 512) := [w426,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_625 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_625 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(6,true)),(false,(1,false),(0,true)),(false,(7,true),(2,true))] s5_625 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_426,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_426 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_626 : List (BitVec 512) := [w427,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_626 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_626 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(0,false),(9,true))] s5_626 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_632 : List (BitVec 512) := [w428,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_632 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_632 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(7,true),(1,true))] s5_632 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_428,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_428 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_634 : List (BitVec 512) := [w429,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_634 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_634 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,true),(8,true)),(false,(0,false),(10,true))] s5_634 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_429,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_429 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_635 : List (BitVec 512) := [w431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_635 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_636 : List (BitVec 512) := [w432,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_636 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_636 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_636 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_432,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_432 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_637 : List (BitVec 512) := [w433,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_637 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_433,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_433 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_638 : List (BitVec 512) := [w434,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_638 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_638 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(3,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_638 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_434,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_434 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_639 : List (BitVec 512) := [w435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_639 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_639 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_639 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_640 : List (BitVec 512) := [w436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_640 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_640 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_640 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_641 : List (BitVec 512) := [w437,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_641 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_641 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_641 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_437,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_437 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_642 : List (BitVec 512) := [w438,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_642 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_642 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(10,true))] s5_642 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_438,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_438 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_643 : List (BitVec 512) := [w439,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_643 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_643 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_643 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_439,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_439 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_644 : List (BitVec 512) := [w440,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_644 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_440,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_440 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_645 : List (BitVec 512) := [w441,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_645 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_441,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_441 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_646 : List (BitVec 512) := [w442,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_646 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_646 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_646 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_442,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_442 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_647 : List (BitVec 512) := [w443,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_647 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_647 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_647 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_443,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_443 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_648 : List (BitVec 512) := [w444,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_648 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_648 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_648 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_444,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_444 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_649 : List (BitVec 512) := [w445,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_649 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(10,true))] s5_649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_445,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_445 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_651 : List (BitVec 512) := [w447,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b5_651 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_651 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(5,true)),(false,(9,true),(5,true))] s5_651 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_447,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_447 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_652 : List (BitVec 512) := [w448,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_652 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_652 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_652 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_448,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_448 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_653 : List (BitVec 512) := [w449,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_653 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_653 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_653 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_449,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_449 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_654 : List (BitVec 512) := [w450,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_654 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_654 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_654 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_450,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_450 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_655 : List (BitVec 512) := [w451,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_655 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_655 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,true),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_655 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_451,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_451 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_656 : List (BitVec 512) := [w452,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_656 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_656 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_656 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_452,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_452 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_657 : List (BitVec 512) := [w453,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_657 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_657 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_657 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_453,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_453 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_658 : List (BitVec 512) := [w454,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_658 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_658 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_658 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_454,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_454 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_659 : List (BitVec 512) := [w455,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_659 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_455,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_455 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_660 : List (BitVec 512) := [w456,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_660 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_660 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_660 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_456,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_456 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_661 : List (BitVec 512) := [w457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_661 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_661 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(10,true))] s5_661 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_663 : List (BitVec 512) := [w459,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_663 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_663 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,true)),(false,(4,true),(5,true)),(false,(8,true),(5,true))] s5_663 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_459,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_459 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_665 : List (BitVec 512) := [w461,w3197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_665 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_665 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_665 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_461,v2_3197,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_461 (PetersenWireProjection.cons pc2_3197 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_666 : List (BitVec 512) := [w461,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_666 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_666 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(3,true),(1,false)),(false,(3,true),(0,true))] s5_666 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_461,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_461 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_667 : List (BitVec 512) := [w462,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_667 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_667 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(2,true))] s5_667 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_462,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_462 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_668 : List (BitVec 512) := [w462,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_668 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_668 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(3,true),(1,true))] s5_668 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_462,v2_3280,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_462 (PetersenWireProjection.cons pc2_3280 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_669 : List (BitVec 512) := [w463,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_669 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_669 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_669 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_463,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_463 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_670 : List (BitVec 512) := [w464,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_670 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_670 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_670 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_464,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_464 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_671 : List (BitVec 512) := [w465,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_671 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_671 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_671 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_465,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_465 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_672 : List (BitVec 512) := [w466,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_672 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_672 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_672 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_466,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_466 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_673 : List (BitVec 512) := [w467,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_673 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_673 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_673 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_467,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_467 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_674 : List (BitVec 512) := [w468,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_674 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_674 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_674 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_675 : List (BitVec 512) := [w469,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_675 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_675 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_675 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_469,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_469 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_676 : List (BitVec 512) := [w470,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_676 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_676 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_676 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_470,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_470 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_677 : List (BitVec 512) := [w471,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_677 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_677 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_677 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_471,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_471 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_678 : List (BitVec 512) := [w472,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_678 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_678 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_678 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_472,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_472 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_679 : List (BitVec 512) := [w473,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_679 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_679 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true)),(false,(0,true),(10,true))] s5_679 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_473,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_473 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_680 : List (BitVec 512) := [w475,w2442,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_680 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_680 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(0,true),(5,true))] s5_680 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_2442,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_2442 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_681 : List (BitVec 512) := [w475,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_681 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_681 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(5,true),(1,false))] s5_681 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_682 : List (BitVec 512) := [w475,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6832]
theorem b5_682 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_682 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true)),(false,(7,true),(1,true))] s5_682 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_683 : List (BitVec 512) := [w475,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_683 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_683 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(3,true),(0,true))] s5_683 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_684 : List (BitVec 512) := [w475,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_684 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_684 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(4,true),(7,true)),(false,(10,true),(1,true))] s5_684 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_475,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_475 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_685 : List (BitVec 512) := [w477,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_685 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_685 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(5,true))] s5_685 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_2443,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_2443 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_686 : List (BitVec 512) := [w477,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_686 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_686 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(8,true)),(false,(5,true),(1,false))] s5_686 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_2494,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_2494 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_687 : List (BitVec 512) := [w477,w3199,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_687 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_687 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true)),(false,(3,true),(0,true))] s5_687 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_3199,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_3199 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_688 : List (BitVec 512) := [w477,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_688 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_688 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(1,false)),(false,(3,true),(0,true))] s5_688 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_689 : List (BitVec 512) := [w477,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6832]
theorem b5_689 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_689 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(5,true),(10,true))] s5_689 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_477,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_477 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_690 : List (BitVec 512) := [w478,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_690 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_690 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(2,true))] s5_690 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_478,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_478 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_691 : List (BitVec 512) := [w478,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_691 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_691 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true)),(false,(3,true),(1,true))] s5_691 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_478,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_478 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_692 : List (BitVec 512) := [w478,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_692 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_692 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_692 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_478,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_478 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_693 : List (BitVec 512) := [w479,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_693 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_693 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(5,true),(10,true))] s5_693 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_479,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6832] (PetersenWireProjection.cons pc2_479 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s5_694 : List (BitVec 512) := [w480,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_694 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_694 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false)),(false,(0,true),(10,true))] s5_694 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_480,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_480 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_695 : List (BitVec 512) := [w481,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_695 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_695 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_695 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_481,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_481 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_696 : List (BitVec 512) := [w482,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_696 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_696 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_696 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_482,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_482 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_697 : List (BitVec 512) := [w483,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_697 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_697 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(10,true))] s5_697 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_483,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_483 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
