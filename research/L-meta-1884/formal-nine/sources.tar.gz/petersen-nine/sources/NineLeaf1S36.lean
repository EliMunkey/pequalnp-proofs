import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_18075 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6555,w6588,w6873]
theorem b4_18075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18075 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(3,true)),(false,(8,true),(9,true))] s4_18075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6555,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s4_18076 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6720,w6857]
theorem b4_18076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18076 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(0,false)),(false,(5,true),(3,true))] s4_18076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6720,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_18077 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6748,w6832]
theorem b4_18077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18077 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(5,true),(8,true))] s4_18077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6748,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6748 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_18078 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6807,w6832]
theorem b4_18078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18078 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(5,true),(8,true))] s4_18078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6807,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6807 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_18079 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6832,w6857]
theorem b4_18079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18079 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(3,true)),(false,(5,true),(3,true))] s4_18079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6832,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6857 rfl))))))))))) (by decide +kernel)
def s4_18080 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6832,w6866]
theorem b4_18080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18080 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(3,true))] s4_18080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6832,v1_6866] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6866 rfl))))))))))) (by decide +kernel)
def s4_18081 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6832,w6890]
theorem b4_18081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18081 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(8,true))] s4_18081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6832,v1_6890] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_18082 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6832,w6908]
theorem b4_18082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18082 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(3,true))] s4_18082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6832,v1_6908] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_18083 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6147,w6300,w6690,w6857]
theorem b4_18083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18083 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(5,true),(1,false))] s4_18083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6147,v1_6300,v1_6690,v1_6857] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6857 rfl)))))))))) (by decide +kernel)
def s4_18095 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6241,w6300,w6690,w6832]
theorem b4_18095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18095 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(8,true),(5,true))] s4_18095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6241,v1_6300,v1_6690,v1_6832] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 rfl))))))))))) (by decide +kernel)
def s4_18102 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832,w6860]
theorem b4_18102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18102 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(8,true),(5,true))] s4_18102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6690,v1_6832,v1_6860] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 (PetersenWireProjection.cons pc1_6860 rfl))))))))))) (by decide +kernel)
def s5_13 : List (BitVec 512) := [w3,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_13 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_13 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_13 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_39 : List (BitVec 512) := [w11,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_39 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_39 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_39 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_11,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_11 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_40 : List (BitVec 512) := [w11,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_40 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_40 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_40 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_11,v1_2491,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_11 (PetersenWireProjection.cons pc1_2491 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_41 : List (BitVec 512) := [w11,w2529,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_41 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_41 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(2,true)),(false,(7,true),(4,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_41 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_11,v1_2529,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_11 (PetersenWireProjection.cons pc1_2529 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_42 : List (BitVec 512) := [w11,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_42 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_42 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_42 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_11,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_11 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_80 : List (BitVec 512) := [w25,w1422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_80 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_80 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(0,true),(5,true))] s5_80 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_1422,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_1422 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_81 : List (BitVec 512) := [w25,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_81 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_81 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(1,true),(0,true))] s5_81 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_82 : List (BitVec 512) := [w25,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_82 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_82 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s5_82 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_25,v1_3935,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_25 (PetersenWireProjection.cons pc1_3935 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_141 : List (BitVec 512) := [w38,w1422,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_141 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_141 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(0,true),(5,true))] s5_141 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_1422,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_1422 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl)))))))))) (by decide +kernel)
def s5_142 : List (BitVec 512) := [w38,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_142 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_142 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_142 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_2494,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_143 : List (BitVec 512) := [w38,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_143 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_143 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_143 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_144 : List (BitVec 512) := [w38,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_144 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_144 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_144 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_2530,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_2530 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_145 : List (BitVec 512) := [w38,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_145 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_145 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true))] s5_145 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3303,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3303 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_146 : List (BitVec 512) := [w38,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_146 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_146 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true))] s5_146 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3321,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3321 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_147 : List (BitVec 512) := [w38,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_147 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_147 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(0,false),(8,true)),(false,(3,true),(0,false)),(false,(3,true),(0,true))] s5_147 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_38,v1_3332,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_38 (PetersenWireProjection.cons pc1_3332 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_196 : List (BitVec 512) := [w94,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_196 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_196 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s5_196 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_94,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_94 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_210 : List (BitVec 512) := [w108,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_210 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_210 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_210 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_108,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_108 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_211 : List (BitVec 512) := [w109,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_211 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_109,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_109 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_212 : List (BitVec 512) := [w110,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_212 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_212 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_212 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_110,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_110 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_241 : List (BitVec 512) := [w128,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_241 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_128,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_128 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_242 : List (BitVec 512) := [w129,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_242 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_242 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_242 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_129,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_129 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_243 : List (BitVec 512) := [w130,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_243 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_243 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_243 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_130,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_130 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_308 : List (BitVec 512) := [w161,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_308 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_308 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_308 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_161,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_161 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_309 : List (BitVec 512) := [w162,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_309 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_162,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_162 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_310 : List (BitVec 512) := [w163,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_310 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_310 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_310 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_163,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_163 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_311 : List (BitVec 512) := [w166,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_311 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_166,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_166 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_312 : List (BitVec 512) := [w169,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_312 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_312 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_312 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_169,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_169 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_313 : List (BitVec 512) := [w170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_313 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_313 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_313 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_314 : List (BitVec 512) := [w171,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_314 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_314 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s5_314 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_315 : List (BitVec 512) := [w171,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_315 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_315 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s5_315 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3293,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_316 : List (BitVec 512) := [w171,w3332,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_316 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_316 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false)),(false,(3,true),(0,true))] s5_316 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3332,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3332 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_317 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_317 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_317 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(10,true),(6,true))] s5_317 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_6179,v1_6522,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_318 : List (BitVec 512) := [w171,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_318 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(7,true)),(false,(4,true),(8,true)),(false,(6,true),(10,true))] s5_318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_319 : List (BitVec 512) := [w171,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_319 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(4,true),(3,true)),(false,(7,true),(4,true)),(false,(6,true),(10,true))] s5_319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_5135,v1_5393,v1_5769,v1_5956,v1_6464,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_320 : List (BitVec 512) := [w171,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_320 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(0,true),(2,true))] s5_320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3901,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3901 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_462 : List (BitVec 512) := [w237,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_462 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_462 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_462 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_237,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_237 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_479 : List (BitVec 512) := [w269,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_479 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_479 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s5_479 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_269,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_269 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_485 : List (BitVec 512) := [w278,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_485 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_485 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_485 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_278,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_278 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_486 : List (BitVec 512) := [w279,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_486 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_486 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_486 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_279,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_279 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_487 : List (BitVec 512) := [w280,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_487 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_487 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_487 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_280,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_280 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_526 : List (BitVec 512) := [w304,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_526 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_526 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_526 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_304,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_304 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_527 : List (BitVec 512) := [w305,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_527 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_527 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_527 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_305,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_305 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_528 : List (BitVec 512) := [w306,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_528 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_528 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_528 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_306,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_306 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_566 : List (BitVec 512) := [w335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_566 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_566 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_566 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_335,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_335 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_567 : List (BitVec 512) := [w338,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_567 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_567 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s5_567 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_338,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_338 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_568 : List (BitVec 512) := [w339,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_568 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_568 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s5_568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_3280,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_3280 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_569 : List (BitVec 512) := [w339,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_569 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_569 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(7,true)),(false,(0,false),(2,true)),(false,(2,true),(0,true))] s5_569 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_3303,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_3303 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_570 : List (BitVec 512) := [w339,w3328,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_570 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_570 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(3,true)),(false,(3,true),(0,true))] s5_570 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_3328,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_3328 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_571 : List (BitVec 512) := [w339,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_571 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_571 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true)),(false,(4,true),(6,true))] s5_571 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_339,v1_3766,v1_4716,v1_5135,v1_5393,v1_5698,v1_6179,v1_6300,v1_6690,v1_6832] (PetersenWireProjection.cons pc1_339 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6832 rfl)))))))))) (by decide +kernel)
def s5_762 : List (BitVec 512) := [w511,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_762 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_762 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(0,false),(5,true))] s5_762 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_511,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_511 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_763 : List (BitVec 512) := [w512,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_763 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_763 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_763 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_512,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_512 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_764 : List (BitVec 512) := [w513,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_764 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_513,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_513 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_765 : List (BitVec 512) := [w514,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_765 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_765 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(0,true),(6,true))] s5_765 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_514,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_514 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
end NineCert
