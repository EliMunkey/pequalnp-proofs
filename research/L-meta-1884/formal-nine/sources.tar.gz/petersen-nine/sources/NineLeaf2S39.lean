import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11912 : List (BitVec 512) := [w2431,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11912 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11913 : List (BitVec 512) := [w2431,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_11913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11913 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(2,true),(0,true))] s4_11913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11914 : List (BitVec 512) := [w2431,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11914 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11914 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11914 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11915 : List (BitVec 512) := [w2431,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11915 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true))] s4_11915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3293,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11916 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11916 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(1,false),(8,true))] s4_11916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11917 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_11917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11917 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(8,true))] s4_11917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11918 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_11918 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11918 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(1,false),(8,true))] s4_11918 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11919 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11919 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s4_11919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11920 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_11920 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11920 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(0,false),(3,true))] s4_11920 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11921 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_11921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11921 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(1,false),(5,true))] s4_11921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11922 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_11922 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11922 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(7,true))] s4_11922 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11923 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_11923 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11923 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(1,false),(3,true))] s4_11923 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11924 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_11924 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11924 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_11924 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11925 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_11925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11925 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(7,true),(8,true)),(false,(1,false),(7,true))] s4_11925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11926 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_11926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11926 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(1,false),(9,true))] s4_11926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6807] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6807 rfl))))))))))) (by decide +kernel)
def s4_11927 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6852]
theorem b4_11927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11927 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(9,true))] s4_11927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_11928 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_11928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11928 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(1,false),(9,true))] s4_11928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_11929 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_11929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11929 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_11929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6868] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6868 rfl))))))))))) (by decide +kernel)
def s4_11930 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_11930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11930 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(7,true))] s4_11930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11931 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_11931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11931 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(4,true),(8,true))] s4_11931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11932 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_11932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11932 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(4,true),(5,true))] s4_11932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11933 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6832]
theorem b4_11933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11933 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(4,true),(9,true))] s4_11933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_11934 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_11934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11934 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(7,true),(8,true))] s4_11934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11935 : List (BitVec 512) := [w2431,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6785]
theorem b4_11935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11935 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(7,true),(9,true))] s4_11935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11936 : List (BitVec 512) := [w2431,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_11936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11936 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(3,true),(5,true))] s4_11936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11937 : List (BitVec 512) := [w2431,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6690]
theorem b4_11937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11937 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(3,true),(9,true))] s4_11937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11938 : List (BitVec 512) := [w2431,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588,w6690]
theorem b4_11938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11938 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(3,true),(9,true))] s4_11938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11939 : List (BitVec 512) := [w2431,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588,w6690]
theorem b4_11939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11939 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(8,true)),(false,(3,true),(1,false))] s4_11939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2431,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2431 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11940 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6300,w6522,w6588]
theorem b4_11940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11940 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_11940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11941 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11941 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(4,true))] s4_11941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11942 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_11942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11942 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(1,false),(3,true))] s4_11942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11943 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11943 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(0,false)),(false,(1,false),(8,true))] s4_11943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11944 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11944 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(0,false))] s4_11944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11945 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11945 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(1,false),(7,true))] s4_11945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11946 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_11946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11946 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(1,false),(5,true))] s4_11946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11947 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_11947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11947 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(1,false),(7,true))] s4_11947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11948 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_11948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11948 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,false))] s4_11948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11949 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_11949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11949 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(8,true)),(false,(1,false),(8,true))] s4_11949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11950 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_11950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11950 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(0,false),(6,true)),(false,(4,true),(3,true))] s4_11950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11951 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_11951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11951 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(4,true))] s4_11951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11952 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_11952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11952 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_11952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6225,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11953 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_11953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11953 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_11953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11954 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_11954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11954 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(3,true),(7,true))] s4_11954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11955 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_11955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11955 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(7,true))] s4_11955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11956 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_11956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11956 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(7,true),(0,false))] s4_11956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11957 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_11957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11957 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(7,true),(5,true))] s4_11957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11958 : List (BitVec 512) := [w2435,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6785]
theorem b4_11958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11958 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(7,true),(9,true))] s4_11958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2435,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2435 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11959 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11959 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_11959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11960 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_11960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11960 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(8,true))] s4_11960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11961 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_11961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11961 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11962 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11962 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_11962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11963 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11963 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s4_11963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11964 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11964 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(1,false),(0,false))] s4_11964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11965 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_11965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11965 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(7,true)),(false,(7,true),(0,false))] s4_11965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11966 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_11966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11966 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(1,false),(0,false))] s4_11966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11967 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_11967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11967 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(0,false),(8,true))] s4_11967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11968 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_11968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11968 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(0,false))] s4_11968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11969 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11969 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11970 : List (BitVec 512) := [w2436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_11970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11970 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_11970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2436,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2436 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11971 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_11971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11971 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(5,true))] s4_11971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11972 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11972 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(0,false),(5,true))] s4_11972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11973 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_11973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11973 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(0,false),(3,true)),(false,(1,false),(5,true))] s4_11973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11974 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_11974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11974 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(3,true))] s4_11974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11975 : List (BitVec 512) := [w2457,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_11975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11975 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(1,false),(8,true))] s4_11975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2457,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2457 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
