import NinePin31
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17081 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5199,w5393,w5585,w5956,w6300,w6588]
theorem b4_17081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17081 := by
  intro m le c
  apply rejects_sound r31 i7 8 tgt (small31 adj) hot31 [] s4_17081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v31_3766,v31_4344,v31_4716,v31_4926,v31_5199,v31_5393,v31_5585,v31_5956,v31_6300,v31_6588] (PetersenWireProjection.cons pc31_3766 (PetersenWireProjection.cons pc31_4344 (PetersenWireProjection.cons pc31_4716 (PetersenWireProjection.cons pc31_4926 (PetersenWireProjection.cons pc31_5199 (PetersenWireProjection.cons pc31_5393 (PetersenWireProjection.cons pc31_5585 (PetersenWireProjection.cons pc31_5956 (PetersenWireProjection.cons pc31_6300 (PetersenWireProjection.cons pc31_6588 rfl)))))))))) (by decide +kernel)
end NineCert
