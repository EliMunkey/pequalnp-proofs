import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5766 : List (BitVec 512) := [w3766,w4344,w4716,w5041,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b5_5766 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5766 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s5_5766 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5041,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5041 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5870 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5864,w5956,w6300,w6588]
theorem b5_5870 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5870 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5870 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5864,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5864 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5871 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5865,w5956,w6300,w6588]
theorem b5_5871 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5871 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5871 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5865,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5865 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5872 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5866,w5956,w6300,w6588]
theorem b5_5872 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5872 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(4,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5872 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5866,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5866 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5873 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5867,w5956,w6300,w6588]
theorem b5_5873 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5873 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5873 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5867,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5867 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5874 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5868,w5956,w6300,w6588]
theorem b5_5874 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5874 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(8,true),(0,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5874 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5868,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5868 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5875 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5869,w5956,w6300,w6588]
theorem b5_5875 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5875 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(3,true)),(false,(0,true),(8,true)),(false,(7,true),(3,true)),(false,(1,true),(0,false))] s5_5875 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5869,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5869 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5876 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5882,w5956,w6300,w6588]
theorem b5_5876 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5876 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s5_5876 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5882,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5882 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5903 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6244,w6300,w6588]
theorem b5_5903 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5903 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_5903 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6244,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6244 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5906 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6504,w6588]
theorem b5_5906 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5906 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(6,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_5906 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6504,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6504 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5911 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6581,w6588]
theorem b5_5911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5911 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(1,false))] s5_5911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6581,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6581 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_5912 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6583,w6588]
theorem b5_5912 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5912 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(0,false),(9,true)),(false,(2,false),(0,false))] s5_5912 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6583,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6583 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_6019 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6757]
theorem b5_6019 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6019 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(7,true),(0,true)),(false,(5,true),(4,true)),(false,(1,true),(6,true))] s5_6019 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6757] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6757 rfl)))))))))) (by decide +kernel)
def s5_6020 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6758]
theorem b5_6020 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6020 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6758] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6758 rfl)))))))))) (by decide +kernel)
def s5_6021 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6759]
theorem b5_6021 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6021 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_6021 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6759] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6759 rfl)))))))))) (by decide +kernel)
def s5_6022 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6760]
theorem b5_6022 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6022 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(6,true))] s5_6022 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6760] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6760 rfl)))))))))) (by decide +kernel)
def s5_6023 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6761]
theorem b5_6023 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6023 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(3,true)),(false,(2,true),(8,true)),(false,(1,false),(0,true)),(false,(0,true),(6,true))] s5_6023 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6761] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6761 rfl)))))))))) (by decide +kernel)
def s5_6064 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6555,w6813,w6873]
theorem b5_6064 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(7,true),(8,true)),(false,(1,false),(4,true)),(false,(10,true),(6,true))] s5_6064 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6555,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6116 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6555,w6785,w6873]
theorem b5_6116 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6116 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(8,true),(9,true)),(false,(6,true),(10,true))] s5_6116 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6555,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6148 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6501,w6813,w6873]
theorem b5_6148 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6148 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(5,true),(9,true)),(false,(8,true),(10,true))] s5_6148 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6501,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6501 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6149 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5861,w6101,w6522,w6785,w6873]
theorem b5_6149 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6149 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(8,true),(9,true)),(false,(6,true),(10,true))] s5_6149 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5861,v1_6101,v1_6522,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6150 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5873,w5956,w6464,w6813,w6873]
theorem b5_6150 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6150 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(5,true),(9,true)),(false,(8,true),(10,true))] s5_6150 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5873,v1_5956,v1_6464,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5873 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6161 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w6179,w6241,w6522,w6785,w6873]
theorem b5_6161 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6161 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(3,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(10,true),(6,true))] s5_6161 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_6179,v1_6241,v1_6522,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6198 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6764]
theorem b5_6198 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6198 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(1,false)),(false,(1,true),(7,true))] s5_6198 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5585,v1_5956,v1_6300,v1_6588,v1_6764] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6764 rfl)))))))))) (by decide +kernel)
def s5_6211 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6720,w6762]
theorem b5_6211 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6211 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_6211 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5585,v1_5956,v1_6300,v1_6720,v1_6762] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6762 rfl)))))))))) (by decide +kernel)
def s5_6216 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5638,w5861,w5956,w6300,w6588]
theorem b5_6216 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6216 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true)),(false,(1,true),(7,true))] s5_6216 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5638,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5638 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_6220 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5769,w5861,w5956,w6300,w6588]
theorem b5_6220 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6220 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(1,true),(7,true))] s5_6220 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_4716,v1_5135,v1_5470,v1_5769,v1_5861,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5470 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5861 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s5_6239 : List (BitVec 512) := [w3766,w4344,w5135,w5205,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_6239 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6239 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6239 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_5135,v1_5205,v1_5393,v1_5585,v1_6101,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6240 : List (BitVec 512) := [w3766,w4344,w5135,w5239,w5393,w5585,w6179,w6522,w6720,w6873]
theorem b5_6240 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6240 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true)),(false,(10,true),(6,true))] s5_6240 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_5135,v1_5239,v1_5393,v1_5585,v1_6179,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6241 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5530,w5585,w6101,w6522,w6720,w6873]
theorem b5_6241 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6241 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6241 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_5135,v1_5393,v1_5530,v1_5585,v1_6101,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5530 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6250 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6154,w6522,w6720,w6873]
theorem b5_6250 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6250 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6250 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6154,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6154 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s5_6257 : List (BitVec 512) := [w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6555,w6720,w6873]
theorem b5_6257 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6257 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_6257 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6555,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl)))))))))) (by decide +kernel)
def s6_17 : List (BitVec 512) := [w1257,w2468,w3766,w4344,w4716,w5098,w5585,w5956,w6300]
theorem b6_17 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_17 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(6,true))] s6_17 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1257,v1_2468,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1257 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_19 : List (BitVec 512) := [w1374,w2443,w3766,w4344,w4716,w5098,w5585,w5956,w6300]
theorem b6_19 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_19 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(0,true),(9,true)),(false,(7,true),(0,true))] s6_19 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2443,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2443 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_20 : List (BitVec 512) := [w1374,w2494,w3766,w4344,w4716,w5098,w5585,w5956,w6300]
theorem b6_20 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_20 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(4,true)),(false,(9,true),(1,false)),(false,(7,true),(0,true))] s6_20 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2494,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2494 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_21 : List (BitVec 512) := [w1374,w2852,w3766,w4344,w5098,w5393,w5585,w5956,w6300]
theorem b6_21 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_21 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,true),(4,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s6_21 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1374,v1_2852,v1_3766,v1_4344,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1374 (PetersenWireProjection.cons pc1_2852 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_22 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b6_22 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_22 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,true),(5,true)),(false,(3,true),(2,true))] s6_22 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3258,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_23 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5098,w5393,w5585,w5956,w6300]
theorem b6_23 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_23 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,true),(5,true)),(false,(3,true),(1,true))] s6_23 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1384,v1_3293,v1_4344,v1_4716,v1_5098,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1384 (PetersenWireProjection.cons pc1_3293 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_27 : List (BitVec 512) := [w1403,w3766,w4716,w5059,w5393,w5698,w6179,w6522,w6588]
theorem b6_27 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_27 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(8,true),(7,true)),(false,(10,true),(9,true)),(false,(5,true),(9,true))] s6_27 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4716,v1_5059,v1_5393,v1_5698,v1_6179,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
def s6_34 : List (BitVec 512) := [w1722,w1734,w3766,w4344,w4716,w5393,w5585,w5956,w6300]
theorem b6_34 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_34 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(1,true),(0,false)),(false,(6,true),(1,true)),(false,(1,true),(0,true))] s6_34 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1722,v1_1734,v1_3766,v1_4344,v1_4716,v1_5393,v1_5585,v1_5956,v1_6300] (PetersenWireProjection.cons pc1_1722 (PetersenWireProjection.cons pc1_1734 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 rfl))))))))) (by decide +kernel)
def s6_35 : List (BitVec 512) := [w1723,w3766,w4716,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b6_35 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_35 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(2,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s6_35 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1723,v1_3766,v1_4716,v1_5393,v1_5698,v1_6179,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1723 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
def s6_72 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5585,w6101,w6555,w6720,w6873]
theorem b6_72 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_72 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(10,true)),(false,(6,true),(10,true))] s6_72 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2468,v1_3766,v1_4344,v1_5135,v1_5585,v1_6101,v1_6555,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6555 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))) (by decide +kernel)
def s6_75 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5098,w5585,w5956,w6300,w6588]
theorem b6_75 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_75 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s6_75 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5098,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5098 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
def s6_76 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5107,w5585,w5956,w6300,w6588]
theorem b6_76 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_76 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s6_76 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_2488,v1_3766,v1_4344,v1_4716,v1_5107,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_2488 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5107 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))) (by decide +kernel)
end NineCert
