import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4854 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_4854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4854 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(2,true),(5,true))] s4_4854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4855 : List (BitVec 512) := [w967,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_4855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4855 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(5,true),(2,true))] s4_4855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3766,v3_5135,v3_5393,v3_5698,v3_5769,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s4_4856 : List (BitVec 512) := [w967,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_4856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4856 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_4856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3901,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3901 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_4857 : List (BitVec 512) := [w967,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4857 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_4857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3901,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3901 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4858 : List (BitVec 512) := [w967,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4858 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(1,true))] s4_4858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3935,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3935 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_4859 : List (BitVec 512) := [w967,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_4859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4859 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(0,false),(1,true))] s4_4859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_967,v3_3935,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_967 (PetersenWireProjection.cons pc3_3935 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s4_5319 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5618,w5956,w6300,w6588]
theorem b4_5319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(0,true),(5,true))] s4_5319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1076,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5618,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1076 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5618 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5358 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5358 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(6,true))] s4_5358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1076,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1076 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5578 : List (BitVec 512) := [w1112,w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5578 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1112,v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1112 (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5579 : List (BitVec 512) := [w1112,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5579 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1112,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1112 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_5618 : List (BitVec 512) := [w1119,w1795,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5618 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_1795,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_1795 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5702 : List (BitVec 512) := [w1119,w3099,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5702 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5702 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5702 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3099,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3099 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5703 : List (BitVec 512) := [w1119,w3099,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6588]
theorem b4_5703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5703 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3099,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3099 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_5704 : List (BitVec 512) := [w1119,w3123,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5704 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3123,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3123 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5706 : List (BitVec 512) := [w1119,w3127,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5706 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5706 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(6,true))] s4_5706 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3127,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3127 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5707 : List (BitVec 512) := [w1119,w3152,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5707 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5707 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true))] s4_5707 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3152,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3152 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5739 : List (BitVec 512) := [w1119,w3766,w4079,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5739 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4079,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5740 : List (BitVec 512) := [w1119,w3766,w4146,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5740 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5740 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5740 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4146,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5741 : List (BitVec 512) := [w1119,w3766,w4163,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5741 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4163,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5742 : List (BitVec 512) := [w1119,w3766,w4174,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5742 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true))] s4_5742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4174,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4174 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5743 : List (BitVec 512) := [w1119,w3766,w4179,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5743 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4179,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5744 : List (BitVec 512) := [w1119,w3766,w4258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5744 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true))] s4_5744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5745 : List (BitVec 512) := [w1119,w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5745 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true))] s4_5745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5746 : List (BitVec 512) := [w1119,w3766,w4297,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5746 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4297,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5747 : List (BitVec 512) := [w1119,w3766,w4344,w4376,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5747 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4376,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4376 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5777 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6690]
theorem b4_5777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5777 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(6,true))] s4_5777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_5782 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_5782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5782 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(6,true))] s4_5782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5792 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6690]
theorem b4_5792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5792 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(7,true))] s4_5792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_5797 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_5797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5797 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(7,true))] s4_5797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5805 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6690]
theorem b4_5805 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5805 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true))] s4_5805 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_5810 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_5810 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5810 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true))] s4_5810 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5839 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_5839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5839 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(6,true),(7,true))] s4_5839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5848 : List (BitVec 512) := [w1119,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_5848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5848 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(5,true),(6,true))] s4_5848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5883 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b4_5883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5883 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5895 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6061,w6101,w6300,w6588]
theorem b4_5895 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5895 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5895 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5899 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6103,w6300,w6588]
theorem b4_5899 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5899 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5899 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6103,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6103 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5901 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6136,w6300,w6588]
theorem b4_5901 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5901 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5901 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5912 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b4_5912 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5912 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5912 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_5921 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6690]
theorem b4_5921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5921 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_5930 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6690]
theorem b4_5930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5930 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s4_5935 : List (BitVec 512) := [w1119,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_5935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5935 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(7,true)),(false,(2,true),(6,true))] s4_5935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1119,v3_3766,v3_4344,v3_5135,v3_5393,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1119 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_6732 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_6732 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6732 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(0,true),(2,true))] s4_6732 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_4746,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4746 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_6808 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_6808 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6808 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(0,true),(6,true))] s4_6808 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5992,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5992 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_6841 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_6841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6841 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_6841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_6852 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6330,w6588]
theorem b4_6852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6852 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(0,true),(7,true))] s4_6852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6330,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6330 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_6882 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_6882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6882 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(7,true))] s4_6882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_6888 : List (BitVec 512) := [w1231,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_6888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_6888 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(6,true),(7,true))] s4_6888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1231,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1231 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7151 : List (BitVec 512) := [w1284,w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7151 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7151 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7151 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1284,v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1284 (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7154 : List (BitVec 512) := [w1284,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7154 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7154 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7154 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1284,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1284 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_7254 : List (BitVec 512) := [w1292,w3123,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7254 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_7254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3123,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3123 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7256 : List (BitVec 512) := [w1292,w3127,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7256 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3127,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3127 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7259 : List (BitVec 512) := [w1292,w3147,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7259 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(7,true))] s4_7259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3147,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3147 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7309 : List (BitVec 512) := [w1292,w3766,w3936,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7309 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7309 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7309 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7312 : List (BitVec 512) := [w1292,w3766,w4146,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7312 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7312 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7312 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4146,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4146 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7313 : List (BitVec 512) := [w1292,w3766,w4163,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7313 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false))] s4_7313 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4163,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4163 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7314 : List (BitVec 512) := [w1292,w3766,w4174,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7314 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7314 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7314 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4174,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4174 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7315 : List (BitVec 512) := [w1292,w3766,w4179,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7315 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7316 : List (BitVec 512) := [w1292,w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7316 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7316 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false))] s4_7316 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7317 : List (BitVec 512) := [w1292,w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7317 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7317 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false))] s4_7317 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7318 : List (BitVec 512) := [w1292,w3766,w4297,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7318 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7318 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7318 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4297,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4297 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7319 : List (BitVec 512) := [w1292,w3766,w4344,w4382,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7319 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7319 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7319 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4382,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4382 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7335 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w4926,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_7335 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7335 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(5,true),(6,true))] s4_7335 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_7377 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6690]
theorem b4_7377 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7377 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_7377 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_7382 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_7382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7382 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,false)),(false,(2,true),(6,true))] s4_7382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1292,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1292 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
end NineCert
