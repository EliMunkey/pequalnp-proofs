import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_996 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5122,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_3766,v1_4344,v1_4716,v1_5122,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5122 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1020 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6898]
theorem b4_1020 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1020 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1020 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6898] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_1033 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6444,w6588,w6873]
theorem b4_1033 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1033 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1033 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_160,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6444,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_160 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6444 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1037 : List (BitVec 512) := [w164,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1037 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1037 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true))] s4_1037 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_164,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_164 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1038 : List (BitVec 512) := [w165,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1038 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1038 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1038 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_165,v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_165 (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1039 : List (BitVec 512) := [w165,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1039 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_1039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_165,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_165 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1040 : List (BitVec 512) := [w165,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1040 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true))] s4_1040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_165,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_165 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1041 : List (BitVec 512) := [w167,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1041 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1041 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1041 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_167,v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_167 (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1042 : List (BitVec 512) := [w167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1042 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1042 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_1042 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1043 : List (BitVec 512) := [w167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1043 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1043 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true))] s4_1043 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_167,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_167 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1044 : List (BitVec 512) := [w168,w202,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1044 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1044 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(0,true)),(false,(0,false),(5,true))] s4_1044 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_168,v1_202,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_168 (PetersenWireProjection.cons pc1_202 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1045 : List (BitVec 512) := [w168,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1045 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [] s4_1045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_168,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_168 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1046 : List (BitVec 512) := [w168,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1046 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1046 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true))] s4_1046 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_168,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_168 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1047 : List (BitVec 512) := [w171,w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1047 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1047 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1047 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_192,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_192 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1048 : List (BitVec 512) := [w171,w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1048 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1048 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1048 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1049 : List (BitVec 512) := [w171,w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1049 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_200,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_200 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1050 : List (BitVec 512) := [w171,w202,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1050 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1050 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1050 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_202,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_202 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1051 : List (BitVec 512) := [w171,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_1051 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1051 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(0,true))] s4_1051 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_1052 : List (BitVec 512) := [w171,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6890]
theorem b4_1052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1052 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s4_1052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1664,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1664 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_1053 : List (BitVec 512) := [w171,w1832,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1053 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(7,true))] s4_1053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1832,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1832 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1054 : List (BitVec 512) := [w171,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1054 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(7,true),(0,true))] s4_1054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1867,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1867 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1055 : List (BitVec 512) := [w171,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1055 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,true),(7,true))] s4_1055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1875,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1875 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1056 : List (BitVec 512) := [w171,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_1056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1056 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(0,true),(7,true)),(false,(9,true),(5,true))] s4_1056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1894,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1894 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1057 : List (BitVec 512) := [w171,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588,w6873]
theorem b4_1057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1057 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(9,true),(8,true))] s4_1057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1915,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1915 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1058 : List (BitVec 512) := [w171,w1916,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1058 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(8,true),(0,true))] s4_1058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1916,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1916 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1059 : List (BitVec 512) := [w171,w1917,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1059 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1059 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(0,true),(8,true))] s4_1059 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_1917,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_1917 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1060 : List (BitVec 512) := [w171,w2104,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1060 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1060 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(2,true)),(false,(0,true),(6,true))] s4_1060 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2104,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2104 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1061 : List (BitVec 512) := [w171,w2124,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1061 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,true),(6,true))] s4_1061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2124,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2124 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1062 : List (BitVec 512) := [w171,w2125,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1062 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1062 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(6,true))] s4_1062 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2125,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2125 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1063 : List (BitVec 512) := [w171,w2143,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_1063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1063 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(6,true)),(false,(6,true),(0,true)),(false,(9,true),(5,true))] s4_1063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2143,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2143 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1064 : List (BitVec 512) := [w171,w2165,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873]
theorem b4_1064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1064 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(6,true),(0,true)),(false,(5,true),(9,true))] s4_1064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2165,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2165 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1065 : List (BitVec 512) := [w171,w2171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_1065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1065 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(3,true),(7,true))] s4_1065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1066 : List (BitVec 512) := [w171,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6785,w6873]
theorem b4_1066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1066 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(5,true),(7,true))] s4_1066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6300,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1067 : List (BitVec 512) := [w171,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6588,w6873]
theorem b4_1067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1067 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(9,true),(7,true))] s4_1067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6464,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1068 : List (BitVec 512) := [w171,w2172,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1068 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(0,true),(7,true))] s4_1068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2172,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2172 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1069 : List (BitVec 512) := [w171,w2173,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1069 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(0,true),(7,true))] s4_1069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2173,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2173 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1070 : List (BitVec 512) := [w171,w2175,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1070 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1070 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(0,true),(7,true))] s4_1070 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2175,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2175 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1071 : List (BitVec 512) := [w171,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_1071 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1071 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(9,true))] s4_1071 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2468,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2468 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1072 : List (BitVec 512) := [w171,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_1072 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1072 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_1072 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1073 : List (BitVec 512) := [w171,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6873]
theorem b4_1073 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1073 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_1073 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1074 : List (BitVec 512) := [w171,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6908]
theorem b4_1074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1074 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_1074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2527,v1_3766,v1_4344,v1_4716,v1_5135,v1_5585,v1_5956,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2527 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_1075 : List (BitVec 512) := [w171,w2819,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1075 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1075 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(5,true)),(false,(3,true),(0,true))] s4_1075 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2819,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2819 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1076 : List (BitVec 512) := [w171,w2836,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1076 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(6,true)),(false,(0,true),(3,true))] s4_1076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2836,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2836 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1077 : List (BitVec 512) := [w171,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1077 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(0,true),(3,true))] s4_1077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2837,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2837 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1078 : List (BitVec 512) := [w171,w2879,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6873]
theorem b4_1078 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1078 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(0,true),(3,true)),(false,(5,true),(9,true))] s4_1078 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2879,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2879 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1079 : List (BitVec 512) := [w171,w2885,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_1079 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1079 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(5,true),(4,true))] s4_1079 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2885,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2885 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1080 : List (BitVec 512) := [w171,w2886,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1080 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s4_1080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2886,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2886 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1081 : List (BitVec 512) := [w171,w2889,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1081 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(0,true),(4,true))] s4_1081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_2889,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_2889 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1082 : List (BitVec 512) := [w171,w3075,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1082 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(2,true)),(false,(2,true),(0,true))] s4_1082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3075,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3075 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1083 : List (BitVec 512) := [w171,w3123,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1083 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,true),(2,true))] s4_1083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3123,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3123 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1084 : List (BitVec 512) := [w171,w3127,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1084 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(2,true),(0,true))] s4_1084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3127,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3127 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1085 : List (BitVec 512) := [w171,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_1085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1085 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(5,true),(4,true))] s4_1085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3182,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3182 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 rfl))))))))))) (by decide +kernel)
def s4_1086 : List (BitVec 512) := [w171,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_1086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1086 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(2,true)),(false,(9,true),(8,true))] s4_1086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3182,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3182 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1087 : List (BitVec 512) := [w171,w3183,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1087 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(0,true),(3,true))] s4_1087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3183,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3183 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1088 : List (BitVec 512) := [w171,w3186,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1088 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(0,true),(3,true))] s4_1088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3186,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3186 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1089 : List (BitVec 512) := [w171,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1089 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s4_1089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1090 : List (BitVec 512) := [w171,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1090 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true))] s4_1090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1091 : List (BitVec 512) := [w171,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1091 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(9,true))] s4_1091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3258,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3258 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1092 : List (BitVec 512) := [w171,w3766,w4344,w4519,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1092 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(3,true))] s4_1092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4519,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4519 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1093 : List (BitVec 512) := [w171,w3766,w4344,w4571,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1093 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_1093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4571,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4571 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1094 : List (BitVec 512) := [w171,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1094 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(3,true))] s4_1094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4599,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4599 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1095 : List (BitVec 512) := [w171,w3766,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1095 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,true)),(false,(0,true),(4,true))] s4_1095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_4785,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4785 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1096 : List (BitVec 512) := [w171,w3766,w4344,w4716,w4796,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1096 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(6,true)),(false,(0,true),(4,true))] s4_1096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_4796,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4796 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1097 : List (BitVec 512) := [w171,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1097 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s4_1097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_4810,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4810 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
