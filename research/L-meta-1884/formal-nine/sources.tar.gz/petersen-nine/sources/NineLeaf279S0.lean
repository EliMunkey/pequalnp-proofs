import NinePin279
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4838 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588,w6873]
theorem b3_4838 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4838 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s3_4838 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5698,v279_5848,v279_5956,v279_6300,v279_6588,v279_6873] (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5698 (PetersenWireProjection.cons pc279_5848 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 (PetersenWireProjection.cons pc279_6873 rfl)))))))))))) (by decide +kernel)
def s3_4905 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588,w6873]
theorem b3_4905 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4905 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s3_4905 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5769,v279_5848,v279_5956,v279_6300,v279_6588,v279_6873] (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5769 (PetersenWireProjection.cons pc279_5848 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 (PetersenWireProjection.cons pc279_6873 rfl)))))))))))) (by decide +kernel)
def s4_1517 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_1517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1517 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_1517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_197,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5698,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_197 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5698 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_1519 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_1519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1519 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_1519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_197,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5848,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_197 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5848 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_1672 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_1672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1672 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_1672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_204,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6225,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_204 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6225 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_4864 : List (BitVec 512) := [w972,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4864 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_4864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_972,v279_1626,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_972 (PetersenWireProjection.cons pc279_1626 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_4865 : List (BitVec 512) := [w972,w3766,w4344,w4426,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4865 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_4865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_972,v279_3766,v279_4344,v279_4426,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_972 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4426 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_4866 : List (BitVec 512) := [w972,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_4866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4866 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_4866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_972,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5769,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_972 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5769 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_4873 : List (BitVec 512) := [w975,w3766,w4344,w4428,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4873 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_4873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_975,v279_3766,v279_4344,v279_4428,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_975 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4428 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8221 : List (BitVec 512) := [w1328,w1626,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8221 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1328,v279_1626,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_1328 (PetersenWireProjection.cons pc279_1626 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8222 : List (BitVec 512) := [w1328,w1635,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8222 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1328,v279_1635,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_1328 (PetersenWireProjection.cons pc279_1635 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8472 : List (BitVec 512) := [w1328,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_8472 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8472 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8472 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1328,v279_3766,v279_4344,v279_5135,v279_5393,v279_5585,v279_5769,v279_5956,v279_6300,v279_6422,v279_6588] (PetersenWireProjection.cons pc279_1328 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5769 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6422 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8479 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_8479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8479 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1328,v279_3766,v279_4716,v279_5135,v279_5393,v279_5585,v279_5698,v279_5956,v279_6300,v279_6389,v279_6588] (PetersenWireProjection.cons pc279_1328 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5698 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6389 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8482 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b4_8482 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8482 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8482 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1328,v279_3766,v279_4716,v279_5135,v279_5393,v279_5585,v279_5848,v279_5956,v279_6300,v279_6389,v279_6588] (PetersenWireProjection.cons pc279_1328 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5848 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6389 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_8817 : List (BitVec 512) := [w1374,w1652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8817 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8817 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_8817 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1374,v279_1652,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_1374 (PetersenWireProjection.cons pc279_1652 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_9571 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_9571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9571 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_9571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1384,v279_3766,v279_4716,v279_5135,v279_5393,v279_5585,v279_5698,v279_5956,v279_6300,v279_6389,v279_6588] (PetersenWireProjection.cons pc279_1384 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5698 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6389 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_9580 : List (BitVec 512) := [w1388,w1652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9580 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_9580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_1388,v279_1652,v279_3766,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_1388 (PetersenWireProjection.cons pc279_1652 (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl))))))))))) (by decide +kernel)
def s4_15835 : List (BitVec 512) := [w3766,w4344,w4348,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_15835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15835 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s4_15835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_3766,v279_4344,v279_4348,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588,v279_6873] (PetersenWireProjection.cons pc279_3766 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4348 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 (PetersenWireProjection.cons pc279_6873 rfl))))))))))) (by decide +kernel)
def s5_410 : List (BitVec 512) := [w197,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_410 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_410 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s5_410 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_197,v279_3258,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_197 (PetersenWireProjection.cons pc279_3258 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl)))))))))) (by decide +kernel)
def s5_411 : List (BitVec 512) := [w197,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_411 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_411 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s5_411 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_197,v279_3280,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_197 (PetersenWireProjection.cons pc279_3280 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl)))))))))) (by decide +kernel)
def s5_1483 : List (BitVec 512) := [w972,w3208,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1483 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1483 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s5_1483 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_972,v279_3208,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_972 (PetersenWireProjection.cons pc279_3208 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl)))))))))) (by decide +kernel)
def s5_1495 : List (BitVec 512) := [w975,w3209,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1495 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1495 := by
  intro m le c
  apply rejects_sound r279 i6 5 tgt (small279 adj) hot279 [] s5_1495 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v279_975,v279_3209,v279_4344,v279_4716,v279_5135,v279_5393,v279_5585,v279_5956,v279_6300,v279_6588] (PetersenWireProjection.cons pc279_975 (PetersenWireProjection.cons pc279_3209 (PetersenWireProjection.cons pc279_4344 (PetersenWireProjection.cons pc279_4716 (PetersenWireProjection.cons pc279_5135 (PetersenWireProjection.cons pc279_5393 (PetersenWireProjection.cons pc279_5585 (PetersenWireProjection.cons pc279_5956 (PetersenWireProjection.cons pc279_6300 (PetersenWireProjection.cons pc279_6588 rfl)))))))))) (by decide +kernel)
end NineCert
