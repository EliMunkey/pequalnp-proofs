import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_5359 : List (BitVec 512) := [w3766,w4197,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5359 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5359 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5359 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4197,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4197 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5360 : List (BitVec 512) := [w3766,w4198,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5360 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5360 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5360 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4198,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4198 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5361 : List (BitVec 512) := [w3766,w4210,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5361 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5361 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5361 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4210,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4210 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5362 : List (BitVec 512) := [w3766,w4211,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5362 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5362 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5362 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4211,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4211 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5363 : List (BitVec 512) := [w3766,w4212,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5363 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5363 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5363 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4212,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4212 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5364 : List (BitVec 512) := [w3766,w4213,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5364 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5364 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5364 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4213,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4213 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5365 : List (BitVec 512) := [w3766,w4215,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5365 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5365 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5365 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4215,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4215 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5366 : List (BitVec 512) := [w3766,w4216,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5366 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5366 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5366 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4216,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4216 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5367 : List (BitVec 512) := [w3766,w4219,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5367 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5367 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5367 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4219,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4219 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5368 : List (BitVec 512) := [w3766,w4220,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5368 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5368 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5368 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4220,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4220 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5369 : List (BitVec 512) := [w3766,w4221,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5369 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5369 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5369 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4221,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4221 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5370 : List (BitVec 512) := [w3766,w4222,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5370 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5370 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5370 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4222,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4222 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5371 : List (BitVec 512) := [w3766,w4223,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5371 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5371 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5371 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4223,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4223 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5372 : List (BitVec 512) := [w3766,w4224,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5372 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5372 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5372 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4224,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4224 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5373 : List (BitVec 512) := [w3766,w4225,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b5_5373 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5373 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5373 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4225,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4225 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5374 : List (BitVec 512) := [w3766,w4225,w4716,w5135,w5393,w5585,w5956,w6353,w6389,w6588]
theorem b5_5374 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5374 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(8,true))] s5_5374 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4225,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6353,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4225 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6353 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5375 : List (BitVec 512) := [w3766,w4226,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5375 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5375 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5375 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4226,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4226 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5376 : List (BitVec 512) := [w3766,w4227,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5376 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5376 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5376 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4227,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4227 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5377 : List (BitVec 512) := [w3766,w4230,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5377 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5377 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5377 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4230,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4230 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5378 : List (BitVec 512) := [w3766,w4231,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5378 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5378 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5378 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4231,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4231 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5379 : List (BitVec 512) := [w3766,w4232,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5379 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4232,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4232 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5380 : List (BitVec 512) := [w3766,w4233,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5380 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5380 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5380 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4233,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4233 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5381 : List (BitVec 512) := [w3766,w4234,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5381 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5381 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5381 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4234,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4234 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5382 : List (BitVec 512) := [w3766,w4235,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5382 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5382 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5382 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4235,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4235 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5383 : List (BitVec 512) := [w3766,w4236,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_5383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5383 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(4,true))] s5_5383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4236,v3_4344,v3_4716,v3_5200,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4236 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5200 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5384 : List (BitVec 512) := [w3766,w4237,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5384 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5384 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5384 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4237,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4237 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5385 : List (BitVec 512) := [w3766,w4238,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5385 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5385 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5385 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4238,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4238 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5386 : List (BitVec 512) := [w3766,w4241,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5386 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5386 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5386 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4241,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4241 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5387 : List (BitVec 512) := [w3766,w4242,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5387 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5387 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5387 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4242,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4242 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5388 : List (BitVec 512) := [w3766,w4243,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5388 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5388 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5388 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5389 : List (BitVec 512) := [w3766,w4243,w4344,w4768,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5389 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5389 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(8,false)),(false,(0,true),(3,true))] s5_5389 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4344,v3_4768,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4768 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5390 : List (BitVec 512) := [w3766,w4243,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b5_5390 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5390 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s5_5390 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5391 : List (BitVec 512) := [w3766,w4243,w5135,w5393,w5585,w5656,w5956,w6389,w6422,w6588]
theorem b5_5391 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5391 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(7,true),(2,true)),(false,(1,true),(6,true))] s5_5391 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_5135,v3_5393,v3_5585,v3_5656,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5656 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5392 : List (BitVec 512) := [w3766,w4243,w5135,w5393,w5769,w5956,w6389,w6422,w6478,w6588]
theorem b5_5392 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5392 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(5,true),(2,true)),(false,(8,true),(3,true))] s5_5392 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4243,v3_5135,v3_5393,v3_5769,v3_5956,v3_6389,v3_6422,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4243 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5393 : List (BitVec 512) := [w3766,w4246,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5393 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5393 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5393 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4246,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4246 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5394 : List (BitVec 512) := [w3766,w4247,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5394 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5394 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5394 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4247,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4247 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5398 : List (BitVec 512) := [w3766,w4254,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5398 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5398 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5398 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4254,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4254 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5399 : List (BitVec 512) := [w3766,w4255,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5399 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5399 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5399 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4255,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4255 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5400 : List (BitVec 512) := [w3766,w4256,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5400 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5400 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5400 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4256,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4256 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5401 : List (BitVec 512) := [w3766,w4257,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5401 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5401 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5401 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4257,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4257 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5402 : List (BitVec 512) := [w3766,w4258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5402 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5402 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5402 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5403 : List (BitVec 512) := [w3766,w4258,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_5403 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5403 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true)),(false,(4,true),(7,true))] s5_5403 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4258,v3_4344,v3_5135,v3_5393,v3_5769,v3_5956,v3_6464,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5404 : List (BitVec 512) := [w3766,w4259,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5404 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5404 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5404 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4259,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4259 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5405 : List (BitVec 512) := [w3766,w4262,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5405 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5405 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5405 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4262,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4262 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5406 : List (BitVec 512) := [w3766,w4263,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5406 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5406 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5406 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4263,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4263 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5409 : List (BitVec 512) := [w3766,w4269,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5409 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5409 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5409 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4269,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4269 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5410 : List (BitVec 512) := [w3766,w4270,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5410 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5410 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5410 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4270,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4270 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5411 : List (BitVec 512) := [w3766,w4271,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5411 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5411 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5411 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4271,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4271 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5412 : List (BitVec 512) := [w3766,w4272,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5412 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5412 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5412 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4272,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4272 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5415 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5415 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5415 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5415 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5416 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_5416 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5416 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_5416 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5135,v3_5393,v3_6179,v3_6522,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5417 : List (BitVec 512) := [w3766,w4276,w4344,w4716,w5187,w5393,w5585,w5956,w6389,w6588]
theorem b5_5417 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5417 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s5_5417 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5418 : List (BitVec 512) := [w3766,w4276,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_5418 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5418 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(4,true),(8,true))] s5_5418 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4344,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_5419 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w5645,w6389,w6522,w6588]
theorem b5_5419 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5419 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(7,true),(6,true)),(false,(1,true),(6,true))] s5_5419 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_5645,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5645 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5420 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_5420 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5420 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s5_5420 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5421 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w5585,w6225,w6389,w6522,w6588]
theorem b5_5421 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5421 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(5,true)),(false,(7,true),(8,true))] s5_5421 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_5585,v3_6225,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5422 : List (BitVec 512) := [w3766,w4276,w4716,w5135,w5393,w6179,w6389,w6522,w6588,w6785]
theorem b5_5422 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5422 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s5_5422 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5135,v3_5393,v3_6179,v3_6389,v3_6522,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))) (by decide +kernel)
def s5_5423 : List (BitVec 512) := [w3766,w4276,w4716,w5187,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_5423 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5423 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true)),(false,(1,true),(4,true))] s5_5423 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5424 : List (BitVec 512) := [w3766,w4276,w5135,w5393,w5585,w6101,w6389,w6522,w6588,w6720]
theorem b5_5424 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5424 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(7,true),(6,true)),(false,(7,true),(3,true))] s5_5424 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4276,v3_5135,v3_5393,v3_5585,v3_6101,v3_6389,v3_6522,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4276 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl)))))))))) (by decide +kernel)
def s5_5425 : List (BitVec 512) := [w3766,w4277,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5425 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5425 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5425 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4277,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4277 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5426 : List (BitVec 512) := [w3766,w4280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5426 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5426 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5426 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4280,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4280 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5427 : List (BitVec 512) := [w3766,w4281,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5427 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5427 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5427 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4281,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4281 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5435 : List (BitVec 512) := [w3766,w4288,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5435 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5435 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5435 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4288,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4288 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_5436 : List (BitVec 512) := [w3766,w4289,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5436 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5436 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_5436 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4289,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4289 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
