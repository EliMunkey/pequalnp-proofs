import NinePin163
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2995 : List (BitVec 512) := [w1388,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2995 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2995 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2995 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2996 : List (BitVec 512) := [w1388,w2497,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2996 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2996 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2996 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_2497,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_2497 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3052 : List (BitVec 512) := [w1390,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3052 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3052 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3052 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3053 : List (BitVec 512) := [w1390,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3053 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3053 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3053 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3280,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3280 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3054 : List (BitVec 512) := [w1390,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3054 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3054 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3054 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3293,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3293 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3055 : List (BitVec 512) := [w1390,w3296,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3055 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3055 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3055 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3296,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3296 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3247 : List (BitVec 512) := [w1415,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3247 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3247 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3247 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3248 : List (BitVec 512) := [w1415,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3248 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_2496,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_2496 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3308 : List (BitVec 512) := [w1417,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3308 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3308 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3308 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3309 : List (BitVec 512) := [w1417,w3280,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3309 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3280,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3280 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3310 : List (BitVec 512) := [w1417,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3310 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3310 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3310 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3303,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3303 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3311 : List (BitVec 512) := [w1417,w3306,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3311 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3306,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3306 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3320 : List (BitVec 512) := [w1423,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3320 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_3321 : List (BitVec 512) := [w1423,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3321 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3321 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_3321 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_2496,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_2496 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_5522 : List (BitVec 512) := [w3766,w4344,w4403,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_5522 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5522 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_5522 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_4748,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_4748 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl)))))))))) (by decide +kernel)
def s5_5526 : List (BitVec 512) := [w3766,w4344,w4403,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_5526 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5526 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_5526 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl)))))))))) (by decide +kernel)
end NineCert
