import NinePin163
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9679 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_9679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9679 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9694 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_9694 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9694 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9694 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9703 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_9703 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9703 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9703 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9739 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6720]
theorem b4_9739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9739 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6225,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl))))))))))) (by decide +kernel)
def s4_9743 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9743 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9744 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9744 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9745 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_9745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9745 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9749 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_9749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9749 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9750 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_9750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9750 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9751 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_9751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9751 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9752 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_9752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9752 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1390,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1390 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10374 : List (BitVec 512) := [w1415,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10374 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10374 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10374 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10385 : List (BitVec 512) := [w1415,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_10385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10385 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3303,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6464,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3303 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10386 : List (BitVec 512) := [w1415,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10386 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3303,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3303 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10432 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4752,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10432 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_4752,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4752 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10483 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_10483 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10483 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10483 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10494 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5999,w6300,w6588]
theorem b4_10494 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10494 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10494 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_5999,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_5999 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10501 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_10501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10501 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10539 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_10539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10539 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6489,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6489 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10540 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_10540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10540 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6499,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6499 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10547 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_10547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10547 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10548 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_10548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10548 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6572,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6572 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10584 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_10584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10584 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10585 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_10585 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10585 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10585 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10586 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_10586 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10586 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10586 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5769,v163_5956,v163_6300,v163_6464,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10587 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_10587 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10587 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10587 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5769,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10597 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10597 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10597 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10597 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10598 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_10598 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10598 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10598 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10599 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_10599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10599 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10603 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_10603 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10603 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10603 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6464,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10604 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10604 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10604 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10604 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10605 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_10605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10605 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6489,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6489 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10606 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_10606 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10606 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10606 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1417,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6499,v163_6588] (PetersenWireProjection.cons pc163_1417 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6499 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10608 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10608 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10610 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_10610 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10610 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10610 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10611 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_10611 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10611 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10611 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10613 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10613 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10613 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10613 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_10614 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_10614 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10614 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_10614 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1423,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6572,v163_6588] (PetersenWireProjection.cons pc163_1423 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6572 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_15897 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_15897 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15897 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_15897 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4392,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_5993,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4392 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_5993 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_15905 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_15905 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15905 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_15905 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4392,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4392 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_15996 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15996 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_15996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_4716,v163_4748,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4748 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16028 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_16028 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16028 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16028 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16031 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6336,w6588]
theorem b4_16031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16031 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6336,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6336 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16040 : List (BitVec 512) := [w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16040 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16040 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16040 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4403,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4403 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16061 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_16061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16061 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4404,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4404 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16063 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16063 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4404,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4404 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16064 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_16064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16064 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4404,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4404 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16221 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16221 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4417,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4417 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16222 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_16222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16222 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4417,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6464,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4417 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_16224 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16224 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_16224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4417,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4417 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_17087 : List (BitVec 512) := [w3766,w4344,w4716,w4932,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_17087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17087 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_17087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4716,v163_4932,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4932 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_17382 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5993,w6300,w6588,w6832]
theorem b4_17382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17382 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_17382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5993,v163_6300,v163_6588,v163_6832] (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5993 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 (PetersenWireProjection.cons pc163_6832 rfl))))))))))) (by decide +kernel)
def s5_2249 : List (BitVec 512) := [w1249,w3250,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2249 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2249 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2249 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1249,v163_3250,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1249 (PetersenWireProjection.cons pc163_3250 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2256 : List (BitVec 512) := [w1252,w3251,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2256 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2256 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2256 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1252,v163_3251,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1252 (PetersenWireProjection.cons pc163_3251 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2279 : List (BitVec 512) := [w1265,w3254,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2279 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2279 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2279 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1265,v163_3254,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1265 (PetersenWireProjection.cons pc163_3254 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2284 : List (BitVec 512) := [w1268,w3255,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2284 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2284 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1268,v163_3255,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1268 (PetersenWireProjection.cons pc163_3255 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2324 : List (BitVec 512) := [w1292,w1875,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_2324 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2324 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2324 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1292,v163_1875,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1292 (PetersenWireProjection.cons pc163_1875 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2357 : List (BitVec 512) := [w1292,w2494,w3766,w4344,w4716,w5135,w5956,w6179,w6300,w6588]
theorem b5_2357 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2357 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2357 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1292,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1292 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2501 : List (BitVec 512) := [w1312,w3258,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2501 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2501 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2501 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3258,v163_4344,v163_5135,v163_5393,v163_5698,v163_5769,v163_5956,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl)))))))))) (by decide +kernel)
def s5_2601 : List (BitVec 512) := [w1328,w2857,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2601 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2601 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2601 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_2857,v163_3766,v163_4344,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_2857 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2757 : List (BitVec 512) := [w1374,w1875,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6720]
theorem b5_2757 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2757 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2757 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_1875,v163_3766,v163_4344,v163_5135,v163_5393,v163_5585,v163_6225,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_1875 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl)))))))))) (by decide +kernel)
def s5_2866 : List (BitVec 512) := [w1384,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2866 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2866 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2866 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2867 : List (BitVec 512) := [w1384,w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2867 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2867 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2867 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_2496,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_2496 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))) (by decide +kernel)
def s5_2962 : List (BitVec 512) := [w1384,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2962 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2962 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s5_2962 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_5135,v163_5393,v163_5698,v163_5769,v163_5956,v163_6300,v163_6720] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6720 rfl)))))))))) (by decide +kernel)
end NineCert
