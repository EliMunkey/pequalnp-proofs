import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5402 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_5402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5402 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true))] s4_5402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5403 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6543,w6588]
theorem b4_5403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5403 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false))] s4_5403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5404 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_5404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5404 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(4,true),(8,true))] s4_5404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5405 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_5405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5405 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(4,true))] s4_5405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6101,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5406 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6588]
theorem b4_5406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5406 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(4,true))] s4_5406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5407 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6522,w6720]
theorem b4_5407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5407 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(4,true))] s4_5407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6522,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5408 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_5408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5408 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(1,false))] s4_5408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_5409 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6389,w6522,w6588]
theorem b4_5409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5409 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(3,true)),(false,(5,true),(9,true))] s4_5409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5410 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_5410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5410 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(5,true))] s4_5410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6522,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5411 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6522,w6588]
theorem b4_5411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5411 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(8,true),(7,true))] s4_5411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5412 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_5412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5412 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(8,true)),(false,(8,true),(9,true))] s4_5412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_6179,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5413 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_5413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5413 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(3,true),(7,true)),(false,(9,true),(8,true))] s4_5413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_6179,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_5414 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_5414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5414 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(4,true),(7,true))] s4_5414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6464,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6464 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5415 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_5415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5415 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_5415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5470,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5470 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5416 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_5416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5416 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_5416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5470,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5470 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5417 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_5417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5417 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_5417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5471,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5418 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_5418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5418 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_5418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5135,v4_5471,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5419 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_5419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5419 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_5419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5420 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_5420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5420 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_5420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5421 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5421 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,false),(1,true))] s4_5421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5200,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5200 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5422 : List (BitVec 512) := [w1076,w3766,w4344,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b4_5422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5422 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,false),(1,true))] s4_5422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4716,v4_5200,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5200 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5423 : List (BitVec 512) := [w1076,w3766,w4344,w4746,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5423 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(5,true),(0,true))] s4_5423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4746,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4746 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5424 : List (BitVec 512) := [w1076,w3766,w4344,w4747,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5424 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,true),(5,true))] s4_5424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4747,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4747 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5425 : List (BitVec 512) := [w1076,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5425 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_5425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5426 : List (BitVec 512) := [w1076,w3766,w4344,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5426 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_5426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5427 : List (BitVec 512) := [w1076,w3766,w4344,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5427 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_5427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4750,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4750 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5428 : List (BitVec 512) := [w1076,w3766,w4344,w4766,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_5428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5428 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s4_5428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4766,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5429 : List (BitVec 512) := [w1076,w3766,w4344,w4766,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5429 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(4,true),(0,true))] s4_5429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_4766,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4766 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5430 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5621,w5956,w6101,w6300,w6588]
theorem b4_5430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5430 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,false)),(false,(0,true),(7,true))] s4_5430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5621,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5621 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5431 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5636,w5956,w6101,w6300,w6588]
theorem b4_5431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5431 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,false)),(false,(0,true),(7,true))] s4_5431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5636,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5636 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5432 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5656,w5956,w6300,w6389,w6588]
theorem b4_5432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5432 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s4_5432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5656,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5656 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5433 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b4_5433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5433 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,false),(7,true))] s4_5433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5656,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5656 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5434 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5659,w5956,w6300,w6588]
theorem b4_5434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5434 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(7,true))] s4_5434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5659,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5659 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5435 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5659,w5956,w6300,w6588,w6690]
theorem b4_5435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5435 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,false),(7,true))] s4_5435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5659,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5659 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5436 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5660,w5956,w6300,w6588]
theorem b4_5436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5436 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(7,true))] s4_5436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5660,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5660 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5437 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5662,w5956,w6300,w6588]
theorem b4_5437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5437 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,false),(7,true))] s4_5437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5662,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5662 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5438 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5665,w5956,w6101,w6300,w6588]
theorem b4_5438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5438 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(2,true)),(false,(0,true),(7,true))] s4_5438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5665,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5665 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5439 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b4_5439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5439 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_5439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5440 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6720]
theorem b4_5440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5440 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_5440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6101,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5441 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5698,w6101,w6300,w6522,w6588]
theorem b4_5441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5441 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(4,true))] s4_5441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5698,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5442 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_5442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5442 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,false),(0,true))] s4_5442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5750,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5750 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5443 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_5443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5443 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(7,false))] s4_5443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5760,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5760 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5444 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_5444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5444 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(7,false))] s4_5444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5767,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5767 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5445 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b4_5445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5445 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_5445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5446 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6720]
theorem b4_5446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5446 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true))] s4_5446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5848,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5447 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6588]
theorem b4_5447 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5447 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s4_5447 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5448 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6061,w6300,w6720]
theorem b4_5448 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5448 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true))] s4_5448 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6061,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5449 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b4_5449 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5449 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5449 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5450 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6720]
theorem b4_5450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5450 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_5450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5451 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6237,w6300,w6588]
theorem b4_5451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5451 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true))] s4_5451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6237,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6237 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5452 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b4_5452 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5452 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_5452 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5453 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6720]
theorem b4_5453 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5453 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true))] s4_5453 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6389,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5454 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b4_5454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5454 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s4_5454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6489,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5455 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6720]
theorem b4_5455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5455 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true))] s4_5455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6489,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6489 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5456 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6499,w6588]
theorem b4_5456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5456 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,false),(4,true))] s4_5456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6499,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6499 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5457 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6543,w6588]
theorem b4_5457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5457 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(4,true))] s4_5457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5458 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6575,w6588]
theorem b4_5458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5458 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(0,false),(7,true))] s4_5458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6575,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6575 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5459 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5459 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_5459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5460 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6601]
theorem b4_5460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5460 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(3,true)),(false,(0,true),(5,true))] s4_5460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6601] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6601 rfl))))))))))) (by decide +kernel)
def s4_5461 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6618]
theorem b4_5461 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5461 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_5461 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6618] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6618 rfl))))))))))) (by decide +kernel)
def s4_5462 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6653]
theorem b4_5462 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5462 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,false)),(false,(0,true),(5,true))] s4_5462 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6653] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6653 rfl))))))))))) (by decide +kernel)
def s4_5463 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6748]
theorem b4_5463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5463 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true))] s4_5463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6748] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6748 rfl))))))))))) (by decide +kernel)
def s4_5464 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6821]
theorem b4_5464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5464 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,false),(3,true))] s4_5464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6821] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6821 rfl))))))))))) (by decide +kernel)
def s4_5465 : List (BitVec 512) := [w1076,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6852]
theorem b4_5465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5465 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,false),(3,true))] s4_5465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588,v4_6852] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
end NineCert
