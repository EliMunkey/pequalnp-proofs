import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4 : List (BitVec 512) := [w0,w1353,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_4 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,true),(8,true))] s3_4 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_1353,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_1353 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_5 : List (BitVec 512) := [w0,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_5 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_5 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_6 : List (BitVec 512) := [w0,w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_6 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_6 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s3_6 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_7 : List (BitVec 512) := [w0,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_7 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_7 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_7 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_8 : List (BitVec 512) := [w0,w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_8 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_8 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s3_8 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_9 : List (BitVec 512) := [w0,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b3_9 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_9 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_9 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_10 : List (BitVec 512) := [w0,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b3_10 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_10 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s3_10 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_11 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_11 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_11 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_11 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_12 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_12 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_12 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_12 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_13 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_13 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_13 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true))] s3_13 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_14 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_14 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_14 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true))] s3_14 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_15 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_15 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_15 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(6,true),(7,true))] s3_15 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_16 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_16 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_16 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s3_16 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_17 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_17 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_17 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true))] s3_17 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl)))))))))))) (by decide +kernel)
def s3_18 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_18 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_18 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false))] s3_18 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_19 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b3_19 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_19 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true))] s3_19 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_20 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6588]
theorem b3_20 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_20 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true))] s3_20 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_21 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_21 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_21 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s3_21 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_22 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_22 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_22 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,false))] s3_22 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_23 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_23 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_23 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_23 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_24 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b3_24 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_24 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true))] s3_24 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_25 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6588]
theorem b3_25 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_25 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(7,true))] s3_25 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6489,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6489 (PetersenWireProjection.cons pc0_6588 rfl)))))))))))) (by decide +kernel)
def s3_26 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_26 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_26 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true))] s3_26 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_27 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6690]
theorem b3_27 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_27 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true))] s3_27 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl)))))))))))) (by decide +kernel)
def s3_28 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_28 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_28 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true))] s3_28 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5848,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5848 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_29 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_29 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_29 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(6,true))] s3_29 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6136,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6136 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_30 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_30 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_30 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_30 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_31 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_31 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_31 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_31 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_32 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b3_32 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_32 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(8,true),(1,true))] s3_32 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s3_33 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b3_33 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_33 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(8,true),(1,true))] s3_33 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s3_34 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_34 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_34 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s3_34 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_35 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6908]
theorem b3_35 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_35 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(0,false))] s3_35 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl)))))))))))) (by decide +kernel)
def s3_36 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_36 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_36 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_36 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_37 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_37 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_37 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true))] s3_37 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s3_38 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832,w6908]
theorem b3_38 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_38 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s3_38 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832,v0_6908] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 (PetersenWireProjection.cons pc0_6908 rfl)))))))))))) (by decide +kernel)
def s3_39 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_39 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_39 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s3_39 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_40 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6908]
theorem b3_40 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_40 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false))] s3_40 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873,v0_6908] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 (PetersenWireProjection.cons pc0_6908 rfl)))))))))))) (by decide +kernel)
def s3_41 : List (BitVec 512) := [w21,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b3_41 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_41 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true))] s3_41 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6908] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6908 rfl))))))))))) (by decide +kernel)
def s3_82 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_82 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_82 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true))] s3_82 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_83 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6904]
theorem b3_83 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_83 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_83 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588,v0_6904] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6904 rfl)))))))))))) (by decide +kernel)
def s3_84 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_84 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_84 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_84 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_85 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_85 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_85 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s3_85 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_86 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6904]
theorem b3_86 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_86 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(5,true))] s3_86 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873,v0_6904] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 (PetersenWireProjection.cons pc0_6904 rfl)))))))))))) (by decide +kernel)
def s3_87 : List (BitVec 512) := [w34,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b3_87 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_87 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_87 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6904] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6904 rfl))))))))))) (by decide +kernel)
def s3_110 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_110 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_110 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true))] s3_110 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_111 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588,w6890]
theorem b3_111 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_111 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,false),(8,true))] s3_111 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl)))))))))))) (by decide +kernel)
def s3_112 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_112 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_112 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s3_112 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s3_113 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_113 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_113 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s3_113 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s3_114 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873,w6890]
theorem b3_114 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_114 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(1,true))] s3_114 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873,v0_6890] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 (PetersenWireProjection.cons pc0_6890 rfl)))))))))))) (by decide +kernel)
def s3_115 : List (BitVec 512) := [w70,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6890]
theorem b3_115 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_115 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,false),(8,true))] s3_115 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s3_122 : List (BitVec 512) := [w103,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_122 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_122 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s3_122 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1915,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1915 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_123 : List (BitVec 512) := [w103,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_123 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_123 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true))] s3_123 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_1915,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_1915 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_124 : List (BitVec 512) := [w103,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_124 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_124 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s3_124 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2171,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2171 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_125 : List (BitVec 512) := [w103,w2171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_125 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_125 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true))] s3_125 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_2171,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_2171 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_126 : List (BitVec 512) := [w103,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_126 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_126 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true))] s3_126 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3182,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3182 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_127 : List (BitVec 512) := [w103,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_127 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_127 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true))] s3_127 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3182,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3182 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_128 : List (BitVec 512) := [w103,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_128 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_128 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true))] s3_128 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_129 : List (BitVec 512) := [w103,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_129 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_129 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true))] s3_129 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_130 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b3_130 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_130 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true))] s3_130 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_131 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6873]
theorem b3_131 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_131 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(8,true))] s3_131 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_132 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b3_132 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_132 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true))] s3_132 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_133 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6873]
theorem b3_133 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_133 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true))] s3_133 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
def s3_134 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_134 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_134 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true))] s3_134 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s3_135 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_135 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_135 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s3_135 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl)))))))))))) (by decide +kernel)
end NineCert
