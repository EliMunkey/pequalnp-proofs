import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11378 : List (BitVec 512) := [w2302,w2683,w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6300,w6588]
theorem b4_11378 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11378 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11378 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2683,v2_3766,v2_4344,v2_4716,v2_4926,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11379 : List (BitVec 512) := [w2302,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11379 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11379 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11379 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11380 : List (BitVec 512) := [w2302,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_11380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11380 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11381 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11381 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11381 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_11381 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11382 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11382 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11382 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_11382 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11383 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_11383 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11383 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_11383 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6553,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6553 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11384 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_11384 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11384 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(5,true))] s4_11384 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11385 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_11385 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11385 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_11385 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_11386 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b4_11386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11386 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true)),(false,(0,false),(9,true))] s4_11386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_11387 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b4_11387 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11387 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(9,true),(7,true))] s4_11387 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11388 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b4_11388 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11388 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(7,true))] s4_11388 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6464,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11389 : List (BitVec 512) := [w2302,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_11389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11389 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(5,true),(4,true))] s4_11389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11390 : List (BitVec 512) := [w2302,w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_11390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11390 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true))] s4_11390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11391 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6101,w6300,w6588]
theorem b4_11391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11391 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(8,true),(4,true))] s4_11391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11392 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6225,w6300,w6588]
theorem b4_11392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11392 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(8,true),(3,true))] s4_11392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11393 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6436,w6588]
theorem b4_11393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11393 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s4_11393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11394 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6464,w6588]
theorem b4_11394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11394 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(3,true),(7,true)),(false,(8,true),(3,true))] s4_11394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11395 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b4_11395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11395 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false)),(false,(8,true),(3,true))] s4_11395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11396 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6748]
theorem b4_11396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11396 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(8,true),(4,true))] s4_11396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11397 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6785]
theorem b4_11397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11397 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(7,true),(3,true)),(false,(8,true),(3,true))] s4_11397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11398 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6857]
theorem b4_11398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11398 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(8,true),(3,true))] s4_11398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11399 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b4_11399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11399 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(8,true),(4,true))] s4_11399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11400 : List (BitVec 512) := [w2302,w3766,w4344,w5135,w5393,w5585,w6101,w6300,w6522,w6588]
theorem b4_11400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11400 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true)),(false,(8,true),(4,true))] s4_11400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11401 : List (BitVec 512) := [w2302,w3766,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b4_11401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11401 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(8,true),(3,true))] s4_11401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11402 : List (BitVec 512) := [w2302,w3766,w5135,w5393,w5585,w5956,w6101,w6300,w6389,w6588]
theorem b4_11402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11402 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(8,true),(3,true))] s4_11402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2302,v2_3766,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2302 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11406 : List (BitVec 512) := [w2326,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_11406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11406 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s4_11406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11407 : List (BitVec 512) := [w2326,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11407 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11407 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s4_11407 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11408 : List (BitVec 512) := [w2326,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_11408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11408 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s4_11408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11409 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11409 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true))] s4_11409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11410 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_11410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11410 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(8,true))] s4_11410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11411 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_11411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11411 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true))] s4_11411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11412 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_11412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11412 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(9,true))] s4_11412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11413 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_11413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11413 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(7,true))] s4_11413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11414 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_11414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11414 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(7,true))] s4_11414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11415 : List (BitVec 512) := [w2326,w3258,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588]
theorem b4_11415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11415 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(7,true))] s4_11415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11416 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_11416 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11416 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(8,true))] s4_11416 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11417 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_11417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11417 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false))] s4_11417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11418 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_11418 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11418 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(6,true),(2,true)),(false,(1,false),(4,true))] s4_11418 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11419 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_11419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11419 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(0,false),(5,true))] s4_11419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6572,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6572 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11420 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_11420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11420 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(0,false),(9,true))] s4_11420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_11421 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_11421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11421 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(6,true),(2,true)),(false,(1,false),(8,true))] s4_11421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11422 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_11422 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11422 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(9,true),(8,true))] s4_11422 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11423 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b4_11423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11423 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true))] s4_11423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6522,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11424 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_11424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11424 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(7,true)),(false,(7,true),(0,false))] s4_11424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11425 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_11425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11425 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true))] s4_11425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11426 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_11426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11426 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true))] s4_11426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_11427 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6201,w6300,w6588]
theorem b4_11427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11427 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(7,true),(8,true))] s4_11427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6201,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6201 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11428 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_11428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11428 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(7,true),(8,true))] s4_11428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11429 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5848,w5956,w6179,w6300,w6588]
theorem b4_11429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11429 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(7,true),(4,true))] s4_11429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5848,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11430 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6225,w6300,w6588]
theorem b4_11430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11430 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,false),(7,true)),(false,(3,true),(7,true))] s4_11430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11431 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6422,w6588]
theorem b4_11431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11431 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(6,true)),(false,(7,true),(3,true))] s4_11431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11432 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6478,w6588]
theorem b4_11432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11432 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(7,true),(4,true))] s4_11432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6478,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6478 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11433 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6567,w6588]
theorem b4_11433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11433 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,false)),(false,(7,true),(3,true))] s4_11433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6567,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6567 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11434 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6720]
theorem b4_11434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11434 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(3,true)),(false,(7,true),(3,true))] s4_11434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11435 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6807]
theorem b4_11435 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11435 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(7,true),(4,true))] s4_11435 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6807] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6807 rfl))))))))))) (by decide +kernel)
def s4_11436 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6866]
theorem b4_11436 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11436 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,false),(8,true)),(false,(3,true),(7,true))] s4_11436 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6866] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_11437 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6588,w6873]
theorem b4_11437 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11437 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(7,true),(4,true))] s4_11437 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6179,v2_6300,v2_6588,v2_6873] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11438 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b4_11438 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11438 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true))] s4_11438 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11439 : List (BitVec 512) := [w2326,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588,w6832]
theorem b4_11439 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11439 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true)),(false,(4,true),(7,true))] s4_11439 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl)))))))))) (by decide +kernel)
def s4_11440 : List (BitVec 512) := [w2326,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_11440 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11440 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s4_11440 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11441 : List (BitVec 512) := [w2326,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_11441 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11441 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s4_11441 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4344,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11442 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b4_11442 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11442 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(7,true),(3,true))] s4_11442 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11443 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6690]
theorem b4_11443 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11443 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(3,true),(7,true))] s4_11443 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5698,v2_5769,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11444 : List (BitVec 512) := [w2326,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6389,w6588]
theorem b4_11444 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11444 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(2,true),(4,true)),(false,(3,true),(7,true))] s4_11444 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2326,v2_3766,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6179,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2326 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
end NineCert
