import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_15213 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5645,w5956,w6389,w6588]
theorem b4_15213 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15213 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(5,true))] s4_15213 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5645,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5645 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15214 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5646,w5956,w6300,w6588]
theorem b4_15214 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15214 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(6,true))] s4_15214 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5646,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5646 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15215 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5648,w5956,w6300,w6588]
theorem b4_15215 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15215 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,false),(5,true)),(false,(0,true),(5,true))] s4_15215 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5648,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5648 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15216 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5649,w5956,w6300,w6588]
theorem b4_15216 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15216 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_15216 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5649,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5649 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15217 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5650,w5956,w6300,w6588]
theorem b4_15217 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15217 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(6,true))] s4_15217 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5650,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5650 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15218 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5655,w5956,w6300,w6588]
theorem b4_15218 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15218 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(5,true))] s4_15218 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5655,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5655 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15219 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b4_15219 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15219 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(5,true))] s4_15219 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5656,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5656 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15220 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5656,w5956,w6389,w6588]
theorem b4_15220 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15220 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(5,true))] s4_15220 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5656,v3_5956,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5656 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15221 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5657,w5956,w6300,w6588]
theorem b4_15221 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15221 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_15221 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5657,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5657 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15222 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5659,w5956,w6300,w6588]
theorem b4_15222 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15222 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,false)),(false,(0,true),(5,true))] s4_15222 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5659,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5659 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15223 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5660,w5956,w6300,w6588]
theorem b4_15223 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15223 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(6,true))] s4_15223 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5660,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5660 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15224 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5662,w5956,w6300,w6588]
theorem b4_15224 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15224 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(6,true))] s4_15224 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5662,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5662 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15225 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_15225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15225 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(0,false),(5,true))] s4_15225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5665,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5665 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15226 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5666,w5956,w6300,w6588]
theorem b4_15226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15226 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true)),(false,(0,false),(5,true))] s4_15226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5666,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5666 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15227 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5667,w5956,w6300,w6588]
theorem b4_15227 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15227 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(0,false),(5,true))] s4_15227 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5667,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5667 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15228 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5669,w5956,w6300,w6588]
theorem b4_15228 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15228 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true)),(false,(0,false),(5,true))] s4_15228 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5669,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5669 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15229 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5670,w5956,w6300,w6588]
theorem b4_15229 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15229 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(5,true))] s4_15229 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5670,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5670 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15230 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5672,w5956,w6300,w6588]
theorem b4_15230 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15230 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(0,false),(5,true))] s4_15230 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5672,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5672 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15231 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_15231 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15231 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15231 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15232 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_15232 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15232 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(7,false))] s4_15232 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5750,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5750 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15233 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_15233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15233 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(8,false))] s4_15233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5760,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5760 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15234 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_15234 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15234 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(5,true)),(false,(1,true),(0,true))] s4_15234 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5767,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5767 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15235 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_15235 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15235 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true))] s4_15235 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5769,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5769 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15236 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_15236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15236 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s4_15236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15237 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6389,w6588]
theorem b4_15237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15237 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_15237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_5995,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_5995 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15238 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6389,w6588]
theorem b4_15238 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15238 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true))] s4_15238 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6017,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6017 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15239 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6033,w6389,w6588]
theorem b4_15239 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15239 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(6,true))] s4_15239 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6033,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6033 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15240 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_15240 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15240 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15240 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6061,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15241 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_15241 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15241 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(7,false))] s4_15241 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6166,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6166 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15242 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_15242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15242 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,false))] s4_15242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6173,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6173 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15243 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_15243 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15243 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s4_15243 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15244 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_15244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15244 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s4_15244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15245 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6389,w6588]
theorem b4_15245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15245 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s4_15245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15246 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_15246 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15246 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(2,true),(0,false))] s4_15246 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6237,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6237 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15247 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_15247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15247 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(2,true),(0,false))] s4_15247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6499,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6499 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15248 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_15248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15248 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(6,true),(0,false))] s4_15248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6572,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6572 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s4_15249 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_15249 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15249 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15249 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s4_15250 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6599]
theorem b4_15250 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15250 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(6,true)),(false,(0,true),(8,true))] s4_15250 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6599] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6599 rfl))))))))))) (by decide +kernel)
def s4_15251 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6600]
theorem b4_15251 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15251 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,false)),(false,(0,true),(8,true))] s4_15251 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6600] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6600 rfl))))))))))) (by decide +kernel)
def s4_15252 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6601]
theorem b4_15252 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15252 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(7,true)),(false,(0,true),(9,true))] s4_15252 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6601] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6601 rfl))))))))))) (by decide +kernel)
def s4_15253 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6603]
theorem b4_15253 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15253 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(6,true)),(false,(0,true),(8,true))] s4_15253 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6603] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6603 rfl))))))))))) (by decide +kernel)
def s4_15254 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6604]
theorem b4_15254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15254 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s4_15254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6604] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6604 rfl))))))))))) (by decide +kernel)
def s4_15255 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6606]
theorem b4_15255 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15255 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,true)),(false,(0,true),(9,true))] s4_15255 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6606] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6606 rfl))))))))))) (by decide +kernel)
def s4_15256 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6615]
theorem b4_15256 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15256 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,false),(5,true)),(false,(0,true),(8,true))] s4_15256 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6615] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6615 rfl))))))))))) (by decide +kernel)
def s4_15257 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6616]
theorem b4_15257 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15257 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,false)),(false,(0,true),(8,true))] s4_15257 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6616] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6616 rfl))))))))))) (by decide +kernel)
def s4_15258 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_15258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15258 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_15258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6618] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6618 rfl))))))))))) (by decide +kernel)
def s4_15259 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6620]
theorem b4_15259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15259 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,false)),(false,(0,true),(8,true))] s4_15259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6620] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6620 rfl))))))))))) (by decide +kernel)
def s4_15260 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6621]
theorem b4_15260 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15260 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_15260 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6621] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6621 rfl))))))))))) (by decide +kernel)
def s4_15261 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6623]
theorem b4_15261 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15261 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(9,true))] s4_15261 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6623] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6623 rfl))))))))))) (by decide +kernel)
def s4_15262 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6643]
theorem b4_15262 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15262 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,false)),(false,(0,true),(8,true))] s4_15262 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6643] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6643 rfl))))))))))) (by decide +kernel)
def s4_15263 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6644]
theorem b4_15263 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15263 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,false),(1,true)),(false,(0,true),(8,true))] s4_15263 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6644] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6644 rfl))))))))))) (by decide +kernel)
def s4_15264 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6645]
theorem b4_15264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15264 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(2,true)),(false,(0,true),(9,true))] s4_15264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6645] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6645 rfl))))))))))) (by decide +kernel)
def s4_15265 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6647]
theorem b4_15265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(1,true)),(false,(0,true),(8,true))] s4_15265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6647] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6647 rfl))))))))))) (by decide +kernel)
def s4_15266 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_15266 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15266 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s4_15266 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6690] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6690 rfl))))))))))) (by decide +kernel)
def s4_15267 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15267 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15267 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15267 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s4_15268 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_15268 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15268 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s4_15268 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s4_15269 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_15269 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15269 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_15269 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s4_15270 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b4_15270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15270 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s4_15270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s4_15271 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_15271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15271 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(2,true),(0,false))] s4_15271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6821] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6821 rfl))))))))))) (by decide +kernel)
def s4_15272 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_15272 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15272 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(2,true),(0,false))] s4_15272 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6859] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6859 rfl))))))))))) (by decide +kernel)
def s4_15273 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6868]
theorem b4_15273 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15273 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(6,true),(0,false))] s4_15273 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6868] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6868 rfl))))))))))) (by decide +kernel)
def s4_15274 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_15274 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15274 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(2,true),(6,true)),(false,(1,false),(0,false))] s4_15274 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6869] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6869 rfl))))))))))) (by decide +kernel)
def s4_15275 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_15275 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15275 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(0,false))] s4_15275 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6897] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6897 rfl))))))))))) (by decide +kernel)
def s4_15276 : List (BitVec 512) := [w3766,w4179,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_15276 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15276 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s4_15276 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4179,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6905] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4179 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6905 rfl))))))))))) (by decide +kernel)
end NineCert
