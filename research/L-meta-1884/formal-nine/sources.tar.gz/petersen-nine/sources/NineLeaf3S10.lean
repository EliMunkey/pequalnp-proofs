import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3903 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b3_3903 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3903 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false))] s3_3903 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3904 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b3_3904 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3904 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3904 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3905 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6785]
theorem b3_3905 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3905 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(2,true),(6,true))] s3_3905 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_3906 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6857]
theorem b3_3906 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3906 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true)),(false,(8,true),(0,false))] s3_3906 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6857] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6857 rfl)))))))))))) (by decide +kernel)
def s3_3907 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588,w6873]
theorem b3_3907 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3907 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(2,true),(6,true))] s3_3907 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6101,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3908 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3908 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3908 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3908 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3909 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b3_3909 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3909 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_3909 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3910 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_3910 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3910 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(2,true))] s3_3910 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3911 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6567,w6588]
theorem b3_3911 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3911 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(0,false))] s3_3911 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3912 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6866]
theorem b3_3912 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3912 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,false),(8,true))] s3_3912 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl)))))))))))) (by decide +kernel)
def s3_3913 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588,w6873]
theorem b3_3913 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3913 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(8,true))] s3_3913 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3914 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b3_3914 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3914 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true))] s3_3914 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6201,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6201 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3915 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b3_3915 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3915 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,false),(6,true))] s3_3915 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6225,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6225 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3916 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6478,w6588]
theorem b3_3916 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3916 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3916 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3917 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6489,w6588]
theorem b3_3917 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3917 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(2,true))] s3_3917 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3918 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6567,w6588]
theorem b3_3918 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3918 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_3918 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3919 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6832]
theorem b3_3919 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3919 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(6,true),(8,true))] s3_3919 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3920 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588,w6904]
theorem b3_3920 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3920 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(8,true))] s3_3920 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588,v3_6904] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6904 rfl)))))))))))) (by decide +kernel)
def s3_3921 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b3_3921 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3921 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3921 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6478,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6478 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3922 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b3_3922 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3922 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(5,true))] s3_3922 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6489,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6489 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3923 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_3923 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3923 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3923 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3924 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6567,w6588]
theorem b3_3924 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3924 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(5,true),(0,false))] s3_3924 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3925 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588,w6785]
theorem b3_3925 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3925 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true)),(false,(7,true),(6,true))] s3_3925 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_3926 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_3926 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3926 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3926 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3927 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b3_3927 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3927 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true))] s3_3927 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6567,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6567 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3928 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3928 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3928 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3928 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3929 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6807]
theorem b3_3929 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3929 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_3929 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6807 rfl)))))))))))) (by decide +kernel)
def s3_3930 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785,w6866]
theorem b3_3930 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3930 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(0,false),(6,true))] s3_3930 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785,v3_6866] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6866 rfl)))))))))))) (by decide +kernel)
def s3_3931 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6807]
theorem b3_3931 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3931 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_3931 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6807] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6807 rfl))))))))))) (by decide +kernel)
def s3_3932 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6866]
theorem b3_3932 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3932 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true)),(false,(0,false),(5,true))] s3_3932 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6866] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6866 rfl))))))))))) (by decide +kernel)
def s3_3933 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b3_3933 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3933 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true))] s3_3933 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6720] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6720 rfl))))))))))) (by decide +kernel)
def s3_3934 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832]
theorem b3_3934 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3934 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_3934 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s3_3935 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b3_3935 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3935 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(1,true)),(false,(8,true),(7,true))] s3_3935 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6720,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6720 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3936 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6873]
theorem b3_3936 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3936 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true)),(false,(8,true),(7,true))] s3_3936 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6785,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3937 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b3_3937 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3937 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true))] s3_3937 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3938 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b3_3938 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3938 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_3938 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3939 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6588,w6873]
theorem b3_3939 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3939 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(7,true),(8,true))] s3_3939 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6464,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3940 : List (BitVec 512) := [w3766,w3936,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6873]
theorem b3_3940 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3940 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(7,true),(8,true))] s3_3940 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3941 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3941 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3941 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3941 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3942 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3942 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3942 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3942 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3943 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_3943 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3943 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_3943 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3944 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_3944 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3944 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3944 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3945 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_3945 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3945 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3945 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3946 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3946 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3946 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true))] s3_3946 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl))))))))))) (by decide +kernel)
def s3_3947 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_3947 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3947 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_3947 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl))))))))))) (by decide +kernel)
def s3_3948 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_3948 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3948 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(4,true))] s3_3948 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl))))))))))) (by decide +kernel)
def s3_3949 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_3949 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3949 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_3949 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl))))))))))) (by decide +kernel)
def s3_3950 : List (BitVec 512) := [w3766,w3936,w4344,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_3950 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3950 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_3950 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3936,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3936 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3951 : List (BitVec 512) := [w3766,w3943,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3951 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3951 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3951 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3943,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3943 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3952 : List (BitVec 512) := [w3766,w3943,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_3952 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3952 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_3952 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3943,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3943 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl))))))))))) (by decide +kernel)
def s3_3955 : List (BitVec 512) := [w3766,w3946,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3955 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3955 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3955 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3946,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3946 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3957 : List (BitVec 512) := [w3766,w3948,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3957 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3957 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3957 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3948,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3948 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3958 : List (BitVec 512) := [w3766,w3969,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3958 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3958 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s3_3958 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_3969,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_3969 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s3_3959 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b3_3959 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3959 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3959 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3960 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b3_3960 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3960 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(5,true))] s3_3960 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6136,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6136 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3961 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b3_3961 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3961 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true))] s3_3961 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6179,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3962 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b3_3962 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3962 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(6,true))] s3_3962 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6436,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6436 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3963 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b3_3963 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3963 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true))] s3_3963 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6464,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3964 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3964 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3964 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true))] s3_3964 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
def s3_3965 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b3_3965 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3965 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(7,true))] s3_3965 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6748] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6748 rfl)))))))))))) (by decide +kernel)
def s3_3966 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b3_3966 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3966 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(7,true))] s3_3966 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6785] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6785 rfl)))))))))))) (by decide +kernel)
def s3_3967 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b3_3967 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3967 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(5,true))] s3_3967 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6832] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6832 rfl)))))))))))) (by decide +kernel)
def s3_3968 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b3_3968 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3968 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true))] s3_3968 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588,v3_6873] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 (PetersenWireProjection.cons pc3_6873 rfl)))))))))))) (by decide +kernel)
def s3_3969 : List (BitVec 512) := [w3766,w4079,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_3969 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3969 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true))] s3_3969 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5698,v3_5848,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5848 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))))) (by decide +kernel)
end NineCert
