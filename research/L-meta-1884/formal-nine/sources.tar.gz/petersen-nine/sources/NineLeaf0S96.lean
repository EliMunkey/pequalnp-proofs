import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1086 : List (BitVec 512) := [w852,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_1086 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1086 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true)),(false,(5,true),(0,true))] s5_1086 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_2468,v0_2681,v0_3766,v0_4344,v0_4716,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1087 : List (BitVec 512) := [w852,w3766,w4716,w5135,w5393,w5698,w6179,w6389,w6522,w6588]
theorem b5_1087 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1087 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(7,true)),(false,(2,true),(8,true)),(false,(7,true),(8,true))] s5_1087 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1088 : List (BitVec 512) := [w852,w3766,w4926,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b5_1088 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1088 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(7,true),(6,true)),(false,(3,true),(7,true)),(false,(9,true),(3,true))] s5_1088 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4926,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_1089 : List (BitVec 512) := [w852,w3766,w5135,w5393,w5698,w5769,w5956,w6389,w6422,w6588]
theorem b5_1089 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1089 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(5,true),(1,true)),(false,(8,true),(2,true)),(false,(7,true),(4,true))] s5_1089 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6389,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2381 : List (BitVec 512) := [w1292,w3307,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_2381 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2381 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true)),(false,(7,true),(8,true))] s5_2381 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3307,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3307 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2397 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6538,w6588]
theorem b5_2397 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(7,true),(8,true)),(false,(7,true),(8,true))] s5_2397 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1292,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6538,v0_6588] (PetersenWireProjection.cons pc0_1292 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6538 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2475 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2475 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2475 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,false)),(false,(9,true),(0,true)),(false,(5,true),(2,true))] s5_2475 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2488 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_2488 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2488 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true)),(false,(5,true),(1,true))] s5_2488 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2686,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2490 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6813]
theorem b5_2490 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2490 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true)),(false,(5,true),(1,true))] s5_2490 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_2686,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_2686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 rfl)))))))))) (by decide +kernel)
def s5_2496 : List (BitVec 512) := [w1312,w3193,w3766,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2496 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2496 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true)),(false,(4,true),(10,true))] s5_2496 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3193,v0_3766,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3193 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2508 : List (BitVec 512) := [w1312,w3283,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_2508 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2508 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(6,true),(7,true)),(false,(10,true),(1,true))] s5_2508 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3283,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_2513 : List (BitVec 512) := [w1312,w3582,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2513 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2513 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true)),(false,(4,true),(10,true))] s5_2513 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3582,v0_4344,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2526 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w6048,w6179,w6300,w6785]
theorem b5_2526 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2526 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,false),(2,true)),(false,(6,true),(7,true)),(false,(10,true),(1,true))] s5_2526 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6048,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_2564 : List (BitVec 512) := [w1312,w3766,w4602,w5135,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2564 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2564 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(2,true),(6,true)),(false,(4,true),(10,true))] s5_2564 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1312,v0_3766,v0_4602,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1312 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2609 : List (BitVec 512) := [w1328,w3248,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2609 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2609 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2609 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3248,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2630 : List (BitVec 512) := [w1328,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2630 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2630 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2630 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2631 : List (BitVec 512) := [w1328,w3739,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_2631 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2631 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_2631 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3739,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3739 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_2632 : List (BitVec 512) := [w1328,w3741,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6821]
theorem b5_2632 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2632 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(1,false),(10,true))] s5_2632 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3741,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6821] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3741 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6821 rfl)))))))))) (by decide +kernel)
def s5_2640 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2640 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2640 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true))] s5_2640 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2668 : List (BitVec 512) := [w1328,w3766,w4716,w5135,w5393,w5675,w5698,w5956,w6300,w6690]
theorem b5_2668 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2668 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1328,v0_3766,v0_4716,v0_5135,v0_5393,v0_5675,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1328 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2809 : List (BitVec 512) := [w1374,w3360,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2809 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2809 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2809 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3360,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3360 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2810 : List (BitVec 512) := [w1374,w3582,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6832]
theorem b5_2810 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2810 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true)),(false,(8,true),(10,true))] s5_2810 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_2811 : List (BitVec 512) := [w1374,w3644,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2811 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2811 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2811 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3644,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2828 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2828 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2828 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2828 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2879 : List (BitVec 512) := [w1384,w3248,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_2879 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2879 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2879 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3248,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2891 : List (BitVec 512) := [w1384,w3283,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_2891 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2891 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true)),(false,(7,true),(10,true))] s5_2891 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3283,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_2892 : List (BitVec 512) := [w1384,w3283,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6690]
theorem b5_2892 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2892 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2892 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3283,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_6061,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2893 : List (BitVec 512) := [w1384,w3283,w3766,w4716,w5135,w5393,w5585,w6201,w6300,w6690]
theorem b5_2893 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2893 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2893 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3283,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_6201,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3283 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2909 : List (BitVec 512) := [w1384,w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2909 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2909 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(4,true),(10,true))] s5_2909 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2910 : List (BitVec 512) := [w1384,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_2910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2910 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2911 : List (BitVec 512) := [w1384,w3644,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_2911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2911 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(4,true),(10,true))] s5_2911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3644,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_2912 : List (BitVec 512) := [w1384,w3644,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_2912 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2912 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2912 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3644,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2913 : List (BitVec 512) := [w1384,w3739,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_2913 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2913 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_2913 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3739,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3739 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_2914 : List (BitVec 512) := [w1384,w3751,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6868]
theorem b5_2914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2914 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(1,false),(10,true))] s5_2914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3751,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6868] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3751 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6868 rfl)))))))))) (by decide +kernel)
def s5_2930 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_2930 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s5_2930 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_2954 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w6048,w6179,w6300,w6785]
theorem b5_2954 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true)),(false,(7,true),(10,true))] s5_2954 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6048,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_2976 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b5_2976 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2976 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2976 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2978 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w6048,w6061,w6300,w6690]
theorem b5_2978 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2978 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2978 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6061,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2979 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w6048,w6201,w6300,w6690]
theorem b5_2979 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2979 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2979 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4716,v0_5135,v0_5393,v0_5585,v0_6048,v0_6201,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_2981 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5675,w5698,w5956,w6300,w6690]
theorem b5_2981 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2981 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_2981 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1384,v0_3766,v0_4716,v0_5135,v0_5393,v0_5675,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1384 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_3025 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3025 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3025 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s5_3025 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3046 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_3046 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3046 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true)),(false,(4,true),(10,true))] s5_3046 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1388,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6225,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1388 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_3070 : List (BitVec 512) := [w1403,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300]
theorem b5_3070 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3070 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(1,true)),(false,(8,true),(0,true)),(false,(10,true),(1,true))] s5_3070 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_1664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_1664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 rfl)))))))))) (by decide +kernel)
def s5_3071 : List (BitVec 512) := [w1403,w1664,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6890]
theorem b5_3071 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3071 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,false),(1,true)),(false,(9,true),(0,true)),(false,(9,true),(1,true))] s5_3071 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_1664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_1664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_3128 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_3128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3128 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s5_3128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3129 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_3129 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3129 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,false),(7,true)),(false,(6,true),(2,true)),(false,(10,true),(1,true))] s5_3129 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_3130 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6890]
theorem b5_3130 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3130 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true)),(false,(3,true),(7,true))] s5_3130 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_3131 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6522,w6588]
theorem b5_3131 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3131 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(3,true),(7,true))] s5_3131 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3132 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_3132 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3132 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(3,true),(6,true)),(false,(3,true),(7,true))] s5_3132 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3133 : List (BitVec 512) := [w1403,w3582,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b5_3133 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3133 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(6,true),(7,true)),(false,(3,true),(7,true))] s5_3133 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3134 : List (BitVec 512) := [w1403,w3582,w4716,w5187,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b5_3134 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3134 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true)),(false,(1,true),(5,true))] s5_3134 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3582,v0_4716,v0_5187,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3135 : List (BitVec 512) := [w1403,w3666,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_3135 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3135 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(7,true),(8,true))] s5_3135 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3666,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3136 : List (BitVec 512) := [w1403,w3686,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3136 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3136 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true))] s5_3136 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3686,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3156 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3156 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3156 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,false),(7,true)),(false,(9,true),(0,true))] s5_3156 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_3157 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b5_3157 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3157 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,false),(8,true)),(false,(9,true),(1,true))] s5_3157 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_3168 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b5_3168 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3168 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,false),(1,true)),(false,(7,true),(8,true)),(false,(10,true),(1,true))] s5_3168 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3169 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6890]
theorem b5_3169 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3169 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,false),(1,true)),(false,(7,true),(8,true)),(false,(10,true),(1,true))] s5_3169 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6890] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6890 rfl)))))))))) (by decide +kernel)
def s5_3194 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6522,w6588]
theorem b5_3194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3194 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(8,true),(7,true)),(false,(1,true),(5,true))] s5_3194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1403,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_1403 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3253 : List (BitVec 512) := [w1415,w3248,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_3253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3253 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_3253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3248,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3248 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_3274 : List (BitVec 512) := [w1415,w3582,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690]
theorem b5_3274 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3274 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_3274 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3582,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
def s5_3275 : List (BitVec 512) := [w1415,w3739,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807]
theorem b5_3275 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3275 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(2,false),(10,true))] s5_3275 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3739,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6807] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3739 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_3276 : List (BitVec 512) := [w1415,w3761,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6905]
theorem b5_3276 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3276 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true)),(false,(1,false),(10,true))] s5_3276 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3761,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6905] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3761 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6905 rfl)))))))))) (by decide +kernel)
def s5_3282 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3282 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3282 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s5_3282 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_3305 : List (BitVec 512) := [w1415,w3766,w4716,w5135,w5393,w5675,w5698,w5956,w6300,w6690]
theorem b5_3305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3305 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true)),(false,(3,true),(10,true))] s5_3305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4716,v0_5135,v0_5393,v0_5675,v0_5698,v0_5956,v0_6300,v0_6690] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 rfl)))))))))) (by decide +kernel)
end NineCert
