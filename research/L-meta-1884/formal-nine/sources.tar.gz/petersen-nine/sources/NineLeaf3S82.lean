import NinePin3
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_2898 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2898 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2898 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(2,true),(1,true))] s5_2898 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3293,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3293 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2915 : List (BitVec 512) := [w1384,w3766,w4326,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b5_2915 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2915 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_2915 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4326,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6866] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4326 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6866 rfl)))))))))) (by decide +kernel)
def s5_2932 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748]
theorem b5_2932 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2932 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s5_2932 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6748] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6748 rfl)))))))))) (by decide +kernel)
def s5_2943 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w6180,w6300,w6832]
theorem b5_2943 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2943 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s5_2943 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6180,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6180 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_2946 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6832]
theorem b5_2946 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2946 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s5_2946 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6300,v3_6832] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6832 rfl)))))))))) (by decide +kernel)
def s5_2951 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b5_2951 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2951 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s5_2951 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6179,v3_6300,v3_6807] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6807 rfl)))))))))) (by decide +kernel)
def s5_2952 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5956,w6180,w6300,w6785]
theorem b5_2952 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2952 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s5_2952 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5956,v3_6180,v3_6300,v3_6785] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6180 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6785 rfl)))))))))) (by decide +kernel)
def s5_2963 : List (BitVec 512) := [w1384,w3766,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_2963 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2963 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s5_2963 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4403,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4403 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_2983 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b5_2983 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2983 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(0,true),(8,true))] s5_2983 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1384,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6179,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1384 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3057 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3057 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3057 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(1,true),(4,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s5_3057 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1390,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1390 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3058 : List (BitVec 512) := [w1390,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3058 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3058 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s5_3058 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1390,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1390 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3064 : List (BitVec 512) := [w1403,w1664,w3182,w3766,w4344,w4716,w5135,w5393,w5585,w5956]
theorem b5_3064 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3064 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true)),(false,(8,true),(1,true))] s5_3064 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_1664,v3_3182,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_1664 (PetersenWireProjection.cons pc3_3182 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 rfl)))))))))) (by decide +kernel)
def s5_3067 : List (BitVec 512) := [w1403,w1664,w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6873]
theorem b5_3067 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3067 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(8,true),(0,true)),(false,(8,true),(1,true))] s5_3067 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_1664,v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6873] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_1664 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3099 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6690]
theorem b5_3099 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3099 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_3099 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3108 : List (BitVec 512) := [w1403,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690]
theorem b5_3108 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3108 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_3108 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3111 : List (BitVec 512) := [w1403,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588]
theorem b5_3111 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3111 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_3111 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_2488,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_2488 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3137 : List (BitVec 512) := [w1403,w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6464,w6873]
theorem b5_3137 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3137 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(7,true),(5,true)),(false,(9,true),(1,true))] s5_3137 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6464,v3_6873] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6464 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3138 : List (BitVec 512) := [w1403,w3766,w4327,w4716,w5135,w5393,w5585,w5956,w6522,w6873]
theorem b5_3138 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3138 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(7,true)),(false,(9,true),(1,true))] s5_3138 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4327,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6522,v3_6873] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4327 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3162 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6465,w6873]
theorem b5_3162 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3162 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(7,true),(6,true)),(false,(7,true),(5,true)),(false,(9,true),(1,true))] s5_3162 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6465,v3_6873] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6465 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3170 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6523,w6873]
theorem b5_3170 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3170 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(7,true)),(false,(6,true),(7,true)),(false,(9,true),(1,true))] s5_3170 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6523,v3_6873] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6523 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3175 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6690]
theorem b5_3175 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3175 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s5_3175 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3183 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6690]
theorem b5_3183 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3183 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(5,true)),(false,(8,true),(7,true))] s5_3183 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_6179,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3188 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6522,w6588]
theorem b5_3188 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3188 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(6,true),(5,true)),(false,(8,true),(7,true))] s5_3188 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_6179,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3195 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6522,w6690]
theorem b5_3195 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3195 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(7,true),(6,true)),(false,(1,true),(4,true))] s5_3195 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4716,v3_5187,v3_5393,v3_5585,v3_5956,v3_6522,v3_6690] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5187 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3202 : List (BitVec 512) := [w1403,w3766,w4344,w4926,w5135,w5393,w5585,w6101,w6522,w6588]
theorem b5_3202 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3202 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,false),(7,true)),(false,(2,true),(6,true)),(false,(8,true),(7,true))] s5_3202 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1403,v3_3766,v3_4344,v3_4926,v3_5135,v3_5393,v3_5585,v3_6101,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_1403 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3252 : List (BitVec 512) := [w1415,w3202,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3252 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3252 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(0,false))] s5_3252 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3202,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3202 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3257 : List (BitVec 512) := [w1415,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3257 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3257 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,true),(8,true)),(false,(2,true),(6,false))] s5_3257 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3258,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3265 : List (BitVec 512) := [w1415,w3303,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3265 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3265 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(2,true),(1,true))] s5_3265 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3303,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3303 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3277 : List (BitVec 512) := [w1415,w3766,w4338,w4716,w5135,w5393,w5585,w5956,w6300,w6904]
theorem b5_3277 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3277 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s5_3277 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4338,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6904] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4338 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6904 rfl)))))))))) (by decide +kernel)
def s5_3285 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6380,w6588]
theorem b5_3285 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3285 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s5_3285 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6380,v3_6588] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6380 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3288 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6465,w6873]
theorem b5_3288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3288 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(8,true),(9,true))] s5_3288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6465,v3_6873] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6465 (PetersenWireProjection.cons pc3_6873 rfl)))))))))) (by decide +kernel)
def s5_3297 : List (BitVec 512) := [w1415,w3766,w4413,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3297 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s5_3297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1415,v3_3766,v3_4413,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1415 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4413 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3312 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3312 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3312 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true))] s5_3312 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1417,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1417 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3313 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3313 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3313 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(2,true)),(false,(9,true),(0,true))] s5_3313 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1417,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1417 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3323 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3323 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3323 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(0,true),(9,true))] s5_3323 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1423,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1423 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3324 : List (BitVec 512) := [w1423,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b5_3324 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3324 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,true)),(false,(0,false),(6,true)),(false,(9,true),(0,true))] s5_3324 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1423,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6690] (PetersenWireProjection.cons pc3_1423 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6690 rfl)))))))))) (by decide +kernel)
def s5_3337 : List (BitVec 512) := [w1710,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_3337 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3337 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_3337 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4344,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3338 : List (BitVec 512) := [w1710,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3338 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3338 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_3338 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4716,v3_4926,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_4926 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3339 : List (BitVec 512) := [w1710,w3766,w4716,w5135,w5393,w5698,w5956,w6177,w6300,w6588]
theorem b5_3339 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3339 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,true))] s5_3339 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6177,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6177 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3340 : List (BitVec 512) := [w1710,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_3340 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3340 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_3340 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1710,v3_3766,v3_4716,v3_5135,v3_5393,v3_5698,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_1710 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl))))))))) (by decide +kernel)
def s5_3342 : List (BitVec 512) := [w1713,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3342 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3342 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [] s5_3342 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_1713,v3_3766,v3_4716,v3_5135,v3_5393,v3_5585,v3_5956,v3_6300,v3_6389,v3_6588] (PetersenWireProjection.cons pc3_1713 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5393 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3371 : List (BitVec 512) := [w2212,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_3371 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3371 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s5_3371 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2212,v3_3766,v3_4344,v3_4716,v3_5135,v3_5471,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2212 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5471 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3372 : List (BitVec 512) := [w2214,w2468,w2681,w3766,w4344,w4716,w5585,w5956,w6300,w6588]
theorem b5_3372 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3372 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true)),(false,(5,true),(0,true))] s5_3372 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_2681,v3_3766,v3_4344,v3_4716,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_2681 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3373 : List (BitVec 512) := [w2214,w2468,w3258,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3373 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3373 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,false))] s5_3373 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3258,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3258 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3374 : List (BitVec 512) := [w2214,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3374 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3374 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true))] s5_3374 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3375 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w5956,w6389,w6549,w6588]
theorem b5_3375 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3375 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s5_3375 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3376 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_3376 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3376 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_3376 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_6101,v3_6300,v3_6543,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6543 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3377 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w6101,w6389,w6522,w6588]
theorem b5_3377 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3377 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(3,true),(7,true))] s5_3377 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_6101,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3378 : List (BitVec 512) := [w2214,w2468,w3766,w4716,w5135,w5585,w6179,w6389,w6522,w6588]
theorem b5_3378 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3378 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(6,true),(7,true))] s5_3378 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2214,v3_2468,v3_3766,v3_4716,v3_5135,v3_5585,v3_6179,v3_6389,v3_6522,v3_6588] (PetersenWireProjection.cons pc3_2214 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6179 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6522 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3381 : List (BitVec 512) := [w2217,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3381 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3381 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3381 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2217,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2217 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3383 : List (BitVec 512) := [w2219,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3383 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3383 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3383 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2219,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2219 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3384 : List (BitVec 512) := [w2220,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3384 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3384 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_3384 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3385 : List (BitVec 512) := [w2220,w2491,w3766,w4716,w5135,w5585,w5956,w6389,w6422,w6588]
theorem b5_3385 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3385 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_3385 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6422,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6422 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3386 : List (BitVec 512) := [w2220,w2491,w3766,w4716,w5135,w5585,w5956,w6389,w6549,w6588]
theorem b5_3386 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3386 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_3386 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4716,v3_5135,v3_5585,v3_5956,v3_6389,v3_6549,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6389 (PetersenWireProjection.cons pc3_6549 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3387 : List (BitVec 512) := [w2220,w2491,w3766,w4716,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_3387 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3387 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(1,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s5_3387 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2220,v3_2491,v3_3766,v3_4716,v3_5135,v3_5585,v3_6061,v3_6101,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2220 (PetersenWireProjection.cons pc3_2491 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_6061 (PetersenWireProjection.cons pc3_6101 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3388 : List (BitVec 512) := [w2221,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3388 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3388 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_3388 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2221,v3_2494,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2221 (PetersenWireProjection.cons pc3_2494 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3389 : List (BitVec 512) := [w2222,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3389 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3389 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_3389 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2222,v3_2527,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2222 (PetersenWireProjection.cons pc3_2527 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3501 : List (BitVec 512) := [w2280,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3501 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3501 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_3501 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2280,v3_2468,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2280 (PetersenWireProjection.cons pc3_2468 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3642 : List (BitVec 512) := [w2381,w3766,w4079,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3642 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3642 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3642 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4079,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4079 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3643 : List (BitVec 512) := [w2381,w3766,w4161,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3643 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3643 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3643 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4161,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4161 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3644 : List (BitVec 512) := [w2381,w3766,w4344,w4547,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_3644 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3644 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3644 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4344,v3_4547,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4547 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3660 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6075,w6300,w6588]
theorem b5_3660 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3660 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3660 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6075,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6075 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3663 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6350,w6588]
theorem b5_3663 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3663 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3663 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4344,v3_4716,v3_5135,v3_5585,v3_5956,v3_6300,v3_6350,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5585 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6350 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
def s5_3672 : List (BitVec 512) := [w2381,w3766,w4344,w4716,w5135,w5698,w5956,w6017,w6300,w6588]
theorem b5_3672 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3672 := by
  intro m le c
  apply rejects_sound r3 i8 11 tgt (small3 adj) hot3 [(false,(4,true),(6,false)),(false,(0,true),(6,true)),(false,(5,true),(0,true))] s5_3672 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v3_2381,v3_3766,v3_4344,v3_4716,v3_5135,v3_5698,v3_5956,v3_6017,v3_6300,v3_6588] (PetersenWireProjection.cons pc3_2381 (PetersenWireProjection.cons pc3_3766 (PetersenWireProjection.cons pc3_4344 (PetersenWireProjection.cons pc3_4716 (PetersenWireProjection.cons pc3_5135 (PetersenWireProjection.cons pc3_5698 (PetersenWireProjection.cons pc3_5956 (PetersenWireProjection.cons pc3_6017 (PetersenWireProjection.cons pc3_6300 (PetersenWireProjection.cons pc3_6588 rfl)))))))))) (by decide +kernel)
end NineCert
