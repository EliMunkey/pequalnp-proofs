import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1098 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_1098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1098 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(6,true))] s4_1098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5848,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5848 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1099 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_1099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1099 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(6,true)),(false,(0,true),(8,true))] s4_1099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6026,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6026 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1100 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6037,w6300,w6588]
theorem b4_1100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1100 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,true)),(false,(0,true),(8,true))] s4_1100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6037,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6037 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1101 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_1101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1101 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,true),(2,true)),(false,(0,true),(8,true))] s4_1101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6044,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6044 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1102 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6588]
theorem b4_1102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1102 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(0,false),(7,true))] s4_1102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6136,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6136 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1103 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_1103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1103 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_1103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6201,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6201 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1104 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_1104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1104 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true))] s4_1104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6225,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6225 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1105 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6897]
theorem b4_1105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1105 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false))] s4_1105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6897] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6897 rfl))))))))))) (by decide +kernel)
def s4_1106 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6905]
theorem b4_1106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1106 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(0,false))] s4_1106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6905] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6905 rfl))))))))))) (by decide +kernel)
def s4_1107 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6906]
theorem b4_1107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1107 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(0,false),(7,true))] s4_1107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6906] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6906 rfl))))))))))) (by decide +kernel)
def s4_1108 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6910]
theorem b4_1108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1108 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,false),(0,false))] s4_1108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6910] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6910 rfl))))))))))) (by decide +kernel)
def s4_1109 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_1109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1109 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(0,false),(8,true))] s4_1109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6912] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6912 rfl))))))))))) (by decide +kernel)
def s4_1110 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6917]
theorem b4_1110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1110 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(0,false),(7,true))] s4_1110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6917] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6917 rfl))))))))))) (by decide +kernel)
def s4_1111 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_1111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1111 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(5,true))] s4_1111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6720,v1_6890] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_1112 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_1112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1112 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(5,true),(1,false))] s4_1112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6813,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6813 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1113 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873]
theorem b4_1113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1113 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true))] s4_1113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6464,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1114 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_1114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1114 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(8,true),(9,true))] s4_1114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_1115 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_1115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1115 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_1115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1116 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6785,w6873]
theorem b4_1116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1116 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(5,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true))] s4_1116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1117 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6567,w6588,w6873]
theorem b4_1117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1117 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(9,true),(1,false))] s4_1117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6567,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6567 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1118 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b4_1118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1118 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(1,true)),(false,(7,true),(3,true))] s4_1118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6061,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6061 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1119 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_1119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1119 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(2,true)),(false,(8,true),(4,true)),(false,(9,true),(8,true))] s4_1119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1120 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588,w6908]
theorem b4_1120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1120 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(0,false)),(false,(8,true),(7,true))] s4_1120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6300,v1_6588,v1_6908] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6908 rfl))))))))))) (by decide +kernel)
def s4_1121 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6588,w6873]
theorem b4_1121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1121 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(3,true)),(false,(7,true),(6,true)),(false,(8,true),(9,true))] s4_1121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6179,v1_6522,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1122 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_1122 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1122 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(6,true),(3,true))] s4_1122 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1123 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_1123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1123 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(6,true),(7,true))] s4_1123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5698,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1124 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6464,w6588,w6873]
theorem b4_1124 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1124 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(9,true),(7,true))] s4_1124 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6464,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6464 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1125 : List (BitVec 512) := [w171,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785,w6873]
theorem b4_1125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1125 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(6,true),(5,true)),(false,(8,true),(4,true)),(false,(7,true),(5,true))] s4_1125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5956,v1_6179,v1_6300,v1_6785,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6785 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1126 : List (BitVec 512) := [w171,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_1126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1126 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(1,true)),(false,(3,true),(7,true))] s4_1126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_4926,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4926 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1127 : List (BitVec 512) := [w171,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6895]
theorem b4_1127 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1127 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(3,true),(0,false)),(false,(4,true),(7,true))] s4_1127 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588,v1_6895] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6895 rfl))))))))))) (by decide +kernel)
def s4_1128 : List (BitVec 512) := [w171,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_1128 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1128 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true))] s4_1128 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1129 : List (BitVec 512) := [w171,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720,w6873]
theorem b4_1129 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1129 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(4,true),(8,true)),(false,(5,true),(4,true))] s4_1129 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4344,v1_5135,v1_5393,v1_5585,v1_5956,v1_6101,v1_6300,v1_6720,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6720 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1130 : List (BitVec 512) := [w171,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b4_1130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1130 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(4,true),(8,true)),(false,(3,true),(0,false))] s4_1130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588,v1_6890] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_1131 : List (BitVec 512) := [w171,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1131 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1131 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_1131 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3935,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3935 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_1132 : List (BitVec 512) := [w171,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_1132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1132 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(3,true),(7,true)),(false,(0,true),(2,true)),(false,(0,true),(2,true))] s4_1132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_171,v1_3935,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_171 (PetersenWireProjection.cons pc1_3935 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1236 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5122,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1236 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1236 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1236 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_192,v1_3766,v1_4344,v1_4716,v1_5122,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_192 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5122 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1254 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6898]
theorem b4_1254 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1254 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(1,true)),(false,(8,true),(4,true)),(false,(1,true),(0,false))] s4_1254 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_192,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6898] (PetersenWireProjection.cons pc1_192 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6898 rfl))))))))))) (by decide +kernel)
def s4_1270 : List (BitVec 512) := [w195,w1170,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1270 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_1170,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_1170 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1283 : List (BitVec 512) := [w195,w1605,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1283 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1283 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1283 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_1605,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_1605 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1304 : List (BitVec 512) := [w195,w1845,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1304 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1304 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1304 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_1845,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_1845 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1315 : List (BitVec 512) := [w195,w2113,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1315 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1315 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1315 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2113,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2113 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1328 : List (BitVec 512) := [w195,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1328 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1336 : List (BitVec 512) := [w195,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1336 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1336 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1336 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1337 : List (BitVec 512) := [w195,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1337 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1337 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1337 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1338 : List (BitVec 512) := [w195,w2608,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1338 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1338 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1338 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2608,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2608 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1339 : List (BitVec 512) := [w195,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1339 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1339 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1339 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1340 : List (BitVec 512) := [w195,w2636,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1340 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2636,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2636 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1341 : List (BitVec 512) := [w195,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1341 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1342 : List (BitVec 512) := [w195,w2650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_1342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1342 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2650,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6588,v1_6873] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2650 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6873 rfl))))))))))) (by decide +kernel)
def s4_1343 : List (BitVec 512) := [w195,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1343 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1343 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1343 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1344 : List (BitVec 512) := [w195,w2694,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1344 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1344 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1344 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2694,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2694 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1347 : List (BitVec 512) := [w195,w2797,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1347 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1347 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1347 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2797,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2797 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1358 : List (BitVec 512) := [w195,w2989,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1358 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1358 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1358 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_2989,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_2989 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1386 : List (BitVec 512) := [w195,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1386 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1386 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1386 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1398 : List (BitVec 512) := [w195,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1398 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1408 : List (BitVec 512) := [w195,w3766,w4344,w4716,w4982,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1408 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1408 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1408 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_4982,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4982 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1409 : List (BitVec 512) := [w195,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1409 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1409 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1409 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1410 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1410 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1410 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1410 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1411 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5031,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1411 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5031,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5031 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1412 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1412 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1412 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1412 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1413 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5122,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1413 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1413 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(8,true)),(false,(1,true),(0,false))] s4_1413 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5122,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5122 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1414 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5126,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1414 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1414 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1414 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5126,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5126 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1415 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5138,w5393,w5585,w5956,w6300,w6588]
theorem b4_1415 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1415 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1415 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5138,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5138 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_1417 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6588]
theorem b4_1417 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1417 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(9,true))] s4_1417 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_195,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_195 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
