import NinePin132
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4921 : List (BitVec 512) := [w1022,w3766,w4344,w4589,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4921 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4921 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_4921 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1022,v132_3766,v132_4344,v132_4589,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_1022 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4589 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_4930 : List (BitVec 512) := [w1025,w3766,w4344,w4591,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4930 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_4930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1025,v132_3766,v132_4344,v132_4591,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_1025 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4591 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_4932 : List (BitVec 512) := [w1026,w3766,w4344,w4592,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4932 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_4932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1026,v132_3766,v132_4344,v132_4592,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_1026 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4592 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_7690 : List (BitVec 512) := [w1312,w3177,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_7690 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7690 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_7690 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1312,v132_3177,v132_3766,v132_4344,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_1312 (PetersenWireProjection.cons pc132_3177 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl))))))))))) (by decide +kernel)
def s4_7692 : List (BitVec 512) := [w1312,w3177,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b4_7692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7692 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_7692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1312,v132_3177,v132_3766,v132_4344,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6813] (PetersenWireProjection.cons pc132_1312 (PetersenWireProjection.cons pc132_3177 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6813 rfl))))))))))) (by decide +kernel)
def s4_15857 : List (BitVec 512) := [w3766,w4344,w4369,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15857 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_15857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4369,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4369 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl))))))))))) (by decide +kernel)
def s4_15860 : List (BitVec 512) := [w3766,w4344,w4371,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15860 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_15860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4371,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4371 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl))))))))))) (by decide +kernel)
def s4_15861 : List (BitVec 512) := [w3766,w4344,w4372,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_15861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15861 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_15861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4372,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4372 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl))))))))))) (by decide +kernel)
def s4_15928 : List (BitVec 512) := [w3766,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6813]
theorem b4_15928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15928 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_15928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4392,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6720,v132_6813] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4392 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 (PetersenWireProjection.cons pc132_6813 rfl))))))))))) (by decide +kernel)
def s4_16258 : List (BitVec 512) := [w3766,w4344,w4459,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16258 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16258 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_16258 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4459,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4459 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_16259 : List (BitVec 512) := [w3766,w4344,w4461,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16259 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16259 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_16259 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4461,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4461 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_16262 : List (BitVec 512) := [w3766,w4344,w4463,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_16262 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16262 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_16262 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4463,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4463 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_16325 : List (BitVec 512) := [w3766,w4344,w4483,w4716,w5135,w5393,w5585,w6101,w6225,w6300,w6588]
theorem b4_16325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16325 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_16325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4483,v132_4716,v132_5135,v132_5393,v132_5585,v132_6101,v132_6225,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4483 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl))))))))))) (by decide +kernel)
def s4_17350 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6653,w6690]
theorem b4_17350 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17350 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_17350 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4716,v132_5135,v132_5393,v132_5585,v132_5769,v132_5956,v132_6300,v132_6653,v132_6690] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6653 (PetersenWireProjection.cons pc132_6690 rfl))))))))))) (by decide +kernel)
def s4_17638 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6690,w6857]
theorem b4_17638 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17638 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s4_17638 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6225,v132_6300,v132_6690,v132_6857] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6690 (PetersenWireProjection.cons pc132_6857 rfl))))))))))) (by decide +kernel)
def s5_967 : List (BitVec 512) := [w637,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_967 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_967 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_967 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_637,v132_3766,v132_4344,v132_5135,v132_5393,v132_5585,v132_6061,v132_6101,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_637 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6061 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_968 : List (BitVec 512) := [w637,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b5_968 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_968 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_968 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_637,v132_3766,v132_4344,v132_5135,v132_5393,v132_5698,v132_5769,v132_5956,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_637 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5698 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_2482 : List (BitVec 512) := [w1312,w2681,w3766,w4344,w5393,w5698,w5769,w5956,w6300,w6720]
theorem b5_2482 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2482 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_2482 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1312,v132_2681,v132_3766,v132_4344,v132_5393,v132_5698,v132_5769,v132_5956,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_1312 (PetersenWireProjection.cons pc132_2681 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5698 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_2548 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_2548 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2548 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_2548 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1312,v132_3766,v132_4344,v132_5135,v132_5393,v132_5585,v132_6061,v132_6101,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_1312 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6061 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_2557 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5698,w5956,w6225,w6300,w6720]
theorem b5_2557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2557 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_2557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1312,v132_3766,v132_4344,v132_5135,v132_5393,v132_5698,v132_5956,v132_6225,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_1312 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5698 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_3048 : List (BitVec 512) := [w1388,w3766,w4344,w5135,w5393,w5585,w6061,w6101,w6300,w6720]
theorem b5_3048 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3048 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_3048 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_1388,v132_3766,v132_4344,v132_5135,v132_5393,v132_5585,v132_6061,v132_6101,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_1388 (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6061 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5446 : List (BitVec 512) := [w3766,w4295,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5446 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5446 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5446 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4295,v132_4344,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4295 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_5495 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_5495 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5495 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5495 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4392,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4392 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5496 : List (BitVec 512) := [w3766,w4344,w4392,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_5496 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5496 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5496 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4392,v132_5135,v132_5393,v132_5585,v132_5956,v132_6225,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4392 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5530 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b5_5530 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5530 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5530 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4404,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6857] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4404 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6857 rfl)))))))))) (by decide +kernel)
def s5_5532 : List (BitVec 512) := [w3766,w4344,w4404,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b5_5532 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5532 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5532 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4404,v132_5135,v132_5393,v132_5585,v132_5769,v132_5956,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4404 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5533 : List (BitVec 512) := [w3766,w4344,w4404,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_5533 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5533 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5533 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4404,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4404 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5534 : List (BitVec 512) := [w3766,w4344,w4404,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b5_5534 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5534 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5534 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4404,v132_5135,v132_5393,v132_5585,v132_5956,v132_6225,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4404 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5552 : List (BitVec 512) := [w3766,w4344,w4416,w4716,w5135,w5393,w5585,w5956,w6300,w6857]
theorem b5_5552 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5552 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5552 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4416,v132_4716,v132_5135,v132_5393,v132_5585,v132_5956,v132_6300,v132_6857] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4416 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6857 rfl)))))))))) (by decide +kernel)
def s5_5553 : List (BitVec 512) := [w3766,w4344,w4416,w5135,w5393,w5585,w5956,w6101,w6300,w6720]
theorem b5_5553 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5553 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5553 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4416,v132_5135,v132_5393,v132_5585,v132_5956,v132_6101,v132_6300,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4416 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5586 : List (BitVec 512) := [w3766,w4344,w4483,w5135,w5393,w5585,w6101,w6300,w6588,w6720]
theorem b5_5586 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5586 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5586 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4483,v132_5135,v132_5393,v132_5585,v132_6101,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4483 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5616 : List (BitVec 512) := [w3766,w4344,w4517,w5135,w5393,w5585,w6101,w6300,w6588,w6720]
theorem b5_5616 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5616 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5616 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4517,v132_5135,v132_5393,v132_5585,v132_6101,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4517 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5620 : List (BitVec 512) := [w3766,w4344,w4520,w5135,w5393,w5585,w6101,w6300,w6588,w6720]
theorem b5_5620 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5620 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5620 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4520,v132_5135,v132_5393,v132_5585,v132_6101,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4520 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5585 (PetersenWireProjection.cons pc132_6101 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5648 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w5956,w6225,w6300,w6588]
theorem b5_5648 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5648 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5648 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4563,v132_4716,v132_5135,v132_5393,v132_5956,v132_6225,v132_6300,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4563 (PetersenWireProjection.cons pc132_4716 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6225 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_5650 : List (BitVec 512) := [w3766,w4344,w4563,w5135,w5393,w5769,w5956,w6300,w6422,w6588]
theorem b5_5650 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5650 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5650 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4563,v132_5135,v132_5393,v132_5769,v132_5956,v132_6300,v132_6422,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4563 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6422 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_5654 : List (BitVec 512) := [w3766,w4344,w4572,w5135,w5393,w5769,w5956,w6300,w6422,w6588]
theorem b5_5654 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5654 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5654 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4572,v132_5135,v132_5393,v132_5769,v132_5956,v132_6300,v132_6422,v132_6588] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4572 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6422 (PetersenWireProjection.cons pc132_6588 rfl)))))))))) (by decide +kernel)
def s5_5655 : List (BitVec 512) := [w3766,w4344,w4572,w5135,w5393,w5769,w5956,w6300,w6588,w6720]
theorem b5_5655 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5655 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5655 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4572,v132_5135,v132_5393,v132_5769,v132_5956,v132_6300,v132_6588,v132_6720] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4572 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6720 rfl)))))))))) (by decide +kernel)
def s5_5656 : List (BitVec 512) := [w3766,w4344,w4572,w5135,w5393,w5769,w5956,w6300,w6588,w6895]
theorem b5_5656 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5656 := by
  intro m le c
  apply rejects_sound r132 i7 6 tgt (small132 adj) hot132 [] s5_5656 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v132_3766,v132_4344,v132_4572,v132_5135,v132_5393,v132_5769,v132_5956,v132_6300,v132_6588,v132_6895] (PetersenWireProjection.cons pc132_3766 (PetersenWireProjection.cons pc132_4344 (PetersenWireProjection.cons pc132_4572 (PetersenWireProjection.cons pc132_5135 (PetersenWireProjection.cons pc132_5393 (PetersenWireProjection.cons pc132_5769 (PetersenWireProjection.cons pc132_5956 (PetersenWireProjection.cons pc132_6300 (PetersenWireProjection.cons pc132_6588 (PetersenWireProjection.cons pc132_6895 rfl)))))))))) (by decide +kernel)
end NineCert
