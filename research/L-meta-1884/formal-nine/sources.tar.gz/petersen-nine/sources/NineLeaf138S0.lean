import NinePin138
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_4880 : List (BitVec 512) := [w985,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4880 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_4880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_985,v138_1875,v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_985 (PetersenWireProjection.cons pc138_1875 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_4881 : List (BitVec 512) := [w985,w3766,w4344,w4483,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4881 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_4881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_985,v138_3766,v138_4344,v138_4483,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_985 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4483 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_4890 : List (BitVec 512) := [w989,w3766,w4344,w4502,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_4890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_4890 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_4890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_989,v138_3766,v138_4344,v138_4502,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_989 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4502 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_15841 : List (BitVec 512) := [w3766,w4344,w4355,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_15841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15841 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_15841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4355,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4355 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 (PetersenWireProjection.cons pc138_6832 rfl))))))))))) (by decide +kernel)
def s4_15844 : List (BitVec 512) := [w3766,w4344,w4357,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_15844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15844 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_15844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4357,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4357 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 (PetersenWireProjection.cons pc138_6832 rfl))))))))))) (by decide +kernel)
def s4_15845 : List (BitVec 512) := [w3766,w4344,w4358,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_15845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_15845 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_15845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4358,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6588,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4358 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 (PetersenWireProjection.cons pc138_6832 rfl))))))))))) (by decide +kernel)
def s4_16233 : List (BitVec 512) := [w3766,w4344,w4442,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_16233 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16233 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_16233 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4442,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6300,v138_6567,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4442 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6567 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_16237 : List (BitVec 512) := [w3766,w4344,w4444,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16237 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16237 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_16237 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4444,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6179,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4444 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_16242 : List (BitVec 512) := [w3766,w4344,w4448,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16242 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16242 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_16242 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4448,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6179,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4448 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_16245 : List (BitVec 512) := [w3766,w4344,w4450,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_16245 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16245 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_16245 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4450,v138_4716,v138_5135,v138_5393,v138_5585,v138_5956,v138_6179,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4450 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_18045 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6225,w6389,w6522,w6588]
theorem b4_18045 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18045 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18045 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6101,v138_6225,v138_6389,v138_6522,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6101 (PetersenWireProjection.cons pc138_6225 (PetersenWireProjection.cons pc138_6389 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_18049 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6300,w6522,w6690,w6857]
theorem b4_18049 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18049 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18049 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6101,v138_6300,v138_6522,v138_6690,v138_6857] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6101 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6690 (PetersenWireProjection.cons pc138_6857 rfl))))))))))) (by decide +kernel)
def s4_18054 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6553,w6588]
theorem b4_18054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18054 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6101,v138_6389,v138_6522,v138_6553,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6101 (PetersenWireProjection.cons pc138_6389 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6553 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_18056 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6567,w6588]
theorem b4_18056 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18056 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18056 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6101,v138_6389,v138_6522,v138_6567,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6101 (PetersenWireProjection.cons pc138_6389 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6567 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_18057 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6543,w6549,w6588]
theorem b4_18057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18057 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6101,v138_6389,v138_6543,v138_6549,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6101 (PetersenWireProjection.cons pc138_6389 (PetersenWireProjection.cons pc138_6543 (PetersenWireProjection.cons pc138_6549 (PetersenWireProjection.cons pc138_6588 rfl))))))))))) (by decide +kernel)
def s4_18094 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6225,w6300,w6690,w6832]
theorem b4_18094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18094 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6225,v138_6300,v138_6690,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6225 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6690 (PetersenWireProjection.cons pc138_6832 rfl))))))))))) (by decide +kernel)
def s4_18098 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6567,w6690,w6832]
theorem b4_18098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18098 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6300,v138_6567,v138_6690,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6567 (PetersenWireProjection.cons pc138_6690 (PetersenWireProjection.cons pc138_6832 rfl))))))))))) (by decide +kernel)
def s4_18101 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832,w6857]
theorem b4_18101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18101 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6300,v138_6690,v138_6832,v138_6857] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6690 (PetersenWireProjection.cons pc138_6832 (PetersenWireProjection.cons pc138_6857 rfl))))))))))) (by decide +kernel)
def s4_18103 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832,w6868]
theorem b4_18103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_18103 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s4_18103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6300,v138_6690,v138_6832,v138_6868] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6690 (PetersenWireProjection.cons pc138_6832 (PetersenWireProjection.cons pc138_6868 rfl))))))))))) (by decide +kernel)
def s5_613 : List (BitVec 512) := [w362,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_613 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_613 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_613 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_362,v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5698,v138_6179,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_362 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5698 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_1517 : List (BitVec 512) := [w985,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b5_1517 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1517 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_1517 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_985,v138_3766,v138_4344,v138_4716,v138_5135,v138_5471,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_985 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5471 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_3034 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6832]
theorem b5_3034 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3034 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_3034 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_1388,v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5698,v138_6179,v138_6300,v138_6832] (PetersenWireProjection.cons pc138_1388 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5698 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6832 rfl)))))))))) (by decide +kernel)
def s5_3727 : List (BitVec 512) := [w2387,w3766,w4344,w4716,w5135,w5698,w5956,w6026,w6300,w6588]
theorem b5_3727 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3727 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_3727 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_2387,v138_3766,v138_4344,v138_4716,v138_5135,v138_5698,v138_5956,v138_6026,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_2387 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5698 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6026 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_4061 : List (BitVec 512) := [w2468,w3766,w4344,w4421,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4061 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4061 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_4061 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_2468,v138_3766,v138_4344,v138_4421,v138_4716,v138_5135,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_2468 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4421 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_4063 : List (BitVec 512) := [w2468,w3766,w4344,w4423,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4063 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4063 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_4063 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_2468,v138_3766,v138_4344,v138_4423,v138_4716,v138_5135,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_2468 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4423 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_4064 : List (BitVec 512) := [w2468,w3766,w4344,w4424,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4064 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4064 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_4064 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_2468,v138_3766,v138_4344,v138_4424,v138_4716,v138_5135,v138_5585,v138_5956,v138_6300,v138_6588] (PetersenWireProjection.cons pc138_2468 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4424 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5956 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_4068 : List (BitVec 512) := [w2468,w3766,w4344,w4428,w4716,w5135,w5585,w6179,w6522,w6588]
theorem b5_4068 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4068 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_4068 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_2468,v138_3766,v138_4344,v138_4428,v138_4716,v138_5135,v138_5585,v138_6179,v138_6522,v138_6588] (PetersenWireProjection.cons pc138_2468 (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4428 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_5531 : List (BitVec 512) := [w3766,w4344,w4404,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_5531 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5531 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_5531 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4404,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6300,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4404 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6832 rfl)))))))))) (by decide +kernel)
def s5_5557 : List (BitVec 512) := [w3766,w4344,w4417,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b5_5557 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5557 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_5557 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4417,v138_4716,v138_5135,v138_5393,v138_5585,v138_6179,v138_6300,v138_6832] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4417 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6832 rfl)))))))))) (by decide +kernel)
def s5_5649 : List (BitVec 512) := [w3766,w4344,w4563,w4716,w5135,w5393,w6179,w6300,w6522,w6588]
theorem b5_5649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5649 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_5649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4563,v138_4716,v138_5135,v138_5393,v138_6179,v138_6300,v138_6522,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4563 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_6179 (PetersenWireProjection.cons pc138_6300 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
def s5_6077 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6389,w6522,w6588]
theorem b5_6077 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6077 := by
  intro m le c
  apply rejects_sound r138 i7 6 tgt (small138 adj) hot138 [] s5_6077 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v138_3766,v138_4344,v138_4716,v138_5135,v138_5393,v138_5585,v138_5993,v138_6389,v138_6522,v138_6588] (PetersenWireProjection.cons pc138_3766 (PetersenWireProjection.cons pc138_4344 (PetersenWireProjection.cons pc138_4716 (PetersenWireProjection.cons pc138_5135 (PetersenWireProjection.cons pc138_5393 (PetersenWireProjection.cons pc138_5585 (PetersenWireProjection.cons pc138_5993 (PetersenWireProjection.cons pc138_6389 (PetersenWireProjection.cons pc138_6522 (PetersenWireProjection.cons pc138_6588 rfl)))))))))) (by decide +kernel)
end NineCert
