import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10735 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4782,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10735 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10735 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_10735 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4782,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4782 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10736 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4783,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10736 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10736 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(6,true)),(false,(0,true),(3,true))] s4_10736 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4783,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4783 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10737 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4785,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10737 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10737 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,true)),(false,(0,true),(3,true))] s4_10737 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4785,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4785 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10738 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4789,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10738 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10738 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_10738 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4789,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4789 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10739 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4790,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10739 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10739 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_10739 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4790,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4790 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10740 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4791,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10740 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10740 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_10740 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4791,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4791 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10741 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4793,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10741 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10741 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_10741 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4793,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4793 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10742 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4794,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10742 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10742 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_10742 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4794,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4794 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10743 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4796,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10743 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10743 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(5,true)),(false,(0,true),(3,true))] s4_10743 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4796,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4796 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10744 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4803,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10744 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10744 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_10744 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4803,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4803 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10745 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4804,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10745 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10745 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_10745 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4804,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4804 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10746 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4805,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10746 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10746 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(3,true))] s4_10746 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4805,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4805 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10747 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4807,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10747 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10747 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_10747 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4807,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4807 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10748 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4808,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10748 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10748 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_10748 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4808,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4808 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10749 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10749 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10749 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(3,true))] s4_10749 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4810,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4810 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10750 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_10750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10750 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(2,true)),(false,(1,true),(0,true))] s4_10750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5750,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5750 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10751 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_10751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10751 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true))] s4_10751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5760,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5760 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10752 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5767,w5956,w6300,w6588]
theorem b4_10752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10752 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,true))] s4_10752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5767,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5767 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10753 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b4_10753 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10753 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_10753 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5981,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5981 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10754 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_10754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10754 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_10754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5992,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5992 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10755 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_10755 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10755 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_10755 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5993,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5993 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10756 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_10756 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10756 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_10756 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5995,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5995 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10757 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5996,w6300,w6588]
theorem b4_10757 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10757 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_10757 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5996,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5996 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10758 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5998,w6300,w6588]
theorem b4_10758 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10758 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_10758 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5998,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5998 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10759 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6002,w6300,w6588]
theorem b4_10759 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10759 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_10759 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6002,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6002 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10760 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6003,w6300,w6588]
theorem b4_10760 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10760 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_10760 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6003,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6003 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10761 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_10761 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10761 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_10761 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6004,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6004 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10762 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6300,w6588]
theorem b4_10762 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10762 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_10762 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6006,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6006 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10763 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6007,w6300,w6588]
theorem b4_10763 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10763 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_10763 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6007,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6007 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10764 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6009,w6300,w6588]
theorem b4_10764 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10764 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_10764 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6009,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6009 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10765 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_10765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10765 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_10765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6014,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6014 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10766 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_10766 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10766 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_10766 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6017,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6017 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10767 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_10767 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10767 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_10767 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6019,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6019 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10768 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_10768 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10768 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_10768 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6023,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6023 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10769 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_10769 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10769 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_10769 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6024,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6024 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10770 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_10770 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10770 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_10770 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6026,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6026 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10771 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6032,w6300,w6588]
theorem b4_10771 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10771 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_10771 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6032,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6032 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10772 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6033,w6300,w6588]
theorem b4_10772 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10772 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_10772 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6033,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6033 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10773 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6034,w6300,w6588]
theorem b4_10773 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10773 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_10773 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6034,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6034 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10774 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6035,w6300,w6588]
theorem b4_10774 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10774 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(0,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_10774 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6035,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6035 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10775 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6036,w6300,w6588]
theorem b4_10775 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10775 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(0,true),(2,true)),(false,(0,true),(7,true))] s4_10775 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6036,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6036 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10776 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6037,w6300,w6588]
theorem b4_10776 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10776 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(7,true))] s4_10776 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6037,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6037 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10777 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6038,w6300,w6588]
theorem b4_10777 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10777 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(0,true)),(false,(0,true),(7,true))] s4_10777 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6038,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6038 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10778 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6039,w6300,w6588]
theorem b4_10778 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10778 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_10778 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6039,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6039 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10779 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6040,w6300,w6588]
theorem b4_10779 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10779 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_10779 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6040,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6040 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10780 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6041,w6300,w6588]
theorem b4_10780 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10780 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(0,true)),(false,(0,true),(7,true))] s4_10780 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6041,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6041 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10781 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6042,w6300,w6588]
theorem b4_10781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10781 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_10781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6042,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6042 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10782 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_10782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10782 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true)),(false,(0,true),(7,true))] s4_10782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6044,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6044 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10783 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_10783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10783 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(1,true),(0,true))] s4_10783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6087,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6087 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10784 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_10784 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10784 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(1,true),(0,true))] s4_10784 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6099,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6099 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10785 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_10785 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10785 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s4_10785 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6166,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6166 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10786 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_10786 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10786 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(2,true)),(false,(1,false),(0,false))] s4_10786 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10787 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_10787 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10787 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(1,true),(2,true)),(false,(1,false),(0,false))] s4_10787 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10788 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_10788 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10788 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false))] s4_10788 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6553,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6553 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10789 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_10789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10789 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s4_10789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10790 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_10790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10790 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false))] s4_10790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6575,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6575 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10791 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_10791 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10791 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true)),(false,(1,false),(0,false))] s4_10791 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6821] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6821 rfl))))))))))) (by decide +kernel)
def s4_10792 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6859]
theorem b4_10792 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10792 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true)),(false,(1,false),(0,false))] s4_10792 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6859] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6859 rfl))))))))))) (by decide +kernel)
def s4_10793 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6869]
theorem b4_10793 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10793 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(2,true),(6,true)),(false,(1,false),(0,false))] s4_10793 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6869] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6869 rfl))))))))))) (by decide +kernel)
def s4_10794 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6912]
theorem b4_10794 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10794 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false))] s4_10794 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6912] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6912 rfl))))))))))) (by decide +kernel)
def s4_10795 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_10795 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10795 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(9,true),(1,false))] s4_10795 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6857] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6857 rfl))))))))))) (by decide +kernel)
def s4_10796 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_10796 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10796 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_10796 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_10797 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_10797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10797 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(1,false))] s4_10797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813,v0_6873] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_10798 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_10798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10798 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(1,true)),(false,(8,true),(1,false))] s4_10798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
