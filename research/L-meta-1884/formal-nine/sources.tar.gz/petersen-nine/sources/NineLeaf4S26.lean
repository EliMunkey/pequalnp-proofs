import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10425 : List (BitVec 512) := [w1415,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10425 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10425 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10425 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10426 : List (BitVec 512) := [w1415,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10426 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10426 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10426 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10427 : List (BitVec 512) := [w1415,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10427 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10427 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(7,true),(0,false)),(false,(0,true),(6,true))] s4_10427 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10428 : List (BitVec 512) := [w1415,w3766,w4344,w4672,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10428 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4672,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4672 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10429 : List (BitVec 512) := [w1415,w3766,w4344,w4673,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10429 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10429 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10429 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4673,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4673 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10430 : List (BitVec 512) := [w1415,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10430 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10430 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10430 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10431 : List (BitVec 512) := [w1415,w3766,w4344,w4681,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10431 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10431 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10431 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4681,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4681 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10626 : List (BitVec 512) := [w1717,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_10626 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10626 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(4,true)),(false,(1,true),(0,true))] s4_10626 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1717,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6166,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1717 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6166 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10627 : List (BitVec 512) := [w1717,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10627 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10627 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_10627 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1717,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1717 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12333 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_12333 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12333 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12333 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12340 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_12340 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12340 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12340 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12445 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6101,w6300,w6588]
theorem b4_12445 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12445 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12445 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5769,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12450 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_12450 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12450 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12450 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6422,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6422 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12455 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6549,w6588]
theorem b4_12455 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12455 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12455 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5769,v4_5956,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12459 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w6101,w6300,w6522,w6588]
theorem b4_12459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12459 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5769,v4_6101,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12490 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6549,w6588]
theorem b4_12490 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12490 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(7,true)),(false,(6,true),(0,true))] s4_12490 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2468,v4_3766,v4_4344,v4_4716,v4_5135,v4_5585,v4_5956,v4_6101,v4_6300,v4_6549,v4_6588] (PetersenWireProjection.cons pc4_2468 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6549 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12649 : List (BitVec 512) := [w2488,w3766,w4344,w4643,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12649 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12649 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12649 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4643,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4643 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12650 : List (BitVec 512) := [w2488,w3766,w4344,w4643,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12650 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12650 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12650 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4643,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4643 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12651 : List (BitVec 512) := [w2488,w3766,w4344,w4643,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12651 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12651 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12651 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4643,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4643 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12652 : List (BitVec 512) := [w2488,w3766,w4344,w4643,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12652 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4643,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4643 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12653 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12653 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12654 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12654 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12655 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12655 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12656 : List (BitVec 512) := [w2488,w3766,w4344,w4646,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12656 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12657 : List (BitVec 512) := [w2488,w3766,w4344,w4659,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12657 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12658 : List (BitVec 512) := [w2488,w3766,w4344,w4659,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12658 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12659 : List (BitVec 512) := [w2488,w3766,w4344,w4659,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12659 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12660 : List (BitVec 512) := [w2488,w3766,w4344,w4659,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12660 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12660 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12660 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12661 : List (BitVec 512) := [w2488,w3766,w4344,w4666,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12661 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12662 : List (BitVec 512) := [w2488,w3766,w4344,w4666,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12662 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12663 : List (BitVec 512) := [w2488,w3766,w4344,w4666,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12663 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12663 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12663 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12664 : List (BitVec 512) := [w2488,w3766,w4344,w4669,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12664 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12665 : List (BitVec 512) := [w2488,w3766,w4344,w4669,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12665 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12665 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12665 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12666 : List (BitVec 512) := [w2488,w3766,w4344,w4669,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12666 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12666 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12666 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12667 : List (BitVec 512) := [w2488,w3766,w4344,w4669,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12667 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12668 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12668 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12669 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12669 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12670 : List (BitVec 512) := [w2488,w3766,w4344,w4671,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12670 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12671 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12671 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12671 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12671 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12672 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12672 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12673 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12673 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12673 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12673 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12674 : List (BitVec 512) := [w2488,w3766,w4344,w4675,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12674 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12674 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12674 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4675,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4675 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_12675 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_12675 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12675 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12675 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5585,v4_5956,v4_6061,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12676 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_12676 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12676 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,false)),(false,(7,true),(0,true))] s4_12676 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12677 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_12677 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12677 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12677 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_12678 : List (BitVec 512) := [w2488,w3766,w4344,w4678,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_12678 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12678 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(2,true)),(false,(0,false),(4,true)),(false,(7,true),(0,true))] s4_12678 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_2488,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_2488 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_13750 : List (BitVec 512) := [w3520,w4344,w4716,w4813,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13750 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13750 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(2,true),(0,true))] s4_13750 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3520,v4_4344,v4_4716,v4_4813,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3520 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4813 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_13751 : List (BitVec 512) := [w3521,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_13751 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13751 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true)),(false,(0,true),(2,true))] s4_13751 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3521,v4_3901,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3521 (PetersenWireProjection.cons pc4_3901 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_13752 : List (BitVec 512) := [w3521,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13752 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13752 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,false),(6,true)),(false,(0,true),(2,true))] s4_13752 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3521,v4_3901,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3521 (PetersenWireProjection.cons pc4_3901 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14708 : List (BitVec 512) := [w3766,w3939,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_14708 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14708 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(3,true))] s4_14708 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14709 : List (BitVec 512) := [w3766,w3939,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14709 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14709 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14709 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14710 : List (BitVec 512) := [w3766,w3939,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_14710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14710 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true))] s4_14710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6832] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6832 rfl))))))))))) (by decide +kernel)
def s4_14711 : List (BitVec 512) := [w3766,w3939,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_14711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14711 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true))] s4_14711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_14712 : List (BitVec 512) := [w3766,w3939,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_14712 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14712 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(4,true))] s4_14712 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3939,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3939 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_14714 : List (BitVec 512) := [w3766,w3941,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14714 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14714 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14714 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3941,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3941 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14725 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w4810,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14725 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14725 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true)),(false,(0,true),(3,true))] s4_14725 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_4810,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4810 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14726 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_14726 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14726 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14726 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14727 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6044,w6300,w6588]
theorem b4_14727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14727 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(0,true),(3,true)),(false,(0,true),(9,true))] s4_14727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6044,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6044 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14728 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_14728 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14728 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14728 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14729 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_14729 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14729 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true))] s4_14729 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_14730 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_14730 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14730 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14730 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_14731 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_14731 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14731 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(3,true))] s4_14731 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6895] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6895 rfl))))))))))) (by decide +kernel)
def s4_14732 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6908]
theorem b4_14732 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14732 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,false))] s4_14732 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
def s4_14733 : List (BitVec 512) := [w3766,w3945,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_14733 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_14733 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [] s4_14733 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_3766,v4_3945,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_3945 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
end NineCert
