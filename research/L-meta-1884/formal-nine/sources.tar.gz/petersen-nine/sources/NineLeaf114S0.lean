import NinePin114
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_535 : List (BitVec 512) := [w37,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_535 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_37,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6588,v114_6904] (PetersenWireProjection.cons pc114_37 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6588 (PetersenWireProjection.cons pc114_6904 rfl))))))))))) (by decide +kernel)
def s4_561 : List (BitVec 512) := [w40,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_561 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_40,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6464,v114_6588] (PetersenWireProjection.cons pc114_40 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6464 (PetersenWireProjection.cons pc114_6588 rfl))))))))))) (by decide +kernel)
def s4_564 : List (BitVec 512) := [w40,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6904]
theorem b4_564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_564 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_40,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6588,v114_6904] (PetersenWireProjection.cons pc114_40 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6588 (PetersenWireProjection.cons pc114_6904 rfl))))))))))) (by decide +kernel)
def s4_7679 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6785,w6813]
theorem b4_7679 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7679 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_7679 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_2686,v114_3766,v114_4344,v114_4716,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6813] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_2686 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6813 rfl))))))))))) (by decide +kernel)
def s4_8055 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6821]
theorem b4_8055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8055 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6821] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6821 rfl))))))))))) (by decide +kernel)
def s4_8058 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6869]
theorem b4_8058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8058 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6869] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6869 rfl))))))))))) (by decide +kernel)
def s4_8061 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6807,w6813]
theorem b4_8061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8061 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6807,v114_6813] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6807 (PetersenWireProjection.cons pc114_6813 rfl))))))))))) (by decide +kernel)
def s4_8069 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6866]
theorem b4_8069 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8069 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8069 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6813,v114_6866] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6813 (PetersenWireProjection.cons pc114_6866 rfl))))))))))) (by decide +kernel)
def s4_8114 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785,w6813]
theorem b4_8114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8114 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5956,v114_6179,v114_6300,v114_6785,v114_6813] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6813 rfl))))))))))) (by decide +kernel)
def s4_8456 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6821]
theorem b4_8456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8456 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_8456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1328,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6821] (PetersenWireProjection.cons pc114_1328 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6821 rfl))))))))))) (by decide +kernel)
def s4_9197 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6869]
theorem b4_9197 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9197 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9197 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1374,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6225,v114_6300,v114_6869] (PetersenWireProjection.cons pc114_1374 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6225 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6869 rfl))))))))))) (by decide +kernel)
def s4_9491 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6868]
theorem b4_9491 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9491 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9491 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6179,v114_6300,v114_6868] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6868 rfl))))))))))) (by decide +kernel)
def s4_9503 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6866]
theorem b4_9503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9503 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6201,v114_6300,v114_6866] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6201 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6866 rfl))))))))))) (by decide +kernel)
def s4_9543 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6868]
theorem b4_9543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9543 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6868] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6868 rfl))))))))))) (by decide +kernel)
def s4_9551 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866,w6868]
theorem b4_9551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9551 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6866,v114_6868] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6866 (PetersenWireProjection.cons pc114_6868 rfl))))))))))) (by decide +kernel)
def s4_9565 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6201,w6300,w6785]
theorem b4_9565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9565 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5956,v114_6179,v114_6201,v114_6300,v114_6785] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6201 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 rfl))))))))))) (by decide +kernel)
def s4_9691 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6869]
theorem b4_9691 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9691 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9691 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1388,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6179,v114_6300,v114_6869] (PetersenWireProjection.cons pc114_1388 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6869 rfl))))))))))) (by decide +kernel)
def s4_9700 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6866]
theorem b4_9700 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9700 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9700 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1388,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6225,v114_6300,v114_6866] (PetersenWireProjection.cons pc114_1388 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6225 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6866 rfl))))))))))) (by decide +kernel)
def s4_9719 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6869]
theorem b4_9719 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9719 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9719 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1388,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6869] (PetersenWireProjection.cons pc114_1388 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6869 rfl))))))))))) (by decide +kernel)
def s4_9723 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866,w6869]
theorem b4_9723 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9723 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_9723 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1388,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6866,v114_6869] (PetersenWireProjection.cons pc114_1388 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6866 (PetersenWireProjection.cons pc114_6869 rfl))))))))))) (by decide +kernel)
def s4_10526 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6905]
theorem b4_10526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10526 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_10526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1415,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6464,v114_6905] (PetersenWireProjection.cons pc114_1415 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6464 (PetersenWireProjection.cons pc114_6905 rfl))))))))))) (by decide +kernel)
def s4_10536 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6904]
theorem b4_10536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10536 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_10536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1415,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6478,v114_6904] (PetersenWireProjection.cons pc114_1415 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6478 (PetersenWireProjection.cons pc114_6904 rfl))))))))))) (by decide +kernel)
def s4_10565 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6785,w6905]
theorem b4_10565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10565 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_10565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1415,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6785,v114_6905] (PetersenWireProjection.cons pc114_1415 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 (PetersenWireProjection.cons pc114_6905 rfl))))))))))) (by decide +kernel)
def s4_10573 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6904,w6905]
theorem b4_10573 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10573 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_10573 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1415,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6904,v114_6905] (PetersenWireProjection.cons pc114_1415 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6904 (PetersenWireProjection.cons pc114_6905 rfl))))))))))) (by decide +kernel)
def s4_13068 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6179,w6300,w6572,w6588]
theorem b4_13068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13068 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_13068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_2496,v114_3766,v114_4344,v114_4716,v114_5135,v114_5585,v114_5956,v114_6179,v114_6300,v114_6572,v114_6588] (PetersenWireProjection.cons pc114_2496 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6572 (PetersenWireProjection.cons pc114_6588 rfl))))))))))) (by decide +kernel)
def s4_17631 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6572,w6588]
theorem b4_17631 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17631 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s4_17631 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6225,v114_6300,v114_6572,v114_6588] (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6225 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6572 (PetersenWireProjection.cons pc114_6588 rfl))))))))))) (by decide +kernel)
def s5_2230 : List (BitVec 512) := [w1237,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6788]
theorem b5_2230 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2230 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2230 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1237,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6788] (PetersenWireProjection.cons pc114_1237 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6788 rfl)))))))))) (by decide +kernel)
def s5_2235 : List (BitVec 512) := [w1239,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6790]
theorem b5_2235 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2235 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2235 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1239,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6790] (PetersenWireProjection.cons pc114_1239 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6790 rfl)))))))))) (by decide +kernel)
def s5_2239 : List (BitVec 512) := [w1240,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6791]
theorem b5_2239 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2239 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2239 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1240,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6791] (PetersenWireProjection.cons pc114_1240 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6791 rfl)))))))))) (by decide +kernel)
def s5_2253 : List (BitVec 512) := [w1249,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6793]
theorem b5_2253 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2253 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2253 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1249,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6793] (PetersenWireProjection.cons pc114_1249 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6793 rfl)))))))))) (by decide +kernel)
def s5_2260 : List (BitVec 512) := [w1252,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6794]
theorem b5_2260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2260 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1252,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6794] (PetersenWireProjection.cons pc114_1252 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6794 rfl)))))))))) (by decide +kernel)
def s5_2283 : List (BitVec 512) := [w1265,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6799]
theorem b5_2283 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2283 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2283 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1265,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6799] (PetersenWireProjection.cons pc114_1265 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6799 rfl)))))))))) (by decide +kernel)
def s5_2288 : List (BitVec 512) := [w1268,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6800]
theorem b5_2288 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2288 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2288 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1268,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6800] (PetersenWireProjection.cons pc114_1268 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6800 rfl)))))))))) (by decide +kernel)
def s5_2292 : List (BitVec 512) := [w1269,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6801]
theorem b5_2292 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2292 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2292 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1269,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6801] (PetersenWireProjection.cons pc114_1269 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6801 rfl)))))))))) (by decide +kernel)
def s5_2299 : List (BitVec 512) := [w1275,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6802]
theorem b5_2299 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2299 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2299 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1275,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6802] (PetersenWireProjection.cons pc114_1275 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6802 rfl)))))))))) (by decide +kernel)
def s5_2307 : List (BitVec 512) := [w1279,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6804]
theorem b5_2307 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2307 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2307 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1279,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6804] (PetersenWireProjection.cons pc114_1279 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6804 rfl)))))))))) (by decide +kernel)
def s5_2492 : List (BitVec 512) := [w1312,w2686,w3766,w4344,w4716,w5393,w5956,w6179,w6300,w6785]
theorem b5_2492 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2492 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2492 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_2686,v114_3766,v114_4344,v114_4716,v114_5393,v114_5956,v114_6179,v114_6300,v114_6785] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_2686 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6785 rfl)))))))))) (by decide +kernel)
def s5_2510 : List (BitVec 512) := [w1312,w3321,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813]
theorem b5_2510 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2510 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2510 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1312,v114_3321,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6813] (PetersenWireProjection.cons pc114_1312 (PetersenWireProjection.cons pc114_3321 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6813 rfl)))))))))) (by decide +kernel)
def s5_2645 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b5_2645 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2645 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2645 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1328,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5956,v114_6179,v114_6300,v114_6807] (PetersenWireProjection.cons pc114_1328 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6807 rfl)))))))))) (by decide +kernel)
def s5_2764 : List (BitVec 512) := [w1374,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6869]
theorem b5_2764 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2764 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2764 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1374,v114_1913,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_6300,v114_6869] (PetersenWireProjection.cons pc114_1374 (PetersenWireProjection.cons pc114_1913 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6869 rfl)))))))))) (by decide +kernel)
def s5_2805 : List (BitVec 512) := [w1374,w2693,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6869]
theorem b5_2805 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2805 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2805 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1374,v114_2693,v114_3766,v114_4344,v114_4716,v114_5393,v114_5585,v114_5956,v114_6300,v114_6869] (PetersenWireProjection.cons pc114_1374 (PetersenWireProjection.cons pc114_2693 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6869 rfl)))))))))) (by decide +kernel)
def s5_2857 : List (BitVec 512) := [w1379,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6191,w6300]
theorem b5_2857 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2857 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2857 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1379,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6191,v114_6300] (PetersenWireProjection.cons pc114_1379 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6191 (PetersenWireProjection.cons pc114_6300 rfl)))))))))) (by decide +kernel)
def s5_2938 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6869]
theorem b5_2938 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2938 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_2938 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1384,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5585,v114_5956,v114_6300,v114_6869] (PetersenWireProjection.cons pc114_1384 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5585 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6869 rfl)))))))))) (by decide +kernel)
def s5_3295 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b5_3295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3295 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_3295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_1415,v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5956,v114_6179,v114_6300,v114_6807] (PetersenWireProjection.cons pc114_1415 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6179 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6807 rfl)))))))))) (by decide +kernel)
def s5_4710 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_4710 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4710 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_4710 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_2496,v114_3766,v114_4344,v114_4716,v114_5135,v114_5698,v114_5769,v114_5956,v114_6300,v114_6588] (PetersenWireProjection.cons pc114_2496 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5698 (PetersenWireProjection.cons pc114_5769 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6588 rfl)))))))))) (by decide +kernel)
def s5_4712 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5769,w5956,w6300,w6478,w6588]
theorem b5_4712 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4712 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_4712 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_2496,v114_3766,v114_4344,v114_4716,v114_5135,v114_5769,v114_5956,v114_6300,v114_6478,v114_6588] (PetersenWireProjection.cons pc114_2496 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5769 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6478 (PetersenWireProjection.cons pc114_6588 rfl)))))))))) (by decide +kernel)
def s5_4747 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_4747 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4747 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_4747 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_2497,v114_3766,v114_4344,v114_4716,v114_5135,v114_5698,v114_5769,v114_5956,v114_6300,v114_6588] (PetersenWireProjection.cons pc114_2497 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5698 (PetersenWireProjection.cons pc114_5769 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6588 rfl)))))))))) (by decide +kernel)
def s5_4748 : List (BitVec 512) := [w2497,w3766,w4344,w4716,w5135,w5698,w5956,w6225,w6300,w6588]
theorem b5_4748 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4748 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [] s5_4748 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_2497,v114_3766,v114_4344,v114_4716,v114_5135,v114_5698,v114_5956,v114_6225,v114_6300,v114_6588] (PetersenWireProjection.cons pc114_2497 (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5698 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6225 (PetersenWireProjection.cons pc114_6300 (PetersenWireProjection.cons pc114_6588 rfl)))))))))) (by decide +kernel)
def s5_6152 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5956,w6225,w6464,w6813,w6873]
theorem b5_6152 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6152 := by
  intro m le c
  apply rejects_sound r114 i8 7 tgt (small114 adj) hot114 [(false,(7,true),(6,true))] s5_6152 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v114_3766,v114_4344,v114_4716,v114_5135,v114_5393,v114_5956,v114_6225,v114_6464,v114_6813,v114_6873] (PetersenWireProjection.cons pc114_3766 (PetersenWireProjection.cons pc114_4344 (PetersenWireProjection.cons pc114_4716 (PetersenWireProjection.cons pc114_5135 (PetersenWireProjection.cons pc114_5393 (PetersenWireProjection.cons pc114_5956 (PetersenWireProjection.cons pc114_6225 (PetersenWireProjection.cons pc114_6464 (PetersenWireProjection.cons pc114_6813 (PetersenWireProjection.cons pc114_6873 rfl)))))))))) (by decide +kernel)
end NineCert
