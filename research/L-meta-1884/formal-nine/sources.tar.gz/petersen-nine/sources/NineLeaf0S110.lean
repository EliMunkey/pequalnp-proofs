import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s6_87 : List (BitVec 512) := [w3686,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b6_87 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_87 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s6_87 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s6_88 : List (BitVec 512) := [w3686,w4344,w4716,w5393,w5585,w5956,w6239,w6300,w6588]
theorem b6_88 (adj : NineExtra.Hard8) : Blocked tgt 8 s6_88 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true)),(false,(5,true),(0,true))] s6_88 8 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3686,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6239,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6239 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
end NineCert
