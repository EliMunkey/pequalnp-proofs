import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4194 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6573,w6588]
theorem b5_4194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4194 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true)),(false,(0,false),(2,false))] s5_4194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6573,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6573 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4196 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6576,w6588]
theorem b5_4196 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4196 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true)),(false,(0,false),(2,false))] s5_4196 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6576,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6576 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4199 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4199 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4199 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_4199 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4201 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6667,w6807]
theorem b5_4201 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4201 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(9,true)),(false,(0,false),(3,true))] s5_4201 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6667,v0_6807] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6807 rfl)))))))))) (by decide +kernel)
def s5_4205 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6690,w6745]
theorem b5_4205 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4205 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(3,true)),(false,(10,true),(3,true))] s5_4205 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6690,v0_6745] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6745 rfl)))))))))) (by decide +kernel)
def s5_4220 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b5_4220 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4220 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(7,true),(6,true)),(false,(5,true),(0,true))] s5_4220 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4221 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6551,w6588]
theorem b5_4221 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4221 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false)),(false,(3,true),(9,true))] s5_4221 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6551,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6551 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4254 : List (BitVec 512) := [w2468,w3766,w4344,w4814,w5135,w5698,w5769,w5956,w6300,w6588]
theorem b5_4254 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4254 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(4,true))] s5_4254 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2468,v0_3766,v0_4344,v0_4814,v0_5135,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4281 : List (BitVec 512) := [w2488,w3293,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4281 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4281 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4281 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3293,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3293 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4284 : List (BitVec 512) := [w2488,w3303,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4284 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4284 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4284 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3303,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3303 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4287 : List (BitVec 512) := [w2488,w3312,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4287 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4287 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false))] s5_4287 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3312,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3312 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4292 : List (BitVec 512) := [w2488,w3447,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4292 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4292 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4292 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3447,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3447 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4293 : List (BitVec 512) := [w2488,w3454,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4293 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4293 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4293 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3454,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3454 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4294 : List (BitVec 512) := [w2488,w3580,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4294 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4294 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3580,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3580 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4295 : List (BitVec 512) := [w2488,w3581,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4295 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4295 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4295 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3581,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3581 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4296 : List (BitVec 512) := [w2488,w3582,w4716,w5135,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b5_4296 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4296 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s5_4296 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3582,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4297 : List (BitVec 512) := [w2488,w3595,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4297 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4297 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4297 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3595,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3595 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4298 : List (BitVec 512) := [w2488,w3642,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4298 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4298 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4298 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3642,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3642 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4299 : List (BitVec 512) := [w2488,w3644,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4299 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4299 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4299 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3644,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4300 : List (BitVec 512) := [w2488,w3644,w4344,w4716,w5135,w5585,w5956,w6201,w6300,w6588]
theorem b5_4300 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4300 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4300 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3644,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4301 : List (BitVec 512) := [w2488,w3644,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4301 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4301 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4301 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3644,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4302 : List (BitVec 512) := [w2488,w3664,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4302 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4302 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4302 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3664,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3664 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4303 : List (BitVec 512) := [w2488,w3666,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4303 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4303 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4303 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3666,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4304 : List (BitVec 512) := [w2488,w3666,w4344,w4716,w5135,w5585,w5956,w6300,w6478,w6588]
theorem b5_4304 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4304 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4304 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3666,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4305 : List (BitVec 512) := [w2488,w3666,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4305 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3666,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4306 : List (BitVec 512) := [w2488,w3684,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4306 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4306 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4306 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3684,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3684 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4307 : List (BitVec 512) := [w2488,w3686,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4307 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4307 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4307 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3686,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4308 : List (BitVec 512) := [w2488,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_4308 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4308 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false))] s5_4308 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4309 : List (BitVec 512) := [w2488,w3686,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4309 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4309 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4309 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3686,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3686 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4310 : List (BitVec 512) := [w2488,w3691,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4310 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4310 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4310 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3691,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3691 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4311 : List (BitVec 512) := [w2488,w3695,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4311 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4311 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4311 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3695,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3695 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4312 : List (BitVec 512) := [w2488,w3731,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4312 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4312 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4312 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3731,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3731 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4313 : List (BitVec 512) := [w2488,w3738,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4313 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4313 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4313 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3738,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3738 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4314 : List (BitVec 512) := [w2488,w3748,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4314 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4314 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4314 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3748,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3748 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4315 : List (BitVec 512) := [w2488,w3759,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4315 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4315 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_4315 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3759,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3759 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4316 : List (BitVec 512) := [w2488,w3763,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4316 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4316 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4316 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3763,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3763 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4317 : List (BitVec 512) := [w2488,w3766,w3857,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4317 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4317 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(7,true),(1,false)),(false,(6,true),(0,true))] s5_4317 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3857,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3857 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4318 : List (BitVec 512) := [w2488,w3766,w3865,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4318 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4318 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(9,true)),(false,(6,true),(1,true))] s5_4318 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3865,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3865 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4319 : List (BitVec 512) := [w2488,w3766,w3877,w4344,w4716,w5135,w5585,w6061,w6300,w6588]
theorem b5_4319 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4319 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(7,true),(0,true)),(false,(6,true),(1,true))] s5_4319 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3877,v0_4344,v0_4716,v0_5135,v0_5585,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3877 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4320 : List (BitVec 512) := [w2488,w3766,w3913,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4320 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4320 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false)),(false,(6,true),(0,true))] s5_4320 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3913,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3913 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4321 : List (BitVec 512) := [w2488,w3766,w3917,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4321 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4321 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true)),(false,(6,true),(1,true))] s5_4321 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3917,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3917 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4322 : List (BitVec 512) := [w2488,w3766,w3933,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4322 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4322 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(2,true)),(false,(7,true),(1,false)),(false,(6,true),(0,true))] s5_4322 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3933,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3933 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4323 : List (BitVec 512) := [w2488,w3766,w3934,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4323 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4323 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(0,true),(3,true)),(false,(6,true),(1,true))] s5_4323 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_3934,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3934 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4446 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5810,w5956,w6300,w6588]
theorem b5_4446 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4446 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(7,true))] s5_4446 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5810,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5810 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4461 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b5_4461 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4461 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4461 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4465 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6146,w6300,w6588]
theorem b5_4465 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4465 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(2,false))] s5_4465 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6146,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6146 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4470 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6206,w6300,w6588]
theorem b5_4470 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4470 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4470 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6206,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6206 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4489 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6443,w6588]
theorem b5_4489 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4489 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(4,true),(2,false))] s5_4489 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6443,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6443 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4494 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6484,w6588]
theorem b5_4494 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4494 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4494 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6484,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6484 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4500 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b5_4500 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4500 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_4500 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4503 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6554,w6588]
theorem b5_4503 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4503 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(1,false))] s5_4503 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6554,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6554 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4507 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6573,w6588]
theorem b5_4507 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4507 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false))] s5_4507 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6573,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6573 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4510 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_4510 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4510 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_4510 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s5_4516 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6745]
theorem b5_4516 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4516 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(10,true))] s5_4516 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6745] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6745 rfl)))))))))) (by decide +kernel)
def s5_4520 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6805]
theorem b5_4520 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4520 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(10,true))] s5_4520 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6805] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6805 rfl)))))))))) (by decide +kernel)
def s5_4525 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6855]
theorem b5_4525 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4525 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(2,false),(10,true))] s5_4525 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6855] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6855 rfl)))))))))) (by decide +kernel)
def s5_4533 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6894]
theorem b5_4533 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4533 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(2,false),(10,true))] s5_4533 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6894] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6894 rfl)))))))))) (by decide +kernel)
def s5_4540 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6911]
theorem b5_4540 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4540 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(1,false),(10,true))] s5_4540 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6911] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6911 rfl)))))))))) (by decide +kernel)
def s5_4544 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6667,w6785]
theorem b5_4544 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4544 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(10,true))] s5_4544 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6667,v0_6785] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6667 (PetersenWireProjection.cons pc0_6785 rfl)))))))))) (by decide +kernel)
def s5_4550 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6377,w6478,w6588]
theorem b5_4550 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4550 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4550 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6377,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4554 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6432,w6588]
theorem b5_4554 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4554 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true)),(false,(4,true),(9,true))] s5_4554 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6432,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6432 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4558 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6048,w6201,w6300,w6588]
theorem b5_4558 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4558 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(7,true),(2,false))] s5_4558 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6048,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4562 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6061,w6124,w6300,w6588]
theorem b5_4562 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4562 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true))] s5_4562 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6061,v0_6124,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6124 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_4568 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_4568 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4568 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true))] s5_4568 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_6101,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
