import NinePin24
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1094 : List (BitVec 512) := [w856,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1094 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1094 := by
  intro m le c
  apply rejects_sound r24 i7 8 tgt (small24 adj) hot24 [(false,(5,true),(2,true))] s5_1094 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v24_856,v24_3258,v24_4344,v24_4716,v24_5135,v24_5393,v24_5585,v24_5956,v24_6300,v24_6588] (PetersenWireProjection.cons pc24_856 (PetersenWireProjection.cons pc24_3258 (PetersenWireProjection.cons pc24_4344 (PetersenWireProjection.cons pc24_4716 (PetersenWireProjection.cons pc24_5135 (PetersenWireProjection.cons pc24_5393 (PetersenWireProjection.cons pc24_5585 (PetersenWireProjection.cons pc24_5956 (PetersenWireProjection.cons pc24_6300 (PetersenWireProjection.cons pc24_6588 rfl)))))))))) (by decide +kernel)
end NineCert
