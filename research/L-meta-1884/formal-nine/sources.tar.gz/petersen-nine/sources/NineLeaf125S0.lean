import NinePin125
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3789 : List (BitVec 512) := [w861,w2125,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_3789 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3789 := by
  intro m le c
  apply rejects_sound r125 i7 6 tgt (small125 adj) hot125 [] s4_3789 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v125_861,v125_2125,v125_3901,v125_4344,v125_4716,v125_5135,v125_5393,v125_5585,v125_5956,v125_6300,v125_6588] (PetersenWireProjection.cons pc125_861 (PetersenWireProjection.cons pc125_2125 (PetersenWireProjection.cons pc125_3901 (PetersenWireProjection.cons pc125_4344 (PetersenWireProjection.cons pc125_4716 (PetersenWireProjection.cons pc125_5135 (PetersenWireProjection.cons pc125_5393 (PetersenWireProjection.cons pc125_5585 (PetersenWireProjection.cons pc125_5956 (PetersenWireProjection.cons pc125_6300 (PetersenWireProjection.cons pc125_6588 rfl))))))))))) (by decide +kernel)
def s5_1099 : List (BitVec 512) := [w861,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6631]
theorem b5_1099 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1099 := by
  intro m le c
  apply rejects_sound r125 i7 6 tgt (small125 adj) hot125 [] s5_1099 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v125_861,v125_3901,v125_4344,v125_4716,v125_5135,v125_5393,v125_5585,v125_5956,v125_6300,v125_6631] (PetersenWireProjection.cons pc125_861 (PetersenWireProjection.cons pc125_3901 (PetersenWireProjection.cons pc125_4344 (PetersenWireProjection.cons pc125_4716 (PetersenWireProjection.cons pc125_5135 (PetersenWireProjection.cons pc125_5393 (PetersenWireProjection.cons pc125_5585 (PetersenWireProjection.cons pc125_5956 (PetersenWireProjection.cons pc125_6300 (PetersenWireProjection.cons pc125_6631 rfl)))))))))) (by decide +kernel)
end NineCert
