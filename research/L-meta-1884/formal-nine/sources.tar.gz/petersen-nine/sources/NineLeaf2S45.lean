import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_17454 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6164,w6300,w6588]
theorem b4_17454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17454 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(4,true))] s4_17454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6164,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6164 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17463 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6247,w6300,w6588]
theorem b4_17463 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17463 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(3,true),(0,false)),(false,(1,false),(8,true))] s4_17463 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6247,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6247 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17464 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6249,w6300,w6588]
theorem b4_17464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17464 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(4,true))] s4_17464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6249,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6249 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17465 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6250,w6300,w6588]
theorem b4_17465 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17465 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_17465 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6250,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6250 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17468 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6454,w6588]
theorem b4_17468 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17468 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(5,true))] s4_17468 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6454,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6454 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17477 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6506,w6588]
theorem b4_17477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17477 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(4,true),(0,false)),(false,(1,false),(8,true))] s4_17477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6506,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6506 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17478 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6507,w6588]
theorem b4_17478 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17478 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(5,true))] s4_17478 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6507,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6507 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17479 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6508,w6588]
theorem b4_17479 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17479 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_17479 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6508,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6508 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17492 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6783]
theorem b4_17492 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17492 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(1,false),(7,true))] s4_17492 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588,v2_6783] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6783 rfl))))))))))) (by decide +kernel)
def s4_17501 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6828]
theorem b4_17501 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17501 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(0,false)),(false,(1,false),(8,true))] s4_17501 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588,v2_6828] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6828 rfl))))))))))) (by decide +kernel)
def s4_17502 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6829]
theorem b4_17502 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17502 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(1,false),(3,true))] s4_17502 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588,v2_6829] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6829 rfl))))))))))) (by decide +kernel)
def s4_17503 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588,w6830]
theorem b4_17503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17503 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_17503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588,v2_6830] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6830 rfl))))))))))) (by decide +kernel)
def s4_17521 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6767,w6832]
theorem b4_17521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17521 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(0,false),(3,true))] s4_17521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17522 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6767,w6873]
theorem b4_17522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17522 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true)),(false,(1,false),(7,true))] s4_17522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17528 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6451,w6522,w6588]
theorem b4_17528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17528 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true))] s4_17528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17534 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w6158,w6300,w6522,w6588]
theorem b4_17534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17534 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true)),(false,(1,false),(7,true))] s4_17534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_6158,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17563 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5892,w5956,w6300,w6588]
theorem b4_17563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17563 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true)),(false,(1,true),(0,true))] s4_17563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5892,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5892 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_17564 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6237,w6300,w6588]
theorem b4_17564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17564 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17565 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6499,w6588]
theorem b4_17565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17565 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(5,true))] s4_17565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17566 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6575,w6588]
theorem b4_17566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17566 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,false))] s4_17566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6575,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6575 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17567 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6588,w6821]
theorem b4_17567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17567 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(0,false),(9,true))] s4_17567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_17568 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6588,w6852]
theorem b4_17568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17568 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_17568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6588,v2_6852] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_17569 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6588,w6890]
theorem b4_17569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17569 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true)),(false,(1,false),(9,true))] s4_17569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6588,v2_6890] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_17570 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6690,w6832]
theorem b4_17570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17570 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true)),(false,(9,true),(3,true))] s4_17570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6690,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17571 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6813,w6873]
theorem b4_17571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17571 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(9,true),(5,true))] s4_17571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6813,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6813 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17572 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6389,w6522,w6588]
theorem b4_17572 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17572 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(6,true)),(false,(5,true),(3,true))] s4_17572 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17573 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w6225,w6300,w6522,w6588]
theorem b4_17573 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17573 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true)),(false,(4,true),(0,false))] s4_17573 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_6225,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17574 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6136,w6300,w6588]
theorem b4_17574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17574 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(4,true))] s4_17574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17575 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6225,w6300,w6588]
theorem b4_17575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17575 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(4,true))] s4_17575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17576 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6237,w6300,w6588]
theorem b4_17576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17576 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(4,true))] s4_17576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6237,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6237 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17577 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6436,w6588]
theorem b4_17577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17577 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(1,false),(5,true))] s4_17577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6436,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6436 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17578 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6489,w6588]
theorem b4_17578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17578 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(1,false),(5,true))] s4_17578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17579 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6499,w6588]
theorem b4_17579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17579 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(5,true))] s4_17579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6499,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6499 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17580 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6588,w6821]
theorem b4_17580 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17580 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(0,false),(9,true))] s4_17580 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6588,v2_6821] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6821 rfl))))))))))) (by decide +kernel)
def s4_17599 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6454,w6588]
theorem b4_17599 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17599 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(4,true)),(false,(1,false),(4,true))] s4_17599 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6454,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6454 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17605 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6562,w6588]
theorem b4_17605 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17605 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true)),(false,(0,false),(5,true))] s4_17605 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6562,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6562 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_17618 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6136,w6300,w6767,w6873]
theorem b4_17618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17618 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(4,true),(8,true)),(false,(1,false),(8,true))] s4_17618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_17797 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6828]
theorem b4_17797 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17797 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,false)),(false,(9,true),(8,true))] s4_17797 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6828] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6828 rfl))))))))))) (by decide +kernel)
def s4_17798 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6829]
theorem b4_17798 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17798 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(6,true),(0,false)),(false,(9,true),(3,true))] s4_17798 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6829] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6829 rfl))))))))))) (by decide +kernel)
def s4_17805 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6864]
theorem b4_17805 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17805 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,false),(3,true)),(false,(8,true),(9,true))] s4_17805 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6864] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6864 rfl))))))))))) (by decide +kernel)
def s4_17806 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6865]
theorem b4_17806 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17806 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(0,false)),(false,(9,true),(3,true))] s4_17806 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6865] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6865 rfl))))))))))) (by decide +kernel)
def s4_17815 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6902]
theorem b4_17815 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17815 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(9,true))] s4_17815 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6902] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6902 rfl))))))))))) (by decide +kernel)
def s4_17816 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6903]
theorem b4_17816 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17816 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(0,false)),(false,(9,true),(3,true))] s4_17816 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6903] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6903 rfl))))))))))) (by decide +kernel)
def s4_17836 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6781,w6857]
theorem b4_17836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17836 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(1,false))] s4_17836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6781,v2_6857] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_17837 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6782,w6857]
theorem b4_17837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17837 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(3,true),(0,false)),(false,(9,true),(3,true))] s4_17837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6782,v2_6857] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_17838 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6782,w6895]
theorem b4_17838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17838 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(0,false)),(false,(9,true),(3,true))] s4_17838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6782,v2_6895] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6782 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_17839 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6783,w6832]
theorem b4_17839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17839 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(9,true),(4,true))] s4_17839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6783,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6783 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17850 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6828,w6832]
theorem b4_17850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17850 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,false)),(false,(9,true),(4,true))] s4_17850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6828,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6828 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17858 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6865]
theorem b4_17858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17858 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(9,true),(3,true))] s4_17858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832,v2_6865] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6865 rfl))))))))))) (by decide +kernel)
def s4_17863 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6872]
theorem b4_17863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17863 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(6,true)),(false,(9,true),(3,true))] s4_17863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832,v2_6872] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6872 rfl))))))))))) (by decide +kernel)
def s4_17867 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6902]
theorem b4_17867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17867 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(4,true))] s4_17867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832,v2_6902] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6902 rfl))))))))))) (by decide +kernel)
def s4_17873 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6832,w6916]
theorem b4_17873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(3,true))] s4_17873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6832,v2_6916] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6916 rfl))))))))))) (by decide +kernel)
def s4_17885 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6863]
theorem b4_17885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17885 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(9,true),(3,true))] s4_17885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6857,v2_6863] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6857 (PetersenWireProjection.cons pc2_6863 rfl))))))))))) (by decide +kernel)
def s4_17886 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857,w6865]
theorem b4_17886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17886 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(2,true)),(false,(9,true),(1,false))] s4_17886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6857,v2_6865] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6857 (PetersenWireProjection.cons pc2_6865 rfl))))))))))) (by decide +kernel)
def s4_17894 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6863,w6908]
theorem b4_17894 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17894 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(3,true))] s4_17894 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6863,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6863 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17916 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6781,w6852]
theorem b4_17916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17916 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,false),(3,true)),(false,(8,true),(9,true))] s4_17916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6781,v2_6852] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6852 rfl))))))))))) (by decide +kernel)
def s4_17917 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6781,w6890]
theorem b4_17917 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17917 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(9,true))] s4_17917 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6781,v2_6890] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_17929 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6748,w6781,w6832]
theorem b4_17929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17929 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(9,true),(4,true))] s4_17929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6748,v2_6781,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6748 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17931 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6807,w6832]
theorem b4_17931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17931 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(0,false)),(false,(9,true),(4,true))] s4_17931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6807,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6807 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s4_17932 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6832,w6857]
theorem b4_17932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17932 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(9,true),(3,true))] s4_17932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6832,v2_6857] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_17933 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6832,w6866]
theorem b4_17933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17933 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(6,true)),(false,(9,true),(3,true))] s4_17933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6832,v2_6866] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6866 rfl))))))))))) (by decide +kernel)
def s4_17934 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6832,w6890]
theorem b4_17934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17934 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(4,true))] s4_17934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6832,v2_6890] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6890 rfl))))))))))) (by decide +kernel)
def s4_17935 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6781,w6832,w6908]
theorem b4_17935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17935 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(0,false),(4,true)),(false,(9,true),(3,true))] s4_17935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6781,v2_6832,v2_6908] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6781 (PetersenWireProjection.cons pc2_6832 (PetersenWireProjection.cons pc2_6908 rfl))))))))))) (by decide +kernel)
def s4_17942 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6767,w6832]
theorem b4_17942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17942 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(2,true)),(false,(5,true),(8,true))] s4_17942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
end NineCert
