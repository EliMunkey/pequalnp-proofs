import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s1_0 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_0 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_0 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_0 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_5 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_5 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_5 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_5 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_8 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_8 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_8 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_8 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_9 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_9 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_9 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_9 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_10 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_10 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_10 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_10 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_14 : List (BitVec 512) := [w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_14 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_14 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_14 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_15 : List (BitVec 512) := [w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b1_15 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_15 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_15 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s1_17 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b1_17 (adj : NineExtra.Hard8) : Blocked tgt 13 s1_17 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s1_17 13 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s2_0 : List (BitVec 512) := [w0,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_0 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_0 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s2_0 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_1 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_1 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_1 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s2_1 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_2 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b2_2 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_2 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s2_2 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_3 : List (BitVec 512) := [w0,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_3 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_3 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s2_3 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_0,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_0 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s2_4 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_4 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_4 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s2_4 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s2_5 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b2_5 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_5 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s2_5 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s2_14 : List (BitVec 512) := [w274,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_14 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_14 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s2_14 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_274,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_274 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s2_15 : List (BitVec 512) := [w274,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b2_15 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_15 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true))] s2_15 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_274,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_274 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s2_22 : List (BitVec 512) := [w581,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_22 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_22 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s2_22 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_581,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_581 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s2_23 : List (BitVec 512) := [w581,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b2_23 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_23 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true))] s2_23 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_581,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_581 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s2_28 : List (BitVec 512) := [w852,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_28 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_28 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s2_28 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_29 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_29 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_29 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true))] s2_29 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_30 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b2_30 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_30 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s2_30 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_31 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b2_31 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_31 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true))] s2_31 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_32 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b2_32 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_32 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true))] s2_32 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_33 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b2_33 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_33 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true))] s2_33 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_34 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b2_34 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_34 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true))] s2_34 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_35 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b2_35 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_35 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s2_35 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_36 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b2_36 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_36 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true))] s2_36 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_37 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b2_37 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_37 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s2_37 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_38 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b2_38 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_38 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true))] s2_38 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s2_39 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b2_39 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_39 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true))] s2_39 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s2_40 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b2_40 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_40 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true))] s2_40 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s2_41 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b2_41 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_41 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true))] s2_41 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s2_42 : List (BitVec 512) := [w852,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b2_42 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_42 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true))] s2_42 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_852,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_852 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s2_113 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_113 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_113 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s2_113 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_114 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_114 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_114 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s2_114 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_115 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b2_115 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_115 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s2_115 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_116 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b2_116 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_116 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true))] s2_116 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_117 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b2_117 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_117 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true))] s2_117 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_118 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b2_118 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_118 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true))] s2_118 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_119 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b2_119 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_119 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true))] s2_119 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_120 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b2_120 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_120 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s2_120 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_121 : List (BitVec 512) := [w2203,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b2_121 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_121 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true))] s2_121 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2203,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2203 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s2_163 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_163 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_163 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s2_163 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_164 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_164 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_164 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s2_164 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_165 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b2_165 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_165 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s2_165 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_166 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b2_166 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_166 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true))] s2_166 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_167 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b2_167 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_167 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true))] s2_167 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_168 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b2_168 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_168 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s2_168 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_169 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b2_169 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_169 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true))] s2_169 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_170 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b2_170 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_170 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true))] s2_170 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_171 : List (BitVec 512) := [w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b2_171 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_171 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true))] s2_171 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s2_172 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b2_172 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_172 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true))] s2_172 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_173 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b2_173 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_173 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s2_173 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_174 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b2_174 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_174 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true))] s2_174 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_175 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b2_175 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_175 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true))] s2_175 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_176 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b2_176 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_176 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true))] s2_176 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_177 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b2_177 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_177 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true))] s2_177 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_178 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b2_178 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_178 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true))] s2_178 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_179 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b2_179 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_179 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true))] s2_179 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_180 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b2_180 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_180 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true))] s2_180 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_181 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b2_181 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_181 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true))] s2_181 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s2_182 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b2_182 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_182 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true))] s2_182 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s2_183 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b2_183 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_183 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true))] s2_183 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s2_184 : List (BitVec 512) := [w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b2_184 (adj : NineExtra.Hard8) : Blocked tgt 12 s2_184 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true))] s2_184 12 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6785] (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
end NineCert
