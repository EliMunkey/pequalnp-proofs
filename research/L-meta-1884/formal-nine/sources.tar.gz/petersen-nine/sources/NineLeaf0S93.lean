import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_45 : List (BitVec 512) := [w14,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_45 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_45 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_45 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_14,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_14 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_46 : List (BitVec 512) := [w14,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_46 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_46 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s5_46 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_14,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_14 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_47 : List (BitVec 512) := [w14,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_47 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_47 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(8,true)),(false,(1,false),(0,false)),(false,(6,true),(0,true))] s5_47 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_14,v0_2528,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_14 (PetersenWireProjection.cons pc0_2528 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_48 : List (BitVec 512) := [w14,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_48 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_48 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_48 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_14,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_14 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_59 : List (BitVec 512) := [w21,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_59 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_59 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(0,false),(2,true)),(false,(4,true),(0,true))] s5_59 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_2690,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_2690 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_60 : List (BitVec 512) := [w21,w2696,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_60 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_60 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(4,true),(0,true))] s5_60 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_2696,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_2696 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_61 : List (BitVec 512) := [w21,w2701,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_61 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_61 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s5_61 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_2701,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_2701 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_62 : List (BitVec 512) := [w21,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_62 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_62 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(1,true))] s5_62 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_21,v0_3935,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_21 (PetersenWireProjection.cons pc0_3935 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_121 : List (BitVec 512) := [w34,w2172,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_121 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_121 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(6,true))] s5_121 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_2172,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_2172 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_122 : List (BitVec 512) := [w34,w2173,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_122 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_122 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,false)),(false,(0,true),(6,true))] s5_122 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_2173,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_2173 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_123 : List (BitVec 512) := [w34,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_123 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_123 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s5_123 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_2494,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_2494 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_124 : List (BitVec 512) := [w34,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_124 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_124 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_124 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_125 : List (BitVec 512) := [w34,w2530,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_125 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_125 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(7,true)),(false,(0,false),(7,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s5_125 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_34,v0_2530,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_34 (PetersenWireProjection.cons pc0_2530 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_162 : List (BitVec 512) := [w70,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_162 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_162 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_162 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_163 : List (BitVec 512) := [w70,w2527,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_163 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_163 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s5_163 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_2527,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_2527 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_164 : List (BitVec 512) := [w70,w2528,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_164 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_164 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,false),(8,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s5_164 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_70,v0_2528,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_70 (PetersenWireProjection.cons pc0_2528 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_187 : List (BitVec 512) := [w83,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_187 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_187 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(0,false),(9,true))] s5_187 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_83,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_83 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_188 : List (BitVec 512) := [w85,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_188 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_188 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(0,false),(5,true)),(false,(9,true),(0,true)),(false,(0,false),(9,true))] s5_188 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_85,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_85 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_189 : List (BitVec 512) := [w86,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_189 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_189 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true))] s5_189 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_86,v0_3258,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_86 (PetersenWireProjection.cons pc0_3258 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_190 : List (BitVec 512) := [w87,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_190 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_190 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_190 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_87,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_87 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_191 : List (BitVec 512) := [w88,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_191 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_191 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_191 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_88,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_88 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_192 : List (BitVec 512) := [w89,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_192 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_192 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_192 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_89,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_89 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_193 : List (BitVec 512) := [w90,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_193 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_193 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_193 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_90,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_90 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_194 : List (BitVec 512) := [w91,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_194 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_194 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_194 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_91,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_91 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_197 : List (BitVec 512) := [w95,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_197 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_197 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true))] s5_197 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_95,v0_3258,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_95 (PetersenWireProjection.cons pc0_3258 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_198 : List (BitVec 512) := [w96,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_198 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_198 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_198 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_96,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_96 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_199 : List (BitVec 512) := [w97,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_199 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_199 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_199 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_97,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_97 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_200 : List (BitVec 512) := [w98,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_200 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_200 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s5_200 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_98,v0_2171,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_98 (PetersenWireProjection.cons pc0_2171 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_201 : List (BitVec 512) := [w100,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_201 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_201 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_201 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_100,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_100 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_202 : List (BitVec 512) := [w102,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_202 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_202 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_202 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_102,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_102 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_203 : List (BitVec 512) := [w103,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_203 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_203 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true)),(false,(8,true),(7,true))] s5_203 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_6179,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_204 : List (BitVec 512) := [w103,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_204 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_204 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(8,true),(2,true)),(false,(7,true),(3,true)),(false,(9,true),(10,true))] s5_204 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl)))))))))) (by decide +kernel)
def s5_205 : List (BitVec 512) := [w103,w3935,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b5_205 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_205 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(0,true),(1,true)),(false,(9,true),(3,true))] s5_205 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_103,v0_3935,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_103 (PetersenWireProjection.cons pc0_3935 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl)))))))))) (by decide +kernel)
def s5_305 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6599]
theorem b5_305 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_305 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_305 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_160,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6599] (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6599 rfl)))))))))) (by decide +kernel)
def s5_306 : List (BitVec 512) := [w160,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6321,w6588]
theorem b5_306 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_306 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s5_306 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_160,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6321,v0_6588] (PetersenWireProjection.cons pc0_160 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6321 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_353 : List (BitVec 512) := [w192,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6600]
theorem b5_353 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_353 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_353 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_192,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6600] (PetersenWireProjection.cons pc0_192 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6600 rfl)))))))))) (by decide +kernel)
def s5_378 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6601]
theorem b5_378 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_378 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_378 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6601] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6601 rfl)))))))))) (by decide +kernel)
def s5_379 : List (BitVec 512) := [w195,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6331,w6588]
theorem b5_379 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_379 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(9,true))] s5_379 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6331,v0_6588] (PetersenWireProjection.cons pc0_195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6331 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_432 : List (BitVec 512) := [w200,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6604]
theorem b5_432 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_432 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(7,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_432 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_200,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6604] (PetersenWireProjection.cons pc0_200 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6604 rfl)))))))))) (by decide +kernel)
def s5_461 : List (BitVec 512) := [w234,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_461 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_461 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_461 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_234,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_234 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_470 : List (BitVec 512) := [w258,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_470 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_470 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,false),(5,true)),(false,(0,true),(9,true)),(false,(0,false),(8,true))] s5_470 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_258,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_258 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_471 : List (BitVec 512) := [w260,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_471 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_471 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s5_471 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_260,v0_3258,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_260 (PetersenWireProjection.cons pc0_3258 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_472 : List (BitVec 512) := [w261,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_472 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_472 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_472 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_261,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_261 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_473 : List (BitVec 512) := [w262,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_473 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_473 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_473 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_262,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_262 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_474 : List (BitVec 512) := [w263,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_474 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_474 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_474 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_263,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_263 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_475 : List (BitVec 512) := [w264,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_475 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_475 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_475 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_264,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_264 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_476 : List (BitVec 512) := [w265,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_476 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_476 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_476 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_265,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_265 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_477 : List (BitVec 512) := [w266,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_477 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_477 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_477 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_266,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_266 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_480 : List (BitVec 512) := [w272,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_480 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_480 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_480 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_272,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_272 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_481 : List (BitVec 512) := [w274,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_481 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(7,true),(6,true)),(false,(3,true),(10,true))] s5_481 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_274,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_274 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl)))))))))) (by decide +kernel)
def s5_564 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6615]
theorem b5_564 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_564 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_564 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_332,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6615] (PetersenWireProjection.cons pc0_332 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6615 rfl)))))))))) (by decide +kernel)
def s5_565 : List (BitVec 512) := [w332,w3766,w4344,w4716,w5135,w5393,w5585,w5981,w6300,w6588]
theorem b5_565 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_565 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(8,true),(6,true)),(false,(1,true),(0,false)),(false,(0,true),(8,true))] s5_565 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_332,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5981,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_332 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5981 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_579 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6616]
theorem b5_579 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_579 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(5,true),(1,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_579 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_357,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6616] (PetersenWireProjection.cons pc0_357 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6616 rfl)))))))))) (by decide +kernel)
def s5_597 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6618]
theorem b5_597 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_597 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(10,true))] s5_597 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_360,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6618] (PetersenWireProjection.cons pc0_360 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6618 rfl)))))))))) (by decide +kernel)
def s5_598 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5993,w6300,w6588]
theorem b5_598 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_598 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(8,true))] s5_598 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_360,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5993,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_360 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5993 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_601 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5402,w5585,w5956,w6300,w6588]
theorem b5_601 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_601 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(5,true)),(false,(2,true),(5,true)),(false,(1,false),(0,true)),(false,(0,true),(6,true))] s5_601 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_360,v0_3766,v0_4344,v0_4716,v0_5135,v0_5402,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_360 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5402 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_618 : List (BitVec 512) := [w365,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6621]
theorem b5_618 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_618 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(6,true),(8,true)),(false,(1,true),(0,false)),(false,(0,true),(10,true))] s5_618 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_365,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6621] (PetersenWireProjection.cons pc0_365 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6621 rfl)))))))))) (by decide +kernel)
def s5_824 : List (BitVec 512) := [w566,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_824 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_824 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true))] s5_824 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_566,v0_3258,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_566 (PetersenWireProjection.cons pc0_3258 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_825 : List (BitVec 512) := [w567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_825 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_825 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_825 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_826 : List (BitVec 512) := [w568,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_826 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_826 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_826 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_568,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_568 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_827 : List (BitVec 512) := [w569,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_827 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_827 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_827 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_569,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_569 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_829 : List (BitVec 512) := [w571,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_829 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_829 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true))] s5_829 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_571,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_571 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_830 : List (BitVec 512) := [w572,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_830 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_830 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(3,true),(0,true))] s5_830 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_572,v0_2681,v0_3766,v0_4344,v0_4716,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_572 (PetersenWireProjection.cons pc0_2681 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s5_831 : List (BitVec 512) := [w573,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_831 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_831 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s5_831 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_573,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_573 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
end NineCert
