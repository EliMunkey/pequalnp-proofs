import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_5080 : List (BitVec 512) := [w1076,w1664,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_5080 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5080 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(4,true)),(false,(4,true),(8,true))] s4_5080 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1664,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1664 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5081 : List (BitVec 512) := [w1076,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5081 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5081 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(4,true))] s4_5081 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1666,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1666 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5082 : List (BitVec 512) := [w1076,w1666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5082 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5082 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(4,true))] s4_5082 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1666,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1666 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5083 : List (BitVec 512) := [w1076,w1668,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5083 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(4,true))] s4_5083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1668,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1668 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5084 : List (BitVec 512) := [w1076,w1669,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5084 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_5084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1669,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1669 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5085 : List (BitVec 512) := [w1076,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5085 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5085 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(4,true))] s4_5085 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1670,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1670 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5086 : List (BitVec 512) := [w1076,w1670,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5086 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5086 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(4,true))] s4_5086 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1670,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1670 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5087 : List (BitVec 512) := [w1076,w1670,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5087 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5087 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(4,true))] s4_5087 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1670,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1670 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5088 : List (BitVec 512) := [w1076,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_5088 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5088 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_5088 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1672,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1672 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5089 : List (BitVec 512) := [w1076,w1672,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5089 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5089 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true))] s4_5089 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1672,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1672 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5090 : List (BitVec 512) := [w1076,w1673,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5090 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5090 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,false),(3,true)),(false,(5,true),(0,true))] s4_5090 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1673,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1673 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5091 : List (BitVec 512) := [w1076,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5091 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5091 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true))] s4_5091 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1674,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1674 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5092 : List (BitVec 512) := [w1076,w1674,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5092 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5092 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(4,true)),(false,(0,true),(4,true))] s4_5092 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1674,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1674 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5093 : List (BitVec 512) := [w1076,w1674,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_5093 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5093 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(7,true)),(false,(0,true),(4,true))] s4_5093 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1674,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6101,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1674 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5094 : List (BitVec 512) := [w1076,w1676,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5094 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5094 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,false),(8,true)),(false,(0,true),(5,true))] s4_5094 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1676,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1676 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5095 : List (BitVec 512) := [w1076,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5095 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5095 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true))] s4_5095 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5096 : List (BitVec 512) := [w1076,w1867,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5096 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5096 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true))] s4_5096 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1867,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5097 : List (BitVec 512) := [w1076,w1867,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_5097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5097 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,true)),(false,(4,true),(6,true))] s4_5097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1867,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1867 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5098 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4483,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5098 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5098 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(3,true))] s4_5098 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4483,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4483 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5099 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_5099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5099 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_5099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5100 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_5100 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5100 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true))] s4_5100 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5101 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_5101 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5101 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_5101 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_4716,v4_5135,v4_5471,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5102 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5102 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_5102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5103 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_5103 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5103 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_5103 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5104 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_5104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5104 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(3,true),(7,true))] s4_5104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5848,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5848 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5105 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_5105 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5105 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(4,true),(3,true))] s4_5105 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5106 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5106 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5106 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_5106 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5107 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6618]
theorem b4_5107 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5107 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(5,true))] s4_5107 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6618] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6618 rfl))))))))))) (by decide +kernel)
def s4_5108 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_5108 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5108 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(5,true),(3,true))] s4_5108 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5109 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_5109 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5109 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_5109 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5110 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_5110 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5110 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(5,true),(7,true))] s4_5110 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6813] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6813 rfl))))))))))) (by decide +kernel)
def s4_5111 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6588,w6873]
theorem b4_5111 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5111 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(4,true),(5,true))] s4_5111 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5112 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5112 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5112 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true))] s4_5112 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_5113 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6101,w6225,w6300,w6588]
theorem b4_5113 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5113 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(7,true),(6,true)),(false,(8,true),(0,true))] s4_5113 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6101,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6101 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5114 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6179,w6225,w6300,w6588]
theorem b4_5114 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5114 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(8,true),(0,true))] s4_5114 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6179,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5115 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_5115 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5115 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(8,true))] s4_5115 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_6225,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5116 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_5116 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5116 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true))] s4_5116 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5117 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b4_5117 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5117 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(7,true),(3,true))] s4_5117 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5393,v4_5698,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5698 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5118 : List (BitVec 512) := [w1076,w1875,w3766,w4344,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_5118 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5118 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,false),(7,true)),(false,(0,true),(6,true))] s4_5118 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1875,v4_3766,v4_4344,v4_5135,v4_5471,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1875 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5471 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl)))))))))) (by decide +kernel)
def s4_5119 : List (BitVec 512) := [w1076,w1883,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5119 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5119 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(8,true))] s4_5119 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1883,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1883 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5120 : List (BitVec 512) := [w1076,w1883,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5120 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5120 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(0,true),(8,true))] s4_5120 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1883,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1883 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5121 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5121 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true))] s4_5121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5122 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5122 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5122 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true))] s4_5122 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5123 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6543,w6588]
theorem b4_5123 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5123 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_5123 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6543,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6543 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5124 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w6389,w6522,w6588]
theorem b4_5124 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5124 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true)),(false,(5,true),(9,true))] s4_5124 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6389,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5125 : List (BitVec 512) := [w1076,w1891,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5125 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5125 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(8,true),(0,true))] s4_5125 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1891,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1891 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5126 : List (BitVec 512) := [w1076,w1892,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6588]
theorem b4_5126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5126 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,false),(7,true)),(false,(4,true),(3,true))] s4_5126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1892,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6389,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1892 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6389 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5127 : List (BitVec 512) := [w1076,w1893,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5127 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5127 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(8,true))] s4_5127 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1893,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1893 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5128 : List (BitVec 512) := [w1076,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5128 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5128 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true))] s4_5128 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1894,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1894 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5129 : List (BitVec 512) := [w1076,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5129 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5129 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true))] s4_5129 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1894,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1894 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5130 : List (BitVec 512) := [w1076,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6588,w6873]
theorem b4_5130 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5130 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(0,true),(8,true)),(false,(5,true),(6,true))] s4_5130 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1894,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6588,v4_6873] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1894 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6873 rfl))))))))))) (by decide +kernel)
def s4_5131 : List (BitVec 512) := [w1076,w1895,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5131 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5131 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_5131 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1895,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1895 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5132 : List (BitVec 512) := [w1076,w1896,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5132 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5132 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(6,true)),(false,(8,true),(0,true))] s4_5132 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1896,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1896 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5133 : List (BitVec 512) := [w1076,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6522,w6588]
theorem b4_5133 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5133 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true)),(false,(5,true),(9,true))] s4_5133 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5134 : List (BitVec 512) := [w1076,w1908,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6852]
theorem b4_5134 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5134 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_5134 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6588,v4_6852] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6852 rfl))))))))))) (by decide +kernel)
def s4_5135 : List (BitVec 512) := [w1076,w1908,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5135 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5135 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(2,true)),(false,(0,true),(8,true))] s4_5135 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5136 : List (BitVec 512) := [w1076,w1908,w3766,w4716,w5135,w5393,w5585,w6061,w6300,w6588,w6690]
theorem b4_5136 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5136 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true)),(false,(4,true),(9,true))] s4_5136 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1908,v4_3766,v4_4716,v4_5135,v4_5393,v4_5585,v4_6061,v4_6300,v4_6588,v4_6690] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1908 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6061 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_5137 : List (BitVec 512) := [w1076,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5137 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5137 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true))] s4_5137 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1910,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1910 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5138 : List (BitVec 512) := [w1076,w1910,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5138 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5138 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,true),(8,true))] s4_5138 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1910,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1910 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5139 : List (BitVec 512) := [w1076,w1912,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5139 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5139 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,false),(3,true)),(false,(0,true),(9,true))] s4_5139 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1912,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1912 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5140 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5140 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5140 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s4_5140 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5141 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_5141 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5141 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(4,true)),(false,(0,true),(8,true))] s4_5141 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_5142 : List (BitVec 512) := [w1076,w1913,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_5142 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5142 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(4,true),(6,true)),(false,(0,true),(8,true))] s4_5142 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1913,v4_3766,v4_4344,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1913 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_5143 : List (BitVec 512) := [w1076,w1915,w3766,w4344,w4716,w5135,w5393,w5585,w6300,w6588,w6908]
theorem b4_5143 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5143 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(4,true)),(false,(8,true),(0,true)),(false,(1,false),(9,true))] s4_5143 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1076,v4_1915,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_6300,v4_6588,v4_6908] (PetersenWireProjection.cons pc4_1076 (PetersenWireProjection.cons pc4_1915 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6908 rfl))))))))))) (by decide +kernel)
end NineCert
