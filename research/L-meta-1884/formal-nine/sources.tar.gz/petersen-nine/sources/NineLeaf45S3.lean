import NinePin45
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_7503 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785,w6807]
theorem b4_7503 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7503 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7503 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6785,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7504 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6807]
theorem b4_7504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7504 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6179,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s4_7513 : List (BitVec 512) := [w1292,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_7513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7513 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4344,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7515 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6690]
theorem b4_7515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7515 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5848,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7516 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6690]
theorem b4_7516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7516 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(0,true))] s4_7516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6101,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7517 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6690]
theorem b4_7517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7517 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6201,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7519 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6807]
theorem b4_7519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7519 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6389,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7520 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6690]
theorem b4_7520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7520 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_7520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6422,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7521 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6690]
theorem b4_7521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7521 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6478,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6478 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7522 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6522,w6690]
theorem b4_7522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7522 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_7522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6522,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6690 rfl))))))))))) (by decide +kernel)
def s4_7524 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6748]
theorem b4_7524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7524 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_7524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690,v45_6748] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6748 rfl))))))))))) (by decide +kernel)
def s4_7525 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6852]
theorem b4_7525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7525 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(1,true))] s4_7525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690,v45_6852] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6852 rfl))))))))))) (by decide +kernel)
def s4_7526 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6690,w6890]
theorem b4_7526 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7526 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s4_7526 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6690,v45_6890] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6890 rfl))))))))))) (by decide +kernel)
def s4_7527 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6389,w6422,w6588]
theorem b4_7527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7527 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(0,true))] s4_7527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6389,v45_6422,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6422 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7528 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6389,w6522,w6588]
theorem b4_7528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7528 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s4_7528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6389,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7529 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b4_7529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7529 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5848,v45_5956,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7531 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690]
theorem b4_7531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7531 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6061,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6061 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7532 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5956,w6061,w6300,w6690,w6807]
theorem b4_7532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7532 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6061,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6061 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_7533 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6389,w6588]
theorem b4_7533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7533 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7535 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6690]
theorem b4_7535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7535 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6201,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6201 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7536 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b4_7536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7536 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7538 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b4_7538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7538 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_7539 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6389,w6588]
theorem b4_7539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7539 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6389,v45_6588] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6389 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_7541 : List (BitVec 512) := [w1292,w3766,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6690]
theorem b4_7541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7541 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_7541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1292,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6179,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s4_8264 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_8264 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8264 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(5,true))] s4_8264 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1328,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1328 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_8373 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6807]
theorem b4_8373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8373 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,false),(5,true))] s4_8373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1328,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1328 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_9341 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9341 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9341 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s4_9341 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1384,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_9451 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6807]
theorem b4_9451 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9451 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s4_9451 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1384,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_10373 : List (BitVec 512) := [w1415,w3258,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10373 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10373 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(5,true))] s4_10373 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1415,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_1415 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_10477 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6807]
theorem b4_10477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10477 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,false),(5,true))] s4_10477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_1415,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6807] (PetersenWireProjection.cons pc45_1415 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6807 rfl))))))))))) (by decide +kernel)
def s4_12361 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5263,w5585,w5698,w5956,w6300,w6588]
theorem b4_12361 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12361 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s4_12361 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5263,v45_5585,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5263 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_12394 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5689,w5698,w5956,w6300,w6588]
theorem b4_12394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12394 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s4_12394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5689,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_16247 : List (BitVec 512) := [w3766,w4344,w4452,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_16247 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16247 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_16247 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4452,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6225,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4452 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6225 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_16248 : List (BitVec 512) := [w3766,w4344,w4452,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_16248 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_16248 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_16248 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4452,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4452 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_17171 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5683,w5956,w6300,w6588,w6873]
theorem b4_17171 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17171 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(5,true))] s4_17171 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5683,v45_5956,v45_6300,v45_6588,v45_6873] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5683 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6873 rfl))))))))))) (by decide +kernel)
def s4_17173 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5848,w5956,w6300,w6588]
theorem b4_17173 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17173 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_17173 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5848,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5848 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17174 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5956,w6300,w6572,w6588]
theorem b4_17174 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17174 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_17174 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5956,v45_6300,v45_6572,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6572 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17175 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5689,w5956,w6300,w6588,w6720]
theorem b4_17175 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17175 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(5,true))] s4_17175 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5689,v45_5956,v45_6300,v45_6588,v45_6720] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5689 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 (PetersenWireProjection.cons pc45_6720 rfl))))))))))) (by decide +kernel)
def s4_17177 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5690,w5698,w5956,w6300,w6588]
theorem b4_17177 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17177 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_17177 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5690,v45_5698,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5690 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17178 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5690,w5956,w6101,w6300,w6588]
theorem b4_17178 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17178 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_17178 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5690,v45_5956,v45_6101,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5690 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6101 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17179 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5690,w5956,w6300,w6522,w6588]
theorem b4_17179 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17179 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true))] s4_17179 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5690,v45_5956,v45_6300,v45_6522,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5690 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6522 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17181 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5690,w5956,w6300,w6588]
theorem b4_17181 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17181 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s4_17181 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5690,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5690 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s4_17193 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6237,w6300,w6588]
theorem b4_17193 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17193 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(1,true))] s4_17193 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6237,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6237 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17196 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6499,w6588]
theorem b4_17196 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17196 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(0,true),(3,true))] s4_17196 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6499,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6499 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s4_17204 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6572,w6588]
theorem b4_17204 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17204 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true))] s4_17204 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5698,v45_5956,v45_6300,v45_6572,v45_6588] (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6572 (PetersenWireProjection.cons pc45_6588 rfl))))))))))) (by decide +kernel)
def s5_43 : List (BitVec 512) := [w13,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_43 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_43 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_43 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_13,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_13 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_102 : List (BitVec 512) := [w28,w1292,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6588]
theorem b5_102 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_102 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_102 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_1292,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_1292 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_104 : List (BitVec 512) := [w28,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_104 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_104 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(1,true)),(false,(3,true),(0,true))] s5_104 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_106 : List (BitVec 512) := [w28,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_106 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_106 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_106 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_108 : List (BitVec 512) := [w28,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_108 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_108 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_108 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_28,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_28 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_346 : List (BitVec 512) := [w191,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_346 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_346 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_346 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_191,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_191 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_347 : List (BitVec 512) := [w192,w2171,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6600]
theorem b5_347 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_347 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(3,true))] s5_347 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_2171,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6600] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_2171 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6600 rfl)))))))))) (by decide +kernel)
def s5_348 : List (BitVec 512) := [w192,w2178,w3766,w4344,w4716,w5135,w5393,w5956,w6300,w6588]
theorem b5_348 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_348 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(3,true),(5,true))] s5_348 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_192,v45_2178,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_192 (PetersenWireProjection.cons pc45_2178 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_572 : List (BitVec 512) := [w357,w1384,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6785]
theorem b5_572 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_572 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,false),(5,true))] s5_572 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_1384,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6785] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_1384 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6785 rfl)))))))))) (by decide +kernel)
def s5_577 : List (BitVec 512) := [w357,w3258,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588]
theorem b5_577 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_577 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_577 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3258,v45_4344,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_583 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w6179,w6300,w6690,w6807]
theorem b5_583 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_583 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_583 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_6179,v45_6300,v45_6690,v45_6807] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6807 rfl)))))))))) (by decide +kernel)
def s5_584 : List (BitVec 512) := [w357,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6690]
theorem b5_584 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_584 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_584 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5769,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5769 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_585 : List (BitVec 512) := [w357,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690]
theorem b5_585 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_585 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_585 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl))))))))) (by decide +kernel)
def s5_586 : List (BitVec 512) := [w357,w3766,w4716,w5135,w5393,w5698,w6179,w6300,w6690,w6832]
theorem b5_586 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_586 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(5,true))] s5_586 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_357,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_6179,v45_6300,v45_6690,v45_6832] (PetersenWireProjection.cons pc45_357 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_6179 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 (PetersenWireProjection.cons pc45_6832 rfl)))))))))) (by decide +kernel)
def s5_906 : List (BitVec 512) := [w627,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_906 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_906 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_906 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_627,v45_3766,v45_4344,v45_4716,v45_5135,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_627 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_908 : List (BitVec 512) := [w628,w2164,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6690]
theorem b5_908 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_908 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [] s5_908 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2164,v45_3766,v45_4716,v45_5135,v45_5393,v45_5698,v45_5956,v45_6300,v45_6690] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2164 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5698 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6690 rfl)))))))))) (by decide +kernel)
def s5_910 : List (BitVec 512) := [w628,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_910 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_910 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(1,true),(3,true)),(false,(3,true),(0,true))] s5_910 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2468,v45_3766,v45_4344,v45_4716,v45_5135,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2468 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5135 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_911 : List (BitVec 512) := [w628,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_911 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_911 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s5_911 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2681,v45_3258,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6588] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2681 (PetersenWireProjection.cons pc45_3258 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6588 rfl)))))))))) (by decide +kernel)
def s5_912 : List (BitVec 512) := [w628,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6643]
theorem b5_912 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_912 := by
  intro m le c
  apply rejects_sound r45 i6 7 tgt (small45 adj) hot45 [(false,(5,true),(0,true)),(false,(5,true),(0,true))] s5_912 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v45_628,v45_2681,v45_3766,v45_4344,v45_4716,v45_5393,v45_5585,v45_5956,v45_6300,v45_6643] (PetersenWireProjection.cons pc45_628 (PetersenWireProjection.cons pc45_2681 (PetersenWireProjection.cons pc45_3766 (PetersenWireProjection.cons pc45_4344 (PetersenWireProjection.cons pc45_4716 (PetersenWireProjection.cons pc45_5393 (PetersenWireProjection.cons pc45_5585 (PetersenWireProjection.cons pc45_5956 (PetersenWireProjection.cons pc45_6300 (PetersenWireProjection.cons pc45_6643 rfl)))))))))) (by decide +kernel)
end NineCert
