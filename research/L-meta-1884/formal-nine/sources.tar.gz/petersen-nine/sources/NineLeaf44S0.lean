import NinePin44
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1913 : List (BitVec 512) := [w332,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1913 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1913 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(4,true))] s4_1913 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_332,v44_1672,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_332 (PetersenWireProjection.cons pc44_1672 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_1919 : List (BitVec 512) := [w332,w2167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_1919 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1919 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(4,true))] s4_1919 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_332,v44_2167,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_332 (PetersenWireProjection.cons pc44_2167 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_2039 : List (BitVec 512) := [w357,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2039 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2039 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(2,true),(4,true))] s4_2039 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_357,v44_1672,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_357 (PetersenWireProjection.cons pc44_1672 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_2063 : List (BitVec 512) := [w357,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_2063 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2063 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(4,true),(2,true))] s4_2063 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_357,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588,v44_6832] (PetersenWireProjection.cons pc44_357 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 (PetersenWireProjection.cons pc44_6832 rfl))))))))))) (by decide +kernel)
def s4_2102 : List (BitVec 512) := [w360,w1672,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2102 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2102 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s4_2102 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_360,v44_1672,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_360 (PetersenWireProjection.cons pc44_1672 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_2169 : List (BitVec 512) := [w360,w3178,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2169 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2169 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s4_2169 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_360,v44_3178,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_360 (PetersenWireProjection.cons pc44_3178 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_2244 : List (BitVec 512) := [w360,w3766,w4344,w4716,w5135,w5393,w5585,w5765,w5956,w6300,w6588]
theorem b4_2244 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2244 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s4_2244 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_360,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5765,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_360 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5765 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_2325 : List (BitVec 512) := [w365,w2167,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_2325 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_2325 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(1,true),(0,true))] s4_2325 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_365,v44_2167,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_365 (PetersenWireProjection.cons pc44_2167 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_7471 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6171,w6179,w6300,w6588]
theorem b4_7471 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7471 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(2,true),(4,true))] s4_7471 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1292,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5956,v44_6171,v44_6179,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_1292 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6171 (PetersenWireProjection.cons pc44_6179 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_7972 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6216,w6300,w6588]
theorem b4_7972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7972 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s4_7972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1312,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6216,v44_6300,v44_6588] (PetersenWireProjection.cons pc44_1312 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6216 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_10170 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6510,w6522,w6588]
theorem b4_10170 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10170 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(1,true),(4,true))] s4_10170 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1403,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6510,v44_6522,v44_6588] (PetersenWireProjection.cons pc44_1403 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6510 (PetersenWireProjection.cons pc44_6522 (PetersenWireProjection.cons pc44_6588 rfl))))))))))) (by decide +kernel)
def s4_17277 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5765,w5956,w6300,w6690,w6832]
theorem b4_17277 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17277 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [] s4_17277 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5765,v44_5956,v44_6300,v44_6690,v44_6832] (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5765 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6690 (PetersenWireProjection.cons pc44_6832 rfl))))))))))) (by decide +kernel)
def s5_2522 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5956,w6170,w6300,w6785]
theorem b5_2522 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2522 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(2,true),(0,true))] s5_2522 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1312,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5956,v44_6170,v44_6300,v44_6785] (PetersenWireProjection.cons pc44_1312 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6170 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6785 rfl)))))))))) (by decide +kernel)
def s5_2540 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6093,w6300,w6720]
theorem b5_2540 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2540 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(2,true),(0,true))] s5_2540 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1312,v44_3766,v44_4344,v44_5135,v44_5393,v44_5585,v44_5956,v44_6093,v44_6300,v44_6720] (PetersenWireProjection.cons pc44_1312 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6093 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6720 rfl)))))))))) (by decide +kernel)
def s5_2544 : List (BitVec 512) := [w1312,w3766,w4344,w5135,w5393,w5585,w5956,w6216,w6300,w6720]
theorem b5_2544 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2544 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s5_2544 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1312,v44_3766,v44_4344,v44_5135,v44_5393,v44_5585,v44_5956,v44_6216,v44_6300,v44_6720] (PetersenWireProjection.cons pc44_1312 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6216 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6720 rfl)))))))))) (by decide +kernel)
def s5_2835 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5695,w6179,w6300,w6832]
theorem b5_2835 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2835 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [] s5_2835 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1374,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5695,v44_6179,v44_6300,v44_6832] (PetersenWireProjection.cons pc44_1374 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5695 (PetersenWireProjection.cons pc44_6179 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6832 rfl)))))))))) (by decide +kernel)
def s5_3165 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6510,w6873]
theorem b5_3165 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3165 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(1,true),(4,true))] s5_3165 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_1403,v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5956,v44_6510,v44_6873] (PetersenWireProjection.cons pc44_1403 (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6510 (PetersenWireProjection.cons pc44_6873 rfl)))))))))) (by decide +kernel)
def s5_5811 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5765,w5956,w6300,w6618]
theorem b5_5811 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5811 := by
  intro m le c
  apply rejects_sound r44 i7 8 tgt (small44 adj) hot44 [(false,(0,true),(2,true))] s5_5811 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v44_3766,v44_4344,v44_4716,v44_5135,v44_5393,v44_5585,v44_5765,v44_5956,v44_6300,v44_6618] (PetersenWireProjection.cons pc44_3766 (PetersenWireProjection.cons pc44_4344 (PetersenWireProjection.cons pc44_4716 (PetersenWireProjection.cons pc44_5135 (PetersenWireProjection.cons pc44_5393 (PetersenWireProjection.cons pc44_5585 (PetersenWireProjection.cons pc44_5765 (PetersenWireProjection.cons pc44_5956 (PetersenWireProjection.cons pc44_6300 (PetersenWireProjection.cons pc44_6618 rfl)))))))))) (by decide +kernel)
end NineCert
