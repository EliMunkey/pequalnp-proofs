import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_3093 : List (BitVec 512) := [w1403,w2354,w3766,w4716,w5135,w5393,w5585,w5698,w6522,w6588]
theorem b5_3093 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3093 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(6,true),(5,true))] s5_3093 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2354,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3094 : List (BitVec 512) := [w1403,w2410,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_3094 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3094 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_3094 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2410,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2410 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3095 : List (BitVec 512) := [w1403,w2427,w3766,w4344,w4716,w5135,w5393,w5585,w6522,w6588]
theorem b5_3095 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3095 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(6,true),(5,true))] s5_3095 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2427,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2427 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3097 : List (BitVec 512) := [w1403,w2468,w3766,w4344,w4716,w5135,w5311,w5585,w5956,w6588]
theorem b5_3097 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3097 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true))] s5_3097 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5311,v2_5585,v2_5956,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5311 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3178 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6522,w6873]
theorem b5_3178 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3178 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(0,false),(2,true)),(false,(4,true),(5,true)),(false,(10,true),(1,true))] s5_3178 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6873] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3179 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6158,w6522,w6890]
theorem b5_3179 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3179 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true)),(false,(6,true),(5,true))] s5_3179 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6158,v2_6522,v2_6890] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6890 rfl)))))))))) (by decide +kernel)
def s5_3180 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6163,w6522,w6588]
theorem b5_3180 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3180 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_3180 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6163,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6163 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3187 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5585,w6246,w6522,w6588]
theorem b5_3187 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3187 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(6,true),(5,true))] s5_3187 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_6246,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3190 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5884,w5956,w6464,w6873]
theorem b5_3190 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3190 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(3,true)),(false,(0,false),(2,true)),(false,(5,true),(7,true)),(false,(10,true),(1,true))] s5_3190 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3191 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5393,w5884,w6179,w6522,w6588]
theorem b5_3191 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3191 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(4,true),(7,true)),(false,(6,true),(5,true))] s5_3191 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_6179,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3199 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5187,w5393,w5585,w6158,w6522,w6588]
theorem b5_3199 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3199 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(5,true),(4,true)),(false,(1,true),(7,true))] s5_3199 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_4716,v2_5187,v2_5393,v2_5585,v2_6158,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5187 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3203 : List (BitVec 512) := [w1403,w3766,w4344,w5135,w5393,w5518,w5585,w6101,w6522,w6588]
theorem b5_3203 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3203 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(0,true),(8,true)),(false,(8,true),(4,true)),(false,(6,true),(5,true))] s5_3203 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4344,v2_5135,v2_5393,v2_5518,v2_5585,v2_6101,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5518 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3213 : List (BitVec 512) := [w1403,w3766,w4716,w5135,w5393,w5585,w5698,w6158,w6522,w6588]
theorem b5_3213 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3213 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(0,true),(8,true)),(false,(3,true),(7,true)),(false,(6,true),(5,true))] s5_3213 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1403,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_6158,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_1403 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3245 : List (BitVec 512) := [w1415,w2320,w3766,w4344,w4716,w5135,w5393,w5956,w6464,w6873]
theorem b5_3245 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3245 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_3245 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_2320,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_2320 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3278 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5313,w5585,w5956,w6300,w6588]
theorem b5_3278 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3278 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(0,true),(9,true))] s5_3278 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5313,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5313 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3294 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5884,w5956,w6464,w6873]
theorem b5_3294 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3294 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(0,false),(2,true)),(false,(0,true),(9,true)),(false,(6,true),(10,true))] s5_3294 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_1415,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5884,v2_5956,v2_6464,v2_6873] (PetersenWireProjection.cons pc2_1415 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5884 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3365 : List (BitVec 512) := [w2205,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3365 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3365 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(8,true)),(false,(1,true),(0,true))] s5_3365 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2205,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2205 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3366 : List (BitVec 512) := [w2206,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3366 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3366 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(1,true),(0,true)),(false,(5,true),(8,true)),(false,(1,true),(0,true))] s5_3366 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2206,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2206 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3368 : List (BitVec 512) := [w2207,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3368 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3368 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(4,true),(5,true)),(false,(1,true),(0,true))] s5_3368 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2207,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2207 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3369 : List (BitVec 512) := [w2208,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3369 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3369 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(1,true),(0,true)),(false,(8,true),(9,true)),(false,(1,true),(0,true))] s5_3369 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2208,v2_3258,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2208 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3390 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w5956,w6389,w6422,w6588]
theorem b5_3390 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3390 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false)),(false,(8,true),(5,true))] s5_3390 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3391 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w6061,w6101,w6300,w6588]
theorem b5_3391 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3391 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s5_3391 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3392 : List (BitVec 512) := [w2223,w2488,w3766,w4716,w5135,w5585,w6101,w6300,w6543,w6588]
theorem b5_3392 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3392 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(8,true),(4,true))] s5_3392 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2488,v2_3766,v2_4716,v2_5135,v2_5585,v2_6101,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3393 : List (BitVec 512) := [w2223,w2681,w3258,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b5_3393 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3393 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true)),(false,(3,true),(0,true))] s5_3393 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3258,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3258 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3394 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b5_3394 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3394 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true)),(false,(0,false),(6,true))] s5_3394 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3395 : List (BitVec 512) := [w2223,w2681,w3766,w4716,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_3395 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3395 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(4,true)),(false,(6,true),(4,true))] s5_3395 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3396 : List (BitVec 512) := [w2223,w2681,w3766,w5393,w5585,w6061,w6101,w6300,w6588,w6720]
theorem b5_3396 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3396 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true)),(false,(5,true),(9,true))] s5_3396 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2681,v2_3766,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl)))))))))) (by decide +kernel)
def s5_3397 : List (BitVec 512) := [w2223,w2686,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_3397 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3397 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(5,true))] s5_3397 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3398 : List (BitVec 512) := [w2223,w2686,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3398 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3398 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(6,true),(4,true))] s5_3398 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2686,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3399 : List (BitVec 512) := [w2223,w2690,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3399 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3399 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true)),(false,(4,true),(6,true))] s5_3399 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3400 : List (BitVec 512) := [w2223,w2690,w3766,w4716,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_3400 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3400 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true)),(false,(5,true),(4,true))] s5_3400 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2690,v2_3766,v2_4716,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3401 : List (BitVec 512) := [w2223,w2691,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_3401 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3401 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(8,true)),(false,(0,false),(8,true)),(false,(7,true),(0,true))] s5_3401 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2691,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2691 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3402 : List (BitVec 512) := [w2223,w2696,w3766,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b5_3402 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3402 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(5,true),(4,true))] s5_3402 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3403 : List (BitVec 512) := [w2223,w2696,w3766,w4716,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b5_3403 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3403 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(3,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true)),(false,(6,true),(4,true))] s5_3403 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2696,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2696 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3404 : List (BitVec 512) := [w2223,w2697,w3766,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b5_3404 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3404 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(1,false),(0,false)),(false,(7,true),(0,true))] s5_3404 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_2697,v2_3766,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_2697 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3405 : List (BitVec 512) := [w2223,w3293,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b5_3405 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3405 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(6,true),(2,false))] s5_3405 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3293,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3406 : List (BitVec 512) := [w2223,w3293,w4716,w5135,w5393,w5585,w6061,w6101,w6300,w6588]
theorem b5_3406 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3406 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(0,false),(6,true)),(false,(2,true),(0,true)),(false,(5,true),(9,true))] s5_3406 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3293,v2_4716,v2_5135,v2_5393,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3293 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3407 : List (BitVec 512) := [w2223,w3303,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b5_3407 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3407 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(2,true),(0,true)),(false,(5,true),(2,false))] s5_3407 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3303,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3408 : List (BitVec 512) := [w2223,w3303,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b5_3408 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3408 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(2,true),(0,true)),(false,(6,true),(9,true))] s5_3408 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3303,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3409 : List (BitVec 512) := [w2223,w3303,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b5_3409 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3409 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(0,false)),(false,(2,true),(0,true)),(false,(6,true),(5,true))] s5_3409 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3303,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3303 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3410 : List (BitVec 512) := [w2223,w3312,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b5_3410 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3410 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true)),(false,(0,false),(7,true)),(false,(3,true),(0,true))] s5_3410 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3312,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3312 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3411 : List (BitVec 512) := [w2223,w3766,w4344,w4716,w5135,w5393,w6179,w6522,w6785,w6873]
theorem b5_3411 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3411 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(3,true),(4,true)),(false,(9,true),(5,true)),(false,(5,true),(8,true))] s5_3411 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_6179,v2_6522,v2_6785,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6785 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3412 : List (BitVec 512) := [w2223,w3766,w4344,w5135,w5393,w5585,w6101,w6522,w6720,w6873]
theorem b5_3412 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3412 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(8,true)),(false,(5,true),(9,true)),(false,(5,true),(9,true))] s5_3412 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_6101,v2_6522,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3413 : List (BitVec 512) := [w2223,w3766,w4344,w5135,w5393,w5769,w5956,w6464,w6720,w6873]
theorem b5_3413 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3413 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(8,true),(7,true)),(false,(7,true),(8,true)),(false,(10,true),(6,true))] s5_3413 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4344,v2_5135,v2_5393,v2_5769,v2_5956,v2_6464,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl)))))))))) (by decide +kernel)
def s5_3414 : List (BitVec 512) := [w2223,w3766,w4369,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3414 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3414 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(8,true)),(false,(0,false),(8,true)),(false,(0,true),(4,true))] s5_3414 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4369,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4369 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3415 : List (BitVec 512) := [w2223,w3766,w4425,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3415 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3415 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(0,true)),(false,(0,false),(8,true)),(false,(0,true),(4,true))] s5_3415 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4425,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4425 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3416 : List (BitVec 512) := [w2223,w3766,w4589,w4716,w5200,w5393,w5585,w5956,w6300,w6588]
theorem b5_3416 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3416 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(2,true)),(false,(0,true),(7,true)),(false,(0,true),(3,true)),(false,(1,true),(7,true))] s5_3416 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4589,v2_4716,v2_5200,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4589 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5200 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3417 : List (BitVec 512) := [w2223,w3766,w4593,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_3417 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3417 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,false),(3,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s5_3417 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4593,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4593 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3418 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5645,w6389,w6522,w6588]
theorem b5_3418 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3418 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,true)),(false,(5,true),(4,true)),(false,(1,true),(8,true))] s5_3418 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5645,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5645 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3419 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6082,w6300,w6588]
theorem b5_3419 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3419 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(5,true)),(false,(0,true),(7,true)),(false,(3,true),(4,true)),(false,(1,true),(0,false))] s5_3419 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6082,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6082 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3420 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6200,w6300,w6588]
theorem b5_3420 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3420 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(7,true)),(false,(3,true),(6,true)),(false,(1,true),(0,true)),(false,(0,true),(4,true))] s5_3420 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6200,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6200 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3421 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6415,w6588]
theorem b5_3421 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3421 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(0,true),(7,true)),(false,(5,true),(3,true)),(false,(1,true),(0,false))] s5_3421 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6415,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6415 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3422 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6334,w6389,w6588]
theorem b5_3422 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3422 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,true)),(false,(5,true),(3,true)),(false,(1,true),(6,true))] s5_3422 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6334,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6334 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3423 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6353,w6389,w6588]
theorem b5_3423 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3423 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(0,true),(6,true)),(false,(3,true),(5,true)),(false,(1,true),(6,true))] s5_3423 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6353,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6353 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3424 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6370,w6389,w6588]
theorem b5_3424 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3424 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3424 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6370,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6370 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3425 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6371,w6389,w6588]
theorem b5_3425 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3425 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3425 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6371,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6371 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3426 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6372,w6389,w6588]
theorem b5_3426 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3426 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(5,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3426 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6372,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6372 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3427 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6373,w6389,w6588]
theorem b5_3427 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3427 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3427 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6373,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6373 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3428 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6374,w6389,w6588]
theorem b5_3428 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3428 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(2,true),(4,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3428 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6374,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6374 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3429 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w5956,w6375,w6389,w6588]
theorem b5_3429 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3429 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(4,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(6,true))] s5_3429 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6375,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6375 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3430 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w6038,w6061,w6300,w6588]
theorem b5_3430 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3430 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(2,true)),(false,(6,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_3430 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6038,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6038 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3431 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w6039,w6061,w6300,w6588]
theorem b5_3431 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3431 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(3,true),(2,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_3431 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6039,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6039 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3432 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w6040,w6061,w6300,w6588]
theorem b5_3432 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3432 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(3,true)),(false,(1,true),(0,false)),(false,(0,true),(5,true))] s5_3432 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6040,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6040 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s5_3433 : List (BitVec 512) := [w2223,w3766,w4716,w5135,w5393,w5585,w6041,w6061,w6300,w6588]
theorem b5_3433 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3433 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(8,true),(7,true)),(false,(1,false),(0,true)),(false,(0,true),(5,true))] s5_3433 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2223,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_6041,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2223 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6041 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
end NineCert
