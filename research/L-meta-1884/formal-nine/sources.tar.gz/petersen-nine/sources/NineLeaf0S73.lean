import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_13829 : List (BitVec 512) := [w3567,w3766,w4344,w4599,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_13829 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13829 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(0,true)),(false,(0,true),(2,true))] s4_13829 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4599,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4599 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13830 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5750,w5956,w6300,w6588]
theorem b4_13830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13830 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s4_13830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5750,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5750 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13831 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5760,w5956,w6300,w6588]
theorem b4_13831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13831 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true))] s4_13831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5760,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5760 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13832 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5981,w6300,w6588]
theorem b4_13832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13832 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5981,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5981 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13833 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5992,w6300,w6588]
theorem b4_13833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13833 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_13833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5992,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5992 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13834 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5993,w6300,w6588]
theorem b4_13834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13834 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(0,true)),(false,(0,true),(7,true))] s4_13834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5993,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5993 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13835 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5995,w6300,w6588]
theorem b4_13835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13835 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5995,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5995 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13836 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5996,w6300,w6588]
theorem b4_13836 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13836 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13836 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5996,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5996 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13837 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5998,w6300,w6588]
theorem b4_13837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13837 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(7,true))] s4_13837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_5998,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_5998 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13838 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6002,w6300,w6588]
theorem b4_13838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13838 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(0,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6002,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6002 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13839 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6003,w6300,w6588]
theorem b4_13839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13839 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,true)),(false,(0,true),(7,true))] s4_13839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6003,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6003 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13840 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6004,w6300,w6588]
theorem b4_13840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13840 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6004,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6004 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13841 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6006,w6300,w6588]
theorem b4_13841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13841 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(7,true))] s4_13841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6006,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6006 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13842 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6014,w6300,w6588]
theorem b4_13842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13842 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6014,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6014 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13843 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6017,w6300,w6588]
theorem b4_13843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13843 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6017,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6017 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13844 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6019,w6300,w6588]
theorem b4_13844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13844 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6019,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6019 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13845 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6023,w6300,w6588]
theorem b4_13845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13845 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6023,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6023 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13846 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6024,w6300,w6588]
theorem b4_13846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13846 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_13846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6024,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6024 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13847 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6026,w6300,w6588]
theorem b4_13847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13847 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(0,true),(7,true))] s4_13847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6026,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6026 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13848 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6087,w6300,w6588]
theorem b4_13848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13848 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(1,true),(0,true))] s4_13848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6087,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6087 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13849 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6099,w6300,w6588]
theorem b4_13849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13849 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true)),(false,(1,true),(0,true))] s4_13849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6099,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6099 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13850 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_13850 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13850 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(6,true)),(false,(1,false),(0,false))] s4_13850 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13851 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_13851 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13851 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s4_13851 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13852 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6553,w6588]
theorem b4_13852 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13852 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(7,true),(2,true)),(false,(1,false),(0,false))] s4_13852 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6553,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6553 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13853 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_13853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13853 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(5,true)),(false,(5,true),(7,true)),(false,(1,false),(0,false))] s4_13853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13854 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6575,w6588]
theorem b4_13854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13854 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(6,true),(2,true)),(false,(1,false),(0,false))] s4_13854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6575,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6575 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13855 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6821]
theorem b4_13855 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13855 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(1,true)),(false,(5,true),(8,true)),(false,(1,false),(0,false))] s4_13855 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6821] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6821 rfl))))))))))) (by decide +kernel)
def s4_13856 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6857]
theorem b4_13856 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13856 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(5,true)),(false,(8,true),(1,true)),(false,(9,true),(1,false))] s4_13856 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6690,v0_6857] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6857 rfl))))))))))) (by decide +kernel)
def s4_13857 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6890]
theorem b4_13857 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13857 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(7,true)),(false,(1,true),(7,true)),(false,(9,true),(0,false))] s4_13857 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6890] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_13858 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6813,w6873]
theorem b4_13858 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13858 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(1,false))] s4_13858 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6813,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6813 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13859 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6549,w6588]
theorem b4_13859 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13859 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(1,true)),(false,(8,true),(1,false))] s4_13859 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6389,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13860 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6464,w6720,w6873]
theorem b4_13860 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13860 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(4,true)),(false,(2,true),(8,true)),(false,(8,true),(9,true))] s4_13860 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6464,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13861 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588,w6890]
theorem b4_13861 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13861 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(1,true),(8,true)),(false,(8,true),(0,false))] s4_13861 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6588,v0_6890] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6890 rfl))))))))))) (by decide +kernel)
def s4_13862 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6720,w6873]
theorem b4_13862 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13862 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(1,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_13862 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13863 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6785,w6873]
theorem b4_13863 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13863 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(4,true)),(false,(6,true),(7,true)),(false,(9,true),(8,true))] s4_13863 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6522,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13864 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6389,w6522,w6588]
theorem b4_13864 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13864 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_13864 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13865 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6522,w6588,w6873]
theorem b4_13865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13865 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(2,true)),(false,(7,true),(8,true))] s4_13865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6101,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13866 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6690,w6832]
theorem b4_13866 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13866 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(7,true),(9,true))] s4_13866 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6690,v0_6832] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_13867 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785,w6873]
theorem b4_13867 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13867 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(7,true)),(false,(6,true),(5,true)),(false,(9,true),(6,true))] s4_13867 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13868 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588]
theorem b4_13868 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13868 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_13868 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13869 : List (BitVec 512) := [w3567,w3766,w4344,w4716,w5135,w5470,w5585,w5956,w6300,w6588,w6690]
theorem b4_13869 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13869 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(7,true)),(false,(0,true),(7,true)),(false,(0,true),(5,true))] s4_13869 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5470,v0_5585,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5470 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_13870 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6690,w6720]
theorem b4_13870 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13870 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(1,true)),(false,(9,true),(3,true))] s4_13870 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6690,v0_6720] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6690 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_13871 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6720,w6873]
theorem b4_13871 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13871 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(4,true)),(false,(8,true),(7,true)),(false,(9,true),(3,true))] s4_13871 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5769,v0_5956,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13872 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5585,w5956,w6101,w6300,w6720,w6873]
theorem b4_13872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13872 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(2,true),(6,true)),(false,(3,true),(9,true))] s4_13872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5585,v0_5956,v0_6101,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13873 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6422,w6588]
theorem b4_13873 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13873 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true)),(false,(3,true),(6,true))] s4_13873 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13874 : List (BitVec 512) := [w3567,w3766,w4344,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6720]
theorem b4_13874 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13874 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(8,true),(2,true)),(false,(6,true),(3,true))] s4_13874 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3567,v0_3766,v0_4344,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_13875 : List (BitVec 512) := [w3569,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_13875 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13875 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_13875 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3569,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3569 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13876 : List (BitVec 512) := [w3569,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_13876 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13876 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(0,true),(8,true)),(false,(0,true),(4,true))] s4_13876 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3569,v0_3766,v0_4344,v0_4716,v0_5187,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3569 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5187 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_13877 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_13877 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13877 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s4_13877 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13878 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_13878 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13878 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true)),(false,(1,false),(0,false))] s4_13878 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13879 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6549,w6588]
theorem b4_13879 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13879 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true))] s4_13879 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13880 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_13880 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13880 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(0,false),(8,true))] s4_13880 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6572,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6572 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13881 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_13881 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13881 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(7,true),(6,true)),(false,(8,true),(2,true))] s4_13881 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720,v0_6873] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_13882 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_13882 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13882 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(6,true)),(false,(6,true),(0,false))] s4_13882 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6225,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6225 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13883 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6522,w6588]
theorem b4_13883 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13883 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(6,true)),(false,(6,true),(7,true))] s4_13883 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13884 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5698,w6179,w6300,w6588,w6832]
theorem b4_13884 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13884 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(7,true)),(false,(1,true),(5,true)),(false,(7,true),(6,true))] s4_13884 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_6179,v0_6300,v0_6588,v0_6832] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_13885 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6201,w6300,w6588]
theorem b4_13885 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13885 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(0,false)),(false,(6,true),(3,true))] s4_13885 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13886 : List (BitVec 512) := [w3582,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6478,w6588]
theorem b4_13886 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13886 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(6,true),(3,true))] s4_13886 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5769,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13887 : List (BitVec 512) := [w3582,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6389,w6588]
theorem b4_13887 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13887 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(7,true)),(false,(2,true),(6,true))] s4_13887 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13888 : List (BitVec 512) := [w3582,w3766,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588,w6690]
theorem b4_13888 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13888 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(1,true),(8,true)),(false,(2,true),(6,true))] s4_13888 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_3766,v0_4716,v0_5135,v0_5393,v0_5698,v0_5769,v0_5956,v0_6300,v0_6588,v0_6690] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6690 rfl))))))))))) (by decide +kernel)
def s4_13889 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6101,w6300,w6588]
theorem b4_13889 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13889 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(6,true),(2,true))] s4_13889 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13890 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6237,w6300,w6588]
theorem b4_13890 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13890 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(0,false)),(false,(0,false),(7,true))] s4_13890 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6237,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6237 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13891 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6422,w6588]
theorem b4_13891 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13891 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(4,true)),(false,(2,true),(7,true))] s4_13891 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_13892 : List (BitVec 512) := [w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6499,w6588]
theorem b4_13892 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_13892 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(1,true),(6,true)),(false,(1,true),(5,true)),(false,(1,false),(0,false))] s4_13892 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6499,v0_6588] (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6499 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
