import NinePin163
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_2298 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5956,w6300,w6588]
theorem b3_2298 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2298 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2298 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2300 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5956,w6300,w6588]
theorem b3_2300 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2300 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2300 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2618 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6201,w6300,w6588]
theorem b3_2618 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2618 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2618 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2622 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6588]
theorem b3_2622 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2622 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2622 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2626 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6300,w6588]
theorem b3_2626 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2626 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2626 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2628 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6225,w6300,w6588]
theorem b3_2628 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2628 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2628 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2806 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6478,w6588]
theorem b3_2806 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2806 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2806 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5698,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s3_2810 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6478,w6588]
theorem b3_2810 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_2810 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s3_2810 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1415,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6464,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1415 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl)))))))))))) (by decide +kernel)
def s4_7099 : List (BitVec 512) := [w1249,w3766,w4344,w4716,w5135,w5393,w5585,w5644,w5956,w6300,w6588]
theorem b4_7099 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7099 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7099 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1249,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5644,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1249 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5644 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7104 : List (BitVec 512) := [w1252,w3766,w4344,w4716,w5135,w5393,w5585,w5645,w5956,w6300,w6588]
theorem b4_7104 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7104 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7104 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1252,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5645,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1252 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5645 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7121 : List (BitVec 512) := [w1265,w3766,w4344,w4716,w5135,w5393,w5585,w5655,w5956,w6300,w6588]
theorem b4_7121 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7121 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7121 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1265,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5655,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1265 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5655 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7126 : List (BitVec 512) := [w1268,w3766,w4344,w4716,w5135,w5393,w5585,w5656,w5956,w6300,w6588]
theorem b4_7126 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7126 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7126 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1268,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5656,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1268 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5656 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7129 : List (BitVec 512) := [w1269,w3766,w4344,w4716,w5135,w5393,w5585,w5657,w5956,w6300,w6588]
theorem b4_7129 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7129 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7129 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1269,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5657,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1269 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5657 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7136 : List (BitVec 512) := [w1275,w3766,w4344,w4716,w5135,w5393,w5585,w5665,w5956,w6300,w6588]
theorem b4_7136 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7136 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7136 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1275,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5665,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1275 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5665 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7143 : List (BitVec 512) := [w1279,w3766,w4344,w4716,w5135,w5393,w5585,w5667,w5956,w6300,w6588]
theorem b4_7143 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7143 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7143 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1279,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5667,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1279 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5667 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7475 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6225,w6300,w6588]
theorem b4_7475 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7475 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7475 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1292,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5956,v163_6179,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1292 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7488 : List (BitVec 512) := [w1292,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6567,w6588]
theorem b4_7488 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7488 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7488 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1292,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5956,v163_6179,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_1292 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7588 : List (BitVec 512) := [w1312,w2125,w3766,w4344,w4716,w5135,w5393,w5956,w6225,w6300,w6588]
theorem b4_7588 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7588 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7588 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_2125,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_2125 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7699 : List (BitVec 512) := [w1312,w3197,w4344,w4392,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7699 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7699 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7699 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3197,v163_4344,v163_4392,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3197 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4392 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7711 : List (BitVec 512) := [w1312,w3258,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_7711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7711 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7716 : List (BitVec 512) := [w1312,w3280,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_7716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7716 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3280,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3280 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7951 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6056,w6300,w6588]
theorem b4_7951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7951 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6056,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6056 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7956 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6066,w6300,w6588]
theorem b4_7956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7956 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6066,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6066 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_7978 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_7978 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7978 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_7978 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8097 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6225,w6300,w6588]
theorem b4_8097 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8097 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8097 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1312,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1312 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8265 : List (BitVec 512) := [w1328,w3258,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_8265 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8265 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8265 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8270 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_8270 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8270 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8270 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3280,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3280 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8271 : List (BitVec 512) := [w1328,w3280,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_8271 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8271 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8271 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3280,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3280 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8411 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w5994,w6300,w6588]
theorem b4_8411 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8411 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8411 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_5994,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_5994 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8419 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_8419 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8419 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8419 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8420 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_8420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8420 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8421 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_8421 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8421 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8421 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8424 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6332,w6588]
theorem b4_8424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8424 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6332,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6332 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8432 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_8432 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8432 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8432 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8433 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6489,w6588]
theorem b4_8433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8433 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6489,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6489 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8434 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6499,w6588]
theorem b4_8434 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8434 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8434 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6499,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6499 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8464 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_8464 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8464 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8464 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8466 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_8466 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8466 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8466 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1328,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5769,v163_5956,v163_6300,v163_6464,v163_6588] (PetersenWireProjection.cons pc163_1328 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6464 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8820 : List (BitVec 512) := [w1374,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_8820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8820 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_1875,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_1875 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8865 : List (BitVec 512) := [w1374,w2443,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6336,w6588]
theorem b4_8865 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8865 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8865 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_2443,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6336,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_2443 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6336 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_8872 : List (BitVec 512) := [w1374,w2494,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6567,w6588]
theorem b4_8872 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8872 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_8872 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_2494,v163_3766,v163_4344,v163_4716,v163_5135,v163_5585,v163_5956,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_2494 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9061 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6869]
theorem b4_9061 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9061 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9061 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_4748,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6869] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4748 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6869 rfl))))))))))) (by decide +kernel)
def s4_9074 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4920,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9074 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9074 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9074 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_4920,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4920 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9083 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4932,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9083 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9083 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9083 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_4932,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4932 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9199 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_9199 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9199 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9199 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9205 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6385,w6588]
theorem b4_9205 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9205 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9205 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6385,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6385 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9210 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6397,w6588]
theorem b4_9210 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9210 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9210 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6397,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6397 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9215 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_9215 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9215 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9215 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1374,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6572,v163_6588] (PetersenWireProjection.cons pc163_1374 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6572 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9342 : List (BitVec 512) := [w1384,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_9342 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9342 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9342 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3258,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3258 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9352 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_9352 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9352 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9352 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3293,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3293 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9353 : List (BitVec 512) := [w1384,w3293,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_9353 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9353 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9353 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3293,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6201,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3293 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9400 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w4749,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9400 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_4749,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_4749 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9457 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6588]
theorem b4_9457 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9457 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9457 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5848,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5848 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9506 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6588]
theorem b4_9506 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9506 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9506 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9507 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6237,w6300,w6588]
theorem b4_9507 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9507 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9507 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6237,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6237 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9514 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6337,w6588]
theorem b4_9514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9514 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6337,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6337 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9521 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_9521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9521 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6478,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6478 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9524 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6567,w6588]
theorem b4_9524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9524 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6567,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6567 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9525 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6572,w6588]
theorem b4_9525 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9525 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9525 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6572,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6572 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9562 : List (BitVec 512) := [w1384,w3766,w4344,w4716,w5135,w5393,w5698,w5769,w5956,w6300,w6588]
theorem b4_9562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9562 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5698,v163_5769,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5698 (PetersenWireProjection.cons pc163_5769 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9577 : List (BitVec 512) := [w1384,w3766,w4716,w5135,w5393,w5585,w5956,w6179,w6201,w6300,w6690]
theorem b4_9577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9577 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1384,v163_3766,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6179,v163_6201,v163_6300,v163_6690] (PetersenWireProjection.cons pc163_1384 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6201 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6690 rfl))))))))))) (by decide +kernel)
def s4_9583 : List (BitVec 512) := [w1388,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6588]
theorem b4_9583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9583 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_1875,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_6179,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_1875 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_6179 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9584 : List (BitVec 512) := [w1388,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w6225,w6300,w6588]
theorem b4_9584 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9584 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9584 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_1875,v163_3766,v163_4344,v163_4716,v163_5135,v163_5393,v163_5585,v163_6225,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_1875 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_6225 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
def s4_9636 : List (BitVec 512) := [w1388,w3766,w4344,w4404,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9636 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9636 := by
  intro m le c
  apply rejects_sound r163 i7 6 tgt (small163 adj) hot163 [] s4_9636 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v163_1388,v163_3766,v163_4344,v163_4404,v163_4716,v163_5135,v163_5393,v163_5585,v163_5956,v163_6300,v163_6588] (PetersenWireProjection.cons pc163_1388 (PetersenWireProjection.cons pc163_3766 (PetersenWireProjection.cons pc163_4344 (PetersenWireProjection.cons pc163_4404 (PetersenWireProjection.cons pc163_4716 (PetersenWireProjection.cons pc163_5135 (PetersenWireProjection.cons pc163_5393 (PetersenWireProjection.cons pc163_5585 (PetersenWireProjection.cons pc163_5956 (PetersenWireProjection.cons pc163_6300 (PetersenWireProjection.cons pc163_6588 rfl))))))))))) (by decide +kernel)
end NineCert
