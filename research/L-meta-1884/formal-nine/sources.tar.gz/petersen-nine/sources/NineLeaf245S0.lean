import NinePin245
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_1518 : List (BitVec 512) := [w197,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_1518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1518 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_1518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_197,v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5769,v245_5956,v245_6300,v245_6588] (PetersenWireProjection.cons pc245_197 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_1670 : List (BitVec 512) := [w204,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_1670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_1670 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_1670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_204,v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5769,v245_5956,v245_6300,v245_6588] (PetersenWireProjection.cons pc245_204 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_7615 : List (BitVec 512) := [w1312,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6522,w6588]
theorem b4_7615 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7615 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_7615 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_1312,v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5956,v245_6300,v245_6522,v245_6588] (PetersenWireProjection.cons pc245_1312 (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_8016 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b4_8016 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8016 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_8016 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_1312,v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5956,v245_6300,v245_6543,v245_6588] (PetersenWireProjection.cons pc245_1312 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6543 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_8076 : List (BitVec 512) := [w1312,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_8076 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8076 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_8076 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_1312,v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5956,v245_6389,v245_6522,v245_6588] (PetersenWireProjection.cons pc245_1312 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6389 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12454 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6543,w6588]
theorem b4_12454 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12454 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12454 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_5956,v245_6300,v245_6543,v245_6588] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6543 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12456 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6575,w6588]
theorem b4_12456 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12456 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12456 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_5956,v245_6300,v245_6575,v245_6588] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6575 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12458 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6389,w6522,w6588]
theorem b4_12458 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12458 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12458 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_5956,v245_6389,v245_6522,v245_6588] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6389 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12460 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5769,w6225,w6300,w6522,w6588]
theorem b4_12460 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12460 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12460 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_6225,v245_6300,v245_6522,v245_6588] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_6225 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12819 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b4_12819 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12819 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12819 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2488,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_5956,v245_6300,v245_6389,v245_6588] (PetersenWireProjection.cons pc245_2488 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6389 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_12820 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6543,w6588]
theorem b4_12820 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_12820 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_12820 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2488,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5769,v245_5956,v245_6300,v245_6543,v245_6588] (PetersenWireProjection.cons pc245_2488 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6543 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_17263 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5756,w5956,w6300,w6543,w6588]
theorem b4_17263 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17263 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_17263 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5756,v245_5956,v245_6300,v245_6543,v245_6588] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5756 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6543 (PetersenWireProjection.cons pc245_6588 rfl))))))))))) (by decide +kernel)
def s4_17291 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5768,w5956,w6300,w6588,w6890]
theorem b4_17291 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17291 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_17291 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5768,v245_5956,v245_6300,v245_6588,v245_6890] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5768 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 (PetersenWireProjection.cons pc245_6890 rfl))))))))))) (by decide +kernel)
def s4_17345 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6910]
theorem b4_17345 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17345 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_17345 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5769,v245_5956,v245_6300,v245_6588,v245_6910] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 (PetersenWireProjection.cons pc245_6910 rfl))))))))))) (by decide +kernel)
def s4_17376 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6522,w6588,w6890]
theorem b4_17376 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17376 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_17376 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5769,v245_5956,v245_6522,v245_6588,v245_6890] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 (PetersenWireProjection.cons pc245_6890 rfl))))))))))) (by decide +kernel)
def s4_17380 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6522,w6813,w6873]
theorem b4_17380 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_17380 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s4_17380 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_5769,v245_5956,v245_6522,v245_6813,v245_6873] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6813 (PetersenWireProjection.cons pc245_6873 rfl))))))))))) (by decide +kernel)
def s5_2456 : List (BitVec 512) := [w1312,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b5_2456 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_2456 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_2456 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_1312,v245_2488,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5956,v245_6300,v245_6588] (PetersenWireProjection.cons pc245_1312 (PetersenWireProjection.cons pc245_2488 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 rfl)))))))))) (by decide +kernel)
def s5_4135 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5750,w5956,w6522,w6588]
theorem b5_4135 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4135 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_4135 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5750,v245_5956,v245_6522,v245_6588] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5750 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6588 rfl)))))))))) (by decide +kernel)
def s5_4235 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6813,w6873]
theorem b5_4235 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4235 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_4235 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_5956,v245_6522,v245_6813,v245_6873] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6813 (PetersenWireProjection.cons pc245_6873 rfl)))))))))) (by decide +kernel)
def s5_4246 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6101,w6522,w6785,w6873]
theorem b5_4246 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4246 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_4246 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_6101,v245_6522,v245_6785,v245_6873] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_6101 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6785 (PetersenWireProjection.cons pc245_6873 rfl)))))))))) (by decide +kernel)
def s5_4248 : List (BitVec 512) := [w2468,w3766,w4344,w4716,w5135,w5585,w6179,w6522,w6720,w6873]
theorem b5_4248 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4248 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_4248 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_4716,v245_5135,v245_5585,v245_6179,v245_6522,v245_6720,v245_6873] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_6179 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6720 (PetersenWireProjection.cons pc245_6873 rfl)))))))))) (by decide +kernel)
def s5_4260 : List (BitVec 512) := [w2468,w3766,w4344,w5135,w5585,w5769,w5956,w6522,w6720,w6873]
theorem b5_4260 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4260 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_4260 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_2468,v245_3766,v245_4344,v245_5135,v245_5585,v245_5769,v245_5956,v245_6522,v245_6720,v245_6873] (PetersenWireProjection.cons pc245_2468 (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5769 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6720 (PetersenWireProjection.cons pc245_6873 rfl)))))))))) (by decide +kernel)
def s5_6128 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6522,w6720,w6890]
theorem b5_6128 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6128 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_6128 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5393,v245_5585,v245_6179,v245_6522,v245_6720,v245_6890] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5393 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_6179 (PetersenWireProjection.cons pc245_6522 (PetersenWireProjection.cons pc245_6720 (PetersenWireProjection.cons pc245_6890 rfl)))))))))) (by decide +kernel)
def s5_6190 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5470,w5585,w5786,w5956,w6300,w6588]
theorem b5_6190 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_6190 := by
  intro m le c
  apply rejects_sound r245 i6 5 tgt (small245 adj) hot245 [] s5_6190 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v245_3766,v245_4344,v245_4716,v245_5135,v245_5470,v245_5585,v245_5786,v245_5956,v245_6300,v245_6588] (PetersenWireProjection.cons pc245_3766 (PetersenWireProjection.cons pc245_4344 (PetersenWireProjection.cons pc245_4716 (PetersenWireProjection.cons pc245_5135 (PetersenWireProjection.cons pc245_5470 (PetersenWireProjection.cons pc245_5585 (PetersenWireProjection.cons pc245_5786 (PetersenWireProjection.cons pc245_5956 (PetersenWireProjection.cons pc245_6300 (PetersenWireProjection.cons pc245_6588 rfl)))))))))) (by decide +kernel)
end NineCert
