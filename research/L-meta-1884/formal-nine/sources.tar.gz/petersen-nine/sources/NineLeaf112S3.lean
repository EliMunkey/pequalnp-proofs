import NinePin112
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_4541 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6913]
theorem b5_4541 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4541 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4541 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6913] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6913 rfl)))))))))) (by decide +kernel)
def s5_4543 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6918]
theorem b5_4543 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4543 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4543 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6588,v112_6918] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6918 rfl)))))))))) (by decide +kernel)
def s5_4608 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5698,w5956,w6300,w6588,w6890]
theorem b5_4608 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4608 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4608 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_5135,v112_5585,v112_5698,v112_5956,v112_6300,v112_6588,v112_6890] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5698 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
def s5_4612 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b5_4612 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4612 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4612 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_5135,v112_5585,v112_5848,v112_5956,v112_6300,v112_6389,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4624 : List (BitVec 512) := [w2488,w3766,w4716,w5135,w5585,w5956,w6201,w6300,w6588,w6690]
theorem b5_4624 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4624 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4624 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4716,v112_5135,v112_5585,v112_5956,v112_6201,v112_6300,v112_6588,v112_6690] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6201 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6690 rfl)))))))))) (by decide +kernel)
def s5_4632 : List (BitVec 512) := [w2488,w3766,w4926,w5135,w5585,w6101,w6300,w6389,w6543,w6588]
theorem b5_4632 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4632 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [(false,(7,true),(6,true))] s5_4632 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2488,v112_3766,v112_4926,v112_5135,v112_5585,v112_6101,v112_6300,v112_6389,v112_6543,v112_6588] (PetersenWireProjection.cons pc112_2488 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4926 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_6101 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6389 (PetersenWireProjection.cons pc112_6543 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4649 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_4649 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4649 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4649 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4655 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6237,w6300,w6588]
theorem b5_4655 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4655 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4655 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6237,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4656 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6499,w6588]
theorem b5_4656 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4656 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4656 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4659 : List (BitVec 512) := [w2492,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4659 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4659 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4659 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2492,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_2492 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4666 : List (BitVec 512) := [w2496,w3312,w4344,w4716,w5135,w5585,w5956,w6300,w6572,w6588]
theorem b5_4666 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4666 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4666 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3312,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6572,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3312 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6572 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4692 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5848,w5956,w6300,w6588]
theorem b5_4692 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4692 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4692 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5848,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5848 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4699 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6237,w6300,w6588]
theorem b5_4699 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4699 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4699 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6237,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6237 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4701 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6499,w6588]
theorem b5_4701 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4701 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4701 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6499,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6499 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4704 : List (BitVec 512) := [w2496,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4704 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4704 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4704 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2496,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_2496 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_4752 : List (BitVec 512) := [w2498,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6578,w6588]
theorem b5_4752 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_4752 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_4752 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_2498,v112_3766,v112_4344,v112_4716,v112_5135,v112_5585,v112_5956,v112_6300,v112_6578,v112_6588] (PetersenWireProjection.cons pc112_2498 (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6578 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5465 : List (BitVec 512) := [w3766,w4344,w4352,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5465 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5465 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5465 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4352,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4352 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5469 : List (BitVec 512) := [w3766,w4344,w4365,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5469 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5469 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5469 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4365,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4365 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5474 : List (BitVec 512) := [w3766,w4344,w4373,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5474 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5474 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5474 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4373,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4373 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5479 : List (BitVec 512) := [w3766,w4344,w4378,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5479 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5479 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5479 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4378,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4378 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5481 : List (BitVec 512) := [w3766,w4344,w4380,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5481 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5481 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5481 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4380,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4380 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5485 : List (BitVec 512) := [w3766,w4344,w4385,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5485 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5485 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5485 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4385,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4385 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5490 : List (BitVec 512) := [w3766,w4344,w4391,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5490 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5490 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5490 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4391,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4391 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5502 : List (BitVec 512) := [w3766,w4344,w4396,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5502 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5502 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5502 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4396,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4396 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5504 : List (BitVec 512) := [w3766,w4344,w4398,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5504 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5504 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5504 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4398,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4398 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5507 : List (BitVec 512) := [w3766,w4344,w4401,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5507 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5507 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5507 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4401,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4401 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5540 : List (BitVec 512) := [w3766,w4344,w4408,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5540 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5540 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5540 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4408,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4408 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5543 : List (BitVec 512) := [w3766,w4344,w4411,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5543 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5543 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5543 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4411,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4411 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5558 : List (BitVec 512) := [w3766,w4344,w4418,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5558 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5558 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5558 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4418,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4418 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5562 : List (BitVec 512) := [w3766,w4344,w4451,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5562 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5562 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5562 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4451,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4451 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5569 : List (BitVec 512) := [w3766,w4344,w4468,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5569 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5569 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5569 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4468,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4468 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5571 : List (BitVec 512) := [w3766,w4344,w4470,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5571 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5571 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5571 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4470,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4470 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5576 : List (BitVec 512) := [w3766,w4344,w4476,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5576 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5576 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5576 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4476,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4476 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5592 : List (BitVec 512) := [w3766,w4344,w4494,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5592 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5592 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5592 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4494,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4494 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5603 : List (BitVec 512) := [w3766,w4344,w4509,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5603 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5603 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5603 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4509,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4509 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5606 : List (BitVec 512) := [w3766,w4344,w4512,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5606 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5606 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5606 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4512,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4512 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5622 : List (BitVec 512) := [w3766,w4344,w4522,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5622 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5622 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5622 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4522,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4522 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5623 : List (BitVec 512) := [w3766,w4344,w4529,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5623 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5623 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5623 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4529,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4529 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5625 : List (BitVec 512) := [w3766,w4344,w4531,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5625 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5625 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5625 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4531,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4531 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5627 : List (BitVec 512) := [w3766,w4344,w4533,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5627 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5627 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5627 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4533,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4533 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5635 : List (BitVec 512) := [w3766,w4344,w4549,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5635 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5635 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5635 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4549,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4549 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5637 : List (BitVec 512) := [w3766,w4344,w4551,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5637 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5637 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5637 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4551,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4551 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5640 : List (BitVec 512) := [w3766,w4344,w4554,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5640 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5640 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5640 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4554,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4554 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5657 : List (BitVec 512) := [w3766,w4344,w4574,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5657 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5657 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5657 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4574,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4574 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5738 : List (BitVec 512) := [w3766,w4344,w4716,w4928,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5738 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5738 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5738 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4928,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4928 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5743 : List (BitVec 512) := [w3766,w4344,w4716,w4936,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5743 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5743 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5743 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4936,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4936 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5749 : List (BitVec 512) := [w3766,w4344,w4716,w4946,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_5749 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5749 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5749 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_4946,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_4946 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5799 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5709,w5956,w6300,w6588]
theorem b5_5799 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5799 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5799 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5709,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5709 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5862 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5851,w5956,w6300,w6588]
theorem b5_5862 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5862 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5862 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5851,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5851 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5865 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5854,w5956,w6300,w6588]
theorem b5_5865 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5865 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5865 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5854,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5854 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5868 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5857,w5956,w6300,w6588]
theorem b5_5868 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5868 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5868 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5857,v112_5956,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5857 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5891 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6139,w6300,w6588]
theorem b5_5891 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5891 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5891 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6139,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6139 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5893 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6144,w6300,w6588]
theorem b5_5893 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5893 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5893 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6144,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6144 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5900 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6235,w6300,w6588]
theorem b5_5900 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5900 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5900 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6235,v112_6300,v112_6588] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6235 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 rfl)))))))))) (by decide +kernel)
def s5_5914 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6920]
theorem b5_5914 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5914 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5914 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6588,v112_6920] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6588 (PetersenWireProjection.cons pc112_6920 rfl)))))))))) (by decide +kernel)
def s5_5929 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6597,w6890]
theorem b5_5929 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_5929 := by
  intro m le c
  apply rejects_sound r112 i8 7 tgt (small112 adj) hot112 [] s5_5929 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v112_3766,v112_4344,v112_4716,v112_5135,v112_5393,v112_5585,v112_5956,v112_6300,v112_6597,v112_6890] (PetersenWireProjection.cons pc112_3766 (PetersenWireProjection.cons pc112_4344 (PetersenWireProjection.cons pc112_4716 (PetersenWireProjection.cons pc112_5135 (PetersenWireProjection.cons pc112_5393 (PetersenWireProjection.cons pc112_5585 (PetersenWireProjection.cons pc112_5956 (PetersenWireProjection.cons pc112_6300 (PetersenWireProjection.cons pc112_6597 (PetersenWireProjection.cons pc112_6890 rfl)))))))))) (by decide +kernel)
end NineCert
