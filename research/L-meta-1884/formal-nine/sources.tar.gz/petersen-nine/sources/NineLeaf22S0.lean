import NinePin22
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s5_1090 : List (BitVec 512) := [w853,w3258,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b5_1090 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_1090 := by
  intro m le c
  apply rejects_sound r22 i7 8 tgt (small22 adj) hot22 [(false,(5,true),(2,true))] s5_1090 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v22_853,v22_3258,v22_4344,v22_4716,v22_5135,v22_5393,v22_5585,v22_5956,v22_6300,v22_6588] (PetersenWireProjection.cons pc22_853 (PetersenWireProjection.cons pc22_3258 (PetersenWireProjection.cons pc22_4344 (PetersenWireProjection.cons pc22_4716 (PetersenWireProjection.cons pc22_5135 (PetersenWireProjection.cons pc22_5393 (PetersenWireProjection.cons pc22_5585 (PetersenWireProjection.cons pc22_5956 (PetersenWireProjection.cons pc22_6300 (PetersenWireProjection.cons pc22_6588 rfl)))))))))) (by decide +kernel)
end NineCert
