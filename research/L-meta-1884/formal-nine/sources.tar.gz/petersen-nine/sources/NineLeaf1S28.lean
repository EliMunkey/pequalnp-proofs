import NinePin1
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9704 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6241,w6300,w6588]
theorem b4_9704 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9704 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(5,true),(6,true)),(false,(0,false),(3,true)),(false,(0,true),(5,true))] s4_9704 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6241,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6241 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9705 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6243,w6300,w6588]
theorem b4_9705 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9705 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9705 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6243,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6243 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9711 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6756]
theorem b4_9711 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9711 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(5,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_9711 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588,v1_6756] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 (PetersenWireProjection.cons pc1_6756 rfl))))))))))) (by decide +kernel)
def s4_9727 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w6101,w6147,w6300,w6588]
theorem b4_9727 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9727 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(2,true),(6,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_9727 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1388,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_6101,v1_6147,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1388 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_6101 (PetersenWireProjection.cons pc1_6147 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9754 : List (BitVec 512) := [w1403,w1412,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9754 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9754 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9754 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_1412,v1_3766,v1_4344,v1_4716,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_1412 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9781 : List (BitVec 512) := [w1403,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9781 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9781 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9781 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9782 : List (BitVec 512) := [w1403,w2313,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9782 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9782 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9782 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2313,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9783 : List (BitVec 512) := [w1403,w2313,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9783 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9783 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(3,true),(7,true))] s4_9783 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2313,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2313 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9830 : List (BitVec 512) := [w1403,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9830 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9830 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9830 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9831 : List (BitVec 512) := [w1403,w2555,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9831 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9831 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9831 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2555,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9832 : List (BitVec 512) := [w1403,w2555,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b4_9832 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9832 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_9832 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2555,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2555 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9834 : List (BitVec 512) := [w1403,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9834 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9834 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9834 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9835 : List (BitVec 512) := [w1403,w2589,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9835 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9835 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9835 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2589,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2589 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9837 : List (BitVec 512) := [w1403,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9837 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9837 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9837 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9838 : List (BitVec 512) := [w1403,w2613,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9838 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9838 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9838 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9839 : List (BitVec 512) := [w1403,w2613,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_9839 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9839 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_9839 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9840 : List (BitVec 512) := [w1403,w2613,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9840 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9840 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(3,true),(7,true))] s4_9840 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2613,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2613 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9841 : List (BitVec 512) := [w1403,w2614,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9841 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9841 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_9841 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2614,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2614 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9842 : List (BitVec 512) := [w1403,w2615,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_9842 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9842 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(3,true),(7,true))] s4_9842 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2615,v1_3766,v1_4716,v1_5135,v1_5393,v1_5585,v1_5698,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2615 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5698 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9843 : List (BitVec 512) := [w1403,w2623,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9843 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9843 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_9843 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2623,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2623 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9844 : List (BitVec 512) := [w1403,w2644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9844 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9844 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true))] s4_9844 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2644,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2644 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9845 : List (BitVec 512) := [w1403,w2651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9845 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9845 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9845 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2651,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2651 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9846 : List (BitVec 512) := [w1403,w2655,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9846 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9846 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(1,false))] s4_9846 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2655,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2655 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9847 : List (BitVec 512) := [w1403,w2667,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9847 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9847 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9847 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2667,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9848 : List (BitVec 512) := [w1403,w2667,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9848 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9848 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9848 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2667,v1_3766,v1_4344,v1_4716,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2667 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9849 : List (BitVec 512) := [w1403,w2680,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9849 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9849 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_9849 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2680,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2680 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9853 : List (BitVec 512) := [w1403,w2695,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_9853 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9853 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_9853 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2695,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2695 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl))))))))))) (by decide +kernel)
def s4_9854 : List (BitVec 512) := [w1403,w2695,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9854 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9854 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9854 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_2695,v1_3766,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_2695 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9915 : List (BitVec 512) := [w1403,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9915 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9915 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9915 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9916 : List (BitVec 512) := [w1403,w3766,w4004,w4344,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9916 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9916 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9916 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4004,v1_4344,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4004 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9950 : List (BitVec 512) := [w1403,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9950 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9951 : List (BitVec 512) := [w1403,w3766,w4344,w4635,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9951 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4635,v1_4716,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4635 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9981 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9981 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9981 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9981 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9982 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4987,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9982 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9982 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9982 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_4987,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4987 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9983 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w4989,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9983 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9983 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9983 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_4989,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_4989 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9985 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5002,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9985 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9985 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9985 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5002,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5002 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9986 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5013,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9986 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9986 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9986 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5013,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5013 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9987 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5024,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9987 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9987 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9987 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5024,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5024 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9988 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5034,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9988 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9988 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9988 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5034,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5034 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9989 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5040,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9989 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9989 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9989 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5040,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5040 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9990 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5044,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9990 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9990 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9990 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5044,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5044 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9991 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5053,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9991 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9991 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9991 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5053,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9992 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5053,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9992 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9992 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9992 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5053,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5053 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9993 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9993 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9993 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_9993 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_9994 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9994 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9994 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_9994 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5135,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9995 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9995 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9995 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_9995 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9996 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5623,w5956,w6300,w6588]
theorem b4_9996 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9996 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(0,true),(7,true))] s4_9996 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5623,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5623 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9997 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9997 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9997 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(4,true),(7,true))] s4_9997 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5769,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5769 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9998 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_9998 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9998 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(8,true))] s4_9998 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6179,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6179 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_9999 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_9999 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9999 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(7,true),(1,false))] s4_9999 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6300,v1_6478,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6478 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10000 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6300,w6588]
theorem b4_10000 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10000 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true))] s4_10000 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6300,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_10001 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6300,w6690,w6890]
theorem b4_10001 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10001 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10001 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10002 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6300,w6890]
theorem b4_10002 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10002 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10002 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl)))))))))) (by decide +kernel)
def s4_10003 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6389,w6522,w6588]
theorem b4_10003 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10003 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10003 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6389,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6389 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10004 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5059,w5393,w5585,w5956,w6522,w6588]
theorem b4_10004 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10004 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10004 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5059,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5059 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl)))))))))) (by decide +kernel)
def s4_10005 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5097,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_10005 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10005 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10005 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5097,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5097 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10006 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5129,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_10006 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10006 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(3,true)),(false,(0,false),(8,true)),(false,(5,true),(0,true))] s4_10006 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5129,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6690] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5129 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6690 rfl))))))))))) (by decide +kernel)
def s4_10007 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5129,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_10007 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10007 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10007 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5129,v1_5135,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5129 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10008 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5187,w5393,w5585,w5956,w6300,w6890]
theorem b4_10008 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10008 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10008 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5187,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10009 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5187,w5393,w5585,w5956,w6522,w6588]
theorem b4_10009 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10009 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10009 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5187,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5187 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10012 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6300,w6890]
theorem b4_10012 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10012 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10012 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10013 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5205,w5393,w5585,w5956,w6522,w6588]
theorem b4_10013 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10013 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10013 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5205,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5205 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
def s4_10014 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6300,w6890]
theorem b4_10014 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10014 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(1,true),(7,true)),(false,(0,true),(4,true)),(false,(1,false),(5,true))] s4_10014 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6300,v1_6890] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6300 (PetersenWireProjection.cons pc1_6890 rfl))))))))))) (by decide +kernel)
def s4_10015 : List (BitVec 512) := [w1403,w3766,w4344,w4716,w5135,w5239,w5393,w5585,w5956,w6522,w6588]
theorem b4_10015 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10015 := by
  intro m le c
  apply rejects_sound r1 i8 12 tgt (small1 adj) hot1 [(false,(7,true),(1,true)),(false,(0,true),(4,true)),(false,(9,true),(8,true))] s4_10015 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v1_1403,v1_3766,v1_4344,v1_4716,v1_5135,v1_5239,v1_5393,v1_5585,v1_5956,v1_6522,v1_6588] (PetersenWireProjection.cons pc1_1403 (PetersenWireProjection.cons pc1_3766 (PetersenWireProjection.cons pc1_4344 (PetersenWireProjection.cons pc1_4716 (PetersenWireProjection.cons pc1_5135 (PetersenWireProjection.cons pc1_5239 (PetersenWireProjection.cons pc1_5393 (PetersenWireProjection.cons pc1_5585 (PetersenWireProjection.cons pc1_5956 (PetersenWireProjection.cons pc1_6522 (PetersenWireProjection.cons pc1_6588 rfl))))))))))) (by decide +kernel)
end NineCert
