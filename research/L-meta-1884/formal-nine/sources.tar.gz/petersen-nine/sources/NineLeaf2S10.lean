import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_3371 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6543,w6588]
theorem b3_3371 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3371 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s3_3371 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3372 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b3_3372 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3372 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s3_3372 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3373 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6543,w6588]
theorem b3_3373 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3373 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s3_3373 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_3374 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b3_3374 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3374 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s3_3374 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3375 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6543,w6588]
theorem b3_3375 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3375 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s3_3375 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_3376 : List (BitVec 512) := [w2488,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b3_3376 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_3376 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s3_3376 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_4606 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5848,w5956,w6300,w6588]
theorem b3_4606 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4606 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_4606 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4607 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5956,w6136,w6300,w6588]
theorem b3_4607 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4607 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_4607 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4608 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5956,w6179,w6300,w6588]
theorem b3_4608 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4608 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_4608 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4609 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5956,w6300,w6464,w6588]
theorem b3_4609 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4609 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(4,true))] s3_4609 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4610 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5956,w6300,w6522,w6588]
theorem b3_4610 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4610 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_4610 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4611 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5521,w5585,w5956,w6300,w6588,w6785]
theorem b3_4611 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4611 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(8,true))] s3_4611 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl)))))))))))) (by decide +kernel)
def s3_4646 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5848,w5903,w5956,w6300,w6588]
theorem b3_4646 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4646 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_4646 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5848,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4666 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5903,w5956,w6300,w6588]
theorem b3_4666 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4666 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_4666 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4685 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6136,w6164,w6300,w6588]
theorem b3_4685 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4685 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_4685 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6136,v2_6164,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6164 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4699 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6164,w6300,w6588]
theorem b3_4699 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4699 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_4699 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6164,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6164 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4705 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6179,w6246,w6300,w6588]
theorem b3_4705 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4705 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_4705 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6179,v2_6246,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4715 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6246,w6300,w6588]
theorem b3_4715 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4715 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_4715 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6246,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6246 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4723 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6505,w6588]
theorem b3_4723 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4723 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(3,true)),(false,(2,true),(7,true))] s3_4723 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6505,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6505 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4727 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6522,w6559,w6588]
theorem b3_4727 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4727 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_4727 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4733 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6559,w6588]
theorem b3_4733 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4733 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_4733 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4739 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588,w6827]
theorem b3_4739 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4739 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(7,true)),(false,(2,true),(7,true))] s3_4739 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6827] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6827 rfl))))))))))) (by decide +kernel)
def s3_4745 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6767,w6832]
theorem b3_4745 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4745 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(2,true))] s3_4745 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_4746 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6767,w6873]
theorem b3_4746 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4746 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(8,true),(4,true))] s3_4746 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s3_4752 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6451,w6522,w6588]
theorem b3_4752 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4752 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(4,true),(3,true))] s3_4752 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4792 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6061,w6101,w6300,w6588]
theorem b3_4792 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4792 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(3,true),(7,true))] s3_4792 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6061,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4793 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6101,w6300,w6522,w6588]
theorem b3_4793 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4793 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(3,true),(7,true))] s3_4793 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6101,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4794 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6300,w6522,w6588]
theorem b3_4794 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4794 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(3,true),(6,true))] s3_4794 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4795 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5479,w5585,w6179,w6300,w6588,w6832]
theorem b3_4795 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4795 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(3,true),(6,true))] s3_4795 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5479,v2_5585,v2_6179,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5479 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_4796 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5848,w5956,w6300,w6588]
theorem b3_4796 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4796 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_4796 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5848,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4797 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6136,w6300,w6588]
theorem b3_4797 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4797 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(3,true))] s3_4797 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6136,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6136 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4798 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6179,w6300,w6588]
theorem b3_4798 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4798 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(6,true),(3,true))] s3_4798 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4799 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5521,w5585,w5956,w6300,w6522,w6588]
theorem b3_4799 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4799 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(3,true),(4,true))] s3_4799 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5521,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5521 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4826 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5887,w5956,w6300,w6588]
theorem b3_4826 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4826 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_4826 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5848,v2_5887,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5887 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4827 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5848,w5903,w5956,w6300,w6588]
theorem b3_4827 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4827 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_4827 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5848,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4844 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5903,w5956,w6300,w6588]
theorem b3_4844 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4844 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_4844 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4865 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6559,w6588]
theorem b3_4865 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4865 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s3_4865 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6559,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6559 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4872 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6767,w6832]
theorem b3_4872 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4872 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(7,true)),(false,(2,true),(6,true))] s3_4872 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_4873 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6767,w6873]
theorem b3_4873 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4873 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(1,true)),(false,(8,true),(4,true))] s3_4873 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s3_4892 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5894,w5956,w6300,w6588]
theorem b3_4892 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4892 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_4892 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5848,v2_5894,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4893 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5848,w5903,w5956,w6300,w6588]
theorem b3_4893 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4893 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_4893 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5848,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4908 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5894,w5956,w6225,w6300,w6588]
theorem b3_4908 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4908 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_4908 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4909 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5894,w5956,w6300,w6389,w6588]
theorem b3_4909 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4909 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true))] s3_4909 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4910 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5894,w5956,w6300,w6489,w6588]
theorem b3_4910 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4910 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_4910 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4911 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5894,w5956,w6300,w6588,w6690]
theorem b3_4911 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4911 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(8,true))] s3_4911 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5894,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl)))))))))))) (by decide +kernel)
def s3_4912 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5903,w5956,w6300,w6588]
theorem b3_4912 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4912 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_4912 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4921 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6225,w6249,w6300,w6588]
theorem b3_4921 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4921 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_4921 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6225,v2_6249,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6249 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4929 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6249,w6300,w6588]
theorem b3_4929 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4929 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_4929 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6249,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6249 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4935 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6452,w6588]
theorem b3_4935 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4935 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(3,true)),(false,(6,true),(7,true))] s3_4935 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6452,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6452 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4939 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6489,w6507,w6588]
theorem b3_4939 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4939 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_4939 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6489,v2_6507,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6507 (PetersenWireProjection.cons pc2_6588 rfl)))))))))))) (by decide +kernel)
def s3_4945 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6507,w6588]
theorem b3_4945 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4945 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_4945 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6507,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6507 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4953 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6781]
theorem b3_4953 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4953 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(7,true)),(false,(6,true),(7,true))] s3_4953 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6781] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6781 rfl))))))))))) (by decide +kernel)
def s3_4961 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6767,w6832]
theorem b3_4961 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4961 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(7,true),(6,true))] s3_4961 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6767,v2_6832] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
def s3_4962 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6767,w6873]
theorem b3_4962 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4962 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(4,true))] s3_4962 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6767,v2_6873] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6767 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s3_4968 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6451,w6522,w6588]
theorem b3_4968 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4968 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s3_4968 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6451,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6451 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4972 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5769,w6158,w6300,w6522,w6588]
theorem b3_4972 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4972 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s3_4972 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_6158,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6158 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4981 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5887,w5956,w6300,w6588]
theorem b3_4981 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4981 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false))] s3_4981 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5887,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5887 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4982 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5894,w5956,w6300,w6588]
theorem b3_4982 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4982 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false))] s3_4982 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5894,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4983 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5848,w5903,w5956,w6300,w6588]
theorem b3_4983 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4983 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_4983 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_4999 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6225,w6300,w6588]
theorem b3_4999 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4999 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(3,true))] s3_4999 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6225,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6225 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_5000 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5894,w5956,w6300,w6489,w6588]
theorem b3_5000 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5000 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(0,false),(4,true))] s3_5000 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5894,v2_5956,v2_6300,v2_6489,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5894 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6489 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s3_5001 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5903,w5956,w6300,w6588]
theorem b3_5001 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5001 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true))] s3_5001 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5903,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5903 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s3_5041 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6781]
theorem b3_5041 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5041 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(8,true),(2,true))] s3_5041 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6781] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6781 rfl))))))))))) (by decide +kernel)
def s3_5042 : List (BitVec 512) := [w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6690,w6720,w6782]
theorem b3_5042 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_5042 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(8,true),(2,true))] s3_5042 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720,v2_6782] (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6782 rfl))))))))))) (by decide +kernel)
end NineCert
