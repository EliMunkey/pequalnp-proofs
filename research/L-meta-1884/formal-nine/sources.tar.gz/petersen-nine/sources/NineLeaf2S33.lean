import NinePin2
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_11514 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_11514 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11514 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(7,true),(4,true))] s4_11514 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5698,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11515 : List (BitVec 512) := [w2352,w3766,w4344,w4716,w5135,w5393,w5769,w5956,w6300,w6464,w6588]
theorem b4_11515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11515 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(7,true),(5,true))] s4_11515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4716,v2_5135,v2_5393,v2_5769,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11516 : List (BitVec 512) := [w2352,w3766,w4344,w4926,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11516 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11516 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(8,true),(4,true))] s4_11516 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11517 : List (BitVec 512) := [w2352,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6422,w6588]
theorem b4_11517 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11517 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(8,true),(5,true))] s4_11517 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11518 : List (BitVec 512) := [w2352,w3766,w4344,w5135,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_11518 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11518 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(8,true),(9,true))] s4_11518 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4344,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11519 : List (BitVec 512) := [w2352,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11519 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11519 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(6,true)),(false,(0,false),(6,true)),(false,(3,true),(5,true))] s4_11519 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_4926,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11520 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6389,w6588]
theorem b4_11520 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11520 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(3,true),(5,true))] s4_11520 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11521 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588,w6690]
theorem b4_11521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11521 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(1,true),(5,true)),(false,(7,true),(0,false)),(false,(3,true),(9,true))] s4_11521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11522 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6389,w6588]
theorem b4_11522 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11522 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(0,false)),(false,(3,true),(5,true))] s4_11522 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11523 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5848,w5956,w6300,w6389,w6588]
theorem b4_11523 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11523 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(3,true),(1,false))] s4_11523 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5848,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5848 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11524 : List (BitVec 512) := [w2352,w3766,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11524 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11524 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(5,true),(6,true)),(false,(2,true),(4,true)),(false,(3,true),(1,false))] s4_11524 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2352,v2_3766,v2_4716,v2_5135,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2352 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11527 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11527 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11527 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(0,false),(2,true))] s4_11527 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4583,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4583 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11528 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_11528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11528 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(0,false),(7,true))] s4_11528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_4800,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4800 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11529 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_11529 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11529 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(7,true))] s4_11529 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11530 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w6300,w6522,w6588]
theorem b4_11530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11530 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(7,true))] s4_11530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_4926,v2_5135,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11531 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_11531 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11531 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s4_11531 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11532 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w6300,w6522,w6588]
theorem b4_11532 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11532 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(6,true))] s4_11532 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5698,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11533 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_11533 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11533 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_11533 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11534 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w6300,w6522,w6588]
theorem b4_11534 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11534 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(6,true),(7,true))] s4_11534 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5769,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11535 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_11535 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11535 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(0,false))] s4_11535 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11536 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_11536 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11536 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(2,true)),(false,(7,true),(0,false))] s4_11536 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11537 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6690]
theorem b4_11537 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11537 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true))] s4_11537 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11538 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_11538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11538 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_11538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11539 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6300,w6522,w6588,w6690]
theorem b4_11539 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11539 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(8,true))] s4_11539 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6300,v2_6522,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11540 : List (BitVec 512) := [w2354,w2468,w3766,w4344,w4716,w5135,w5585,w6389,w6522,w6588]
theorem b4_11540 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11540 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(3,true)),(false,(2,true),(4,true))] s4_11540 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2468,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_6389,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2468 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11541 : List (BitVec 512) := [w2354,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_11541 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11541 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11541 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11542 : List (BitVec 512) := [w2354,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_11542 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11542 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(1,true)),(false,(3,true),(0,false))] s4_11542 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11543 : List (BitVec 512) := [w2354,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_11543 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11543 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11543 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6543,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6543 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11544 : List (BitVec 512) := [w2354,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11544 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11544 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(1,true)),(false,(0,false),(4,true))] s4_11544 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2488,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2488 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11545 : List (BitVec 512) := [w2354,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_11545 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11545 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(2,true),(6,true)),(false,(4,true),(0,false))] s4_11545 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11546 : List (BitVec 512) := [w2354,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_11546 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11546 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true))] s4_11546 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6422,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6422 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11547 : List (BitVec 512) := [w2354,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_11547 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11547 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true))] s4_11547 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6549,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6549 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11548 : List (BitVec 512) := [w2354,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_11548 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11548 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(3,true),(6,true)),(false,(0,false),(3,true))] s4_11548 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2491,v2_3766,v2_4344,v2_4716,v2_5135,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2491 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5135 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11549 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4584,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11549 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11549 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(3,true))] s4_11549 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4584,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4584 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11550 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5654,w5956,w6300,w6588]
theorem b4_11550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11550 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(7,true))] s4_11550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5654,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5654 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11551 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_11551 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11551 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(7,true))] s4_11551 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5698,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5698 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11552 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6031,w6300,w6588]
theorem b4_11552 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11552 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(0,true),(4,true))] s4_11552 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6031,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6031 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11553 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6061,w6300,w6588]
theorem b4_11553 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11553 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(3,true))] s4_11553 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6061,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6061 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11554 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_11554 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11554 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(7,true))] s4_11554 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6179,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6179 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11555 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6361,w6588]
theorem b4_11555 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11555 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(0,true),(5,true))] s4_11555 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6361,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6361 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11556 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_11556 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11556 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(3,true))] s4_11556 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6389,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6389 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11557 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_11557 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11557 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(7,true))] s4_11557 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6464,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6464 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11558 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6522,w6588]
theorem b4_11558 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11558 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(5,true))] s4_11558 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11559 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_11559 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11559 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(1,false))] s4_11559 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11560 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_11560 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11560 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(1,false))] s4_11560 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11561 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6857]
theorem b4_11561 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11561 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(1,false))] s4_11561 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6857] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6857 rfl))))))))))) (by decide +kernel)
def s4_11562 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6895]
theorem b4_11562 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11562 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(1,false))] s4_11562 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6895] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6895 rfl))))))))))) (by decide +kernel)
def s4_11563 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6690,w6720]
theorem b4_11563 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11563 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(3,true),(9,true))] s4_11563 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6690,v2_6720] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6690 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11564 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6720,w6873]
theorem b4_11564 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11564 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(7,true)),(false,(5,true),(0,true)),(false,(5,true),(9,true))] s4_11564 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6720,v2_6873] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6720 (PetersenWireProjection.cons pc2_6873 rfl))))))))))) (by decide +kernel)
def s4_11565 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588]
theorem b4_11565 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11565 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(5,true))] s4_11565 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11566 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w4716,w5393,w5585,w6300,w6522,w6588,w6720]
theorem b4_11566 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11566 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(5,true))] s4_11566 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_6300,v2_6522,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6522 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11567 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w5393,w5585,w5769,w5956,w6300,w6588,w6720]
theorem b4_11567 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11567 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(7,true),(8,true))] s4_11567 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11568 : List (BitVec 512) := [w2354,w2681,w3766,w4344,w5393,w5585,w5956,w6101,w6300,w6588,w6720]
theorem b4_11568 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11568 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(6,true)),(false,(5,true),(0,true)),(false,(4,true),(8,true))] s4_11568 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2681,v2_3766,v2_4344,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588,v2_6720] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2681 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6720 rfl))))))))))) (by decide +kernel)
def s4_11569 : List (BitVec 512) := [w2354,w2683,w3766,w4344,w4716,w4926,w5393,w5585,w5956,w6300,w6588]
theorem b4_11569 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11569 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11569 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2683,v2_3766,v2_4344,v2_4716,v2_4926,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_4926 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11570 : List (BitVec 512) := [w2354,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11570 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11570 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11570 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11571 : List (BitVec 512) := [w2354,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6690]
theorem b4_11571 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11571 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(1,true)),(false,(7,true),(0,false)),(false,(6,true),(0,true))] s4_11571 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6690] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6690 rfl))))))))))) (by decide +kernel)
def s4_11572 : List (BitVec 512) := [w2354,w2683,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6748]
theorem b4_11572 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11572 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(1,true)),(false,(0,false),(8,true)),(false,(6,true),(0,true))] s4_11572 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2683,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6748] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2683 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6748 rfl))))))))))) (by decide +kernel)
def s4_11573 : List (BitVec 512) := [w2354,w2686,w3766,w4344,w4716,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_11573 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11573 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(5,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11573 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5769,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5769 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11574 : List (BitVec 512) := [w2354,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11574 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11574 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11574 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11575 : List (BitVec 512) := [w2354,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6785]
theorem b4_11575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11575 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6785] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6785 rfl))))))))))) (by decide +kernel)
def s4_11576 : List (BitVec 512) := [w2354,w2686,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6813]
theorem b4_11576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11576 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(5,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2686,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6813] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2686 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6813 rfl))))))))))) (by decide +kernel)
def s4_11577 : List (BitVec 512) := [w2354,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_11577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11577 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(6,true),(2,true)),(false,(8,true),(0,false)),(false,(6,true),(0,true))] s4_11577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6101,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6101 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl))))))))))) (by decide +kernel)
def s4_11578 : List (BitVec 512) := [w2354,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588]
theorem b4_11578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11578 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 rfl)))))))))) (by decide +kernel)
def s4_11579 : List (BitVec 512) := [w2354,w2690,w3766,w4344,w4716,w5393,w5585,w5956,w6300,w6588,w6832]
theorem b4_11579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_11579 := by
  intro m le c
  apply rejects_sound r2 i8 12 tgt (small2 adj) hot2 [(false,(7,true),(2,true)),(false,(0,false),(7,true)),(false,(6,true),(0,true))] s4_11579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v2_2354,v2_2690,v2_3766,v2_4344,v2_4716,v2_5393,v2_5585,v2_5956,v2_6300,v2_6588,v2_6832] (PetersenWireProjection.cons pc2_2354 (PetersenWireProjection.cons pc2_2690 (PetersenWireProjection.cons pc2_3766 (PetersenWireProjection.cons pc2_4344 (PetersenWireProjection.cons pc2_4716 (PetersenWireProjection.cons pc2_5393 (PetersenWireProjection.cons pc2_5585 (PetersenWireProjection.cons pc2_5956 (PetersenWireProjection.cons pc2_6300 (PetersenWireProjection.cons pc2_6588 (PetersenWireProjection.cons pc2_6832 rfl))))))))))) (by decide +kernel)
end NineCert
