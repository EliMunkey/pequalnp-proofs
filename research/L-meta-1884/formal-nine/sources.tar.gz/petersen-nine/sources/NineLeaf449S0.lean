import NinePin449
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s3_4716 : List (BitVec 512) := [w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6464,w6499,w6588]
theorem b3_4716 (adj : NineExtra.Hard8) : Blocked tgt 11 s3_4716 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s3_4716 11 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_3766,v449_4344,v449_4716,v449_4926,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6464,v449_6499,v449_6588] (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_4926 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6464 (PetersenWireProjection.cons pc449_6499 (PetersenWireProjection.cons pc449_6588 rfl)))))))))))) (by decide +kernel)
def s4_5621 : List (BitVec 512) := [w1119,w1894,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_5621 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_5621 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_5621 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1119,v449_1894,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6588] (PetersenWireProjection.cons pc449_1119 (PetersenWireProjection.cons pc449_1894 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_7579 : List (BitVec 512) := [w1312,w1891,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_7579 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_7579 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_7579 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1312,v449_1891,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6588] (PetersenWireProjection.cons pc449_1312 (PetersenWireProjection.cons pc449_1891 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_8428 : List (BitVec 512) := [w1328,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_8428 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8428 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_8428 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1328,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6436,v449_6588] (PetersenWireProjection.cons pc449_1328 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6436 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_8477 : List (BitVec 512) := [w1328,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_8477 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8477 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_8477 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1328,v449_3766,v449_4716,v449_4926,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6389,v449_6588] (PetersenWireProjection.cons pc449_1328 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_4926 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6389 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_9765 : List (BitVec 512) := [w1403,w1875,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9765 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9765 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_9765 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1403,v449_1875,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6588] (PetersenWireProjection.cons pc449_1403 (PetersenWireProjection.cons pc449_1875 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10515 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_10515 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10515 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10515 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1415,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6436,v449_6588] (PetersenWireProjection.cons pc449_1415 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6436 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10578 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6389,w6422,w6588]
theorem b4_10578 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10578 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10578 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1415,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6389,v449_6422,v449_6588] (PetersenWireProjection.cons pc449_1415 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6389 (PetersenWireProjection.cons pc449_6422 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10590 : List (BitVec 512) := [w1415,w3766,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10590 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10590 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10590 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1415,v449_3766,v449_4716,v449_4926,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6389,v449_6588] (PetersenWireProjection.cons pc449_1415 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_4926 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6389 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10596 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10596 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10596 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10596 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1417,v449_3766,v449_4344,v449_4716,v449_4926,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6588] (PetersenWireProjection.cons pc449_1417 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_4926 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10600 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6389,w6588]
theorem b4_10600 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10600 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10600 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1417,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6389,v449_6588] (PetersenWireProjection.cons pc449_1417 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6389 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10601 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6422,w6588]
theorem b4_10601 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10601 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10601 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1417,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6422,v449_6588] (PetersenWireProjection.cons pc449_1417 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6422 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s4_10602 : List (BitVec 512) := [w1417,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6436,w6588]
theorem b4_10602 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10602 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s4_10602 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1417,v449_3766,v449_4344,v449_4716,v449_5135,v449_5393,v449_5585,v449_5956,v449_6300,v449_6436,v449_6588] (PetersenWireProjection.cons pc449_1417 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4344 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5585 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6436 (PetersenWireProjection.cons pc449_6588 rfl))))))))))) (by decide +kernel)
def s5_3085 : List (BitVec 512) := [w1403,w1875,w3766,w4716,w5135,w5393,w5698,w5956,w6300,w6588]
theorem b5_3085 (adj : NineExtra.Hard8) : Blocked tgt 9 s5_3085 := by
  intro m le c
  apply rejects_sound r449 i4 3 tgt (small449 adj) hot449 [] s5_3085 9 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v449_1403,v449_1875,v449_3766,v449_4716,v449_5135,v449_5393,v449_5698,v449_5956,v449_6300,v449_6588] (PetersenWireProjection.cons pc449_1403 (PetersenWireProjection.cons pc449_1875 (PetersenWireProjection.cons pc449_3766 (PetersenWireProjection.cons pc449_4716 (PetersenWireProjection.cons pc449_5135 (PetersenWireProjection.cons pc449_5393 (PetersenWireProjection.cons pc449_5698 (PetersenWireProjection.cons pc449_5956 (PetersenWireProjection.cons pc449_6300 (PetersenWireProjection.cons pc449_6588 rfl)))))))))) (by decide +kernel)
end NineCert
