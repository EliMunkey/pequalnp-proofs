import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_10389 : List (BitVec 512) := [w1415,w3335,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10389 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10389 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10389 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10390 : List (BitVec 512) := [w1415,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10390 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10390 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10390 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10391 : List (BitVec 512) := [w1415,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10391 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10392 : List (BitVec 512) := [w1415,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10392 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10393 : List (BitVec 512) := [w1415,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10393 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10394 : List (BitVec 512) := [w1415,w3582,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10394 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3582,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10395 : List (BitVec 512) := [w1415,w3582,w4344,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10395 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10396 : List (BitVec 512) := [w1415,w3582,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10396 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10397 : List (BitVec 512) := [w1415,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10397 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10398 : List (BitVec 512) := [w1415,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10398 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10399 : List (BitVec 512) := [w1415,w3651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10399 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false)),(false,(0,true),(9,true))] s4_10399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10400 : List (BitVec 512) := [w1415,w3665,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10400 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10400 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10400 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3665,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3665 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10401 : List (BitVec 512) := [w1415,w3666,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10401 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10401 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10401 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3666,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10402 : List (BitVec 512) := [w1415,w3666,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10402 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10402 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10402 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3666,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10403 : List (BitVec 512) := [w1415,w3666,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10403 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10403 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10403 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3666,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3666 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10404 : List (BitVec 512) := [w1415,w3689,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10404 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10404 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10404 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3689,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3689 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10405 : List (BitVec 512) := [w1415,w3693,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10405 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10405 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10405 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3693,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3693 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10406 : List (BitVec 512) := [w1415,w3766,w3861,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10406 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10406 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10406 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_3861,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3861 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10420 : List (BitVec 512) := [w1415,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10420 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10420 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10420 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10433 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10433 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10433 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10433 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10446 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5203,w5393,w5585,w5956,w6300,w6588]
theorem b4_10446 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10446 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10446 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5203,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5203 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10459 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5474,w5585,w5956,w6300,w6588]
theorem b4_10459 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10459 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10459 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5474,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5474 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10470 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5675,w5956,w6300,w6588]
theorem b4_10470 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10470 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10470 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5675,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10481 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5730,w5956,w6300,w6588]
theorem b4_10481 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10481 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10481 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5730,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5730 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10495 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6048,w6300,w6588]
theorem b4_10495 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10495 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10495 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6048,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6048 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10504 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6377,w6588]
theorem b4_10504 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10504 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10504 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6377,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10513 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6417,w6588]
theorem b4_10513 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10513 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false)),(false,(0,true),(9,true))] s4_10513 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6417,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6417 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10521 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6464,w6588]
theorem b4_10521 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10521 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10521 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10528 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6474,w6588]
theorem b4_10528 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10528 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10528 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6474,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6474 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10530 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6478,w6588]
theorem b4_10530 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10530 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10530 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10538 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6484,w6588]
theorem b4_10538 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10538 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10538 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6484,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6484 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10550 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6667]
theorem b4_10550 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10550 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10550 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588,v0_6667] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6667 rfl))))))))))) (by decide +kernel)
def s4_10575 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6389,w6588]
theorem b4_10575 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10575 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(0,true),(6,true)),(false,(5,true),(0,false)),(false,(0,true),(9,true))] s4_10575 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10576 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6464,w6588]
theorem b4_10576 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10576 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10576 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6464,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6464 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10577 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6377,w6478,w6588]
theorem b4_10577 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10577 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(6,true)),(false,(0,false),(1,true)),(false,(0,true),(9,true))] s4_10577 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6377,v0_6478,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6377 (PetersenWireProjection.cons pc0_6478 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10583 : List (BitVec 512) := [w1415,w3766,w4344,w4716,w5135,w5393,w5675,w5698,w5956,w6300,w6588]
theorem b4_10583 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10583 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10583 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5675,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5675 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10589 : List (BitVec 512) := [w1415,w3766,w4602,w4716,w5135,w5393,w5585,w5698,w5956,w6300,w6588]
theorem b4_10589 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10589 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(0,true)),(false,(7,true),(0,false)),(false,(0,true),(9,true))] s4_10589 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1415,v0_3766,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1415 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10616 : List (BitVec 512) := [w1706,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6588]
theorem b4_10616 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10616 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,true))] s4_10616 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6177,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6177 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10617 : List (BitVec 512) := [w1706,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10617 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10617 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_10617 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10618 : List (BitVec 512) := [w1706,w4344,w4716,w5135,w5393,w5585,w5956,w6177,w6300,w6588]
theorem b4_10618 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10618 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(7,true),(8,true)),(false,(1,true),(0,true))] s4_10618 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6177,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6177 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10619 : List (BitVec 512) := [w1706,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10619 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10619 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_10619 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1706,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1706 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))) (by decide +kernel)
def s4_10620 : List (BitVec 512) := [w1707,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6173,w6300,w6588]
theorem b4_10620 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10620 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(8,true)),(false,(1,true),(0,true))] s4_10620 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1707,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6173,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1707 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6173 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10621 : List (BitVec 512) := [w1707,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10621 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10621 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_10621 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1707,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1707 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10622 : List (BitVec 512) := [w1708,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6166,w6300,w6588]
theorem b4_10622 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10622 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(1,true),(7,true)),(false,(1,true),(0,true))] s4_10622 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1708,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6166,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1708 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6166 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10623 : List (BitVec 512) := [w1708,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10623 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10623 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [] s4_10623 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1708,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1708 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10652 : List (BitVec 512) := [w2195,w3766,w4344,w4716,w5135,w5471,w5585,w5769,w5956,w6300,w6588]
theorem b4_10652 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10652 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_10652 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10653 : List (BitVec 512) := [w2195,w3766,w4344,w4716,w5135,w5471,w5585,w5956,w6300,w6588]
theorem b4_10653 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10653 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(1,true)),(false,(0,true),(6,true)),(false,(0,true),(5,true))] s4_10653 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2195,v0_3766,v0_4344,v0_4716,v0_5135,v0_5471,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2195 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5471 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10654 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4583,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10654 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10654 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(0,true),(2,true))] s4_10654 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4583,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4583 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10655 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w4800,w5135,w5585,w5956,w6300,w6588]
theorem b4_10655 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10655 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(0,true),(3,true))] s4_10655 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_4800,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4800 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10656 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w4926,w5135,w5585,w5956,w6300,w6588]
theorem b4_10656 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10656 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(3,true))] s4_10656 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_4926,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4926 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10657 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5698,w5956,w6300,w6588]
theorem b4_10657 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10657 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(6,true))] s4_10657 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5698,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10658 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5769,w5956,w6300,w6588]
theorem b4_10658 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10658 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(6,true),(3,true))] s4_10658 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5769,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5769 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10659 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10659 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10659 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(1,false))] s4_10659 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10660 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_10660 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10660 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(1,false))] s4_10660 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10661 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588,w6720]
theorem b4_10661 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10661 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(5,true)),(false,(4,true),(0,true)),(false,(3,true),(9,true))] s4_10661 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588,v0_6720] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_10662 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6389,w6522,w6588]
theorem b4_10662 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10662 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(2,true),(8,true))] s4_10662 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6389,v0_6522,v0_6588] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10663 : List (BitVec 512) := [w2197,w2468,w3766,w4344,w4716,w5135,w5585,w5956,w6522,w6588,w6873]
theorem b4_10663 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10663 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(6,true)),(false,(4,true),(0,true)),(false,(9,true),(8,true))] s4_10663 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2197,v0_2468,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6522,v0_6588,v0_6873] (PetersenWireProjection.cons pc0_2197 (PetersenWireProjection.cons pc0_2468 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6522 (PetersenWireProjection.cons pc0_6588 (PetersenWireProjection.cons pc0_6873 rfl))))))))))) (by decide +kernel)
def s4_10664 : List (BitVec 512) := [w2201,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6061,w6300,w6588]
theorem b4_10664 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10664 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10664 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2201,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6061,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2201 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6061 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10665 : List (BitVec 512) := [w2201,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6389,w6588]
theorem b4_10665 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10665 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(0,true)),(false,(6,true),(0,false)),(false,(5,true),(0,true))] s4_10665 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2201,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6389,v0_6588] (PetersenWireProjection.cons pc0_2201 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6389 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10666 : List (BitVec 512) := [w2201,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6543,w6588]
theorem b4_10666 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10666 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10666 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2201,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6543,v0_6588] (PetersenWireProjection.cons pc0_2201 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6543 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10667 : List (BitVec 512) := [w2201,w2488,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6588]
theorem b4_10667 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10667 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(0,true)),(false,(0,false),(7,true)),(false,(5,true),(0,true))] s4_10667 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2201,v0_2488,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2201 (PetersenWireProjection.cons pc0_2488 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_10668 : List (BitVec 512) := [w2202,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6101,w6300,w6588]
theorem b4_10668 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10668 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(1,true)),(false,(7,true),(0,false)),(false,(5,true),(0,true))] s4_10668 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2202,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6101,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_2202 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6101 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10669 : List (BitVec 512) := [w2202,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6422,w6588]
theorem b4_10669 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10669 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10669 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2202,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6422,v0_6588] (PetersenWireProjection.cons pc0_2202 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6422 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_10670 : List (BitVec 512) := [w2202,w2491,w3766,w4344,w4716,w5135,w5585,w5956,w6300,w6549,w6588]
theorem b4_10670 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10670 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(6,true),(1,true)),(false,(0,false),(6,true)),(false,(5,true),(0,true))] s4_10670 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_2202,v0_2491,v0_3766,v0_4344,v0_4716,v0_5135,v0_5585,v0_5956,v0_6300,v0_6549,v0_6588] (PetersenWireProjection.cons pc0_2202 (PetersenWireProjection.cons pc0_2491 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6549 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
