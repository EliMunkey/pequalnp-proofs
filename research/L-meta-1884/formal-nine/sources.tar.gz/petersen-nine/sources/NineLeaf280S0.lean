import NinePin280
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_3790 : List (BitVec 512) := [w861,w3901,w4344,w4716,w5135,w5393,w5585,w5956,w6101,w6300,w6588]
theorem b4_3790 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_3790 := by
  intro m le c
  apply rejects_sound r280 i5 4 tgt (small280 adj) hot280 [] s4_3790 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v280_861,v280_3901,v280_4344,v280_4716,v280_5135,v280_5393,v280_5585,v280_5956,v280_6101,v280_6300,v280_6588] (PetersenWireProjection.cons pc280_861 (PetersenWireProjection.cons pc280_3901 (PetersenWireProjection.cons pc280_4344 (PetersenWireProjection.cons pc280_4716 (PetersenWireProjection.cons pc280_5135 (PetersenWireProjection.cons pc280_5393 (PetersenWireProjection.cons pc280_5585 (PetersenWireProjection.cons pc280_5956 (PetersenWireProjection.cons pc280_6101 (PetersenWireProjection.cons pc280_6300 (PetersenWireProjection.cons pc280_6588 rfl))))))))))) (by decide +kernel)
end NineCert
