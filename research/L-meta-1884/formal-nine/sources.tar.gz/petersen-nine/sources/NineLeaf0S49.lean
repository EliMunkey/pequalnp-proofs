import NinePin0
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_8925 : List (BitVec 512) := [w1374,w3335,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8925 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8925 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8925 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3335,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3335 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8926 : List (BitVec 512) := [w1374,w3360,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8926 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8926 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8926 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3360,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3360 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8927 : List (BitVec 512) := [w1374,w3360,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8927 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8927 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_8927 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3360,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3360 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8928 : List (BitVec 512) := [w1374,w3360,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8928 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8928 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8928 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3360,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3360 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_8929 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8929 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8929 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8929 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8930 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8930 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8930 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8930 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8931 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8931 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8931 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8931 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8932 : List (BitVec 512) := [w1374,w3411,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8932 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8932 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8932 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3411,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3411 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8933 : List (BitVec 512) := [w1374,w3436,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8933 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8933 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8933 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3436,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3436 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8934 : List (BitVec 512) := [w1374,w3545,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8934 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8934 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8934 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3545,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3545 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8935 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8935 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8935 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8935 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8936 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8936 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8936 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8936 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8937 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8937 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8937 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8937 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8938 : List (BitVec 512) := [w1374,w3567,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8938 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8938 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8938 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3567,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3567 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8939 : List (BitVec 512) := [w1374,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8939 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8939 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8939 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8940 : List (BitVec 512) := [w1374,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8940 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8940 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8940 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8941 : List (BitVec 512) := [w1374,w3572,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8941 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8941 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8941 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3572,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3572 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8942 : List (BitVec 512) := [w1374,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8942 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8942 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8942 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8943 : List (BitVec 512) := [w1374,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8943 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8943 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8943 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8944 : List (BitVec 512) := [w1374,w3577,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8944 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8944 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8944 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3577,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3577 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8945 : List (BitVec 512) := [w1374,w3582,w4344,w4716,w5135,w5393,w5698,w5956,w6179,w6300,w6588]
theorem b4_8945 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8945 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(6,true))] s4_8945 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3582,v0_4344,v0_4716,v0_5135,v0_5393,v0_5698,v0_5956,v0_6179,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3582 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5698 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8946 : List (BitVec 512) := [w1374,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8946 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8946 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8946 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8947 : List (BitVec 512) := [w1374,w3620,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8947 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8947 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8947 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8948 : List (BitVec 512) := [w1374,w3620,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8948 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8948 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8948 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3620,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3620 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8949 : List (BitVec 512) := [w1374,w3643,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8949 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8949 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8949 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8950 : List (BitVec 512) := [w1374,w3643,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8950 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8950 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8950 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8951 : List (BitVec 512) := [w1374,w3643,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8951 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8951 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8951 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3643,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3643 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8952 : List (BitVec 512) := [w1374,w3644,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8952 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3644,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8953 : List (BitVec 512) := [w1374,w3644,w4344,w4716,w5135,w5393,w5585,w5956,w6201,w6300,w6588]
theorem b4_8953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8953 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(1,false))] s4_8953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3644,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6201,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6201 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8954 : List (BitVec 512) := [w1374,w3644,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8954 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3644,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3644 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl)))))))))) (by decide +kernel)
def s4_8955 : List (BitVec 512) := [w1374,w3647,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8955 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3647,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3647 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8956 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8956 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8957 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8957 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8958 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8958 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8959 : List (BitVec 512) := [w1374,w3649,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8959 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3649,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3649 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8960 : List (BitVec 512) := [w1374,w3650,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8960 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true))] s4_8960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3650,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3650 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8961 : List (BitVec 512) := [w1374,w3651,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8961 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true))] s4_8961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3651,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3651 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8962 : List (BitVec 512) := [w1374,w3652,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8962 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true))] s4_8962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3652,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3652 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8963 : List (BitVec 512) := [w1374,w3685,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_8963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8963 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true))] s4_8963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3685,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3685 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_8964 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8964 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8965 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8965 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8966 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8966 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8967 : List (BitVec 512) := [w1374,w3699,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8967 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3699,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3699 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8968 : List (BitVec 512) := [w1374,w3731,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8968 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3731,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3731 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8969 : List (BitVec 512) := [w1374,w3738,w3766,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8969 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3738,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3738 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_8970 : List (BitVec 512) := [w1374,w3742,w3766,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8970 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3742,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3742 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8971 : List (BitVec 512) := [w1374,w3750,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8971 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3750,v0_3766,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3750 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8972 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_8972 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8972 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_8972 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_8973 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_8973 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8973 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_8973 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_8974 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_8974 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8974 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_8974 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_8975 : List (BitVec 512) := [w1374,w3766,w3845,w4344,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_8975 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_8975 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_8975 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_3845,v0_4344,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_3845 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_9021 : List (BitVec 512) := [w1374,w3766,w4344,w4403,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9021 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9021 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_9021 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4403,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4403 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9030 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9030 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9030 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_9030 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_9031 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9031 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9031 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9031 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_9032 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9032 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9032 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_9032 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_9033 : List (BitVec 512) := [w1374,w3766,w4344,w4602,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_9033 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9033 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_9033 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4602,v0_4716,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4602 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_9034 : List (BitVec 512) := [w1374,w3766,w4344,w4608,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9034 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9034 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(2,true))] s4_9034 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4608,v0_4716,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4608 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9057 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9057 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9057 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_9057 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4748,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4748 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9064 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9064 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9064 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(3,true),(9,true))] s4_9064 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6720] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6720 rfl))))))))))) (by decide +kernel)
def s4_9065 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9065 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9065 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(1,false),(9,true))] s4_9065 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6866] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6866 rfl))))))))))) (by decide +kernel)
def s4_9066 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5585,w6179,w6300,w6832]
theorem b4_9066 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9066 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(5,true),(4,true)),(false,(0,true),(8,true)),(false,(7,true),(9,true))] s4_9066 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5585,v0_6179,v0_6300,v0_6832] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6832 rfl))))))))))) (by decide +kernel)
def s4_9067 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4814,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_9067 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9067 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(6,true),(9,true))] s4_9067 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4814,v0_5135,v0_5393,v0_5956,v0_6179,v0_6300,v0_6785] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4814 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6179 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6785 rfl))))))))))) (by decide +kernel)
def s4_9068 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4819,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9068 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9068 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(0,true),(3,true))] s4_9068 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4819,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4819 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
def s4_9084 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4966,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9084 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9084 := by
  intro m le c
  apply rejects_sound r0 i8 12 tgt (small0 adj) hot0 [(false,(4,true),(5,true)),(false,(0,true),(8,true)),(false,(2,true),(3,true))] s4_9084 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v0_1374,v0_3766,v0_4344,v0_4716,v0_4966,v0_5135,v0_5393,v0_5585,v0_5956,v0_6300,v0_6588] (PetersenWireProjection.cons pc0_1374 (PetersenWireProjection.cons pc0_3766 (PetersenWireProjection.cons pc0_4344 (PetersenWireProjection.cons pc0_4716 (PetersenWireProjection.cons pc0_4966 (PetersenWireProjection.cons pc0_5135 (PetersenWireProjection.cons pc0_5393 (PetersenWireProjection.cons pc0_5585 (PetersenWireProjection.cons pc0_5956 (PetersenWireProjection.cons pc0_6300 (PetersenWireProjection.cons pc0_6588 rfl))))))))))) (by decide +kernel)
end NineCert
