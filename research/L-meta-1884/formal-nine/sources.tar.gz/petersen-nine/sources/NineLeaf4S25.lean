import NinePin4
open PetersenWordCost PetersenPackedPin PetersenLayerCheck
namespace NineCert
set_option maxHeartbeats 0
set_option maxRecDepth 300000
def s4_9052 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w5135,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_9052 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9052 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9052 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9053 : List (BitVec 512) := [w1374,w3766,w4344,w4684,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9053 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9053 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9053 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4684,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4684 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_9054 : List (BitVec 512) := [w1374,w3766,w4344,w4704,w4716,w5135,w5393,w5956,w6179,w6300,w6785]
theorem b4_9054 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9054 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(8,true),(6,true))] s4_9054 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4704,v4_4716,v4_5135,v4_5393,v4_5956,v4_6179,v4_6300,v4_6785] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4704 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6785 rfl))))))))))) (by decide +kernel)
def s4_9055 : List (BitVec 512) := [w1374,w3766,w4344,w4709,w4716,w5135,w5393,w5585,w5956,w6300,w6866]
theorem b4_9055 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9055 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9055 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4709,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6866] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4709 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6866 rfl))))))))))) (by decide +kernel)
def s4_9058 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9058 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9058 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9058 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9077 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9077 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9077 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9077 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9158 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_9158 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9158 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9158 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9177 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6610]
theorem b4_9177 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9177 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9177 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl))))))))))) (by decide +kernel)
def s4_9194 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b4_9194 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9194 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9194 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9225 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610]
theorem b4_9225 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9225 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9225 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 rfl)))))))))) (by decide +kernel)
def s4_9226 : List (BitVec 512) := [w1374,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6610,w6720]
theorem b4_9226 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9226 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9226 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1374,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6610,v4_6720] (PetersenWireProjection.cons pc4_1374 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6610 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9391 : List (BitVec 512) := [w1384,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9391 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9391 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9391 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9392 : List (BitVec 512) := [w1384,w3766,w4344,w4654,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9392 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9392 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(6,true)),(false,(8,true),(0,false)),(false,(0,true),(6,true))] s4_9392 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4654,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9393 : List (BitVec 512) := [w1384,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9393 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9393 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9393 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9394 : List (BitVec 512) := [w1384,w3766,w4344,w4666,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9394 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9394 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9394 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4666,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4666 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9395 : List (BitVec 512) := [w1384,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9395 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9395 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(3,true),(0,false)),(false,(0,true),(6,true))] s4_9395 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9396 : List (BitVec 512) := [w1384,w3766,w4344,w4668,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9396 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9396 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9396 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4668,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4668 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9397 : List (BitVec 512) := [w1384,w3766,w4344,w4669,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9397 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9397 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9397 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4669,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4669 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9398 : List (BitVec 512) := [w1384,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9398 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9398 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9398 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9399 : List (BitVec 512) := [w1384,w3766,w4344,w4683,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9399 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9399 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(7,true)),(false,(0,false),(7,true)),(false,(0,true),(6,true))] s4_9399 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1384,v4_3766,v4_4344,v4_4683,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1384 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4683 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9608 : List (BitVec 512) := [w1388,w2837,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9608 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9608 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9608 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_2837,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_2837 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9639 : List (BitVec 512) := [w1388,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9639 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9639 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9639 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9640 : List (BitVec 512) := [w1388,w3766,w4344,w4646,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_9640 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9640 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9640 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9641 : List (BitVec 512) := [w1388,w3766,w4344,w4646,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9641 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9641 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9641 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9642 : List (BitVec 512) := [w1388,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9642 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9642 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9642 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9643 : List (BitVec 512) := [w1388,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9643 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9643 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9643 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9644 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w4748,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9644 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9644 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9644 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_4748,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4748 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9646 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w4926,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9646 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9646 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9646 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_4926,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4926 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9672 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6720]
theorem b4_9672 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9672 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9672 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9687 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6588]
theorem b4_9687 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9687 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9687 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9688 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6179,w6300,w6720]
theorem b4_9688 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9688 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9688 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6179,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6179 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9692 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6181,w6300,w6588]
theorem b4_9692 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9692 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(0,true),(5,true))] s4_9692 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6181,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6181 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9697 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6225,w6300,w6720]
theorem b4_9697 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9697 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9697 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6225,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6225 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9710 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_9710 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9710 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9710 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_9716 : List (BitVec 512) := [w1388,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_9716 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9716 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(7,true)),(false,(5,true),(0,true))] s4_9716 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1388,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1388 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_9833 : List (BitVec 512) := [w1403,w2588,w3766,w4344,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9833 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9833 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_9833 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_2588,v4_3766,v4_4344,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_2588 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9952 : List (BitVec 512) := [w1403,w3766,w4344,w4636,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9952 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9952 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_9952 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4636,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4636 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9953 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9953 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9953 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9953 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6890] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_9954 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9954 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9954 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9954 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9955 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5135,w5393,w5769,w5956,w6300,w6588]
theorem b4_9955 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9955 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_9955 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9956 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9956 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9956 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_9956 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9957 : List (BitVec 512) := [w1403,w3766,w4344,w4646,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_9957 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9957 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_9957 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4646,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9958 : List (BitVec 512) := [w1403,w3766,w4344,w4648,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9958 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9958 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_9958 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4648,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4648 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9959 : List (BitVec 512) := [w1403,w3766,w4344,w4659,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9959 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9959 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9959 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4659,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4659 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9960 : List (BitVec 512) := [w1403,w3766,w4344,w4667,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9960 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9960 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_9960 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4667,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4667 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9961 : List (BitVec 512) := [w1403,w3766,w4344,w4671,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9961 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9961 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9961 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4671,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4671 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9962 : List (BitVec 512) := [w1403,w3766,w4344,w4673,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_9962 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9962 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true))] s4_9962 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4673,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4673 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9963 : List (BitVec 512) := [w1403,w3766,w4344,w4674,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9963 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9963 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9963 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4674,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4674 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9964 : List (BitVec 512) := [w1403,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9964 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9964 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9964 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9965 : List (BitVec 512) := [w1403,w3766,w4344,w4678,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9965 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9965 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_9965 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4678,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9966 : List (BitVec 512) := [w1403,w3766,w4344,w4682,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9966 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9966 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9966 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4682,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6890] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_9967 : List (BitVec 512) := [w1403,w3766,w4344,w4682,w4716,w5135,w5393,w5585,w5956,w6522,w6588]
theorem b4_9967 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9967 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(3,true),(2,true)),(false,(0,true),(5,true)),(false,(5,true),(9,true))] s4_9967 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4682,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6522,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6522 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9968 : List (BitVec 512) := [w1403,w3766,w4344,w4682,w4716,w5187,w5393,w5585,w5956,w6300,w6588]
theorem b4_9968 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9968 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(0,true),(2,true))] s4_9968 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4682,v4_4716,v4_5187,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4682 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5187 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_9969 : List (BitVec 512) := [w1403,w3766,w4344,w4703,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9969 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9969 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,false),(4,true)),(false,(6,true),(0,true))] s4_9969 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4703,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6890] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4703 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_9970 : List (BitVec 512) := [w1403,w3766,w4344,w4712,w4716,w5135,w5393,w5585,w5956,w6300,w6690]
theorem b4_9970 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9970 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(4,true)),(false,(0,false),(4,true)),(false,(6,true),(0,true))] s4_9970 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4712,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6690] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4712 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6690 rfl))))))))))) (by decide +kernel)
def s4_9971 : List (BitVec 512) := [w1403,w3766,w4344,w4712,w4716,w5135,w5393,w5585,w5956,w6300,w6890]
theorem b4_9971 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_9971 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(0,true),(5,true)),(false,(1,false),(6,true))] s4_9971 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1403,v4_3766,v4_4344,v4_4712,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6890] (PetersenWireProjection.cons pc4_1403 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4712 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6890 rfl))))))))))) (by decide +kernel)
def s4_10280 : List (BitVec 512) := [w1411,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10280 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10280 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10280 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10281 : List (BitVec 512) := [w1411,w3766,w4344,w4678,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10281 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10281 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10281 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4678,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4678 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10282 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w4750,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10282 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10282 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10282 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4716,v4_4750,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_4750 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10302 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5769,w5956,w6300,w6588]
theorem b4_10302 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10302 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10302 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5769,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5769 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10320 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6588,w6720]
theorem b4_10320 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10320 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10320 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588,v4_6720] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 (PetersenWireProjection.cons pc4_6720 rfl))))))))))) (by decide +kernel)
def s4_10328 : List (BitVec 512) := [w1411,w3766,w4344,w4716,w5135,w5393,w5585,w5956,w6300,w6720]
theorem b4_10328 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10328 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(2,true),(3,true)),(false,(5,true),(0,true))] s4_10328 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1411,v4_3766,v4_4344,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6720] (PetersenWireProjection.cons pc4_1411 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6720 rfl)))))))))) (by decide +kernel)
def s4_10423 : List (BitVec 512) := [w1415,w3766,w4344,w4646,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10423 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10423 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(3,true)),(false,(0,false),(3,true)),(false,(0,true),(6,true))] s4_10423 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4646,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4646 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
def s4_10424 : List (BitVec 512) := [w1415,w3766,w4344,w4654,w4716,w5135,w5393,w5585,w5956,w6300,w6588]
theorem b4_10424 (adj : NineExtra.Hard8) : Blocked tgt 10 s4_10424 := by
  intro m le c
  apply rejects_sound r4 i8 11 tgt (small4 adj) hot4 [(false,(6,true),(2,true)),(false,(4,true),(0,false)),(false,(0,true),(6,true))] s4_10424 10 _ le
  exact PetersenWireProjection.reuse _ _ _ _ _ _ [v4_1415,v4_3766,v4_4344,v4_4654,v4_4716,v4_5135,v4_5393,v4_5585,v4_5956,v4_6300,v4_6588] (PetersenWireProjection.cons pc4_1415 (PetersenWireProjection.cons pc4_3766 (PetersenWireProjection.cons pc4_4344 (PetersenWireProjection.cons pc4_4654 (PetersenWireProjection.cons pc4_4716 (PetersenWireProjection.cons pc4_5135 (PetersenWireProjection.cons pc4_5393 (PetersenWireProjection.cons pc4_5585 (PetersenWireProjection.cons pc4_5956 (PetersenWireProjection.cons pc4_6300 (PetersenWireProjection.cons pc4_6588 rfl))))))))))) (by decide +kernel)
end NineCert
